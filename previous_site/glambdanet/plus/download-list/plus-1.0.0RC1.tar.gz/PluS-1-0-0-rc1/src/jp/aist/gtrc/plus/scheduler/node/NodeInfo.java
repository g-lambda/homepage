/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;


import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveInfo;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;


public class NodeInfo {

	private NodeStatus status;
	private NodeResource resource;
	private Map<ReserveId, ReserveInfo> rsvInfos;
	private int lauchProcNum;
	private static final int DEFAULT_LAUNCE_PROC_NUM = 1;

	public NodeInfo(NodeStatus status){
		
		update(status);
		this.rsvInfos = new HashMap<ReserveId, ReserveInfo>();

	}

	public void update(NodeStatus status){
		
		assert(status != null);
		boolean updateRsc = ((this.status == null) || (!this.status.isAlive() && status.isAlive()));
		
		this.status = status;
		if (updateRsc) {
			// update at first time or when node is starting up now
			this.resource = new NodeResource(status);
		}
		setLaunceProcessNum(DEFAULT_LAUNCE_PROC_NUM);

	}

	public void addReserveInfo(ReserveInfo info){

		/*
		 * NOTE: ReserveId#equals() returns true if id are same
		 * even if ReserveId objects are different.
		 * Map#containsKey() uses ReserveId#equals() for check,
		 * so it works well.
		 */
		ReserveId id = info.getReserveId();
		if (rsvInfos.containsKey(id) == false)
			rsvInfos.put(id, info);
		else
			assert(false);

	}

	public void removeReserveInfo(ReserveInfo info){

		ReserveId id = info.getReserveId();
		if (rsvInfos.containsKey(id) == true) {
			rsvInfos.remove(id);
		}

	}

	public boolean isFree(Calendar start, Calendar end){

		for (ReserveInfo info : rsvInfos.values()) {
			if (info.isOverlap(start, end))
				return false;
		}
		
		return true;
		
	}
	
	public boolean isReservedNow() {
		
		Calendar now = Calendar.getInstance();
		return (isFree(now, now) == false);
		
	}
	
	public NodeStatus getStatus() {
		
		return status;
		
	}

	public NodeResource getResource() {
		
		return resource;
		
	}
	
	public void setLaunceProcessNum(int procNum) {
		
		this.lauchProcNum = procNum;
		
	}
	
	public int getLaunchProcessNum() { 
		
		return lauchProcNum;
		
	}
	
	public String toString() {
		
		String s = String.format(Locale.US, "status=%s, resource=%s, launchProcNum=%d, ",
				status.toString(), resource.toString(), lauchProcNum);
		s += "reserve=";
		for (ReserveInfo r : rsvInfos.values()) {
			s += r.toString() + "\n";
		}
		return s;
		
	}
	
}