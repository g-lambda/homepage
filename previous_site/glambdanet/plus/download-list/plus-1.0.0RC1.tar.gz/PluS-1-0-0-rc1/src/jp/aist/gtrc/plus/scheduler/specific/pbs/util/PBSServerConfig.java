/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;


public class PBSServerConfig {

	// config of pbs_server
	private String pbsSrvName;
	private int pbsSrvPort;
	
	// config of this java scheduler
	private String schedSrvName;
	private int schedPort;
	
	// config of authenticate server for RMI.
	// see PBSScheduler#startAuthenticateServer()
	private String authSrvName;
	private int authPort;
	
	/*
	 * PBS_SERVER_PORT, SCHDULER_PORT are default port of Torque
	 */
	public static final int DEFAULT_PBS_SERVER_PORT = 15001;
	public static final int DEFAULT_SCHEDULER_PORT = 15004;
	
	/*
	 * AUTHENTICATE_PORT is a default port for our scheduler.
	 * It's not used by original Torque.
	 */
	public static final int DEFAULT_AUTHENTICATE_PORT = 15005;
	
	public PBSServerConfig() {
		
		this.pbsSrvName = System.getenv("HOSTNAME");
		if (this.pbsSrvName == null)
			this.pbsSrvName = "localhost";
		this.schedSrvName = this.pbsSrvName;
		this.pbsSrvPort = DEFAULT_PBS_SERVER_PORT;
		this.schedPort = DEFAULT_SCHEDULER_PORT;
		this.authSrvName = this.pbsSrvName;
		this.authPort = DEFAULT_AUTHENTICATE_PORT;
		
	}
	
	public PBSServerConfig(PBSSchedulerOptions options) throws PBSException {
		
		this();
		this.schedPort = options.getSchedPort();
		
	}
	
	public String getPBSServerName() {

		return pbsSrvName;
		
	}
	
	public int getPBSServerPort() {
		
		return pbsSrvPort;
		
	}
	
	public String getSchedulerServerName() {

		return schedSrvName;
		
	}
	
	public int getSchedulerPort() {
		
		return schedPort;
		
	}
	
	public String getAuthenticateServerName() {
		
		return authSrvName;
		
	}

	public int getAuthenticateServerPort() {
		
		return authPort;
		
	}
}