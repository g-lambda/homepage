/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import java.util.HashMap;
import java.util.Map;

public enum PBSSchedulerCommandType {
	
	ERROR(-1),
	NULL(0),
	NEW(1),
	TERM(2),
	TIME(3),
	RECYC(4),
	CMD(5),
	CONFIGURE(7),
	QUIT(8),
	RULESET(9),
	FIRST(10),
	RESERVE(20);
	
	private final int value;

	private static Map<Integer, PBSSchedulerCommandType> map
		= new HashMap<Integer, PBSSchedulerCommandType>();
	static {
		for (PBSSchedulerCommandType t : PBSSchedulerCommandType.values()) {
			map.put(t.value, t);
		}
	}

	PBSSchedulerCommandType(int value){
		this.value = value;
	}
	
	public int value(){

		return value;

	}

	public static PBSSchedulerCommandType getType(int value){
		
		PBSSchedulerCommandType type = map.get(value);
		if (type != null)
			return type;
		else
			return ERROR;
		
	}
	
	public boolean mustRunSchedule(){

		switch(this){
		case ERROR:
		case NULL:
		case CONFIGURE:
		case RULESET:
		case QUIT:		// quit scheduler (NEVER SENDED FROM TORQUE!)
			return false;
		case NEW:		// New job was submitted
		case TERM:		// A job was terminated, Run next job
		case TIME:		// pbs_server or ScheduleStarter periodically calls
		case RECYC:		// A RunJob was done, check next
		case CMD:		// pbs_server was enabled to schedule
		case FIRST:		// pbs_server is started
		case RESERVE:	// ReserveManager kicks scheduler
			return true;
		default:
			assert(false);
			return false;
		}
		
	}

	public String toString(){
		
		return this.name() + "(" + this.value + ")";
		
	}

}