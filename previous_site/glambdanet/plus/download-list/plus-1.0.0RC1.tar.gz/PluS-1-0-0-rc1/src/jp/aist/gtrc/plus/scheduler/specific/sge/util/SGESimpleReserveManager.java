/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.util;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.reserve.*;
import jp.aist.gtrc.plus.reserve.ReserveStatus.State;
import static jp.aist.gtrc.plus.reserve.ReserveStatus.State.*;
import jp.aist.gtrc.plus.scheduler.ScheduleStarter;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.specific.sge.mainsrv.SGESimpleMainServer;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGESimpleQInstance;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGESimpleQueueStatus;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGESimpleReserveInfo;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGESimpleStatusManager;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.util.PluSUtil;


public class SGESimpleReserveManager extends ReserveManager {

	transient private SGESimpleMainServer mainServer;
	transient private SGESimpleStatusManager statusMgr;
	
	private static final String POSTFIX_PREQ = "pre";
	private static final String POSTFIX_POSTQ = "post";
	
	enum Phase {
		ActivatePre(0), DelPreActMain(1), ActivateMain(2),
		DelMainActPost(3), DeletePost(4), DeleteMain(5), DeleteAll(6), DeleteSuper(7);
		
		private int phase;
		Phase(int phase) {
			this.phase = phase;
		}
		int getPhase() {
			return phase;
		}
	}
		
	public SGESimpleReserveManager(NodeManager nodeMgr, ScheduleStarter starter,
			ReserveRecorder recorder, NodeAllocator nodeAllocator,
			SGESimpleStatusManager statusMgr, int maxExpired) throws ReserveException {
		
		super(nodeMgr, starter, recorder, nodeAllocator, maxExpired);
		this.statusMgr = statusMgr;
		this.mainServer = SGESimpleMainServer.getInstance();
		
	}
	
	protected ReserveInfo newReserveInfo(ReserveId rsvId, ReserveRequest rsvReq,
			ReserveNodeSet rsvNodeSet) throws ReserveException {
		
		return new SGESimpleReserveInfo(rsvId, rsvReq, rsvNodeSet, this);
		
	}
	
	protected void addNewReserveInfo(ReserveInfo rsvInfo) throws ReserveException {
		
		super.addNewReserveInfo(rsvInfo);
		
		SGESimpleReserveInfo info = (SGESimpleReserveInfo)rsvInfo;

		ReserveRequest req = rsvInfo.getReserveRequest();
		int slotnum = req.getSlotNum();
		String slotnumList;
		if (slotnum > 0) {
			slotnumList = Integer.toString(slotnum);
		} else {
			slotnumList = info.getSlotNumList();
		}
		
		/*
		 *  usage: sge_rsvq_new.sh RSVID SLOTPERNODE USERLIST PE PREPOSTQ
		 */
		PluSUtil.runCommand(new String[] {
				"sge_rsvq_new.sh",
				info.getReserveId().toString(),
				slotnumList,
				info.getUserNames(),
				statusMgr.getPeNames(),
				Boolean.toString(rsvInfo.isMakePrePostQueue())
		});
		
	}
	
	private void scheduleWhenIdle() throws ReserveException {
		
		Calendar now = Calendar.getInstance();
		ReserveTable table = getReserveTable();
		
		/*
		 * Schedule Reserve queue
		 */
		Collection<ReserveInfo> allRsvs = new LinkedList<ReserveInfo>(table.getAllById());
		for (ReserveInfo info : allRsvs) {
			State state = info.getReserveState();
			if (info.isExpired(now) || (state == Canceled)) {
				stopReservePeriodWithoutStatusUpdate(info);		// 'info' may be removed
			}
		}
		Collection<ReserveInfo> expires = getExpiredReserve(now);
		for (ReserveInfo info : table.getAllById()) {
			if (info.isOverlap(now, now)) {
				startReservePeriod(info, expires);
			}
		}

		/*
		 * Schedule normal queue
		 */
		for (QueueStatus q : statusMgr.getQueues()) {
			String qname = q.getName(); 
			if (qname.startsWith(ReserveId.RSVID_PREFIX)) {
				continue;
			}

			SGESimpleQueueStatus queue = (SGESimpleQueueStatus)q;
			NodeManager nodeMgr = getNodeManager();
			// resume/suspend normal queue if needed
			for (SGESimpleQInstance qins : queue.getAllQInstances()) {
				String nodeName =  qins.getQHostName();
				NodeInfo node = nodeMgr.getNode(nodeName);
				if (node == null) {
					assert(false);
					continue;
				}
				String option;
				if (node.isFree(now, now)) {
					if (qins.isRunning()) {
						continue;
					}
					option = "-usq";
				} else {
					if (qins.isSuspended()) {
						continue;
					}
					option = "-sq";
				}
				try {
					PluSUtil.runCommand(new String[]{"qmod", option, qins.getFullName()});
				} catch (ReserveException e) {
					// ignore to continue
				}
			}
			
		}
		
	}
	
	private boolean waitingTooLong(ReserveOperation ope, ReserveInfo target) {
		
		Calendar opStart = ope.getOperationStartTime();
		Calendar now = Calendar.getInstance();
		Calendar rsvStart = target.getStartTime();
		final long WAIT_MAX_MS = 3 * 60 * 1000; // 3 min
		
		if ((now.getTimeInMillis() - opStart.getTimeInMillis()) >= WAIT_MAX_MS) {
			return true;
		}
		
		if (opStart.before(rsvStart)) {
			return (now.after(rsvStart));
		} else {
			Calendar rsvEnd = target.getEndTime();
			return (now.after(rsvEnd));
		}
		
	}
	private void scheduleWaitingCommitAbort() throws ReserveException {
		
		ReserveOperation ope = getCurrentOperation();
		ReserveInfo info = ope.getTargetReserveInfo();
		assert(info != null);
		if (waitingTooLong(ope, info) == false) {
			return;
		}
		
		if (ope.isAbortable()) {
			abort(info.getReserveId());
		} else {
			// To cancel running reserve is not abortable
			// because some jobs has already killed... 
			commit(info.getReserveId());
		}
		
	}
	
	public synchronized void schedule() throws ReserveException {
		
		if (getCurrentOperation().getOperationType() == ReserveOperationType.idle) { 
			scheduleWhenIdle();
		} else {
			scheduleWaitingCommitAbort();
		}
		
	}

	private String getMainQName(ReserveInfo info) {
		return info.getReserveId().toString();
	}
	
	private String getPreQName(ReserveInfo info) {
		return getMainQName(info) + POSTFIX_PREQ;
	}

	private String getPostQName(ReserveInfo info) {
		return getMainQName(info) + POSTFIX_POSTQ;
	}
	
	private SGESimpleQueueStatus getQueue(String qName) {
		return (SGESimpleQueueStatus)statusMgr.getQueue(qName);
	}
	
	private boolean hasJobToRun(SGESimpleQueueStatus queue)  {
		
		try {
			return ((queue.hasRunningJobs() == true) ||
				(mainServer.getPendingJobNum(queue) > 0));
		} catch (SchedulerException e) {
			return false;
		}
		
	}

	private boolean isPreviousPostQRemain(ReserveInfo info, 
			Collection<ReserveInfo> expires) {
		
		ReserveNodeSet tgtNodes = info.getReserveNodeSet();
		String tgtNames[] = tgtNodes.getNames();
		
		for (ReserveInfo rsv : expires) {
			SGESimpleQueueStatus queue = getQueue(getPostQName(rsv));
			if (queue == null) {
				continue;
			}
			for (SGESimpleQInstance qins : queue.getAllQInstances()) {
				String qInsHostName = qins.getQHostName();
				for (String hostname : tgtNames) {
					if (hostname.equals(qInsHostName)) {
						return true;
					}
				}
			}
		}
		return false;
		
	}
	
	private Phase getStartPhase(ReserveInfo info, Collection<ReserveInfo> expires) {
		
		switch (info.getReserveState()) {
		case Confirmed:
		case Running:
			// Start this reserve if needed
			break;
		case Done:
		case Canceled:
		case Destroying:
		case Error:
			// DO NOT start this reserve
			return null;
		default:
			assert(false);
			return null;
		}

		if (isPreviousPostQRemain(info, expires)) {
			// We cannot start reserve of 'info'
			// until previous postQ will be gone...
			return null;
		}

		SGESimpleQueueStatus mainQ = getQueue(getMainQName(info));

		if (info.isMakePrePostQueue()) {
			SGESimpleQueueStatus preQ = getQueue(getPreQName(info));
			if (preQ != null) {
				if (hasJobToRun(preQ)) {
					if (preQ.isSuspended()) {
						// pre queue is suspended, activate now top run pre job!
						return Phase.ActivatePre;
					} else {
						// pre job is running (or wait to run), nothing to do
						return null;
					}
				} else {
					if (hasJobToRun(mainQ)) {
						// pre job is finished, delete preQ and resume mainQ now!
						return Phase.DelPreActMain;
					} else {
						// pre and main job is empty. Wait job submition to pre/mainQ.
						return null;
					}
				}
			}
		}
		
		if ((mainQ != null) && mainQ.isSuspended()) {
			return Phase.ActivateMain;
		} else {
			return null;
		}
		
	}

	private void runScript(String script, ReserveInfo info, Phase phase) throws ReserveException {
		
		assert(phase != null);
		PluSUtil.runCommand(new String[]{
				script, 
				info.getReserveId().toString(),
				Integer.toString(phase.getPhase())});
		
		
	}
	
	private void runStartScript(ReserveInfo info, Phase phase) throws ReserveException {

		runScript("sge_rsvq_start_rsv.sh", info, phase);
		
	}
	
	private void runDeleteScript(ReserveInfo info, Phase phase) throws ReserveException {

		runScript("sge_rsvq_del.sh", info, phase);
		
	}
	

	private void startReservePeriod(ReserveInfo info, Collection<ReserveInfo> expires)
		throws ReserveException {
		
		Phase phase = getStartPhase(info, expires);
		if (phase == null)
			return;
		
		switch (phase) {
		case ActivatePre:
		case DelPreActMain:
		case ActivateMain:
			runStartScript(info, phase);
			break;
		default:
			assert(false);
			break;
		}
		
	}

	private Phase getStopPhase(ReserveInfo info) {
		
		if (info.isMakePrePostQueue()) {
			SGESimpleQueueStatus preQ = getQueue(getPreQName(info));
			if (preQ != null) {
				if (preQ.isSuspended()) {
					// pre has not started, delete all queue now
					return Phase.DeleteAll;
				} else if (hasJobToRun(preQ)) {
					// pre job is running now, wait it finish.
					return null;
				} else {
					// pre has already finished, handle main or post queue
				}
			}

			SGESimpleQueueStatus postQ = getQueue(getPostQName(info));
			if (postQ != null) {
				if (hasJobToRun(postQ)) {
					if (postQ.isSuspended()) {
						// post queue is suspended, disable mainQ and resume postQ
						return Phase.DelMainActPost;
					} else {
						// post job is running (or wait to run), nothing to do
						return null;
					}
				} else {
					// post job is finished or post job doesn't exist, delete all!
					return Phase.DeleteAll;
				}
			} else {
				// post queue is already deleted, mainQ is already deleted
				// call super.remove() to remove from DB
				return Phase.DeleteSuper;
			}
		} else {
			SGESimpleQueueStatus mainQ = getQueue(getMainQName(info));
			return (mainQ != null) ? Phase.DeleteMain : Phase.DeleteSuper;
		}
		
	}

	private void stopReservePeriod(ReserveInfo info) throws ReserveException {
		
		try {
			statusMgr.updateStatus(SGESimpleMainServer.getInstance());
		} catch (SchedulerException e) {
			throw new ReserveException(e.getMessage());
		}
		
		stopReservePeriodWithoutStatusUpdate(info);
		
	}
	
	private void stopReservePeriodWithoutStatusUpdate(ReserveInfo info) throws ReserveException {
		
		Phase phase = getStopPhase(info);
		if (phase == null)
			return;
		
		switch (phase) {
		case DelMainActPost:
			runDeleteScript(info, phase);
			break;
		case DeletePost:
		case DeleteMain:
		case DeleteAll:
			super.removeReserveInfo(info, false);
			runDeleteScript(info, phase);
			break;
		case DeleteSuper:
			// pre/main/postQ is already deleted, delete from super class
			super.removeReserveInfo(info, false);
			break;
		default:
			assert(false);
			break;
		}
		
	}
	
	protected void removeReserveInfo(ReserveInfo info, boolean forceRemove)  throws ReserveException {
		
		if (forceRemove) {
			Phase phase = info.isMakePrePostQueue() ? Phase.DeleteAll : Phase.DeleteMain;
			runDeleteScript(info, phase);
			super.removeReserveInfo(info, forceRemove);
		} else {
			stopReservePeriod(info);
		}
		
	}
	
}
