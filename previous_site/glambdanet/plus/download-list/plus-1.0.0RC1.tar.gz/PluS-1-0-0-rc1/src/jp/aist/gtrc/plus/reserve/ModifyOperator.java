/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;

class ModifyOperator extends ReserveUpdateOperator {
	
	ModifyOperator(ReserveManager rsvMgr, ReserveNodeNormalizer normalizer,
			CommitOperator commiter, AbortOperator aborter) {
		
		super(rsvMgr, normalizer, commiter, aborter);
		
	}
	
	private boolean isOKtoChangeEndTime(ReserveInfo info, Calendar newEnd) {
		
		Calendar oldEnd = info.getEndTime();
		if (newEnd.after(oldEnd) == false) {
			// start < newEnd <= oldEnd
			// always enable change end time
			return true;
		}
		
		ReserveNodeSet nodeSet = info.getReserveNodeSet();
		for (NodeInfo node : nodeSet.getAll()) {
			if (node.isFree(oldEnd, newEnd) == false) {
				// cannot expand reserve period
				return false;
			}
		}
		return true;
		
	}

	private void checkModifyEnable(ReserveInfo info, ReserveRequest newReq) throws ReserveException {
		
		ReserveStatus status = info.getReserveStatus();
		switch (status.getReserveState()) {
		case Confirmed:
			// can change startTime, endTime, nodeNum
			break;
		case Running:
			ReserveRequest oldReq = info.getReserveRequest();
			Calendar oldStart = oldReq.getStartTime();
			Calendar newStart = newReq.getStartTime();
			// can change endTime.
			// cannot change startTime, nodeNum
			if (oldStart.equals(newStart) == false) {
				throw new ReserveException("cannot modify startTime because it's running now");
			}
			if (oldReq.getNodeNum() != newReq.getNodeNum()) {
				throw new ReserveException("cannot modify number of nodes because it's running now");
			}
			if ((oldReq.getEndTime().equals(newReq.getEndTime()) == false) &&
				(isOKtoChangeEndTime(info, newReq.getEndTime()) == false)) {
				throw new ReserveException("cannot expand reserve period"); 
			}
			break;
		case Done:
			throw new ReserveException("cannot modify because it's done");
		case Canceled:
			throw new ReserveException("cannot modify because it was canceled");
		case Destroying:
			throw new ReserveException("cannot modify because it's destroying now");
		case Error:
			throw new ReserveException("cannot modify because it's in error");
		default:
			assert(false);
			throw new ReserveException("program error, cannot cancel"); 
		}

	}
	
	final void modify(ReserveId rsvId, ReserveRequest newReq) throws ReserveException {
		
		logger.debug("Try modify: " + rsvId + "\n" + newReq);

		ReserveInfo info = getReserveInfo(rsvId);
		checkModifyEnable(info, newReq);
		
		ReserveRequest oldReq = info.getReserveRequest();
		Calendar oldStart = oldReq.getStartTime();
		Calendar newStart = newReq.getStartTime();
		
		startCurrentOperation(ReserveOperation.getModifyInstance(info));
		
		// re-put to table because if startTime/endTime is changed, 
		// order in table must be changed also
		table.remove(info);
		try {
			info.modify(newReq);
		} finally {
			table.put(info);
		}
			
		try {
			recorder.store(info);
			
			Calendar start1, start2;
			if (oldStart.equals(newStart)) {
				start1 = oldStart;
				start2 = null;
			} else if (oldStart.before(newStart)) {
				start1 = oldStart;
				start2 = newStart;
			} else {
				start1 = newStart;
				start2 = oldStart;
			}
			
			reallocateNodes(start1, true);
			if (start2 != null) {
				reallocateNodes(start2, true);
			}

			commitCurrentStatus();
		} catch (ReserveException e) {
			abortWithoutException(info);
			throw e;
		}
		
		logger.debug("modified: " + info);

	}

}
