/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;

public class ReserveRequest implements Serializable, GetRefs {

	private static final long serialVersionUID = 5798440468207583306L;

	private String owner;
	private String users[];
	private int nodeNum;
	private Calendar startTime;
	private Calendar endTime;
	private Map<String, String> options;
	private static final String OPT_CPUNUM = "cpunum";
	private static final String OPT_MEM = "mem";
	private static final String OPT_PREPOSTQ = "prepostq";
	private static final String OPT_SLOTNUM = "slotnum";
	private static final boolean MAKE_PREPOSTQ_DEFAULT = false;
	private static final int DEFAULT_SLOTNUM = 0;

	private void checkValidReserveRequest(String owner, String users[], int nodeNum,
			Calendar startTime,	Calendar endTime) throws ReserveException {
		
		if ((owner == null) || (owner.length() == 0))
			throw new ReserveException("Invalid Reserve owner");
		
		if ((users == null) || (users.length == 0))
			throw new ReserveException("Invalid Reserve users");
		for (String name : users) {
			if ((name == null) || (name.length() == 0)) 
				throw new ReserveException("Invalid Reserve user name");
		}
		
		if (nodeNum <= 0)
			throw new ReserveException("Invalid number of Node");
		
		if (startTime == null) 
			throw new ReserveException("missing startTime");
		if (endTime == null) 
			throw new ReserveException("missing endTime");
		if (startTime.before(endTime) == false)
			throw new ReserveException("startTime must be before endTime");

		Calendar now = Calendar.getInstance();
		if (endTime.before(now) == true)
			throw new ReserveException("Reserve period has already passed");

	}
	
	private void init(String owner, String users[], int nodeNum, Calendar startTime,
			Calendar endTime) throws ReserveException {
		
		checkValidReserveRequest(owner, users, nodeNum, startTime, endTime);

		this.owner = owner;
		this.users = users;
		this.nodeNum = nodeNum;
		this.startTime = startTime;
		this.endTime = endTime;
		this.options = new HashMap<String, String>();

	}
	
	protected void modifyRequest(ReserveRequest req) throws ReserveException {
		
		init(req.getOwner(), req.getUsers(), req.getNodeNum(),
				req.getStartTime(), req.getEndTime());
		this.options = new HashMap<String, String>(req.getOptions());
		
	}

	public ReserveRequest(String owner, String users[], int nodeNum, Calendar startTime,
			Calendar endTime) throws ReserveException {
		
		init(owner, users, nodeNum, startTime, endTime);
		
	}
	
	public ReserveRequest(ReserveRequest req) throws ReserveException {
		
		modifyRequest(req);
		
	}
	
	protected ReserveRequest() {
		
	}
	
	public void setNodeCPUNum(int num) throws ReserveException {
		
		if (num > 0) {
			options.put(OPT_CPUNUM, Integer.toString(num));
		} else {
			throw new ReserveException("CPU number must be positive");
		}
		
	}

	public void setNodePhysicalMemory(long memByte) throws ReserveException {
		
		if (memByte > 0) {
			options.put(OPT_MEM, Long.toString(memByte));
		} else {
			throw new ReserveException("memory size must be positive");
		}
		
	}

	public void setMakePrePostQueue(boolean use) {
		
		options.put(OPT_PREPOSTQ, Boolean.toString(use));
		
	}
	
	public void setSlotNum(int num) {
		
		options.put(OPT_SLOTNUM, Integer.toString(num));
		
	}
	
	public String getOwner() {
		return owner;
	}

	public String[] getUsers() {
		return users;
	}
	
	public String getUserNames() {

		String users[] = getUsers();
		String userNames = "";
		for (String name : users) {
			userNames += name + ","; 
		}
		if (userNames.length() > 0) {
			userNames = userNames.substring(0, userNames.length() -1);
		}
		return userNames;
		
	}
	
	public int getNodeNum() {
		return nodeNum;
	}

	public Calendar getStartTime() {
		return startTime;
	}

	public Calendar getEndTime() {
		return endTime;
	}
	
	private String getNodeOption(String attr) {
		String v = options.get(attr);
		if (v != null)
			return v;
		else
			return "";
	}
	
	public int getNodeCPUNum() {
		String n = getNodeOption(OPT_CPUNUM);
		if (n.length() > 0)
			return Integer.parseInt(n);
		else
			return 1;
	}
	
	public long getNodePhysicalMemory() {
		String n = getNodeOption(OPT_MEM);
		if (n.length() > 0)
			return Long.parseLong(n);
		else
			return 1; // = 1 byte
	}
	
	public Map<String, String> getOptions() {
		return options;
	}
	
	public void setOptions(Map<String, String> prop) {
		if (prop != null) {
			this.options = prop;
		}
	}
	
	public boolean isMakePrePostQueue() {
		String s = getNodeOption(OPT_PREPOSTQ);
		return (s.length() > 0) ? Boolean.valueOf(s) : MAKE_PREPOSTQ_DEFAULT;
	}
	
	public int getSlotNum() {
		String s = getNodeOption(OPT_SLOTNUM);
		return (s.length() > 0) ? Integer.valueOf(s) : DEFAULT_SLOTNUM;
	}
	
	public String toString() {
		
		String p = "";
		for (Map.Entry<String, String> ent : options.entrySet()) {
			p += "[" + ent.getKey() + ", " + ent.getValue() + "] ";
		}
		return "from " + String.format(Locale.US, "%tc", startTime)
			+ " to " + String.format(Locale.US, "%tc", endTime)
			+ " by " + owner
			+ " for " + getUserNames()
			+ " of " + nodeNum + "nodes"
			+ " prop = " + p;
		
	}

	public Collection<Object> getRefs() {

		LinkedList<Object> list = new LinkedList<Object>();
		list.add(this);
		list.add(startTime);
		list.add(endTime);
		list.add(options);
		return list;
		
	}
	
}
