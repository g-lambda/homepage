/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.status.NodeStatus;


public class NodeManager {

	private LinkedHashMap<String, NodeInfo> nodeMap;

	public NodeManager() {
		
		nodeMap = new LinkedHashMap<String, NodeInfo>();
		
	}
	
	public synchronized void update(Collection<NodeStatus> nodes){
		
		if ((nodes == null) || (nodes.size() == 0))
			return;
		
		for (NodeStatus node : nodes) {
			addNode(node);
		}
		
		/*
		 * NOTE: Don't call nodeMap.clear() here.
		 * NodeInfo has its reserve information.
		 */
		Collection<NodeInfo> infos = nodeMap.values();
		for (NodeInfo info : infos) {
			NodeStatus status = info.getStatus();
			if (nodes.contains(status) == false) {
				nodeMap.remove(status.getName());
			}
		}
		
	}
	
	public synchronized void addNode(NodeStatus node) {
		
		assert(node != null);
		
		NodeInfo info = nodeMap.get(node.getName());
		if (info == null) {
			info = new NodeInfo(node);
			nodeMap.put(node.getName(), info);
		} else {
			info.update(node);
		}
		
	}

	public synchronized Collection<NodeInfo> getNodes(){

		return nodeMap.values();

	}
	
	public synchronized int getNodeNum() {
		
		return nodeMap.size();
		
	}
	
	public synchronized NodeInfo getNode(String nodeName) {
		
		return nodeMap.get(nodeName);
		
	}
	
	public synchronized Collection<NodeInfo> getUnreservedNodes() {
		
		LinkedList<NodeInfo> unrsv = new LinkedList<NodeInfo>();
		
		for (NodeInfo node : getNodes()) {
			if (node.isReservedNow() == false)
				unrsv.add(node);
		}

		return unrsv;
		
	}

}