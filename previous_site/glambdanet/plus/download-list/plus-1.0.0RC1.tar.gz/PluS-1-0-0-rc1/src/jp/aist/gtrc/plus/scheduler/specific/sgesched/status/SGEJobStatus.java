/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.job.JobID;
import jp.aist.gtrc.plus.scheduler.job.JobStateType;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.node.SGEExecNodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEArch;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class SGEJobStatus extends XMLStatus implements JobStatus {
	
	private class IdRange {
		
		private int min, max, step;
		
		private IdRange(int params[]) {
			if (params.length == 3) {
				min = params[0];
				max = params[1];
				step = params[2];
				assert(min <= max);
				assert(step > 0);
			} else {
				min = step = 0;
				max = -1;	// prevent loop in for()
			}
		}
		
		private boolean isEmpty() {
			return (max < min);
		}
		
		public String toString() {
			return "min=" + min + " max=" + max + " step=" + step;
		}
	}
	
	
	private LinkedHashMap<Integer, SGETaskStatus> tasks;
	private SGETaskStatus template;
	private IdRange allId, runnableId, holdUserId, holdSysId, holdOpeId;
	private QueueStatus relQueue;
	private HashMap<String, ComplexStatus> hardReq;
	private static SGEStatusManager statusMgr = SGEStatusManager.getInstance();
	
	// local variables which may be refered many times.
	// make instance for better performance 
	private IdRange peRange;
	private Integer jobnum, priority;
	private Date submitTime;
	private ReserveId rsvid;
	private String owner, tgtQs[], tgtProj, tgtPe;
	private Integer reqProcnum;
	
	public static final String RSV_ID_KEY = "rsvid";
	public static final String PRIORITY_KEY = "priority";
	private static final int RANGE_INFINITY = 9999999;
	
	SGEJobStatus(Node n) throws SchedulerException {

		super(n, "JB_");

		if (tasks == null) {
			// this job doesn't have running/finished tasks
			// make empty task list
			tasks = new LinkedHashMap<Integer, SGETaskStatus>();
		}
	
		setTaskIdSet();
		addTaskStatus();
		
	}
	
	private void makeHardRequests(Node node) throws Exception {
		
		if (hardReq == null)
			hardReq = new HashMap<String, ComplexStatus>();
		
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node sub = list.item(i);
			if (sub.getNodeType() != Node.ELEMENT_NODE)
				continue;

			ComplexStatus c = new ComplexStatus(sub);
			hardReq.put(c.getName(), c);
		}

	}
	
	protected void addNode(Node node) throws Exception {
		
		String name = node.getNodeName();
		boolean hasTasks = false;
	
		if (name.equals("JB_hard_resource_list")) {
			makeHardRequests(node);
			return;
		} else if (name.equals("JB_ja_tasks")) {
			hasTasks = true;
		} else if (name.equals("JB_ja_template") == false) {
			super.addNode(node);
			return;
		}
		
		if (tasks == null) {
			/*
			 * This method is called from SGEJobStatus constructor.
			 * 'tasks' is null here even if allocate it at constructor. 
			 */
			tasks = new LinkedHashMap<Integer, SGETaskStatus>();
		}
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node sub = list.item(i);
			if (sub.getNodeType() != Node.ELEMENT_NODE)
				continue;
			SGETaskStatus task = new SGETaskStatus(sub, this);
			if (hasTasks) {
				tasks.put(task.getTaskNumber(), task);
			} else {
				template = task;
			}
		}
		
	}
	
	SGETaskStatus getTemplateTask() {
		
		return template;
		
	}
	
	private void setTaskIdSet() {
		
		// always available, id values are constant
		allId = new IdRange(getIntParams("ja_structure"));
		
		// exists if runnable (not started yet) tasks exist
		// not exists if this job is holded
		// Id.min will be incremented after a task finished 
		runnableId = new IdRange(getIntParams("ja_n_h_ids"));
		
		// exists if user/system/operator hold tasks exist
		holdUserId = new IdRange(getIntParams("ja_u_h_ids"));
		holdSysId = new IdRange(getIntParams("ja_s_h_ids"));
		holdOpeId = new IdRange(getIntParams("ja_o_h_ids"));
		
		// ignore zombie tasks, got by getIntParams("ja_z_ids")

	}
	
	private void addDummyTaskStatus(IdRange holdId, int status) {
		
		for (int id = holdId.min; id <= holdId.max; id += holdId.step) {
			SGETaskStatus task = tasks.get(id);
			if (task == null) {
				task = new SGETaskStatus(this, id, status);
				tasks.put(id, task);
			}
		}

	}
	
	private void addTaskStatus() {
		
		if (template != null) {
			addDummyTaskStatus(runnableId, SGETaskStatus.TS_IDLE); 
			addDummyTaskStatus(holdUserId, SGETaskStatus.TS_HELD);
			addDummyTaskStatus(holdSysId, SGETaskStatus.TS_HELD);
			addDummyTaskStatus(holdOpeId, SGETaskStatus.TS_HELD);
		} else {
			 // All tasks are finished. They are already in 'tasks'.
			 // It's not necessary to make dummy SGETaskStatus.
		}
		
	}
	
	int getJobNumber() {
		
		if (jobnum == null)
			jobnum = getInt("job_number");
		return jobnum;
		
	}
	
	public String getOwner() {
		
		if (owner == null)
			owner = getString("owner");
		return owner;
		
	}
	
	public String getUid() {
		
		return getString("uid");
		
	}
	
	public int getPriority() {
		
		if (priority == null)
			priority = getInt(PRIORITY_KEY);
		return priority;
		
	}
	
	public void setPriority(int newPrio) {
		
		setAttrValue(PRIORITY_KEY, Integer.toString(newPrio));
		priority = newPrio;
		
	}
	
	public Date getSubmitTime() {
		
		if (submitTime == null) {
			long t = (long)getInt("submission_time");
			if (t != 0) {
				submitTime = new Date(t * 1000);
			} else {
				assert(false);
				submitTime = new Date();
			}
		}
		return submitTime;
		
	}
	
	public String getName() {

		return Integer.toString(getJobNumber());
		
	}

	public Collection<SGETaskStatus> getAllTasks() {
		return tasks.values();
	}

	public JobID getJobID() {
		// Call SGETaskStatus.getJobID(), not this.
		assert(false);
		return null;
	}

	public JobStateType getState() {
		// Call SGETaskStatus.getJobID(), not this.
		assert(false);
		return null;
	}

	public boolean isReadyToRun() {
		return true;
	}

	public ReserveId getReserveId() {
		
		if (rsvid != null)
			return rsvid;
		
		String s[] = getStringParams("context");
		for (int i = 0; i <= s.length-2; i++) {
			if (s[i].equals(RSV_ID_KEY)) { 
				rsvid = ReserveId.getInstance(s[i+1]);
				return rsvid;
			}
		}
		
		return null;
	}

	public int getRequestedCPUPerNode() {
		
		return 1;
		
	}

	private int checkRequestedProcess() {
		
		SGEParallelEnv pe = getTargetParallelEnv();
		if (pe == null) {
			return 1;
		} else {
			int allocRule = pe.getAllocationRule();
			if (pe.isProcessPerNodeSpecified()) {
				return allocRule;
			}
			switch (allocRule) {
			case SGEParallelEnv.ALLOC_RULE_FILL_UP:
				return 1;
			case SGEParallelEnv.ALLOC_RULE_PE_SLOTS:
				// start all proccesses on single node
				return getPEProcNum();	
			case SGEParallelEnv.ALLOC_RULE_ROUND_ROBIN:
				return 1; // TODO
			default:
				assert(false);
				return 1;
			}
		}

	}
	
	public int getRequestedProcessPerNode() {
		
		if (reqProcnum == null)
			reqProcnum = checkRequestedProcess();
		return reqProcnum;
		
	}
	
	public int getRequestedNodeNum() {

		return getPEProcNum() / getRequestedProcessPerNode();
		
	}

	public Collection<NodeAllocateSet> getNodeRequests() {

		Collection<NodeAllocateSet> nodeReqs = new LinkedList<NodeAllocateSet>();
		int nodeNum = getRequestedNodeNum();
		int cpuNum = getRequestedCPUPerNode();
		int procNum = getRequestedProcessPerNode();
		ComplexStatus arch = (hardReq != null) ? hardReq.get("arch") : null;
		if (arch == null) {
			NodeResource rsc = new NodeResource(cpuNum, procNum);
			nodeReqs.add(new NodeAllocateSet(nodeNum, rsc));
		} else {
			Collection<NodeResource> rscs = SGEArch.getMacthedNodeResources(
					arch.getStringVal(), cpuNum, procNum);
			nodeReqs.add(new NodeAllocateSet(nodeNum, rscs));
		}
		return nodeReqs;
		
	}
	
	public int getRequestedTime() {
		
		return getInt("h_rt");
		
	}

	public String getOwnersGroup() {
		
		return getString("group");
		
	}
	
	public String getGid() {
		
		return getString("gid");
		
	}

	public String getOwnersHost() {
		
		return "unknown";
		
	}

	public QueueStatus getQueueStatus() {

		return relQueue;
		
	}

	public boolean isRunnableOn(NodeStatus node) {

		SGEExecNodeAllocator allocator = new SGEExecNodeAllocator();
		return allocator.isReadyToRun((JobStatus)this, node);
		
	}

	public void setQueueStatus(QueueStatus q) {

		relQueue = q;
		
	}

	public boolean isQueued() {

		// Use SGETaskStatus.isQueued()
		assert(false);
		return true;
	}

	public boolean isRunning() {

		// Use SGETaskStatus.isRunning()
		assert(false);
		return false;
		
	}

	String[] getTargetQueueNames() {
		
		// returns {"foo.q"} if this job was submited by "qsub -q foo.q job.sh"
		// returns {} if -q options wasn't used.
		if (tgtQs == null)
			tgtQs = getStringParams("hard_queue_list");
		return tgtQs;
		
	}
	
	String getTargetParallelEnvName() {
		
		// returns "pe_1" if this job was submited by "qsub -pe pe_1 16 job.sh"
		// returns "" if -pe options wasn't used.
		if (tgtPe == null)
			tgtPe = getString("pe");
		return tgtPe;
		
	}
	
	SGEParallelEnv getTargetParallelEnv() {
		
		return statusMgr.getParallelEnv(getTargetParallelEnvName());
		
	}
	
	int[] getPEProcNumRange() {
		
		if (peRange == null) {
			peRange = new IdRange(getIntParams("pe_range"));
		}
		/*
		 * returns min&max of parallel process number
		 * 
		 * ret					-pe option
		 * --------------------------------------------
		 *	{ 16, 16 }			-pe 16
		 *	{ 16, 32 }			-pe 16-32
		 *	{ 16, 9999999 }	-pe 16-
		 *	{  1, 16 }			-pe -16
		 *
		 *	9999999 is RANGE_INFINITY
		 */
		if (peRange.isEmpty() == false) {
			return new int[]{ peRange.min, peRange.max };
		} else {
			return null;
		}
		
	}
	
	int getPEProcNum() {
		
		int num[] = getPEProcNumRange();
		if (num == null)
			return 1;

		return (num[1] == RANGE_INFINITY) ? num[0] : num[1];

	}
	
	String getTargetProjectName() {
		
		// returns "proj_1" if this job was submited by "qsub -P proj_1 job.sh"
		// returns "" if -P options wasn't used.
		if (tgtProj == null)
			tgtProj = getString("project");
		return tgtProj;
		
	}
	
	Date getExecutionTime() {
		
		/*
		 * NOTE: Job cannot run after exec_time.
		 * 'qsub -a MMDDhhmm' is used.
		 */
		long t = getInt("execution_time");
		if (t > 0) {
			return new Date(1000 * t);
		} else {
			return new Date(); 
		}
		
	}
	
	public boolean isRestartable() {
		
		switch (getInt("restart")) {
		case 0:	// default value
		case 2:	// 'qsub -r n' used
			return false;
		case 1:	// 'qsub -r y' ues
			return true;
		default:
			assert(false);
			return false;
		}
		
	}
	
	public String toString() {
		
		String s = super.toString();
		s += "\nallTask: " + allId.toString();
		s += "\nrunnable: " + runnableId.toString();
		s += "\nqueue: ";
		for (String qName : getTargetQueueNames()) {
			s += qName + " ";
		}
		s += " pe: " + getTargetParallelEnvName();
		s += " proj: " + getTargetProjectName();
		s += "\nTasks in this job\n";
		for (SGETaskStatus t : tasks.values()) {
			s += t.toString();
		}
		if (template != null) {
			s += "\nTemplateTask\n" + template.toString();
		}
		
		return s;
		
	}

}
