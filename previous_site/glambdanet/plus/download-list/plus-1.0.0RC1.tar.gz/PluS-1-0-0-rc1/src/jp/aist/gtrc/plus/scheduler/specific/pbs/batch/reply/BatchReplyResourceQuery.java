/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISDecoder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSException;

public class BatchReplyResourceQuery extends BatchReply {

	class ResourceStatus {
		
		private int available, allocated, reserved, down;
		
		ResourceStatus(int available, int allocated, int reserved, int down) {
			this.available = available;
			this.allocated = allocated;
			this.reserved = reserved;
			this.down = down;
		}
		
		boolean isAvailable() {
			return (available != 0);
		}
		boolean isAllocated() {
			return (allocated != 0);
		}
		boolean isReserved() {
			return (reserved != 0);
		}
		boolean isDown() {
			return (down != 0);
		}
		
	}

	private ResourceStatus status[];
	private boolean isAvailable = false;
	
	public BatchReplyResourceQuery(BatchReplyHeader header) {
		
		super(header);
		
	}
	
	public void decode(DISDecoder decoder) throws PBSException {
		
		int num = decoder.getInt();
		status = new ResourceStatus[num];
		isAvailable = (num > 0) ? true : false;
		for (int i = 0; i < num; i++) {
			status[i] = new ResourceStatus(decoder.getInt(), decoder.getInt(),
					decoder.getInt(), decoder.getInt());
			isAvailable &= status[i].isAvailable();
		}

	}
	
	public boolean isAvailable() {
		
		return isAvailable;
		
	}

}
