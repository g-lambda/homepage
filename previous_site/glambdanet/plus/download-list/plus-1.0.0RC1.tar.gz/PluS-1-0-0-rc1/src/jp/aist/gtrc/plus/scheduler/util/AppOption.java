/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.util.LinkedHashMap;
import java.util.Map;


public class AppOption{
	
	class Option {
		private String optPrefix;
		private String optParam;
		private String defaultValue;
		private String value;
		private String description;
		private boolean required;
		private static final String WITHOUT_VALUE = "###";
		private static final String DUMMY_VALUE = "$$$";
	
		Option(String optPrefix, String optParam, String description, String defaultValue, boolean required){
			this.optPrefix = optPrefix;
			this.optParam = optParam;
			this.defaultValue = defaultValue;
			this.value = defaultValue;
			this.description = description;
			this.required = required;
		}
		
		Option(String optPrefix, String optParam, String description, String defaultValue){
			this(optPrefix, optParam, description, defaultValue, false);
		}
		
		Option(String optPrefix, String description, boolean required){
			this(optPrefix, null, description, WITHOUT_VALUE);
		}

		Option(String optPrefix, String description){
			this(optPrefix, description, false);
		}
		
		String getPrefix() {
			return optPrefix;
		}
		
		String getParam() {
			return optParam;
		}
		
		String getValue(){
			return value;
		}
		
		void setValue(String value){
			this.value = value;
		}
		
		void setValue() {
			setValue(DUMMY_VALUE);
		}
		
		boolean hasParamValue() {
			
			return (defaultValue != WITHOUT_VALUE);
			
		}
		
		boolean isSet() {
			
			if (hasParamValue())
				return (getValue() != defaultValue);
			else
				return (getValue() == DUMMY_VALUE);
			
		}
		
		void setRequired(boolean required) {
			this.required = required;
		}

		boolean isRequired() {
			return required;
		}
		
		public String toString(){
			
			if (hasParamValue()) {
				String s = optPrefix + " " + optParam + "\t" + description;
				if ((defaultValue != null) && (defaultValue.length() > 0))
					s += " (default: " + defaultValue + ")";
				return s;
			} else {
				return optPrefix + "\t\t" + description;
			}
			
		}
	}
	
	
	private String appName;
	private Map<String, Option> map  = new LinkedHashMap<String, Option>();
	private static final String OPT_PREFIX_SHOW_HELP = "-h";
	
	protected AppOption(String appName) {
		
		this.appName = appName;
		
	}
	
	private void addOption(String optPrefix, Option option) {
		
		if (map.containsKey(optPrefix) == false) {
			map.put(optPrefix, option);
		} else {
			assert(false);
			System.err.println("PROGRAM ERROR: option key " + optPrefix + " is duplicated");
			System.exit(1);
		}
		
	}
	
	protected void addRequiredOption(String optPrefix, String optParam,
			String description, String defaultValue) {

		addOption(optPrefix, new Option(optPrefix, optParam, description, defaultValue, true));
		
	}

	protected void addOption(String optPrefix, String optParam,
			String description, String defaultValue) {
		
		addOption(optPrefix, new Option(optPrefix, optParam, description, defaultValue));
		
	}

	protected void addRequiredOption(String optPrefix, String description) {
		
		addOption(optPrefix, new Option(optPrefix, description, true));
		
	}

	protected void addOption(String optPrefix, String description) {
		
		addOption(optPrefix, new Option(optPrefix, description));
		
	}
	
	protected void deleteOption(String optPrefix) {
		
		if (map.containsKey(optPrefix)) {
			map.remove(optPrefix);
		}
		
	}
	
	protected void setRequired(String optPrefix, boolean required) {
		
		Option opt = map.get(optPrefix);
		if (opt != null) {
			opt.setRequired(required);
		}
		
	}

	public void showHelp(){
		
		String msg = appName;
		for (Map.Entry<String, Option> e : map.entrySet()) {
			Option opt = e.getValue();
			String s = opt.getPrefix();
			if (opt.hasParamValue()) {
				s += " " + opt.getParam();
			}
			if (opt.isRequired()) {
				msg += " " + s;
			} else {
				msg += " [" + s + "]";
			}
		}
		System.out.println(msg);
		
		for (Map.Entry<String, Option> e : map.entrySet()) {
			System.out.println("  " + e.getValue().toString());
		}
		
	}
	
	private void checkParams() throws Exception {
		
		for (Map.Entry<String, Option> e : map.entrySet()) {
			Option opt = e.getValue();
			if (opt.isRequired() && !opt.isSet()) {
				String msg = "missing \"" + opt.getPrefix();
				if (opt.hasParamValue()) {
					msg += " " + opt.getParam();
				}
				msg += "\"";
				throw new Exception(msg);
			}
		}
		
	}
	
	public void parse(String args[]) throws Exception {
		
		int i = 0;
		while (i < args.length) {
			String optPrefix = args[i];
			if (optPrefix.equals(OPT_PREFIX_SHOW_HELP)) {
				showHelp();
				System.exit(0);
			}
			
			Option opt = map.get(optPrefix);
			if (opt == null)
				throw new Exception("Unknown parameter: " + optPrefix);
			
			if (opt.hasParamValue()) {
				if (i+1 < args.length)
					opt.setValue(args[i+1]);
				else
					throw new Exception("Lost parameter value of " + optPrefix);
				i += 2;
			} else {
				opt.setValue();
				i++;
			}
			
		}
	
		checkParams();
		
	}
	
	public String getOptionValue(String optPrefix) {
		
		Option opt = map.get(optPrefix);
		if (opt != null)
			return opt.getValue();
		else
			return null;
		
	}
	
	public boolean isOptionSet(String optPrefix) {
		
		Option opt = map.get(optPrefix);
		if (opt != null)
			return opt.isSet();
		else
			return false;
		
	}

}

