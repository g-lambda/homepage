/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.reserve.ReserveException;

public class PluSUtil {

	protected static Logger logger = Logger.getLogger(PluSUtil.class);

	private static String domainName = null;
	static {
		try {
			String fqdn = InetAddress.getLocalHost().getCanonicalHostName();
			int index = fqdn.indexOf('.');
			if (index == -1) {
				fqdn = System.getenv("HOST");
				index = fqdn.indexOf('.');
			}
			if (index > 0) {
				// 'domainName' will be ".example.com" etc
				domainName = fqdn.substring(index);
			} else {
				domainName = "";
			}
		} catch (UnknownHostException e) {
			// ignore
		}
		
	}

	public static String makeFQDN(String hostname) {
		
		if (hostname.indexOf('.') >= 0) {
			return hostname;
		} else {
			return hostname + domainName;
		}
		
	}

	private static Runtime runtime = Runtime.getRuntime();

	public static LinkedList<String> runCommand(String cmdArgs[]) throws ReserveException {

		assert(cmdArgs.length > 0);
		String cmd = "";
		for (String s : cmdArgs) {
			cmd += s + " ";
		}
		cmd = cmd.trim();
		logger.debug("RUN " + cmd);
		
		int ret = -1;
		LinkedList<String> stdoutLines = new LinkedList<String>();
		String stdout = "";

		try {
			Process proc = runtime.exec(cmdArgs);
			
			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(proc.getInputStream(), "US-ASCII"));
				String line;
				while ((line = reader.readLine()) != null) {
					stdoutLines.add(line);
					logger.debug("STDOUT " + line);
				}
				reader.close();
			} catch (Exception e) {
				//ignore
			}

			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(proc.getErrorStream(), "US-ASCII"));
				String line;
				while ((line = reader.readLine()) != null) {
					stdout += line + "\n";
					logger.debug("STDERR " + line);
				}
				reader.close();
			} catch (Exception e) {
				//ignore
			}

			/*
			 * NOTE: If stdout&stderr doesn't read before waitFor(),
			 * waitFor() will be blocked especially many lines are printed. 
			 */
			ret = proc.waitFor();
		} catch (Exception e) {
			throw new ReserveException(e.getMessage());
		}
		logger.debug("exit code = " + ret);
		
		if (ret != 0) {
			stdout = stdout.trim();
			throw new ReserveException("Failed to run \"" + cmd + "\"\n" + stdout);
		}
		
		return stdoutLines;
		
	}

}
