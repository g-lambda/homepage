/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply;

import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSQueueStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;

public class BatchReplyStatusQueue  extends BatchReplyStatus<PBSQueueStatus> {

	public BatchReplyStatusQueue(BatchReplyHeader header){

		super(header);

	}

	protected BatchObjectType getObjectType(){
		
		return BatchObjectType.QUEUE;
		
	}

	protected PBSQueueStatus newStatus(String name){
		
		return new PBSQueueStatus(name);
		
	}

	protected PBSQueueStatus[] emptyArray() {

		return new PBSQueueStatus[]{};
		
	}

	public Collection<QueueStatus> getAllStatus() {

		LinkedList<QueueStatus> list = new LinkedList<QueueStatus>();
		for (PBSQueueStatus node : map.values()) {
			list.add((QueueStatus)node);
		}
		
		return list;
	}

}