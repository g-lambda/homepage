/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map.Entry;

public class ReserveStatus extends ReserveRequest implements Serializable, GetRefs {

	private static final long serialVersionUID = 255953629185187103L;
	
	public enum State {
		Confirmed, Running, Done, Canceled, Destroying, Error
	};
	
	private final ReserveId id;
	private State state;
	private boolean waitCommit;
	private String[] rsvNodes;

	/*
	 * state flow chart:
	 *   init --> CONFIRMED --> RUNNING --> DONE
	 *     				|             |            |
	 *    				V           V           V
	 *            CANCEL or ERROR      same as left
	 */
	
	public final String getStateStr() {

		if (waitCommit) {
			return "Waiting Commit";
		}
		
		updateReserveState();

		return state.name();

	}
	
	public ReserveStatus(ReserveId rsvId, ReserveRequest rsvReq, State state) throws ReserveException{

		super(rsvReq);
		this.id = rsvId;
		this.state = state;
		this.waitCommit = false;
		this.rsvNodes = new String[]{};

	}
	
	public final ReserveRequest getReserveRequest() {
		
		return (ReserveRequest)this;
		
	}

	void setReserveState(State newState){

		this.state = newState;
		
	}

	private void updateReserveState() {
		
		switch(state){
		case Confirmed:
			Calendar now = Calendar.getInstance();
			if (now.after(getStartTime())) {
				if (now.before(getEndTime()))
					setReserveState(State.Running);
				else
					setReserveState(State.Done);
			}
			break;
		case Running:
		case Canceled:
			if (Calendar.getInstance().after(getEndTime()))
				setReserveState(State.Done);
			break;
		case Done:
		case Destroying:
		case Error:
			// don't change state more
			break;
		default:
			assert(false);
			break;
		}
		
	}
	
	void setWaitCommit() {

		assert(waitCommit == false);
		waitCommit = true;
		
	}
	
	void clearWaitCommit() {
		
		assert(waitCommit == true);
		waitCommit = false;
		
	}
	
	public void setReservedNodes(String[] nodeNames){

		rsvNodes = nodeNames;
		
	}
	
	void modifyReserveRequest(ReserveRequest newReq) throws ReserveException {
		
		modifyRequest(newReq);
		
	}
	
	public ReserveId getReserveId() {
		return id;
	}
	
	public State getReserveState() {
		
		updateReserveState();
		return state;
		
	}
	
	public String[] getReservedNodeNames() {
		return rsvNodes;
	}
	
	private String toString(String attr, String value) {
		
		return attr + "\t" + value + "\n";
		
	}
	
	public String toString() {

		long diff = (getEndTime().getTimeInMillis() - getStartTime().getTimeInMillis()) / 1000;
		String nodes = "";
		for (String name : getReservedNodeNames()) {
			nodes += name + " ";
		}
		String opts = "";
		for (Entry<String, String> ent : getOptions().entrySet()) {
			opts += ent.getKey() + "=" + ent.getValue() + " ";
		}
		
		return toString("id", id.toString())
			+ toString("owner", getOwner())
			+ toString("users", getUserNames())
			+ toString("start", String.format(Locale.US, "%tc", getStartTime()))
			+ toString("end", String.format(Locale.US, "%tc", getEndTime()))
			+ toString("duration", Long.toString(diff) + "[sec]")
			+ toString("state", getStateStr())
			+ toString("nodes", nodes.toString())
			+ toString("options", opts);

	}

	public Collection<Object> getRefs() {

		LinkedList<Object> list = new LinkedList<Object>();
		list.add(this);
		list.addAll(super.getRefs());
		list.add(id);
		return list;
		
	}

}