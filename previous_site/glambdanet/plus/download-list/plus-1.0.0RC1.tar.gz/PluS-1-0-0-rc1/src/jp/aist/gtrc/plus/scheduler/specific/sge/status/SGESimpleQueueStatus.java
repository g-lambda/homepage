/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;
import java.util.LinkedHashSet;

import jp.aist.gtrc.plus.scheduler.status.QueueStatus;

public class SGESimpleQueueStatus implements QueueStatus {

	private String qname;
	private Collection<SGESimpleQInstance> instances;
	private int nSuspend = SUSPEND_NOT_CHECKED;
	private static int SUSPEND_NOT_CHECKED = -1;
	
	/*
		% qconf -sql
		all.q
		foo.q
	 */
	
	private SGESimpleQueueStatus(String qname) {
		
		this.qname = qname;
		this.instances = new LinkedHashSet<SGESimpleQInstance>();
		
	}
	
	public static SGESimpleQueueStatus getInstance(String info) {
		
		if (info.length() > 0) {
			return new SGESimpleQueueStatus(info);
		} else {
			assert(false);
			return null;
		}
		
	}
	
	void addQInstance(SGESimpleQInstance qins) {
	
		instances.add(qins);
		
	}
	
	public Collection<SGESimpleQInstance> getAllQInstances() {
		
		return instances;
		
	}
	
	public boolean isReadyToUse() {
		
		return true;
		
	}

	public int getPriority() {

		return 0;
		
	}

	public void setQueueIndex(int index) {

	}

	public int getQueueIndex() {

		return 0;
		
	}

	public String getName() {

		return qname;
		
	}
	
	private void checkSuspendedInstance() {
		
		nSuspend = 0;
		for (SGESimpleQInstance qins : getAllQInstances()) {
			if (qins.isSuspended()) {
				nSuspend++;
			}
		}
		
	}
	
	public boolean isSuspended() {
		
		if (nSuspend == SUSPEND_NOT_CHECKED)
			checkSuspendedInstance();
		return (nSuspend == instances.size());
		
	}
	
	public boolean hasRunningJobs() {
		
		for (SGESimpleQInstance qins : getAllQInstances()) {
			if (qins.getUsedSlotNum() > 0) {
				return true;
			}
		}
		return false;
		
	}
}
