/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.status;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class StatusMap implements Iterable<Map.Entry<String, StatusValue>>{

	private Map<String, StatusValue> map;
	private String name;
	
	static protected final String UNKNOWN_STATUS = "";	// not null

	protected static Logger logger = Logger.getLogger(StatusMap.class);
	
	StatusMap(String name){
		
		this.map = new LinkedHashMap<String, StatusValue>();
		this.name = name;
		
	}

	public String getName(){
		
		return name;
		
	}

	public void putStatus(String attr, String value){

		map.put(attr, new StatusValue(value));

	}

	public void putStatusMap(String name, StatusMap status){

		map.put(name, new StatusValue(status));

	}

	public String getStatus(String attr){

		StatusValue value = map.get(attr);
		if (value != null) {
			return value.getStatus();
		} else {
			logger.debug("unknown/unspecified status: " + attr);
			return UNKNOWN_STATUS;
		}

	}

	public StatusMap getStatusMap(String name){

		StatusValue value = map.get(name);
		if (value != null) {
			return value.getChildMap();
		} else {
			// allocate new map is not exists
			logger.debug("allocate new StatusMap: " + name);
			StatusMap child = new StatusMap(name);
			map.put(name, new StatusValue(child));
			return child;
		}

	}

	public String getStatus(String name, String attr){

		StatusValue value = map.get(name);
		if (value != null) {
			StatusMap child = value.getChildMap();
			if (child != null) {
				return child.getStatus(attr);
			}
		}
		
		logger.debug("unknown status: " + name + "@" + attr);
		return UNKNOWN_STATUS;

	}

	public Iterator<Map.Entry<String, StatusValue>> iterator(){
		
		return map.entrySet().iterator();
		
	}

	public String toString() {
		String s = getName() + "\n";

		for (Map.Entry<String, StatusValue> e : this) {
			s += "\t" + e.getKey() + "\t" + e.getValue().toString() + "\n";
		}
		
		return s;
	}

}