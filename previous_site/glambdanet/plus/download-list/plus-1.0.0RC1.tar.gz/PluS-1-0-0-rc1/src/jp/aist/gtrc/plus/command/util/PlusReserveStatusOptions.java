/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command.util;

import java.util.Calendar;

import jp.aist.gtrc.plus.reserve.ReserveException;


public class PlusReserveStatusOptions extends PlusReserveIdOption {

	private static final String OPT_OF_OWNER = "-o";
	private static final String OPT_RSV_START = "-s";
	private static final String OPT_RSV_END = "-e";
	private static final String OPT_N_EXPIRED = "-ne";
	private static final String OPT_SORT_BY_NODE = "-n";
	private static final String OPT_USE_XML = "-x";

	private static final String DEFAULT_N_EXPIRED = "0";

	public PlusReserveStatusOptions(String appName) {
		
		super(appName);
		addOption(OPT_OF_OWNER, "owner", "show status of owner", null);
		addOption(OPT_RSV_START, "startTime", "Reservation start time, yyyy-MM-ddTHH:mm:ss[+-]zz:zz", null);
		addOption(OPT_RSV_END, "endTime", "Reservation end time", null);
		addOption(OPT_N_EXPIRED, "numShowExpired", "max # of expired reserves to be shown", DEFAULT_N_EXPIRED);
		addOption(OPT_SORT_BY_NODE, "show status sorted by node");
		addOption(OPT_USE_XML, "show status in XML");
		deleteOption(OPT_TRANSACTION);
		
	}
	
	public String getOwner() {
		
		return getOptionValue(OPT_OF_OWNER);
		
	}
	
	public Calendar getStartTime() throws ReserveException {
		
		String t = getOptionValue(OPT_RSV_START);
		return (t != null) ? PlusReserveOptions.makeCalendar(t) : null;
			
	}
	
	public Calendar getEndTime() throws ReserveException {
		
		String t = getOptionValue(OPT_RSV_END);
		return (t != null) ? PlusReserveOptions.makeCalendar(t) : null;
			
	}

	public int getNumShowExpired() throws ReserveException {
		
		String n = getOptionValue(OPT_N_EXPIRED);
		try {
			return Integer.parseInt(n);
		} catch (NumberFormatException e) {
			throw new ReserveException("invalid number: " + n);
		}
		
	}
	
	public boolean isShowByXML() {
		
		return isOptionSet(OPT_USE_XML);
	}
	
	public boolean isShowSortedByNode() {
		
		return isOptionSet(OPT_SORT_BY_NODE);
	}
	
}
