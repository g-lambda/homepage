/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import org.w3c.dom.Node;

import jp.aist.gtrc.plus.scheduler.status.Status;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class SGEParallelEnv extends XMLStatus implements HasACL, Status {

	public static final int ALLOC_RULE_PE_SLOTS = -1;
	public static final int ALLOC_RULE_ROUND_ROBIN = -2;
	public static final int ALLOC_RULE_FILL_UP = -3;
	private static final int ALLOC_RULE_DEFAULT = ALLOC_RULE_PE_SLOTS;
	private static final int ALLOC_RULE_UNKNOWN = 0;
	
	private int allocRule = ALLOC_RULE_UNKNOWN;
	private SGEACL acl; 
	
	SGEParallelEnv(Node node) throws SchedulerException {
		
		super(node, "PE_");
		
	}

	public String getName() {

		return getString("name");
		
	}
	
	public int getSlotNum() {
		
		return getInt("slots");
		
	}
	
	public String getStartProgArg() {
		
		return getString("start_proc_args");
		
	}
	
	public String getStopProgArg() {
		
		return getString("stop_proc_args");

	}
	
	private int parseAllocationRule() {
		
		String r = getString("allocation_rule");
		if (r.startsWith("$") == false) {
			int v;
			try {
				v = Integer.parseInt(r);
				if (v > 0)
					return v;
			} catch (NumberFormatException e) {
			}
			// rule is not positive / invalid
			return ALLOC_RULE_DEFAULT;
		}
		
		if (r.equals("$pe_slots"))
			return ALLOC_RULE_PE_SLOTS;
		if (r.equals("$round_robin"))
			return ALLOC_RULE_ROUND_ROBIN;
		if (r.equals("$fill_up"))
			return ALLOC_RULE_FILL_UP;

		assert(false);
		return ALLOC_RULE_DEFAULT;

	}
	
	public int getAllocationRule() {
		
		if (allocRule == ALLOC_RULE_UNKNOWN)
			allocRule = parseAllocationRule();
		return allocRule;
		
	}

	public boolean isProcessPerNodeSpecified() {
		
		return (getAllocationRule() > 0);
		
	}

	private SGEACL makeAcl() {

		SGEUserACL userAcl = SGEUserACL.getInstance(
				getStringParams("acl"), getStringParams("xacl"));
		return new SGEACL(userAcl); // SGEParallelEnv doesn't have projACL

	}
	
	public SGEACL getAcl() {
	
		if (acl == null)
			acl = makeAcl();
		return acl;
		
	}
	
	public String toSting() {
		
		String s = super.toString();
		s += "\nACL " + getAcl().toString();
		s += "\nAllocRule " + getAllocationRule();
		
		return s;
		
	}
	
}
