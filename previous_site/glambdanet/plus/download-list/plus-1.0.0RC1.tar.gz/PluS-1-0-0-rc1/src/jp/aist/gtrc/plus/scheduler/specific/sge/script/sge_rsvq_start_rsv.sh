#!/bin/sh

# Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
# National Institute of Advanced Industrial Science and Technology
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# usage exmaple:
#  ./sge_rsvq_start_rsv.sh R123 1
#
# PHASE
#	0 : resume preQ
#	1 : delete preQ, resume mainQ
#	2 : resume mainQ
#	other: ignore

if [ "$#" -ne 2 ]; then
  echo 'usage: sge_rsvq_start_rsv.sh RSVID PHASE'
  exit 1
fi

RSVID=$1

SGE_QNAME="${RSVID}"
SGE_HOSTLIST="@${SGE_QNAME}_hosts"
SGE_PHASE=$2
SGE_PREQNAME="${RSVID}pre"

rerun_unrsv_jobs() {
	RSV_HOSTS=`qconf -shgrp ${SGE_HOSTLIST} | grep hostlist | awk -Fhostlist\  '{print $2}'`
	if [ -z "$RSV_HOSTS" ]; then
	  exit 1
	fi
	
	#
	# Suspend unreserved queue instances on reserved host
	#
	for HOST in $RSV_HOSTS; do
	  # get queue instances on $HOST
	  #   excluding reserve queue which name starts with 'R'.
	  QINSTANES_ON_HOST=`qstat -f | grep ${HOST} | grep -v '^R' | awk '{print $1}'`
	
	  # Suspend thier queue instances.
	  # NOTE: jobs on the queue instance is marked as suspended
	  for QINS_NAME in $QINSTANES_ON_HOST; do 
	    qmod -sq ${QINS_NAME}
	  done
	done
	
	#
	# Rerun jobs on thier queue instances
	#
	for HOST in $RSV_HOSTS; do
	  # get suspended jobid and its owner on queue instance on $HOST
	  #   excluding reserve queue which name starts with 'R'.
	  JOBS_ON_HOST=`qstat -q [^R]*@${HOST} -s s | grep '^ ' | awk '{print $1" "$4}'`
	
	  # To rerun unreserved job, we do
	  #   1) suspend job (suspending queue makes jobs suspended actually),
	  #   2) resubmit (copy and submit) job by job owner's account,
	  #   3) delete job which suspended by 1).
	  i=0
	  for ENTRY in $JOBS_ON_HOST; do
	    t=`expr $i % 2`
	    if [ $t -eq 0 ]; then
	      JOBID=$ENTRY
	    else
	      OWNER=$ENTRY
	      qmod -sj $JOBID
	      sudo -u $OWNER qresub $JOBID
	      qdel $JOBID
	    fi 
	    i=`expr $i + 1`
	  done
	done
}

#
# Resume reserve queue
#
if [ "$SGE_PHASE" -eq "0" ]; then
	rerun_unrsv_jobs
	# resume preQ
	qmod -usq "${SGE_PREQNAME}"
elif [ "$SGE_PHASE" -eq "1" ]; then
	# delete preQ, resume mainQ
	qconf -dq "${SGE_PREQNAME}"
	qmod -usq "${SGE_QNAME}"
elif [ "$SGE_PHASE" -eq "2" ]; then
	rerun_unrsv_jobs
	# resume mainQ
	qmod -usq "${SGE_QNAME}"
fi
