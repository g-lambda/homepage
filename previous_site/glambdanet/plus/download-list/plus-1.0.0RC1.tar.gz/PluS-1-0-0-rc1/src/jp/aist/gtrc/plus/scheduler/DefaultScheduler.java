/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collection;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.reserve.*;
import jp.aist.gtrc.plus.scheduler.job.*;
import jp.aist.gtrc.plus.scheduler.mainsrv.MainServer;
import jp.aist.gtrc.plus.scheduler.node.*;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSScheduleStarter;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;


abstract class DefaultScheduler implements PluScheduler {

	protected StatusManager statusMgr;
	protected NodeManager nodeMgr;
	protected JobManager jobMgr;
	protected ReserveManager rsvMgr;
	protected Scheduler scheduler;
	protected NodeAllocator nodeAllocator;
	protected ScheduleStarter starter;
	protected ReserveServer reserveServer;
	
	protected static Logger logger = Logger.getLogger(DefaultScheduler.class);

	protected DefaultScheduler(String args[]) throws Exception {
		
		try {
			logger.info("Starting Scheduler");

			SchedulerOptions options = new SchedulerOptions(args);
			
			statusMgr = getStatusManager(args);
			if (statusMgr == null) {
				throw new SchedulerException("StatusManager cannot be initialized");
			}
			nodeMgr = new NodeManager();
			
			// NOTE: we allow scheduler&nodeAllocator is null
			scheduler = Scheduler.getScheduler(options);
			nodeAllocator = getExecNodeAllocator(options);
			
			starter = getScheduleStarter(args);
			if (starter == null) {
				throw new SchedulerException("SchedulerStarter cannot be started");
			}
			
			rsvMgr = getReserveManager(options);
			if (rsvMgr == null) {
				throw new SchedulerException("ReservaManager cannot be initialized");
			}
			jobMgr = getJobManager(rsvMgr);
			if (jobMgr != null) {
				jobMgr.useStarvedJobHelper(24 * 3600);
			} else {
				// NOTE: we allow jobMgr is null
			}
			
			reserveServer = rsvMgr;
			logger.info("Starting Scheduler succeeded");
		} catch (Exception e) {
			logger.error("Starting Scheduler failed");
			logger.debug(e, e);
			stopScheduler();
			throw e;
		}
		
	}
	
	protected StatusManager getStatusManager(String[] args) throws SchedulerException {
		
		return new StatusManager();
		
	}
	
	protected ScheduleStarter getScheduleStarter(String[] args) throws SchedulerException {
		
		return new PBSScheduleStarter();
		
	}

	protected NodeAllocator getExecNodeAllocator(SchedulerOptions options) throws SchedulerException {
		
		return new ExecNodeAllocator(new NodeSorter(options));
		
	}
	
	protected NodeAllocator getRsvNodeAllocator(SchedulerOptions options) throws SchedulerException {
		
		return new ReserveNodeAllocator();
		
	}
	
	protected NodeManager getReserveNodeManager() throws SchedulerException {
		
		return nodeMgr;
		
	}
	
	protected ReserveManager getReserveManager(SchedulerOptions options) throws SchedulerException {
		
		NodeAllocator rsvNodeAllocator = getRsvNodeAllocator(options);
		if (rsvNodeAllocator == null) {
			throw new SchedulerException("Invalid ReserveNodeAllocator");
		}
		
		ReserveRecorder recorder = new ReserveRecorderImpl(
				options.getReserveFilePath(), getReserveNodeManager());
		return new ReserveManager(getReserveNodeManager(), starter,
				recorder, rsvNodeAllocator, options.getMaxExpiredReserves());

	}
	
	protected JobManager getJobManager(ReserveManager rsvMgr) throws SchedulerException {
		
		return new JobManager(rsvMgr);
		
	}
	
	protected void startReserveServer() throws Exception {

		startReserveServer(null, null);
		
	}

	protected void startReserveServer(RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws Exception {
		
		recoverReserves(getMainServer());

		Remote stub = (ReserveServer)UnicastRemoteObject.exportObject(
				reserveServer, 0, csf, ssf);

		/*
		 * NOTE: registry must get by getRegistry(), not by createRegistry()
		 * Both return value are same, but using registry from createRegistry()
		 * and UnicastRemoteObject.exportObject() may not work correctlly
		 * because of JDK's bug.
		 * See
		 * http://archives.java.sun.com/cgi-bin/wa?A2=ind0509&L=rmi-users&P=R216&I=-3
		 * http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4114579
		 */
		LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
		Registry registry = LocateRegistry.getRegistry(Registry.REGISTRY_PORT);
		
		registry.bind(ReserveServer.RMI_OBJECT_NAME, stub);
		
		logger.info("ReserveServer Started");
		
		starter.runSchedule(new ScheduleOrder(getMainServer()));

	}
	
	protected void stopReserveServer() {
	
		if (reserveServer != null) {
			try {
				UnicastRemoteObject.unexportObject(reserveServer, true);
				Registry registry = LocateRegistry.getRegistry(Registry.REGISTRY_PORT);
				registry.unbind(ReserveServer.RMI_OBJECT_NAME);
			} catch (Exception e) {
				// ignore
				logger.debug("ReserveServer Exit failed", e);
			}
			logger.info("ReserveServer Exited");
			reserveServer = null;
		}
			
	}
	
	
	abstract protected MainServer getMainServer() throws Exception;

	private void recoverReserves(MainServer srv) throws Exception {
		
		if (nodeMgr.getNodeNum() == 0) {
			// get current node status.
			// node status is needed for reserve node check.
			try {
				updateStatus(srv);
			} finally {
				srv.disconnect();
			}
		}

		rsvMgr.recoverFromRecorder();
		
	}
	
	protected void stopScheduler() {
		
		stopReserveServer();
		if (rsvMgr != null) {
			rsvMgr.finish();	// close Reserve information storage
			rsvMgr = null;
		}
		
	}

	public void run() {
		
		ScheduleOrder order = null;
		MainServer srv = null;

		logger.info("Scheduler Started, waiting order");

		do {
			try {
				order = starter.waitOrder();
				if (order == null) {
					assert(false);
					continue;
				}
				if (order.mustRunSchedule() == false) {
					break;
				}
				
				srv = order.getMainServer();
				if (srv == null) {
					assert(false);
					continue;
				}
				if (srv.isConnected() == false) {
					logger.info("Invalid server connection");
					continue;
				}
				runSchedule(order);
			} catch (Exception e) {
				logger.info(e.getMessage());
				logger.debug(e, e);
			} finally {
				if (srv != null) {
					srv.disconnect();
					srv = null;
				}
			}
		} while (order.toBeQuit() == false);
	
		stopScheduler();
		logger.info("Scheduler Exited");
		
	}
	
	protected void updateStatus(MainServer srv) throws SchedulerException{

		statusMgr.updateStatus(srv);
		nodeMgr.update(statusMgr.getNodes());
		
	}
	
	protected boolean isJobSchedulingEnable() {
		
		return ((jobMgr != null) && (nodeAllocator != null));
		
	}

	protected void runSchedule(ScheduleOrder order) throws SchedulerException{

		updateStatus(order.getMainServer());
		
		ReserveId rsvId = order.getReserveId();
		if (rsvId != null) {
			handleReserveCancel(order);
		} else {
			handleReserveExpire(order);
			if (isJobSchedulingEnable()) {
				schedule(order);
			}
		}
		
	}

	protected void schedule(ScheduleOrder order) throws SchedulerException{

		assert(jobMgr != null);
		assert(scheduler != null);
		
		/*
		 * Select one job to run
		 */
		Collection<JobStatus> allJobs = statusMgr.getJobs();
		Collection<JobStatus> runnableJobs = jobMgr.getRunnableJobs(allJobs);
		if (runnableJobs != null) {
			JobStatus job = scheduler.selectJob(runnableJobs);
			runOneJob(order.getMainServer(), job);
		}
		
	}
	
	protected void runOneJob(MainServer srv, JobStatus job) throws SchedulerException {
		
		assert(nodeAllocator != null);

		/*
		 * Select exec-nodes to use
		 */
		ReserveId rsvId = job.getReserveId();
		ReserveInfo rsvInfo = rsvMgr.getReserveInfo(rsvId);
		Collection<NodeInfo> usableNodes, nodes;
		if (rsvInfo != null) {
			usableNodes = rsvInfo.getReservedNodeInfos();
			boolean mustRestart = handleUnreservedJobs(srv, usableNodes);
			if (mustRestart) {
				// some information was changed by handleUnreservedJobs(),
				// don't call runJob(), restart scheduling
				return;
			}
		} else {
			usableNodes = nodeMgr.getUnreservedNodes();
		}
		
		nodes = nodeAllocator.suitable(usableNodes, new NodeAllocateRequest(job));
		if (nodes != null) {
			/*
			 * Run the job at nodes
			 */
			srv.runJob(job, nodes);
		} else {
			// no enough exec-nodes
			// ex: reserve is correct, but too many jobs were submitted
		}

	}
	
	protected boolean handleUnreservedJobs(MainServer srv, Collection<NodeInfo> rsvdNodes) throws SchedulerException {
		
		// do nothing, override this if needed
		
		// false: OK to continue
		// true: some job was reruned (killed), must restart scheduling cycle
		return false;	
		
	}

	private void holdJobs(MainServer srv, Collection<JobStatus> jobs) {

		if ((jobs == null) || (jobs.size() == 0))
			return;	// nothing to hold, do nothing
		
		for (JobStatus job : jobs) {
			try {
				if (job.isQueued()) {
					srv.holdJob(job.getJobID());
				} else if (job.isRunning()) {
					srv.rerunJob(job);
				}
			} catch (SchedulerException e) {
				logger.info("cannot hold/rerun of " + job.getName());
			}
		}

	}
	
	protected void handleReserveExpire(ScheduleOrder order) throws SchedulerException{

		Collection<ReserveInfo> expiredRsv = rsvMgr.getExpiredReserve();
		if (expiredRsv.size() == 0)
			return;	// no expired reserves

		Collection<JobStatus> allJobs = statusMgr.getJobs();
		Collection<JobStatus> holdJobsList = new LinkedList<JobStatus>();
		for (ReserveInfo info : expiredRsv) {
			ReserveId expireId = info.getReserveId();
			for (JobStatus job : allJobs) {
				ReserveId id = job.getReserveId(); 
				if ((id != null) && id.equals(expireId)) {
					holdJobsList.add(job);
				}
			}
		}
		holdJobs(order.getMainServer(), holdJobsList);

		// Remove expired reserves.
		// Their state maybe not only DONE but also CANCELED or ERROR
		for (ReserveInfo info : expiredRsv) {
			rsvMgr.remove(info);
		}

	}

	protected void handleReserveCancel(ScheduleOrder order) throws SchedulerException{

		ReserveId rsvId = order.getReserveId();
		if (rsvId == null)
			return;
		
		ReserveInfo info = rsvMgr.getReserveInfo(rsvId);
		if (info != null) {
			switch (info.getReserveState()) {
			case Confirmed:
			case Running:
				return;
			default:
				break;
			}
		}
		
		Collection<JobStatus> holdJobsList = new LinkedList<JobStatus>();

		for (JobStatus job : statusMgr.getJobs()) {
			ReserveId id = job.getReserveId(); 
			if ((id != null) && id.equals(rsvId)) {
				holdJobsList.add(job);
			}
		}

		holdJobs(order.getMainServer(), holdJobsList);

	}

}