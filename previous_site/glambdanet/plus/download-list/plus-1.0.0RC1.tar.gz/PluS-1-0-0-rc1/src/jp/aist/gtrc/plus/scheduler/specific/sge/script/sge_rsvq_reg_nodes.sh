#!/bin/sh

# Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
# National Institute of Advanced Industrial Science and Technology
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# usage exmaple:
#  ./sge_rsvq_reg_nodes.sh R123 'host0.example.com host1.example.com'
#

if [ "$#" -ne 2 ]; then
  echo 'usage: sge_rsvq_reg_nodes.sh $RSVID $HOSTLIST'
  exit 1
fi

RSVID=$1
HOSTLIST=$2

SGE_QNAME="${RSVID}"
SGE_PREQNAME="${SGE_QNAME}pre"
SGE_POSTQNAME="${SGE_QNAME}post"
SGE_HOSTLIST="@${SGE_QNAME}_hosts"

#
# Modify (or Create if not exists) hostgroup
#
SGE_HOSTFILE="/tmp/sgersv_${SGE_HOSTLIST}"
echo "group_name ${SGE_HOSTLIST}" > ${SGE_HOSTFILE}
echo "hostlist ${HOSTLIST}" >> ${SGE_HOSTFILE}
qconf -Mhgrp ${SGE_HOSTFILE}
if [ $? -ne 0 ]; then
  qconf -Ahgrp ${SGE_HOSTFILE}
  if [ $? -ne 0 ]; then
    exit 1
  fi
fi
rm -f ${SGE_HOSTFILE}

#
# Suspend queue if it already exists
#
qconf -sq ${SGE_QNAME} > /dev/null
if [ $? -eq 0 ]; then
  qmod -sq "${SGE_QNAME}"
fi
qconf -sq ${SGE_PREQNAME} > /dev/null
if [ $? -eq 0 ]; then
  qmod -sq ${SGE_PREQNAME}
  qmod -sq ${SGE_POSTQNAME}
fi

exit 0
