/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import static jp.aist.gtrc.plus.reserve.ReserveStatus.State.*;

class CancelOperator extends ReserveUpdateOperator {
	
	CancelOperator(ReserveManager rsvMgr, ReserveNodeNormalizer normalizer,
			CommitOperator commiter, AbortOperator aborter) {
		
		super(rsvMgr, normalizer, commiter, aborter);
		
	}
	
	private void checkCancelEnable(ReserveInfo info) throws ReserveException {

		switch (info.getReserveState()) {
		case Confirmed:
			// enable to cancel
			break;
		case Running:
			// stop running jobs before cancel
			break;
		case Done:
			throw new ReserveException("cannot cancel because it's done");
		case Canceled:
			throw new ReserveException("cannot cancel because it was already canceled");
		case Destroying:
			throw new ReserveException("cannot cancel because it's destroing now");
		case Error:
			throw new ReserveException("cannot cancel because it's in error");
		default:
			assert(false);
			throw new ReserveException("cannot cancel because it's in unknown status");
		}
		
	}
	
	protected final void cancel(ReserveInfo info) throws ReserveException {
		
		info.setReserveState(Canceled);

		// don't remove ReserveInfo, remain as CANCELED state.
		// but reserved nodes are freed here. 
		info.unregisterReservedNodesForever();
		try {
			recorder.store(info);
		} catch (ReserveException e) {
			throw e;
		}
	
		reallocateNodes(info.getStartTime(), true);
		commitCurrentStatus();
		
	}

	protected void cancel(ReserveId rsvId) throws ReserveException {
	
		ReserveInfo info = getReserveInfo(rsvId);
		checkCancelEnable(info);
		
		boolean abortable = (info.getReserveState() == Confirmed);
		startCurrentOperation(ReserveOperation.getCancelInstance(info, abortable));
		try {
			cancel(info);
		} catch (ReserveException e) {
			abortWithoutException(info);
		}
		
	}
	
	protected final void cancelOfOwner(String owner) throws ReserveException {
		
		for (ReserveInfo info : table.getAllById()) {
			switch (info.getReserveState()) {
			case Confirmed:
			case Running:
				break;
			case Done:
				if (info.getReserveNodeSet() != null) {
					break;		// reserved node has not freed yet
				}
				continue;		// reserved node has already freed
			case Canceled:
			case Destroying:
			case Error:
				continue;
			}
			if (info.getOwner().equals(owner) == false) {
				continue;
			}
			
			startCurrentOperation(ReserveOperation.getCancelOfOwnerInstance(info));
			try {
				cancel(info);
				commit(info);
			} catch (ReserveException e) {
				abortWithoutException(info);
				throw e;
			}
		}

	}

}
