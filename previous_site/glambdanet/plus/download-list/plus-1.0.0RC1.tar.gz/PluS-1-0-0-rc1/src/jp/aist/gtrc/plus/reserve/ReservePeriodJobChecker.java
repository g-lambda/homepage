/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;


import static jp.aist.gtrc.plus.reserve.ReserveStatus.State.*;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.util.Checker;


public class ReservePeriodJobChecker  extends Checker<JobStatus>{

	private ReserveManager rsvMgr;

	public ReservePeriodJobChecker(ReserveManager rsvMgr){
		
		assert(rsvMgr != null);
		this.rsvMgr = rsvMgr;

	}

	public boolean isOK(JobStatus job){
		
		ReserveId id = job.getReserveId();
		if (id == null) {
			// this job is not in reserve queue
			return true;
		}
		
		ReserveInfo info = rsvMgr.getReserveInfo(id);
		if (info == null) {
			// job with reserve, but ReserveManager doesn't know that reserve
			return false;
		}

		String jobOwner = job.getOwner();
		String rsvOwner = info.getOwner();
		if (rsvOwner.equals(jobOwner) == false) {
			// job submitter is not reserve owner
			return false;
		}
		
		// return state is RUNNING or not.
		// return false even if reserve is in it's period but it's
		// state is CANCELED or ERROR.
		return (info.getReserveState() == Running);
		
	}

}