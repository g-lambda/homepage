/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGENodeStatus;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEArch;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;

public class SGESimpleNodeStatus implements NodeStatus {

	private static String[] invalidHeads = { "HOSTNAME", "-", "global" };
	
	private String hostname;
	private OSType os;
	private ArchType arch;
	private int ncpu;
	private double loadavg;
	private long memtotal;
	private boolean isAlive;
	
	/*
	 * NOTE:
	 * 'qhost' shows hostname only (not FQDN)
	 * 'qconf -sel' and 'qstat -f' show FQDN always.
	 * We want to use FQDN always for Map key.
	 * 
	$ qhost
	HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
	-------------------------------------------------------------------------------
	global                  -               -     -       -       -       -       -
	ume00                   lx24-x86        2  0.00 1006.3M  136.2M    2.0G     0.0
	ume01                   lx24-x86        2  0.00 1006.3M  112.6M    2.0G     0.0
	ume02                   lx24-x86        2  0.01 1006.3M  112.4M    2.0G     0.0
	ume03                   lx24-x86        2  0.00 1006.3M  116.1M    2.0G     0.0
	ume04                   lx24-x86        2  0.00 1006.3M  118.5M    2.0G     0.0
	ume05                   lx24-x86        2  0.00 1006.3M  119.8M    2.0G     0.0
	ume06                   lx24-x86        2     - 1006.3M       -    2.0G       -
	ume07                   lx24-x86        2     - 1006.3M       -    2.0G       -
	
	host                    -               -     - -             -    -          -
	
	$ qconf -sel
	ume00.hpcc.jp
	ume01.hpcc.jp
	...
	 */
	
	private SGESimpleNodeStatus(String hostname, OSType os, ArchType arch,
			int ncpu, double loadavg, long memtotal, boolean isAlive) {
		
		assert(hostname.indexOf('.') > 0);
		
		this.hostname = hostname;
		this.os = os;
		this.arch = arch;
		this.ncpu = ncpu;
		this.loadavg = loadavg;
		this.memtotal = memtotal;
		this.isAlive = isAlive;
		
	}

	private SGESimpleNodeStatus(String hostname) {
	
		this(hostname, OSType.Unknown, ArchType.unknown, 1, 0.0, 0, false);
		
	}
	
	public static SGESimpleNodeStatus getInstance(String info, String fqdn) {
		
		if (checkValidInfo(info) == false)
			return null;

		String params[] = info.split("\\s+");
		if (params.length == 8) {
			/*
			String hostname = params[0];
			if (fqdn.startsWith(hostname + ".") == false) {
				return null;
			}
			*/
			if (params[3].equals("-") == false) {
				OSType os = SGEArch.getOSType(params[1]);
				ArchType arch = SGEArch.getArchType(params[1]);
				try {
					int ncpu = Integer.parseInt(params[2]);
					double loadavg = Double.parseDouble(params[3]);	// loadavg of 15min
					long memtotal = SGENodeStatus.getSize(params[4]);
					return new SGESimpleNodeStatus(fqdn, os, arch, ncpu, loadavg, memtotal, true);
				} catch (NumberFormatException e ) {
					// ignore, handle as down host
				}
			}
			return new SGESimpleNodeStatus(fqdn);
		}
		return null;
		
	}
	
	private static boolean checkValidInfo(String info) {
		
		for (String s : invalidHeads) {
			if (info.startsWith(s)) {
				return false;
			}
		}
		return true;
		
	}
	
	public boolean isAlive() {

		return isAlive;
		
	}

	public boolean isIdle() {

		return true;
		
	}

	public OSType getOSType() {
		
		return os;
		
	}

	public ArchType getArchType() {

		return arch;
		
	}

	public int getCPUNum() {

		return ncpu;
		
	}

	public double getLoadAverage() {

		return loadavg;
	}

	public long getPhysicalMemory() {

		return memtotal;
		
	}

	public int getIdleTime() {

		return 15*60 - (int)(15*60*loadavg);
		
	}

	public String getName() {

		return hostname;
		
	}

}
