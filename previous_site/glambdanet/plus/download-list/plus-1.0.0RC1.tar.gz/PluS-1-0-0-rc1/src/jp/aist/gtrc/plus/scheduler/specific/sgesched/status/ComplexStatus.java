/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.HashMap;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.w3c.dom.Node;

public class ComplexStatus extends XMLStatus {

	/*
	 *     <JB_hard_resource_list>
      <element name="qstat_l_requests">
        <CE_name>arch</CE_name>
        <CE_valtype>9</CE_valtype>
        <CE_stringval>lx26-x86</CE_stringval>
        <CE_doubleval>0.000000</CE_doubleval>
        <CE_relop>0</CE_relop>
        <CE_consumable>false</CE_consumable>
        <CE_dominant>0</CE_dominant>
        <CE_pj_doubleval>0.000000</CE_pj_doubleval>
        <CE_pj_dominant>0</CE_pj_dominant>
        <CE_requestable>0</CE_requestable>
        <CE_tagged>0</CE_tagged>
      </element>
    </JB_hard_resource_list>
	 */
	
	enum ValType {
		
		INTEGER(1),
		STRING(2),			// case sensitve string (use strcmp(3))
		TIME(3),
		MEMORY(4),
		BOOLEAN(5),
		CSTRING(6),		// case unsensitive string (use strcasecmp(3)) 
		HOST(7),			// host name string
		DOUBLE(8),
		RESTRING(9);		// regular expression
		
		private int type;
		private static Map<Integer, ValType> map
			= new HashMap<Integer, ValType>();
		static {
			for (ValType v : ValType.values()) {
				map.put(v.type, v);
			}
		}
		
		ValType(int type) {
			this.type = type;
		}
		
		public static ValType getValType(int type) {
			return map.get(type);
		}
		
	}
	
	enum RelationOpe {
		
		EQ(1),
		GE(2),
		GT(3),
		LT(4),
		LE(5),
		NE(6);
		
		private int ope;
		private static Map<Integer, RelationOpe> map
			= new HashMap<Integer, RelationOpe>();
		static {
			for (RelationOpe r : RelationOpe.values()) {
				map.put(r.ope, r);
			}
		}
		
		RelationOpe(int ope) {
			this.ope = ope;
		}
		
		public static RelationOpe getRelationOpe(int ope) {
			return map.get(ope);
		}
		
	}
	
	ComplexStatus(Node node) throws SchedulerException {
		
		super(node, "CE_");
		
	}
	
	public String getName() {
		
		return getString("name");
		
	}
	
	public ValType getValueType() {
		
		ValType v = ValType.getValType(getInt("valtype"));
		return (v != null) ? v : ValType.STRING;
		
	}
	
	public RelationOpe getRelationOpe() {
		
		RelationOpe r = RelationOpe.getRelationOpe(getInt("relop"));
		return (r != null) ? r : RelationOpe.EQ;
		
	}
	
	public String getStringVal() {
		
		return getString("stringval");
		
	}
	
	public double getDoubleVal() {
		
		return getDouble("doubleval");
		
	}

}
