/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

public class SGEACL {
	
	private SGEUserACL userAcl;
	private SGEProjectACL projAcl;
	
	// if acl is null, access is always permitted
	private static boolean DEFAULT_PERMISSION = true;
	
	SGEACL(SGEUserACL userAcl, SGEProjectACL projAcl) {
		
		this.userAcl = userAcl;
		this.projAcl = projAcl;
		
	}
	
	SGEACL(SGEUserACL userACL) {
		
		this(userACL, null);
		
	}
	
	public boolean isAllowedToUser(String username) {
		
		if (userAcl != null)
			return userAcl.isAllowed(username);
		else
			return DEFAULT_PERMISSION;
		
	}
	
	public boolean isAllowedToProject(String projname) {
		
		if (projAcl != null)
			return projAcl.isAllowed(projname);
		else
			return DEFAULT_PERMISSION;
		
	}
	
	public boolean isAllowedTo(String username, String projname) {
		
		return isAllowedToUser(username) && isAllowedToProject(projname);
		
	}
	
	public String toString() {
		
		String s = "";
		if (userAcl != null)
			s += "USER: " + userAcl.toString();
		if (projAcl != null)
			s += " ,PROJ: " + projAcl.toString();
		return s;
		
	}

}
