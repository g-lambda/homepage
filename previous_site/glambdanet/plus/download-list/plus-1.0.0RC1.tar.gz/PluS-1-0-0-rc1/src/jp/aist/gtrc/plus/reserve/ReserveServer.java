/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Calendar;


public interface ReserveServer extends Remote {

	public static final String RMI_OBJECT_NAME = "ReserveServer";

	public ReserveId reserve(ReserveRequest req) throws RemoteException, ReserveException;
	public void commit(ReserveId rsvId) throws RemoteException, ReserveException;
	public void abort(ReserveId rsvId) throws RemoteException, ReserveException;
	
	public ReserveStatus getStatus(ReserveId rsvId) throws RemoteException, ReserveException;
	public ReserveStatus[] getStatus(String owner, Calendar start, Calendar end, int nShowExpired) throws RemoteException, ReserveException;
	
	public void cancel(ReserveId rsvId) throws RemoteException, ReserveException;
	public void cancelOfOwner(String owner) throws RemoteException, ReserveException;
	
	public void modify(ReserveId rsvId, ReserveRequest req) throws RemoteException, ReserveException;
	
	public int availableNodeNum(Calendar start, Calendar end) throws RemoteException, ReserveException;

	public void destroy(ReserveId rsvId) throws RemoteException, ReserveException;
	public void destroyOfOwner(String owner) throws RemoteException, ReserveException;
	
	public void stopServer() throws RemoteException, ReserveException;

}