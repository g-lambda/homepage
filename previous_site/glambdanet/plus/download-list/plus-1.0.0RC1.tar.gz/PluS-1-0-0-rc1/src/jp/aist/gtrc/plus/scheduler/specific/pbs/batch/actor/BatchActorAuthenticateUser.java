/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.actor;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import jp.aist.gtrc.plus.scheduler.net.AcceptChecker;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply.BatchReply;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply.BatchReplyNull;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequest;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequestAuthenticateUser;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequestType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSErrorCode;


public class BatchActorAuthenticateUser  implements BatchActor{

	private AcceptChecker checker;

	public BatchActorAuthenticateUser(AcceptChecker checker){
		
		this.checker = checker;

	}

	public BatchReply operate(BatchRequest request, Socket socket){

		/*
		 * AuthenticateUser request must be sended from
		 * privilaged client port (<1024)
		 */
		int clientPort = socket.getPort();
		if (clientPort >= 1024)
			return new BatchReplyNull(PBSErrorCode.BADCRED);
		
		/*
		 * add client address to checker
		 */
		BatchRequestAuthenticateUser req
			= (BatchRequestAuthenticateUser)request;
		SocketAddress clientAddr = new InetSocketAddress(
				socket.getInetAddress(), req.getClientPort());
		checker.addAllowedClient(clientAddr);
		
		return new BatchReplyNull(PBSErrorCode.SUCCESS);

	}

	public BatchRequestType getRequestType() {

		return BatchRequestType.AuthenUser;
		
	}

}