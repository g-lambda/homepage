/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class SGEOperatord {
	
	private static final String OPED_PATH = "sge_operatord";
	private static final int OPED_PORT = 16000;
	private static final int MAX_TRY = 10;
	private static final int START_WAIT = 100;	// [msec]
	
	private Socket socket = null;
	private static int opedPort = 0;
	
	protected static Logger logger = Logger.getLogger(SGEOperatord.class);
	private static final String STREAM_CHARSET = "US-ASCII";


	public SGEOperatord() throws SchedulerException {

		if (opedPort == 0) {
			restart();
		}
		
	}

	private void restart() throws SchedulerException {
		
		checkStopped();
		opedPort = start();
		
	}
	
	private void checkStopped() {
		
		for (int port = OPED_PORT; port < OPED_PORT + MAX_TRY; port++) {
			try {
				connect(port);
				// oped is running now, shutdown it. 
				shutdown();
			} catch (SchedulerException e) {
				// oped is not running now, it's OK.
			}
		}
		
	}
	
	private int start() throws SchedulerException {

		for (int port = OPED_PORT; port < OPED_PORT + MAX_TRY; port++) {
			Runtime runtime = Runtime.getRuntime();
	
			String cmd[] = { OPED_PATH, Integer.toString(port) };
			Process proc;
			try {
				proc = runtime.exec(cmd);
			} catch (Exception e) {
				// ignore, try next port
				continue;
			}
			
			try {
				Thread.sleep(START_WAIT);
			} catch (InterruptedException e1) {
				// ignore
			}
			
			try {
				proc.exitValue();
				// proccess is dead now, maybe failed to port open
			} catch (IllegalThreadStateException e) {
				// process is running now, it's OK.
				logger.debug("sge_operatord at port " + port + " started");
				return port;
			}
		}
		
		throw new SchedulerException("Cannot start " + OPED_PATH);
		
	}
	
	private Socket connect(int port) throws SchedulerException {
		
		try {
			socket = new Socket("localhost", port);
			logger.debug("connected sge_operatord at port " + port);
			return socket;
		} catch (Exception e) {
			throw new SchedulerException("Cannot connect to sge_operatord at port " + port);
		}
		
	}
	
	public Socket connect() throws SchedulerException {
		
		try {
			return connect(opedPort);
		} catch (SchedulerException e) {
			restart();
			return connect(opedPort);
		}
		
	}

	public boolean isConnected() {
		
		return (socket != null) ? socket.isConnected() : false;
		
	}
	
	public void disconnect() {
		
		if (isConnected()) {
			try {
				sendRequest("Bye");
				socket.close();
				logger.debug("disconnected sge_operatord at port " + opedPort);
			} catch (Exception e) {
				// ignore
			}
			socket = null;
		}
			
	}
	
	public void shutdown() {
		
		if (isConnected()) {
			try {
				int port = socket.getPort();
				sendRequest("Shutdown");
				socket.close();
				logger.debug("sge_operatord at port " + port + " shutdowned");
			} catch (Exception e) {
				// ignore
			}
			socket = null;
		}
		
	}
	
	public void sendRequest(String data) throws SchedulerException {

		try {
			BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream(), STREAM_CHARSET));
			writer.write(data);
			writer.newLine();
			writer.flush();
			logger.debug("Sended: " + data);
		} catch (Exception e) {
			throw new SchedulerException(e.getMessage());
		}

	}

	public String receiveReply() throws SchedulerException {
		
		String data;
		try {
			BufferedReader reader = new BufferedReader(
				new InputStreamReader(socket.getInputStream(), STREAM_CHARSET));
			data = reader.readLine();
		} catch (Exception e) {
			throw new SchedulerException(e.getMessage());
		}
		
		logger.debug("Received: " + data);
		return data;
		
	}


}
