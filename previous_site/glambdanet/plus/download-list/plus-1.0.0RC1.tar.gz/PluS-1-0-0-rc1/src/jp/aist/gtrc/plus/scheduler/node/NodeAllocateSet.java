/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;

public class NodeAllocateSet {
	
	private int reqNum;
	private Collection<NodeResource> resources;
	private HashSet<NodeInfo> rsvdNodes;

	private NodeAllocateSet(int reqNum) {
		
		this.reqNum = reqNum;
		this.rsvdNodes = new HashSet<NodeInfo>();
		
	}
	
	public NodeAllocateSet(int reqNum, NodeResource resource) {
	
		this(reqNum);
		this.resources = new LinkedList<NodeResource>();
		this.resources.add(resource);
		
	}
	
	public NodeAllocateSet(int reqNum, Collection<NodeResource> resources) {
		
		this(reqNum);
		if ((resources != null) && (resources.size() > 0)) {
			this.resources = resources;
		} else {
			this.resources = new LinkedList<NodeResource>();
			NodeResource rsc = new NodeResource(1, 1);
			this.resources.add(rsc);
		}
		
	}
	
	public int getRequestedNum() {
		
		return reqNum;
		
	}
	
	public Collection<NodeResource> getRequestedResources() {
		
		return resources;
		
	}
	
	public boolean isAllocatedEnough() {
		
		return (rsvdNodes.size() >= reqNum);

	}
	
	public void addAllocatedNode(NodeInfo node) {
		
		assert(isAllocatedEnough() == false);
		if (rsvdNodes.contains(node) == false) {
			// duplicate allocation of same node is ignored
			rsvdNodes.add(node);
		} else {
			assert(false);
		}
		
	}
	
	public String toString() {
		
		return "reqnum=" + reqNum + ", allocatedNum=" + rsvdNodes.size() +
			", resources=" + resources.toString();
		
	}
	
}
