/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;


public class SGEQueueStatus extends XMLStatus implements HasACL, QueueStatus {

	private HashMap<String, SGEQInstance> instances;
	private SGEACL acl;
	private Collection<SGEHostGroup> hgroups;
	private HashMap<String, SGEParallelEnv> pes;
	private int qindex;
	private static SGEStatusManager statusMgr = SGEStatusManager.getInstance();

	public SGEQueueStatus(Node node) throws SchedulerException {
	
		super(node, "CQ_");
		if (instances == null) {
			instances = new LinkedHashMap<String, SGEQInstance>();
		}
		
	}
	
	protected void addNode(Node node) throws Exception {
		
		if (node.getNodeName().equals("CQ_qinstances") == false) {
			super.addNode(node);
			return;
		}
		
		if (instances == null) {
			instances = new LinkedHashMap<String, SGEQInstance>();
		}
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node sub = list.item(i);
			if (sub.getNodeType() != Node.ELEMENT_NODE)
				continue;
			SGEQInstance ins = new SGEQInstance(sub);
			// NOTE: hasInstanceOnNode() depends on key is fullname
			instances.put(ins.getFullName(), ins);
		}
		
	}
		
	public String getName() {
		return getString("name");
	}

	public boolean isReadyToUse() {
		return true;
	}

	public int getPriority() {
		return getInt("priority");
	}

	public void setQueueIndex(int index) {

		qindex = index;
		
	}

	public int getQueueIndex() {

		return qindex;
		
	}

	public Collection<SGEQInstance> getAllQInstances() {
		
		return instances.values();
		
	}
	
	public boolean hasInstanceOnNode(SGENodeStatus node) {
		
		// 'fullname' maybe "all.q@host00.example.com"
		String fullName = getName() + "@" + node.getName();
		return instances.containsKey(fullName);
		
	}
	
	private String[] getACLEntrys(String tag) {
		
		return getStringParams(tag, 1);
		
	}

	private SGEACL makeAcl() {
		
		SGEUserACL userAcl = SGEUserACL.getInstance(
				getACLEntrys("acl"), getACLEntrys("xacl"));
		SGEProjectACL projAcl = SGEProjectACL.getInstance(
				getACLEntrys("project"), getACLEntrys("xproject"));
		return new SGEACL(userAcl, projAcl);
		
	}
	
	public SGEACL getAcl() {
		
		if (acl == null)
			acl = makeAcl();
		return acl;
		
	}
	
	private HashMap<String, SGEParallelEnv> makeParallelEnvs() {
		
		HashMap<String, SGEParallelEnv> map = new HashMap<String, SGEParallelEnv>(); 
		String s[] = getStringParams("pe_list", 1);  // drop first "@/"
		for (String peName : s) {
			SGEParallelEnv pe = statusMgr.getParallelEnv(peName);
			if (pe != null) {
				map.put(peName, pe);
			} else {
				// invalid pe name, ignore.
			}
		}
		
		return map;

	}
	
	public HashMap<String, SGEParallelEnv> getParallelEnvs() {
		
		if (pes == null)
			pes = makeParallelEnvs();
		return pes;
		
	}
	
	public boolean hasParallelEnv(String peName) {
		
		return pes.containsKey(peName);
		
	}
	
	private Collection<SGEHostGroup> makeHostGroups() {
		
		LinkedList<SGEHostGroup> list = new LinkedList<SGEHostGroup>(); 
		String s[] = getStringParams("hostlist");
		for (String hgName : s) {
			SGEHostGroup hgroup = statusMgr.getHostGroup(hgName);
			if (hgroup != null) {
				list.add(hgroup);
			} else {
				// invalid hgroup name, ignore
			}
		}
		
		return list;
		
	}
	
	public Collection<SGEHostGroup> getHostGroups() {
		
		if (hgroups == null)
			hgroups = makeHostGroups();
		return hgroups;
		
	}
	
	public String toString() {
		
		String s = super.toString();
		s += "\nACL " + getAcl().toString();
		s += "\nPE ";
		for (SGEParallelEnv pe : getParallelEnvs().values())
			 s += pe.getName() + " ";
		s += "\nHostGroup ";
		for (SGEHostGroup hg : getHostGroups())
			 s += hg.getName() + " ";

		for (SGEQInstance ins : instances.values()) {
			s += '\n' + ins.toString();
		}
		
		return s;
	}

}
