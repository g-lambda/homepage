/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jp.aist.gtrc.plus.reserve.ReserveException;



public class PlusReserveOptions extends PlusReserveServerOption {

	private static final String OPT_TRANSACTION = "-T";
	protected static final String OPT_RSV_START = "-s";
	protected static final String OPT_RSV_END = "-e";
	//static final String OPT_RSV_START2 = "-R";		// PBSPro style
	//static final String OPT_RSV_END2 = "-E";		// PBSPro style
	private static final String OPT_RSV_DURATION = "-D";
	protected static final String OPT_RSV_NODENUM = "-n";
	protected static final String OPT_RSV_USERS = "-U";
	protected static final String OPT_REQ_MEM = "-mem";
	protected static final String OPT_REQ_CPUNUM = "-ncpu";
	protected static final String OPT_MAKE_PREPOSTQ = "-p";
	protected static final String OPT_SLOT_NUM = "-sn";
	protected static final String OPT_SHOW_SIMPLE = "-x";
	
	private static final String ISO8601_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ssZ";
	private static SimpleDateFormat iso8601Format;
	private static String localTimeZone;
	public static final int NO_DURATION = -1;
	
	
	public PlusReserveOptions(String appName) {
		
		super(appName);
		addOption(OPT_TRANSACTION, "act as 2-phase, need to use plus_commit/abort");
		addRequiredOption(OPT_RSV_START, "startTime", "Reservation start time, yyyy-MM-ddTHH:mm:ss{+-}zz:zz or [[[[CC]YY]MM]DD]hhmm[.SS]", null);
		addOption(OPT_RSV_END, "endTime", "Reservation end time", null);
		//addOption(OPT_RSV_START2, "startTime", "Reservation start time, [[[[CC]YY]MM]DD]hhmm[.SS]", null);
		//addOption(OPT_RSV_END2, "endTime", "Reservation end time", null);
		addOption(OPT_RSV_DURATION, "duration", "Reservation duration, [[hh:]mm:]ss", null);
		addRequiredOption(OPT_RSV_NODENUM, "nodeNum", "Number of reserve node", null);
		addOption(OPT_RSV_USERS, "users", "Reserve users, userA{,userB,...}", PlusReserveCommand.getMyname());
		addOption(OPT_REQ_MEM, "memSize", "requested memory size on reserved node [MB]", "1");
		addOption(OPT_REQ_CPUNUM, "cpuNum", "requested CPU num on reserved node", "1");
		addOption(OPT_MAKE_PREPOSTQ, "make R??pre, R??post queues also, SGE only");
		//addOption(OPT_SLOT_NUM, "slotNum", "number of slot of SGE reserve queue", null);
		addOption(OPT_SHOW_SIMPLE, "show reservation id only, if succeeded");
		
	}

	public boolean isTransaction() {
		
		return isOptionSet(OPT_TRANSACTION);
		
	}

	private static String getLocalTimeZone() {
		
		if (localTimeZone != null)
			return localTimeZone;
		
		// localTimeZone will be "+0900" etc.
		localTimeZone = String.format("%tz", new Date());  
		return localTimeZone;
		
	}
	
	public static Calendar makeCalendarFromISO8601(String arg) {
		
		if ((arg == null) || (arg.length() == 0))
			return null;

		/*
		 * make Calendar object from ISO8601 format date&time string.
		 * See http://www.w3.org/TR/NOTE-datetime
		 * 
		 * This function support:
		 * 		"yyyy-MM-ddTHH:mm:ss+zz:zz" or "...-zz:zz"
		 * 		"yyyy-MM-ddTHH:mm:ss+zzzz"  or "...-zzzz"
		 * 		"yyyy-MM-ddTHH:mm:ssZ"	(interpret as UTC)
		 * 		"yyyy-MM-ddTHH:mm:ss"	(interpret as local time)
		 * 1st ant 3rd are strict ISO8601 format,
		 * 2nd and 4th are not but we support them.
		 *
		 * ex:  "1994-11-05T08:15:30-05:00"
		 * digit 0123456789012345678901234
		 * Note: Java timezone format is "{+-}zzzz", without ":".
		 */

		String date;
		int i = arg.lastIndexOf(':');
		if (i == 22) {
			// arg may be "yyyy-MM-ddTHH:mm:ss+zz:zz" [strict ISO8601]
			if (arg.length() != 25)
				return null;
			// cut ':' in timezone for Java interpretation
			date = arg.substring(0, 22) + arg.substring(23);
			// date is "yyyy-MM-ddTHH:mm:ss+zzzz"
		} else if (i == 16) {
			if (arg.charAt(arg.length()-1) == 'Z') {
				// arg may be "yyyy-MM-ddTHH:mm:ssZ" [strict ISO8601 also]
				// time is expressed in UTC
				date = arg.substring(0, arg.length()-1) + "+0000";
				// date is "yyyy-MM-ddTHH:mm:ss+0000"
			} else if (arg.length() == 19) {
				date = arg + getLocalTimeZone();
				// date is "yyyy-MM-ddTHH:mm:ss+zzzz" or "..-zzzz"
			} else {
				// arg may be "yyyy-MM-ddTHH:mm:ss+zzzz"
				date = arg;
			}
		} else {
			return null;
		}
		
		try {
			Calendar c = Calendar.getInstance();
			if (iso8601Format == null)
				iso8601Format = new SimpleDateFormat(ISO8601_FORMAT_PATTERN);
			c.setTime(iso8601Format.parse(date));
			return c;
		} catch (ParseException e) {
			return null;
		}
		
	}
	
	public static Calendar makeCalendarFromHHmm(String arg) {

		if ((arg == null) || (arg.length() == 0))
			return null;
		
		/*
		 * [1] TIME format:
		 * 	[a]	hh:mm		(hh as 24-hour format always) 
		 * 	[b]	hh:mm:ss
		 * [2] DATE format
		 * 	[a]	DD
		 * 	[b]	DD/MM
		 *	[c]	DD/MM/YY	(year as 20YY, ex: 05 means 2005)
		 *	[d]	DD/MM/YYYY
		 *
		 * arg format: TIME or TIME_DATE
		 * 	[1a]	hh:mm
		 * 	[1b]	hh:mm:ss
		 * 	[1a+2a]	hh:mm_DD
		 * 	[1a+2b]	hh:mm_DD/MM
		 * 	[1a+2c]	hh:mm_DD/MM/YY
		 * 	[1a+2d]	hh:mm_DD/MM/YYYY
		 * 	[1b+2a]	hh:mm:ss_DD
		 * 	[1b+2b]	hh:mm:ss_DD/MM
		 * 	[1b+2c]	hh:mm:ss_DD/MM/YY
		 * 	[1b+2d]	hh:mm:ss_DD/MM/YYYY
		 */
		
		// set c as now
		Calendar c = Calendar.getInstance();

		/*
		 * Split time & date
		 */
		String x[] = arg.split("_");
		if ((x.length == 0) || (x.length > 2))
			return null;
		String time, date;
		time = x[0];
		date = (x.length == 2) ? x[1] : null;
		
		try {
			/*
			 * Split time to hh:mm or hh:mm:ss
			 */
			String y[] = time.split(":");
			int sec = 0;
			switch(y.length) {
			case 3:
				sec = Integer.parseInt(y[2]);
				// fall-through
			case 2:
				c.set(Calendar.MILLISECOND, 0);
				c.set(Calendar.SECOND, sec);
				int min = Integer.parseInt(y[1]);
				if ((min < 0) || (60 <= min))
					return null;
				c.set(Calendar.MINUTE, min);
				int hour = Integer.parseInt(y[0]);
				if ((hour < 0) || (24 <= hour))
					return null;
				c.set(Calendar.HOUR_OF_DAY, hour);
				break;
			default:
				return null;
			}
			c.set(Calendar.MILLISECOND, 0);
	
			/*
			 * Split date to DD/MM/YYYY
			 */
			if (date != null) {
				String z[] = date.split("/");
				switch(z.length) {
				case 3:
					int year = Integer.parseInt(z[2]);
					if (year < 0)
						return null;
					if (year < 100)
						year += 2000;
					c.set(Calendar.YEAR, year);
					// fall-through
				case 2:
					int month = Integer.parseInt(z[1]);
					if ((month < 0) || (12 < month))
						return null;
					// MONTH value must be 0...11
					c.set(Calendar.MONTH, month -1);
					// fall-through
				case 1:
					int day = Integer.parseInt(z[0]);
					if ((day < 0) || (31 < day))
						return null;
					c.set(Calendar.DAY_OF_MONTH, day);
					break;
				default:
					return null;
				}
			}
		} catch (final NumberFormatException e) {
			// parseInt() failed
			return null;
		}
		
		return c;
	
	}
	
	public static Calendar makeCalendarFromPOSIX(String arg) {

		if ((arg == null) || (arg.length() == 0))
			return null;
		
		/*
		 * [[[[CC]YY]MM]DD]hhmm[.SS]
		 * 
		 * ex: "Thu Jun  1 16:27:50 JST 2006" is equal to
		 * 		"200606011627.50"		(length = 15)
		 * 		  "0606011627.50"		(length = 13)
		 * 		    "06011627.50"		(length = 11)
		 * 		      "011627.50"		(length = 9)
		 * 		        "1627.50"		(length = 7)
		 * 
		 * ex: "Thu Jun  1 16:27:00 JST 2006" is equal to
		 * 		"200606011627.00"  "200606011627" 
		 * 		  "0606011627.00"    "0606011627"
		 * 		    "06011627.00"      "06011627"
		 * 		      "011627.00"        "011627"
		 * 		        "1627.00"          "1627"
		 */		        

		int length = arg.length();
		if ((length < 4) || (15 < length))
			return null;
		
		if (arg.charAt(length - 3) != '.') {
			arg = arg + ".00";
			length = arg.length();
		}
		
		Calendar c = Calendar.getInstance();
		
		try {
			switch (length) {
			case 15:	// "CCYYMMDDhhmm.SS"
				c.set(Calendar.YEAR, Integer.parseInt(arg.substring(0, 4)));
				break;
			case 13:  // "YYMMDDhhmm.SS"
				c.set(Calendar.YEAR, 2000 + Integer.parseInt(arg.substring(0, 2)));
				break;
			case 11:	// "MMDDhhmm.SS"
				int now_MM = c.get(Calendar.MONTH);
				int arg_MM = Integer.parseInt(arg.substring(0, 2));
				if (arg_MM < now_MM) {
					// set 'c' as next year
					c.add(Calendar.YEAR, 1);
				}
				break;
			case 9:	// "DDhhmm.SS"
				int now_DD = c.get(Calendar.DAY_OF_MONTH);
				int arg_DD = Integer.parseInt(arg.substring(0, 2));
				if (arg_DD < now_DD) {
					// set 'c' as next month
					c.add(Calendar.MONTH, 1);
				}
				break;
			case 7:	// "hhmm.SS"
				int now_hhmm = 100 * c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE);
				int arg_hhmm = Integer.parseInt(arg.substring(0, 4));
				if (arg_hhmm < now_hhmm) {
					// set 'c' as tomorrow
					c.add(Calendar.DAY_OF_MONTH, 1);
				}
				break;
			default:
				break;
			}
			
			int index = 0;
			switch (length) {
			case 15:	// "CCYYMMDDhhmm.SS"
				index += 2;
				// fall through
			case 13:  // "YYMMDDhhmm.SS"
				index += 2;
				// fall through
			case 11:	// "MMDDhhmm.SS"
				c.set(Calendar.MONTH, Integer.parseInt(arg.substring(index, index + 2)) -1);
				index += 2;
				// fall through
			case 9:	// "DDhhmm.SS"
				c.set(Calendar.DAY_OF_MONTH, Integer.parseInt(arg.substring(index, index + 2)));
				index += 2;
				// fall through
			case 7:	// "hhmm.SS"
				c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(arg.substring(index, index + 2)));
				index += 2;
				c.set(Calendar.MINUTE, Integer.parseInt(arg.substring(index, index + 2)));
				index += 3;	// skip "mm."
				c.set(Calendar.SECOND, Integer.parseInt(arg.substring(index, index + 2)));
				c.set(Calendar.MILLISECOND, 0);
				break;
			default:
				return null;
			}
		
			return c;
		} catch (NumberFormatException e) {
			return null;
		}

	}
	
	public static Calendar makeCalendar(String arg) {
		
		Calendar c;
		/*
		c = makeCalendarFromHHmm(arg);
		if (c != null)
			return c;
		*/

		c = makeCalendarFromISO8601(arg);
		if (c != null)
			return c;
		
		c = makeCalendarFromPOSIX(arg);
		if (c != null)
			return c;
		
		return null;
		
	}
	
	private Calendar getTime(String optKey, String optName) throws ReserveException {
		
		String s = getOptionValue(optKey);
		if (s != null) {
			Calendar c = makeCalendar(s);
			if (c != null) {
				return c;
			} else {
				throw new ReserveException("invalid " + optName + ": " + s);
			}
		} else {
			return null;
		}
		
	}
	
	public Calendar getStartTime() throws ReserveException {
		
		return getTime(OPT_RSV_START, "startTime");
			
	}
	
	public Calendar getEndTime() throws ReserveException {
		
		return getTime(OPT_RSV_END, "endTime");
		
	}
	
	public int getDuration() throws ReserveException {
		
		String d = getOptionValue(OPT_RSV_DURATION);
		if (d == null)
			return NO_DURATION;
		
		String s[] = d.split(":");
		try {
			int sec, min = 0, hour = 0, index = 0; 
			switch (s.length) {
			case 3:
				hour = Integer.parseInt(s[index]);
				if (hour < 0) {
					throw new ReserveException("hour must be positive");
				}
				index++;
				// fall-through
			case 2:
				min = Integer.parseInt(s[index]);
				if (min < 0) {
					throw new ReserveException("minute must be positive");
				}
				index++;
				// fall-through
			case 1:
				sec = Integer.parseInt(s[index]);
				if (sec < 0) {
					throw new ReserveException("second must be positive");
				}
				break;
			default:
				throw new ReserveException("invalid duration description: " + d);
			}
			return 3600 * hour + 60 * min + sec;
		} catch (NumberFormatException e) {
			throw new ReserveException("invalid duration description: " + d);
		}
		
	}
	
	public int getNodeNum() throws ReserveException {
		
		String n = getOptionValue(OPT_RSV_NODENUM);
		if ((n != null) && (n.length() > 0)) {
			try {
				return Integer.parseInt(n);
			} catch (NumberFormatException e) {
				throw new ReserveException("invalid node num: " + n);
			}
		} else {
			return 0;
		}

	}
	
	protected String[] getDefaultUsers() {
		
		return new String[]{ PlusReserveCommand.getMyname() };
		
	}
	
	public String[] getUsers() {
		
		String u = getOptionValue(OPT_RSV_USERS);
		if (u == null) {
			return getDefaultUsers();
		} else {
			return u.split(",");
		}
		
	}
	
	public boolean isShowSimple() {
		
		return isOptionSet(OPT_SHOW_SIMPLE);
		
	}
	
	public boolean isMakePrePostQueue() {
		
		return isOptionSet(OPT_MAKE_PREPOSTQ);
		
	}
	
	public long getMemorySize() throws ReserveException {
		
		String n = getOptionValue(OPT_REQ_MEM);
		if ((n != null) && (n.length() > 0)) {
			try {
				long size = 1024 * 1024 * Integer.parseInt(n);
				if (size <= 0) {
					throw new ReserveException("memory size must be positive");
				}
				return size;
			} catch (NumberFormatException e) {
				throw new ReserveException("invalid memory size: " + n);
			}
		} else {
			return 1024 * 1024;	// 1MB memory
		}
		
	}
	
	public int getCPUNum() throws ReserveException {
		
		String n = getOptionValue(OPT_REQ_CPUNUM);
		if ((n != null) && (n.length() > 0)) {
			try {
				int num = Integer.parseInt(n);
				if (num <= 0) {
					throw new ReserveException("CPU num must be positive");
				}
				return num;
			} catch (NumberFormatException e) {
				throw new ReserveException("invalid CPU num: " + n);
			}
		} else {
			return 1;	// 1 CPU core
		}
		
	}
	
	public int getSlotNum() throws ReserveException {
		
		String n = getOptionValue(OPT_SLOT_NUM);
		if ((n != null) && (n.length() > 0)) {
			try {
				int num = Integer.parseInt(n);
				if (num <= 0) {
					throw new ReserveException("slot num must be positive");
				}
				return num;
			} catch (NumberFormatException e) {
				throw new ReserveException("invalid slot num: " + n);
			}
		} else {
			return 0;
		}
		
	}
	
}
