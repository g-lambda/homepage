/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.status;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.job.JobID;
import jp.aist.gtrc.plus.scheduler.job.JobStateType;
import jp.aist.gtrc.plus.scheduler.node.ExecNodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.specific.pbs.job.PBSJobID;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;

//	attr			value
//	-----------------------------
//	14.koume.hpcc.jp	27
//		Job_Name		STDIN
//		Job_Owner		ohkubo@koume.hpcc.jp
//		job_state		Q
//		queue			workq
//		server			koume.hpcc.jp
//		Checkpoint		u
//		ctime			1124952952
//		Error_Path		koume.hpcc.jp:/home/ohkubo/STDIN.e14
//		Hold_Types		n
//		Join_Path		n
//		Keep_Files		n
//		Mail_Points		a
//		mtime			1124952952
//		Output_Path		koume.hpcc.jp:/home/ohkubo/STDIN.o14
//		Priority		0
//		qtime			1124952952
//		Rerunable		True
//		Resource_List	ncpus	1
//		Resource_List	nodect	1
//		Resource_List	walltime	00:15:00
//		substate		2
//		Variable_List	PBS_O_HOME=/home/ohkubo....
//		euser			ohkubo
//		egroup			ohkubo
//		queue_rank		5
//		queue_type		E
//		etime			1124952952
//		x				rsvid:123


public class PBSJobStatus extends StatusMap implements JobStatus {

	class RequestNodeSpec {
		
		private int nodeNum, procPerNode, cpuPerNode;
		
		RequestNodeSpec(String spec) {

			assert(spec != UNKNOWN_STATUS);
			nodeNum = procPerNode = cpuPerNode = 1;

			/*
			 * 'spec'				node	proc	cpu
			 * ------------------------------------------
			 * "x"					x		1		1
			 * "x:ppn=y"			x		y		1
			 * "x:ncpus=z"		x		1		z
			 * "x:ppn=y:ncpus=z"	x		y		z
			 * "ppn=y"				1		y		1
			 * "ncpus=z"			1		1		z
			 * "ppn=y:ncpus=z"	1		y		z
			 * 
			 * x, y, z must be integer.
			 * ex: 'spec' = "1:ppn=3:ncpus=2" means
			 * run 3 process on a dual CPU node.
			 */
			String s[] = spec.split(":");
			for (int i = 0; i < s.length; i++) {
				String t[] = s[i].split("=");
				switch (t.length) {
				case 1:
					try {
						nodeNum = Integer.parseInt(s[i]);
					} catch (NumberFormatException e) {
						// TODO: maybe s[i] is hostname, not supported
						// ignore to continue
					}
					break;
				case 2:
					try {
						if (t[0].equals("ppn")) {
							procPerNode = Integer.parseInt(t[1]);
						} else if (t[0].equals("ncpus")) {
							cpuPerNode = Integer.parseInt(t[1]);
						} else {
							// invalid key is specified, ignore
						}
					} catch (NumberFormatException e) {
						// ignore to continue
					}
					break;
				default:
					break;
				}
			}
			
		}
		
		int getNodeNum() {
			return nodeNum;
		}
		
		int getProcPerNode() {
			return procPerNode;
		}

		int getCPUPerNode() {
			return cpuPerNode;
		}
		
	}
	
	private QueueStatus queue;
	private boolean rsvIdChecked = false;
	private ReserveId rsvId;
	private LinkedList<RequestNodeSpec> reqNodeSpecs;
	private LinkedList<NodeAllocateSet> reqAllocSet;
	private OSType reqOS;
	private ArchType reqArch;
	
	private static final String RES_LIST = "Resource_List";
	private static final String RSVID_KEY = "rsvid";
	
	public PBSJobStatus(String name){
		
		super(name);

		//makeRequestNodeSpecs();
		//makeReserveId();
		
	}
	
	public String getQueueName() {
		
		return getStatus("queue");
		
	}

	public void setQueueStatus(QueueStatus queue) {
		
		/*
		 * set queue of this job is connected.
		 * use getQueueStatus().getPriority() to know queue priority.
		 */
		String qname = getQueueName();
		if (qname != UNKNOWN_STATUS) {
			if (qname.equals(queue.getName()) == false) {
				logger.debug("invalid queue name: " + queue.getName() +
						", must be " + qname);
				return;
			}
		}
		this.queue = queue;
		
	}
	
	public QueueStatus getQueueStatus() {
		
		return queue;
		
	}
	
	public JobID getJobID() {

		// "100.pbsserver.example.com" etc
		return new PBSJobID(getName());

	}

	public String getJobName(){

		// "STDIN" or user specified name
		return getStatus("Job_Name");

	}

	public String getOwner(){

		return getStatus("euser");
		
	}
	
	public String getOwnersGroup(){

		return getStatus("egroup");
		
	}

	public String getOwnersHost(){

		String s[] = getStatus("Job_Owner").split("@");
		if (s.length == 2)
			return s[1];
		else {
			logger.debug("Invalid Job_Owner: " + getStatus("Job_Owner"));
			return "";
		}
		
	}

	public String getJobState(){

		return getStatus("job_state");

	}

	public boolean isQueued(){

		return getJobState().equals("Q");

	}

	public boolean isRunning(){

		return getJobState().equals("R");

	}
	
	public boolean isHolded() {
		
		// "n": not holded, runnable if in queue
		// "u", "o", "s": holded, not runnable
		return (getStatus("Hold_Types").equals("n") == false);
		
	}
	
	public boolean isReadyToRun() {
		
		return (isQueued() && !isHolded());
		
	}

	public int getPriority(){

		String p = getStatus("Priority");
		if (p != UNKNOWN_STATUS)
			return Integer.parseInt(p);
		else
			return 0;

	}
	
	public void setPriority(int priority) {
		
		/*
		 * StarvedJobHelper changes job priority
		 * if it is starved.
		 */
		putStatus("Priority", Integer.toString(priority));
				
	}

	private void addRequestNodeSpec(RequestNodeSpec spec) {
		
		reqNodeSpecs.add(spec);
		NodeResource rsc = new NodeResource(
				spec.getCPUPerNode(), spec.getProcPerNode(),
				getRequestedArchType(), getRequestedOSType());
		NodeAllocateSet set = new NodeAllocateSet(spec.getNodeNum(), rsc);
		reqAllocSet.add(set);
		
	}
	
	private void makeRequestNodeSpecs() {
		
		reqNodeSpecs = new LinkedList<RequestNodeSpec>();
		reqAllocSet = new LinkedList<NodeAllocateSet>();
		
		String s = getStatus(RES_LIST, "nodes");
		if (s != UNKNOWN_STATUS) {
			for (String specTxt : s.split("\\+")) {
				addRequestNodeSpec(new RequestNodeSpec(specTxt)); 
			}
		} else {
			addRequestNodeSpec(new RequestNodeSpec("1"));
		}
		
	}
	
	public Collection<NodeAllocateSet> getNodeRequests() {
		
		if (reqAllocSet == null)
			makeRequestNodeSpecs();
		return reqAllocSet;
		
	}

	public String getRawNodeRequests() {
		
		String s = getStatus(RES_LIST, "nodes");
		if (s == UNKNOWN_STATUS) {
			assert(false);
			s = "1";
		}		
		return s;
		
	}

	public int getRequestedTime(){

		String s = getStatus(RES_LIST, "walltime");
		if (s != UNKNOWN_STATUS) {
			String t[] = s.split(":");
			if (t.length == 3) {
				return 3600 * Integer.parseInt(t[0])
					+ 60 * Integer.parseInt(t[1])
					+ Integer.parseInt(t[2]);	// [sec]
			}
		}

		// Unknown or invalid time format
		return 3600; // [sec] 
	
	}
	
	private OSType getRequestedOSType() {
		
		if (reqOS != null)
			return reqOS;

		reqOS = OSType.Unknown;
		String s = getStatus(RES_LIST, "arch");
		if (s != UNKNOWN_STATUS) {
			s = s.toLowerCase();
			if (s.indexOf("linux") != -1)
				reqOS = OSType.Linux;
			else if ((s.indexOf("solaris") != -1) || (s.indexOf("sunos") != -1))
				reqOS = OSType.Solaris;
		}
		
		return reqOS;
		
	}
	
	private ArchType getRequestedArchType() {
		
		if (reqArch != null)
			return reqArch;

		reqArch = ArchType.unknown;
		String s = getStatus(RES_LIST, "arch");
		if (s != UNKNOWN_STATUS) {
			s = s.toLowerCase();
			ArchType archs[] = ArchType.values();
			/*
			 * Search from tail.
			 * If 'arch' is "sparc64", we want to get sparc64, not sparc.
			 */
			for (int i = archs.length -1; i >= 0; i--) {
				ArchType arch = archs[i];
				if (s.indexOf(arch.name()) != -1) { 
					reqArch = arch;
					break;
				}
			}
		}
			
		return reqArch;
		
	}

	public String getProperties() {
		
		return getStatus("properties");
		
	}
	
	public boolean isRunnableOn(NodeStatus node){
		
		ExecNodeAllocator allocator = new ExecNodeAllocator();
		return allocator.isReadyToRun((JobStatus)this, node);

	}

	public Date getSubmitTime() {

		String t = getStatus("ctime");
		if (t != UNKNOWN_STATUS)
			return new Date(1000 * Long.parseLong(t));
		else
			return new Date(0);
		
	}

	private void makeReserveId() {
		
		/*
		 * To make reservation: way-1 (same as PBSPro)
		 *	> plus_reservee -s .....
		 *	... Reserve id is Rxxx
		 * 
		 * Submit job to reserve queue, use -q option of qsub
		 * 	> qsub ... -q Rxxx
		 * 
		 * This method returns "Rxxx" as ReserveId of the job.
		 */
		String qname = getQueueName();
		if (qname.charAt(0) == 'R') {
			rsvId = ReserveId.getInstance(qname);
			if (rsvId != null)
				return;
		}
		
		/*
		 * To make reservation: way-2 (same as Maui)
		 *	> plus_reservee -s .....
		 *	... Reserve id is Rxxx
		 * 
		 * Submit job to reserve queue, use -x option of qsub
		 * 	> qsub ... -W x=rsvid:Rxxx
		 * 
		 * This method returns "Rxxx" as ReserveId of the job.
		 */
		String s = getStatus("x");
		if (s != UNKNOWN_STATUS) {
			// s maybe "rsvid:Rxxx", Rxxx is ReserveId
			String v[] = s.split(":");
			if ((v.length == 2) && (v[0].equalsIgnoreCase(RSVID_KEY))) {
				rsvId = ReserveId.getInstance(v[1]);
			}
		}
		
	}
	
	public ReserveId getReserveId() {

		if (rsvIdChecked == false) {
			makeReserveId();
			rsvIdChecked = true;
		}
		return rsvId;

	}
	
	public JobStateType getState() {
		
		String s = getJobState();
		if (s.equals("Q"))
			return JobStateType.Queued;
		if (s.equals("R"))
			return JobStateType.Running;
		if (s.equals("E"))
			return JobStateType.Exiting;
		if (s.equals("H"))
			return JobStateType.Held;
		if (s.equals("S"))
			return JobStateType.Suspended;
		
		return JobStateType.Queued;
		
	}

}