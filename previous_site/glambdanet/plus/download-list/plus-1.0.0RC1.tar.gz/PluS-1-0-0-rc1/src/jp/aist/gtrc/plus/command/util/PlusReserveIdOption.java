/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command.util;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;

class PlusReserveIdOption extends PlusReserveServerOption {

	protected static final String OPT_TRANSACTION = "-T";
	protected static final String OPT_RSV_ID = "-r";
	private static final String SAMPLE_RSV_ID = ReserveId.RSVID_PREFIX + "123"; 
	
	protected PlusReserveIdOption(String appName) {
		
		super(appName);
		addOption(OPT_TRANSACTION, "act as 2-phase, need to use plus_commit/abort");
		addOption(OPT_RSV_ID, "reserveId", "Reservation ID (ex: \""
				+ SAMPLE_RSV_ID + "\")", "");
		
	}
	
	public boolean isTransaction() {
		
		return isOptionSet(OPT_TRANSACTION);
		
	}

	public ReserveId getReserveId() throws ReserveException {
	
		if (isOptionSet(OPT_RSV_ID)) {
			ReserveId rsvId = ReserveId.getInstance(getOptionValue(OPT_RSV_ID));
			if (rsvId != null) {
				return rsvId;
			} else {
				throw new ReserveException("Invalid reserve id, must be "
						+ SAMPLE_RSV_ID + " etc");
			}
		} else {
			return null;
		}
			
	}
	
}
