/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import java.net.URL;


import org.apache.log4j.PropertyConfigurator;

public class MainApp {

	private static void loginit() {
		
		URL url = ClassLoader.getSystemResource("log4j.properties");
		if (url != null) {
			PropertyConfigurator.configure(url);
		} else {
			System.err.println("log4j.properties not found");
			System.exit(1);
		}
			
		
	}

	public static PluScheduler makeScheduler(String[] args) throws Exception {
		
		SchedulerOptions options = new SchedulerOptions(args);
		String type = options.getTargetSystem(); 
		
		if (type.equals("pbs"))
			return new PBSScheduler(args);
		if (type.equals("sge"))
			return new SGEQbaseScheduler(args);
		if (type.equals("sgesched"))
			return new SGESelfScheduler(args);

		throw new Exception("Unknown scheduler type: " + args[0]);
		
	}
	
	public static void main(String[] args){
		
		loginit();
		
		try {
			PluScheduler scheduler = makeScheduler(args);
			scheduler.run();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
		
	}

}