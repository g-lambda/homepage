/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

public enum OSType {

	Linux,
	Linux_22,
	Linux_24,
	Linux_26,
	
	Solaris,
	Solaris_8,
	Solaris_9,
	Solaris_10,
	
	Windows,
	Windows_2000,
	Windows_XP,
	
	/*
	NetBSD,
	FreeBSD,
	
	HPUX,
	HPUX_10,
	HPUX_11,
	*/
	
	Unknown;
	
	public boolean isMatch(OSType other) {
		
		switch(other) {
		case Linux:
			switch(this) {
			case Linux:
			case Linux_22:
			case Linux_24:
			case Linux_26:
				return true;
			default:
				return false;
			}
		case Solaris:
			switch(this) {
			case Solaris:
			case Solaris_8:
			case Solaris_9:
			case Solaris_10:
				return true;
			default:
				return false;
			}
		case Windows:
			switch(this) {
			case Windows:
			case Windows_2000:
			case Windows_XP:
				return true;
			default:
				return false;
			}
		case Unknown:
			return true;
		}
		
		return (this == other);
		
	}
	
}
