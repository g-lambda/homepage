/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import java.net.URL;
import java.util.Collection;

import org.apache.log4j.PropertyConfigurator;

import jp.aist.gtrc.plus.scheduler.mainsrv.MainServer;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSScheduleStarter;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEScheduleStarter;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.ServerStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;


public class SimpleFifoScheduler {

	private static void loginit() {
		
		URL url = ClassLoader.getSystemResource("log4j.properties");
		PropertyConfigurator.configure(url);
		
	}


	public static ScheduleStarter makeStarter(String[] args) throws Exception {
		
		String type = (args.length == 0) ? "pbs" : args[0].toLowerCase();

		if (type.equals("pbs"))
			return new PBSScheduleStarter();
		if (type.equals("sge"))
			return new SGEScheduleStarter();

		throw new Exception("Unknown scheduler type: " + args[0]);
		
	}

	public static void main(String[] args) {

		try {
			loginit();
			
			// start scheduling server
			ScheduleStarter starter = makeStarter(args);

			// get scheduling order, and run
			ScheduleOrder order = null;
			do {
				order = starter.waitOrder();
				MainServer srv = order.getMainServer();
				if (order.mustRunSchedule()) {
					try {
						schedule(srv);
					} catch (SchedulerException e) {
						// ignore to continue scheduling
					}
				}
				srv.disconnect();
			} while (order.toBeQuit() == false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static void schedule(MainServer srv) throws SchedulerException {
		
		ServerStatus server = srv.getServerStatus();
		if (!server.isReadyToUse())
			return;
		
		Collection<NodeStatus> nodes = srv.getNodeStatus();
		for (QueueStatus queue : srv.getQueueStatus()) {
			if (!queue.isReadyToUse())
				continue;
			
			for (JobStatus job : srv.getJobStatus(queue)) {
				if (!job.isReadyToRun()) {
					// cannot run now, or already running/exiting
					continue;
				}
				for (NodeStatus node : nodes) {
					if (!job.isRunnableOn(node)) {
						// node is down, or not enough to run this job
						continue;
					}
					srv.runJob(job.getJobID(), node);
					return;
				}
			}

		}
		
	}

}
