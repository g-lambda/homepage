/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchOperationType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISEncoder;

public class BatchRequestManage extends BatchRequest {

	public enum ManagerCommandType{
		CREATE(0),
		DELETE(1),
		SET(2),
		UNSET(3),
		LIST(4),
		PRINT(5),
		ACTIVE(6);
		
		private int value;
		
		ManagerCommandType(int value){
			this.value = value;
		}
		
		int value() {
			return value;
		}
	}

	private ManagerCommandType cmd;
	private BatchObjectType objType;
	private String objName;
	private String attr;
	private String rsc;
	private String value;
	private BatchOperationType opeType;
		
	public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType,
			String objName, String attr, String rsc, String value){
		
		super();
		this.cmd = cmd;
		this.objType = objType;
		this.objName = objName;
		this.attr = attr;
		this.rsc = rsc;
		this.value = value;
		this.opeType = null;
		
	}
	
	public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType,
			String objName, String attr, String value){
		
		this(cmd, objType, objName, attr, null, value);
		
	}

	public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType,
			String objName){
		
		this(cmd, objType, objName, null, null, null);
		
	}

	public void setBatchOperationType(BatchOperationType opeType) {
		
		this.opeType = opeType;
		
	}
	
	protected void encodeBody(DISEncoder encoder){

		encoder.putInt(cmd.value());
		encoder.putInt(objType.value());
		encoder.putString(objName);
		encoder.putAttrRscValue(attr, rsc, value);
		if (opeType != null) {
			encoder.putInt(opeType.value());
		}

	}

	public BatchRequestType getRequestType() {
		
		return BatchRequestType.Manager;
		
	}

}