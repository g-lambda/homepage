/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.w3c.dom.Node;

public class SGEGrantedQueue extends XMLStatus {

	SGEGrantedQueue(Node node) throws SchedulerException {
		
		super(node, "JG_");
		
	}

	public String getName() {

		return getQName();
		
	}
	
	/*
	 *	<JG_qname>all.q@uml2.suri.co.jp</JG_qname>
	 *	<JG_qversion>0</JG_qversion>
	 *	<JG_qhostname>uml2.suri.co.jp</JG_qhostname>
	 *	<JG_slots>1</JG_slots>
	 *	<JG_queue></JG_queue>
	 *	<JG_tag_slave_job>0</JG_tag_slave_job>
	 *	<JG_task_id_range>0</JG_task_id_range>
	 *	...
	 */
	
	public String getQName() {
		
		return getString("qname");
		
	}
	
	public String getQVersion() {
		
		return getString("qversion");
		
	}
	
	public String getQHostname() {
		
		return getString("qhostname");
		
	}
	
	public int getSlotNum() {
		
		return getInt("slots");
		
	}

}
