/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.job.SGEJobID;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEArch;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class SGENodeStatus extends XMLStatus implements HasACL, NodeStatus {

	class LoadStatus extends XMLStatus {

		LoadStatus(Node n) throws SchedulerException {
			super(n, "HL_");
		}

		public String getName() {
			return getString("name");
		}
		public String getValue() {
			return getString("value");
		}
		public int getLastUpdate() {
			return getInt("last_update");
		}
	
		public String toString() {
			return String.format("%14s %12s  (update at %d)",
					getName(), getValue(), getLastUpdate());
		}
		
	}
	
	class ReschedUnknown extends XMLStatus {
		
		static final int SKIP_JR_REMOVE		= 0x00000000;
		static final int SKIP_JR_SEND_ACK	= 0x00000001;
		static final int SKIP_JR				= 0x00000002;
		static final int HANDLE_JR_REMOVE	= 0x00000004;
		static final int HANDLE_JR_WAIT		= 0x00000008;
		
		ReschedUnknown(Node n) throws SchedulerException {
			super(n, "RU_");
		}

		public String getName() {
			return getJobID().toString();
		}
		public SGEJobID getJobID() {
			return new SGEJobID(getInt("job_number"), getInt("task_number"));
		}
		public int getState() {
			return getInt("state");
		}
	
	}
	
	private HashMap<String, LoadStatus> loadMap;
	private HashMap<String, ReschedUnknown> reschedMap;
	private HashMap<String, SGEQInstance> qMap;
	private SGEACL acl;
	
	private static final String UNKNOWN_LOAD_VALUE = "";
	
	public SGENodeStatus(Node n) throws SchedulerException {
		
		super(n, "EH_");
		
		qMap = new HashMap<String, SGEQInstance>();
		
	}

	protected void addNode(Node node) throws Exception {
		
		String nodeName = node.getNodeName(); 
		if (nodeName.equals("EH_load_list")) {
			if (loadMap == null) {
				loadMap = new HashMap<String, LoadStatus>();
			}
			NodeList list = node.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node sub = list.item(i);
				if (sub.getNodeType() != Node.ELEMENT_NODE)
					continue;
				LoadStatus load = new LoadStatus(sub);
				loadMap.put(load.getName(), load);
			}
		} else if (nodeName.equals("EH_reschedule_unknown_list")) {
			if (reschedMap == null) {
				reschedMap = new HashMap<String, ReschedUnknown>();
			}
			NodeList list = node.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node sub = list.item(i);
				if (sub.getNodeType() != Node.ELEMENT_NODE)
					continue;
				ReschedUnknown res = new ReschedUnknown(sub);
				reschedMap.put(res.getName(), res);
			}
		} else {
			super.addNode(node);
		}
		
	}
		
	public String getHostName() {
		
		return getString("name");
		
	}

	public int getCPUNum() {
		
		return getInt("processors");
		
	}
	
	public String getName() {

		return getHostName();
		
	}
	
	private String getLoadValue(String name) {

		if (loadMap != null) {
			LoadStatus l = loadMap.get(name);
			if (l != null) {
				return l.getValue();
			}
		}
		return UNKNOWN_LOAD_VALUE;
	}
	
	public String getArch() {
		
		return getLoadValue("arch");
		
	}

	public String toString() {
		
		String s = "Node " + getHostName() + ": "
			+ "ncpu=" + getCPUNum();
		
		if (loadMap != null) {
			// "global" and "template" doesn't have <EH_load_list>
			for (LoadStatus l : loadMap.values()) {
				s += "\n\t" + l.toString();
			}
		}
		s += "\nACL " + getAcl().toString();
		
		return s;
		
	}

	public boolean isAlive() {
		
		return (getLoadValue("load_avg") != UNKNOWN_LOAD_VALUE);
		
	}
	
	public boolean isIdle() {
		
		// SGENodeStatus information is updated every 40 second.
		// "num_running_jobs" is not "current" value,
		// which maybe 40 seconds before information.
		//return (getCPUNum() >= getInt("num_running_jobs"));
		
		return (getUsedSlotNum() < getTotalSlotNum());
		
	}

	public double getLoadAverage() {
		
		String s = getLoadValue("load_avg");
		if (s != UNKNOWN_LOAD_VALUE)
			return Double.parseDouble(s);
		else
			return 0.0;

	}

	public OSType getOSType() {
		
		return SGEArch.getOSType(getArch());
		
	}

	public ArchType getArchType() {

		return SGEArch.getArchType(getArch());
		
	}

	public static long getSize(String value) {
		
		// 'value' maybe "1501.675781M", ordinary end with "M"
		int len = value.length() - 1;
		if (len < 1)
			return 0;
		
		double v;
		try {
			v = Double.parseDouble(value.substring(0, len));
		} catch (NumberFormatException e) {
			return 0;
			
		}
		
		char c = value.charAt(len);
		switch (c) {
		case 'M':
			return (long)(1024.0 * 1024.0 * v);
		case 'G':
			return (long)(1024.0 * 1024.0 * 1024.0 * v);
		case 'K':
			return (long)(1024.0 * v);
		default:
			assert(false);
			return (long)v;
		}
		
	}
	
	public long getPhysicalMemory() {

		String s = getLoadValue("mem_total");
		if (s != UNKNOWN_LOAD_VALUE) {
			return getSize(s);
		} else {
			return 0;
		}
		
	}

	public int getIdleTime() {
		
		/*
		 * We cannot get idle time from SGE actually.
		 * "load_avg_long" is load average of 15min, which means
		 * 15*60*load = running sec.
		 * So we return 15*60 - running as idle time.
		 */
		String s = getLoadValue("load_avg_long");
		double load;
		if (s != UNKNOWN_LOAD_VALUE)
			load = Double.parseDouble(s);
		else
			load = 0.0;
		if (load >= 1.0)
			return 0;
		return 15*60 - (int)(15*60*load);
		
	}
	
	public void addQInstance(SGEQInstance ins) {
		
		// overwrite 'ins' if already exists
		qMap.put(ins.getQName(), ins);
		
	}
	
	public Collection<SGEQInstance> getAllQInstances() {
		
		return qMap.values();
		
	}

	public SGEQInstance getQInstances(String qName) {
		
		return qMap.get(qName);
		
	}
	
	public int getTotalSlotNum() {
		
		int n = 0;
		for (SGEQInstance ins : getAllQInstances()) {
			n += ins.getTotalSlotNum();
		}
		return n;
		
	}

	public int getUsedSlotNum() {
		
		int n = 0;
		for (SGEQInstance ins : getAllQInstances()) {
			n += ins.getUsedSlotNum();
		}
		return n;
		
	}
	
	private SGEACL makeAcl() {
		
		SGEUserACL userAcl = SGEUserACL.getInstance(
				getStringParams("acl"), getStringParams("xacl"));
		SGEProjectACL projAcl = SGEProjectACL.getInstance(
				getStringParams("prj"), getStringParams("xprj"));
		return new SGEACL(userAcl, projAcl);
		
	}
	
	public SGEACL getAcl() {
		
		if (acl == null)
			acl = makeAcl();
		return acl;
		
	}
	
	public static SGENodeStatus getSGENodeStatus(NodeInfo node) {
		
		NodeStatus status = node.getStatus();
		if (status instanceof SGENodeStatus) {
			return (SGENodeStatus)status;
		} else if (status instanceof SGEQInstance) {
			SGEQInstance ins = (SGEQInstance)status;
			SGENodeStatus nodeStatus = (SGENodeStatus)ins.getNode();
			return nodeStatus;
		} else {
			assert(false);
			return null;
		}
		
	}
	
	public Collection<SGEJobID> getDirtyTasks() {
		
		if (reschedMap != null) {
			LinkedList<SGEJobID> list = new LinkedList<SGEJobID>();
			for (ReschedUnknown res : reschedMap.values()) {
				list.add(res.getJobID());
			}
			return list;
		} else {
			return null;
		}
		
	}

}
