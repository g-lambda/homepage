/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

import jp.aist.gtrc.plus.scheduler.mainsrv.MainServer;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.job.SGEJobID;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.mainsrv.SGEMainServer;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class SGEStatusManager extends StatusManager {
	
	private LinkedHashMap<String, SGEUserset> usersets = null; 
	private LinkedHashMap<String, SGEProject> projs = null; 
	private LinkedHashMap<String, SGEParallelEnv> pes = null; 
	private LinkedHashMap<String, SGEHostGroup> hgroups = null;
	private LinkedHashMap<String, NodeStatus> qInstances;
	private HashSet<SGEJobID> dirtyTasks;
	
	
	private static SGEStatusManager instance = new SGEStatusManager();

	protected SGEStatusManager() {
		
		super();
		
		qInstances = new LinkedHashMap<String, NodeStatus>();
		dirtyTasks = new HashSet<SGEJobID>();
		
	}
	
	public static SGEStatusManager getInstance() {
		
		return instance;
		
	}
	
	protected void getAllJobs(MainServer srv) throws SchedulerException {
		
		for (JobStatus j : srv.getJobStatus(null)) {
			addJob(j);
		}
		
	}

	private void updateSysInfo(MainServer srv) throws SchedulerException{
		
		if (usersets == null) {
			SGEMainServer server = (SGEMainServer)srv;
			usersets = server.getUsersets();
			projs = server.getProjects();
			pes = server.getParallelEnvs();
			hgroups = server.getHostGroups();
		}
		
	}

	public synchronized void updateStatus(MainServer srv) throws SchedulerException{
	
		updateSysInfo(srv);
		super.updateStatus(srv);
		updateQInstances();
		updateDirtyTasks();
		
	}
	
	private void updateQInstances() {
		
		qInstances.clear();
		
		for (QueueStatus q : getQueues()) {
			SGEQueueStatus queue = (SGEQueueStatus)q;
			for (SGEQInstance ins : queue.getAllQInstances()) {
				qInstances.put(ins.getFullName(), ins);

				// node has qIns on it, qIns has node whiich is on.
				String nodeName = ins.getQHostName();
				SGENodeStatus node = (SGENodeStatus)super.getNode(nodeName);
				if (node != null) {
					node.addQInstance(ins);
					ins.setNodeStatus(node);
				} else {
					assert(false);
				}
			}
		}
		
	}
	
	private void updateDirtyTasks() {
		
		dirtyTasks.clear();
		
		for (NodeStatus n : super.getNodes()) {
			SGENodeStatus node = (SGENodeStatus)n;
			Collection<SGEJobID> dirties = node.getDirtyTasks();
			if (dirties == null)
				continue;
			for (SGEJobID jobID : dirties) {
				dirtyTasks.add(jobID);
			}
		}
		
	}
	
	public synchronized boolean isDirtyTask(SGEJobID jobID) {
		
		return dirtyTasks.contains(jobID);
		
	}

	public synchronized Collection<NodeStatus> getNodes(){

		/*
		 * We use SGEQInstance as NodeStatus, not SGENodeStatus.
		 * 'rsvNodeMgr' has Collection<SGENodeStatus> 
		 */
		return qInstances.values();
		
	}
	
	public synchronized HashMap<String, NodeStatus> getNodeMap(){
		
		//return nodes;
		return qInstances;
		
	}

	public synchronized NodeStatus getNode(String nodeName) {
		
		//return nodes.get(nodeName);
		/*
		 * key of 'qInstances' map is SGEQInstance.getFullName()
		 * which maybe "all.q@host00.example.com" etc.
		 * 'nodeName' will be these, not "host00.example.com"
		 * because getNodes() returns 'qInstances' map.
		 * 'nodeName' must have '@', check it by indexOf().
		 */
		assert(nodeName.indexOf('@') != -1);
		return qInstances.get(nodeName);
		
	}
	
	
	public synchronized HashMap<String, SGEUserset> getUsersetMap() {
		
		return usersets;
		
	}
	
	public synchronized SGEUserset getUserset(String usersetName) {
		
		return usersets.get(usersetName);
		
	}
	
	public synchronized HashMap<String, SGEProject> getProjectMap() {
		
		return projs;
		
	}
	
	public synchronized SGEProject getProject(String projName) {
		
		return projs.get(projName);
		
	}
	
	public synchronized HashMap<String, SGEParallelEnv> getParallelEnvMap() {
		
		return pes;
		
	}

	public synchronized SGEParallelEnv getParallelEnv(String peName) {
		
		return pes.get(peName);
		
	}
	
	public synchronized HashMap<String, SGEHostGroup> getHostGroupMap() {
		
		return hgroups;
		
	}

	public synchronized SGEHostGroup getHostGroup(String hgroupName) {
		
		return hgroups.get(hgroupName);
		
	}
	
}
