/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;


import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.ScheduleStarter;
import jp.aist.gtrc.plus.scheduler.StopScheduleOrder;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.apache.log4j.Logger;


public class ReserveManager implements ReserveServer {

	transient private final ReserveTable table;
	transient private final ReserveRecorder recorder;
	transient private final NodeAllocator nodeAllocator;
	transient private final NodeManager nodeMgr;
	transient private final ReserveOperationFacade opeFacade;
	transient private final ScheduleStarter starter;
	transient private int maxExpired;
	transient private ReserveOperation currentOpe;
	transient protected static Logger logger = Logger.getLogger(ReserveManager.class);

	public ReserveManager(NodeManager nodeMgr, ScheduleStarter starter,
			ReserveRecorder recorder, NodeAllocator nodeAllocator, int maxExpired) throws ReserveException {
		
		assert(nodeMgr != null);
		assert(starter != null);
		
		this.table = new ReserveTable();
		this.recorder = recorder;
		this.starter = starter;
		this.nodeAllocator = (nodeAllocator != null)
			? nodeAllocator : new ReserveNodeAllocator();
		this.nodeMgr = nodeMgr;
		this.maxExpired = maxExpired;
		this.currentOpe = ReserveOperation.getIdleInstance();
		
		this.opeFacade = makeReserveOperationFacade();
		
		System.setSecurityManager(new ReserveSecurityManager());
		
	}
	
	protected ReserveOperationFacade makeReserveOperationFacade() throws ReserveException {
		
		return new ReserveOperationFacade(this);
		
	}
	
	public synchronized void recoverFromRecorder() throws ReserveException {
		
		logger.debug("recover reserves start");

		Collection<ReserveInfo> allRsvs = recorder.loadAll();
		table.clear();
		for (ReserveInfo info : allRsvs) {
			logger.debug("Recover Rsv: " + info);
			table.put(info);
		}
		
		opeFacade.recoverFromRecorder();
		
		logger.debug("recover reserves finished");

	}
	
	protected final ReserveTable getReserveTable() {
		
		return table;
		
	}
	
	protected final ReserveRecorder getReserveRecorder() {
		
		return recorder;
		
	}
	
	protected final NodeAllocator getNodeAllocator() {
		
		return nodeAllocator;
		
	}
	
	public final NodeManager getNodeManager() {
		
		return nodeMgr;
		
	}
	
	final synchronized void startCurrentOperation(ReserveOperation ope) throws ReserveException {
		
		if (currentOpe.getOperationType() != ReserveOperationType.idle) {
			logger.debug("commit/abort not called!! " + ope);
			throw new ReserveException("waiting commit/abort now, cannot do any other operation");
		}
		logger.debug("start " + ope);
		currentOpe = ope;

	}
	
	final synchronized void finishCurrentOperation() {
		
		assert(currentOpe.getOperationType() != ReserveOperationType.idle);
		currentOpe = ReserveOperation.getIdleInstance();
		
	}
	
	final public synchronized ReserveOperation getCurrentOperation() {
	
		return currentOpe;
		
	}
	
	protected void addNewReserveInfo(ReserveInfo rsvInfo) throws ReserveException {
		
		table.put(rsvInfo);
		recorder.store(rsvInfo);

	}
	
	private boolean toBeRemoved(ReserveInfo info) {
		
		Calendar now = Calendar.getInstance();
		if (info.isExpired(now) == false) {
			logger.debug("reserve has not expired yet");
			return false;
		}
		Collection<ReserveInfo> expired = table.getNotAfterEndTime(now);
		if (expired.size() < maxExpired) {
			logger.debug("remain expired reseve, maxExpiredNum=" + maxExpired
					+ " > curExpiredNum=" + expired.size());
			return false;
		}
		
		int index = 0;
		for (ReserveInfo r : expired) {
			if (r.compareTo(info) == 0) {
				break;
			}
			index++;
			if (index >= maxExpired) {
				break;
			}
		}
		logger.debug("remain expired reseve, maxExpiredNum=" + maxExpired
				+ ", curExpiredIdx=" + index);
		return (index >= maxExpired);
		
	}
	
	protected void removeReserveInfo(ReserveInfo rsvInfo, boolean forceRemove) throws ReserveException {

		if (rsvInfo.getReserveNodeSet() != null) {
			rsvInfo.unregisterReservedNodesForever();
		}
		
		if (forceRemove || toBeRemoved(rsvInfo)) {
			table.remove(rsvInfo);
			recorder.remove(rsvInfo);
		}
		
	}

	public synchronized final void remove(ReserveInfo info) throws ReserveException {

		logger.debug("Try remove: " + info);

		startCurrentOperation(ReserveOperation.getRemoveInstance(info));
		removeReserveInfo(info, false);
		commit(info.getReserveId());
			
		logger.debug("removed: " + info);

	}

	protected ReserveInfo newReserveInfo(ReserveId rsvId, ReserveRequest rsvReq,
			ReserveNodeSet rsvNodeSet) throws ReserveException {
		
		return new ReserveInfo(rsvId, rsvReq, rsvNodeSet);
		
	}

	public synchronized ReserveId reserve(ReserveRequest rsvReq) throws ReserveException {

		return opeFacade.reserve(rsvReq);
		
	}

	public synchronized void cancel(ReserveId rsvId) throws ReserveException {

		opeFacade.cancel(rsvId);
		
	}
	
	public synchronized void cancelOfOwner(String owner) throws ReserveException {

		opeFacade.cancelOfOwner(owner);

	}

	
	public synchronized void modify(ReserveId rsvId, ReserveRequest newReq) throws ReserveException{

		opeFacade.modify(rsvId, newReq);
		
	}

	public synchronized void destroy(ReserveId rsvId) throws ReserveException {

		opeFacade.destroy(rsvId);

	}
	
	public synchronized void destroyOfOwner(String owner) throws ReserveException {
		
		opeFacade.destroyOfOwner(owner);

	}

	public synchronized void commit(ReserveId rsvId) throws ReserveException {

		opeFacade.commit(rsvId);

	}

	public synchronized void abort(ReserveId rsvId) throws ReserveException {
		
		opeFacade.abort(rsvId);
		
	}
	
	public synchronized ReserveStatus getStatus(ReserveId rsvId) throws ReserveException {

		return opeFacade.getStatus(rsvId);
		
	}

	public synchronized ReserveStatus[] getStatus(String owner, Calendar start, Calendar end, int nShowExpired) throws ReserveException {

		return opeFacade.getStatus(owner, start, end, nShowExpired);

	}
	
	public synchronized int availableNodeNum(Calendar start, Calendar end) throws ReserveException{

		return opeFacade.availableNodeNum(start, end);
		
	}

	protected final void kickScheduler(ReserveInfo info) {
		
		if (starter != null) {
			logger.debug("kick scheduler to run scheduling");
			try {
				ReserveId id = (info != null) ? info.getReserveId() : null;
				starter.runSchedule(id);
			} catch (SchedulerException e) {
				// ignore to continue
				logger.debug("cannot start scheduling", e);
			}
		}
		
	}
	
	public synchronized Collection<ReserveInfo> getExpiredReserve() {
		
		return getExpiredReserve(Calendar.getInstance());
		
	}
	
	public synchronized Collection<ReserveInfo> getExpiredReserve(Calendar now) {
		
		LinkedList<ReserveInfo> list = new LinkedList<ReserveInfo>();
		for (ReserveInfo info : table.getAllById()) {
			if (info.isExpired(now)) {
				// Check time here, not check whether state is DONE.
				// If added DONE reserves only, CANCELED/ERROR reserves
				// remain forever...
				list.add(info);
			}
		}
		return list;
		
	}
	
	public synchronized final void finish() {
		
		if (recorder != null) {
			recorder.finish();
		}
		
	}

	public synchronized final void stopServer() throws ReserveException {

		if (starter != null) {
			StopScheduleOrder order = new StopScheduleOrder();
			starter.runSchedule(order);
			kickScheduler(null);
		}
		
	}

	public ReserveInfo getReserveInfo(ReserveId rsvId) {
		
		return table.get(rsvId);
		
	}

}