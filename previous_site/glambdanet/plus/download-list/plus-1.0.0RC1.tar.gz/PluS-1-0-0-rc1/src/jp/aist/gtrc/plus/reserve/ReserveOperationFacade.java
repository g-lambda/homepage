/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;

import org.apache.log4j.Logger;

public class ReserveOperationFacade implements ReserveServer {
	
	private ReserveManager rsvMgr;
	private ReserveOperator reserver;
	private CancelOperator canceler;
	private ModifyOperator modifier;
	private DestroyOperator destroier;
	private CommitOperator commiter;
	private AbortOperator aborter;
	private GetStatusOperator watcher;
	
	protected static Logger logger = Logger.getLogger(ReserveOperationFacade.class);

	public ReserveOperationFacade(ReserveManager rsvMgr) throws ReserveException {

		this.rsvMgr = rsvMgr;
		commiter = new CommitOperator(rsvMgr);
		aborter = new AbortOperator(rsvMgr);

		ReserveNodeNormalizer normalizer = makeReserveNodeNormalizer(rsvMgr);
		reserver = new ReserveOperator(rsvMgr, normalizer, commiter, aborter);
		canceler = new CancelOperator(rsvMgr, normalizer, commiter, aborter);
		modifier = new ModifyOperator(rsvMgr, normalizer, commiter, aborter);
		destroier = new DestroyOperator(rsvMgr, normalizer, commiter, aborter);
		
		watcher = new GetStatusOperator(rsvMgr);
		
	}
	
	protected ReserveNodeNormalizer makeReserveNodeNormalizer(ReserveManager rsvMgr) {
		
		return new ReserveNodeNormalizer(rsvMgr);
		
	}
	
	protected void recoverFromRecorder() throws ReserveException {
		
		ReserveOperation lastOpe = rsvMgr.getReserveRecorder().loadOperation();
		if (lastOpe != null) {
			rsvMgr.startCurrentOperation(lastOpe);
		}

	}

	public ReserveId reserve(ReserveRequest req) throws ReserveException {

		return reserver.reserve(req);
		
	}

	public void cancel(ReserveId rsvId) throws ReserveException {

		canceler.cancel(rsvId);
		
	}

	public void cancelOfOwner(String owner) throws ReserveException {

		canceler.cancelOfOwner(owner);
		
	}

	public void modify(ReserveId rsvId, ReserveRequest req) throws ReserveException {

		modifier.modify(rsvId, req);
		
	}

	public void destroy(ReserveId rsvId) throws ReserveException {

		destroier.destroy(rsvId);
		
	}

	public void destroyOfOwner(String owner) throws ReserveException {

		destroier.destroyOfOwner(owner);
		
	}

	public void commit(ReserveId rsvId) throws ReserveException {

		commiter.commit(rsvId);
		
	}

	public void abort(ReserveId rsvId) throws ReserveException {

		aborter.abort(rsvId);
		
	}

	public synchronized ReserveStatus getStatus(ReserveId rsvId) throws ReserveException {

		return watcher.getStatus(rsvId);
		
	}

	public ReserveStatus[] getStatus(String owner, Calendar start, Calendar end, int nShowExpired) throws ReserveException {

		return watcher.getStatus(owner, start, end, nShowExpired);

	}

	public int availableNodeNum(Calendar start, Calendar end) throws ReserveException {

		return watcher.availableNodeNum(start, end);
		
	}

	public void stopServer() throws ReserveException {
		
		rsvMgr.stopServer();
		
	}

}
