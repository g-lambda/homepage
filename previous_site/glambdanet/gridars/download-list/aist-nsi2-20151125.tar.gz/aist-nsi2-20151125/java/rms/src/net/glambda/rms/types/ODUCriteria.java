/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.rms.types;

public class ODUCriteria extends CriteriaBase {

    // source and dest STPs
    protected StpType sourceSTP;
    protected StpType destSTP;

    // DOPN service-specific parameters
    protected String superNetworkType;

    // PathFinding result information
    protected String pathType;
    protected int pathOrder;

    // Stp-related parameters
    protected String sourceIfType;
    protected String destIfType;
    protected int sourceTsId;
    protected int destTsId;
    protected int sourceTsWidth;
    protected int destTsWidth;

    public StpType getSourceSTP() {
        return sourceSTP;
    }

    public void setSourceSTP(StpType sourceSTP) {
        this.sourceSTP = sourceSTP;
    }

    public StpType getDestSTP() {
        return destSTP;
    }

    public void setDestSTP(StpType destSTP) {
        this.destSTP = destSTP;
    }

    public String getSuperNetworkType() {
        return superNetworkType;
    }

    public void setSuperNetworkType(String superNetworkType) {
        this.superNetworkType = superNetworkType;
    }

    public String getPathType() {
        return pathType;
    }

    public void setPathType(String pathType) {
        this.pathType = pathType;
    }

    public int getPathOrder() {
        return pathOrder;
    }

    public void setPathOrder(int pathOrder) {
        this.pathOrder = pathOrder;
    }

    public String getSourceIfType() {
        return sourceIfType;
    }

    public void setSourceIfType(String sourceIfType) {
        this.sourceIfType = sourceIfType;
    }

    public String getDestIfType() {
        return destIfType;
    }

    public void setDestIfType(String destIfType) {
        this.destIfType = destIfType;
    }

    public int getSourceTsId() {
        return sourceTsId;
    }

    public void setSourceTsId(int sourceTsId) {
        this.sourceTsId = sourceTsId;
    }

    public int getDestTsId() {
        return destTsId;
    }

    public void setDestTsId(int destTsId) {
        this.destTsId = destTsId;
    }

    public int getSourceTsWidth() {
        return sourceTsWidth;
    }

    public void setSourceTsWidth(int sourceTsWidth) {
        this.sourceTsWidth = sourceTsWidth;
    }

    public int getDestTsWidth() {
        return destTsWidth;
    }

    public void setDestTsWidth(int destTsWidth) {
        this.destTsWidth = destTsWidth;
    }

}
