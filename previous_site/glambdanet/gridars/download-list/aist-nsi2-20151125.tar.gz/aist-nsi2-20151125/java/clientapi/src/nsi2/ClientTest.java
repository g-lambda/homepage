/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2;

import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.impl.EventListener;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.TypesBuilder;
import nsi2.reply.QueryNotificationReply;
import nsi2.reply.QueryReply;
import nsi2.reply.ReserveCommitReply;
import nsi2.reply.ReserveReply;

import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;

public class ClientTest {

    private void showMessage(String header, String txt) {
        System.out.println("**** " + header + " ****");
        System.out.println(txt);
        System.out.println();
    }

    private void showMessage(Object o, String txt) {
        if (o != null) {
            showMessage(o.getClass().getSimpleName(), txt);
        } else {
            showMessage("", txt);
        }
    }

    private static final long DEFAULT_CAPACITY = 200; // [Mbps]

    private ReservationRequestCriteriaType makeDummyReservationRequestCriteriaType() {
        // NOTE: These are DUMMY values for test
        Calendar start = Calendar.getInstance();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.MINUTE, 3);
        int srcvlan = 1780;
        int destvlan = 1780;
        long capacity = DEFAULT_CAPACITY; // [Mbps]
        //
        ScheduleType schedule = TypesBuilder.makeScheduleType(start, end);
        String srcstp = "urn:ogf:network:aist.go.jp:2013:topology:bi-ps";
        String deststp = "urn:ogf:network:aist.go.jp:2013:topology:bi-aist-jgn-x";
        ReservationRequestCriteriaType crit =
                TypesBuilder.makeReservationRequestCriteriaType(schedule, srcstp, srcvlan, deststp,
                        destvlan, capacity);
        return crit;
    }

    // DUMMY VALUE, can be null
    private final String DEFAULT_GLOBAL_RESERVATION_ID = "global";
    // DUMMY VALUE, can be null
    private final String DEFAULT_DESCRIPTION = "nsi2 test";

    private int currentVersion = 0;

    private String testFirstReserve(NSI2Client client) throws Exception {
        // NOTE: connectionId must be null for first reservation
        String connectionId = null;
        String globalReservationId = DEFAULT_GLOBAL_RESERVATION_ID;
        String description = DEFAULT_DESCRIPTION;
        ReservationRequestCriteriaType criteria = makeDummyReservationRequestCriteriaType();
        showMessage(criteria, NSITextDump.toString(criteria));

        ReserveReply reply =
                client.reserve(connectionId, globalReservationId, description, criteria);

        if (reply.getConfirm() != null) {
            ReservationConfirmCriteriaType conf = reply.getConfirm();
            showMessage("ConnectionID", reply.getConnectionId());
            showMessage(conf, NSITextDump.toString(conf));
            currentVersion = conf.getVersion();
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
        return reply.getConnectionId();
    }

    private int getNewVersion() {
        currentVersion++;
        return currentVersion;
    }

    private void testReserveCommit(NSI2Client client, String connectionId) throws Exception {
        ReserveCommitReply reply = client.reserveCommit(connectionId);
        if (reply.getServiceException() == null) {
            System.out.println("ReserveCommitConfirmed");
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
    }

    private void testReserveAbort(NSI2Client client, String connectionId) throws Exception {
        client.reserveAbort(connectionId);
    }

    private void testModify(NSI2Client client, String connectionId, Calendar start, Calendar end,
            long capacity, int version) throws Exception {
        String globalReservationId = DEFAULT_GLOBAL_RESERVATION_ID;
        String description = DEFAULT_DESCRIPTION;
        ScheduleType schedule;
        if (start != null || end != null) {
            // modify schedule
            schedule = TypesBuilder.makeScheduleType(start, end);
        } else {
            schedule = null;
        }
        ReservationRequestCriteriaType criteria;
        if (capacity > 0) {
            // modify capacity (and schedule if it's specified)
            criteria = TypesBuilder.makeReservationRequestCriteriaType(schedule, capacity);
        } else {
            System.out.println("nothing specified to be modified");
            return;
        }
        criteria.setVersion(version);
        showMessage(criteria, NSITextDump.toString(criteria));

        ReserveReply reply =
                client.reserve(connectionId, globalReservationId, description, criteria);

        if (reply.getConfirm() != null) {
            ReservationConfirmCriteriaType conf = reply.getConfirm();
            showMessage(conf, NSITextDump.toString(conf));
            currentVersion = conf.getVersion();
        } else if (reply.getServiceException() != null) {
            showMessage(reply.getServiceException(),
                    NSITextDump.toString(reply.getServiceException()));
            showMessage(reply.getConnectionStates(),
                    NSITextDump.toString(reply.getConnectionStates()));
        }
    }

    private void testQuery(NSI2Client client, String connectionId) throws Exception {
        QueryType queryType = new QueryType();
        queryType.getConnectionId().add(connectionId);
        {
            // QuerySummarySync
            QuerySummaryConfirmedType summary = client.querySummarySync(queryType);
            showMessage("QuerySummary (sync)", NSITextDump.toString(summary));
        }
        if (hasRequester) {
            // QuerySummary (async)
            QueryReply reply = client.querySummary(queryType);
            if (reply.getSummary() != null) {
                List<QuerySummaryResultType> summary = reply.getSummary();
                showMessage("QuerySummary (async)", NSITextDump.toStringQuerySummayList(summary));
            } else {
                showMessage("QuerySummary (async)", NSITextDump.toString(reply.getException()));
            }
        }
        if (hasRequester) {
            // QueryRecursive (async)
            QueryReply reply = client.queryRecursive(queryType);
            if (reply.getRecursive() != null) {
                List<QueryRecursiveResultType> recursive = reply.getRecursive();
                showMessage("QueryRecursive (async)",
                        NSITextDump.toStringQueryRecursiveList(recursive));
            } else {
                showMessage("QueryRecursive (async)", NSITextDump.toString(reply.getException()));
            }
        }
    }

    private void testQueryNotification(NSI2Client client, String connectionId) throws Exception {
        QueryNotificationType type = new QueryNotificationType();
        type.setConnectionId(connectionId);
        {
            // QueryNotification (sync)
            QueryNotificationConfirmedType conf = client.queryNotificationSync(type);
            showMessage("QueryNotification (sync)", NSITextDump.toString(conf));
        }
        if (hasRequester) {
            // QueryNotification (async)
            QueryNotificationReply reply = client.queryNotification(type);
            if (reply.getConfirmed() != null) {
                showMessage("QueryNotification (async)", NSITextDump.toString(reply.getConfirmed()));
            } else {
                showMessage("QueryNotification (async)", NSITextDump.toString(reply.getException()));
            }
        }
    }

    private boolean hasRequester = false;

    private NSI2Client makeClient(String[] args) throws Exception {
        String providerNSA = args[0];
        String providerURI = args[1];
        String requesterNSA = args[2];
        String requesterURI;
        if (args[3].equals("-")) {
            requesterURI = null;
            System.out.println("replyTo will be null. You must use QuerySync to get status");
        } else {
            requesterURI = args[3];
            hasRequester = true;
        }
        long replyWaitMsec = 60 * 1000L; // [msec]
        String httpUser, httpPassword, oauth = null;
        if (args.length == 6) {
            httpUser = args[4];
            httpPassword = args[5];
        } else if (args.length == 5) {
            oauth = args[4];
            httpUser = httpPassword = null;
        } else {
            httpUser = httpPassword = null;
        }
        // listener can be null if you don't want it
        EventListener listener = new SampleEventListener();
        if (oauth == null) {
            return new NSI2Client(providerNSA, providerURI, requesterNSA, requesterURI,
                    replyWaitMsec, httpUser, httpPassword, listener);
        } else {
            return new NSI2Client(providerNSA, providerURI, requesterNSA, requesterURI,
                    replyWaitMsec, oauth, listener);
        }
    }

    private void test(String[] args) throws Exception {
        NSI2Client client = makeClient(args);
        // first reserve & commit
        String connectionId = testFirstReserve(client);
        Thread.sleep(1000);
        testReserveCommit(client, connectionId);
        Thread.sleep(1000);
        // query
        testQuery(client, connectionId);
        Thread.sleep(1000);
        // modify (change capacity) & commit
        testModify(client, connectionId, null, null, 2 * DEFAULT_CAPACITY, getNewVersion());
        Thread.sleep(1000);
        testReserveCommit(client, connectionId);
        Thread.sleep(1000);
        // modify (change capacity & startTime) & abort
        Calendar newStart = Calendar.getInstance();
        Calendar newEnd = (Calendar) newStart.clone();
        newEnd.add(Calendar.MINUTE, 10);
        testModify(client, connectionId, newStart, newEnd, 4 * DEFAULT_CAPACITY, getNewVersion());
        Thread.sleep(1000);
        testReserveAbort(client, connectionId);
        Thread.sleep(1000);
        // provision
        client.provision(connectionId);
        Thread.sleep(1000);
        // release
        client.release(connectionId);
        Thread.sleep(1000);
        // queryNotification
        testQueryNotification(client, connectionId);
        Thread.sleep(1000);
        // terminate
        client.terminate(connectionId);
        Thread.sleep(1000);
    }

    public static void main(String[] args) {
        if (args.length < 4) {
            System.err.println("Usage: java ClientTest providerNSA providerURI"
                    + " requesterNSA {requesterURI|-} [httpUser httpPassword]");
            System.exit(1);
        }
        ClientTest app = new ClientTest();
        try {
            app.test(args);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // NOTE: Endpoint.stop() doesn't stop all threads in CXF, so we must
        // call this at the end to stop requester port.
        System.exit(0);
    }

}
