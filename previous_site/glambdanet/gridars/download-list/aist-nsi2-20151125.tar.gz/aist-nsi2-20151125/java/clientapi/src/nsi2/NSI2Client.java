/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import net.glambda.nsi2.impl.EventListener;
import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.impl.SampleRequesterWaitable;
import net.glambda.nsi2.impl.SampleRequesterWaitable.FailedMessage;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.nsi2.util.SecurityUtil;
import nsi2.reply.QueryNotificationReply;
import nsi2.reply.QueryReply;
import nsi2.reply.ReserveCommitReply;
import nsi2.reply.ReserveReply;

import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

public class NSI2Client {

    private final String providerNSA, requesterNSA, replyTo;
    private final long replyWaitMsec; // [msec]
    private final ConnectionProviderPort provider;
    private final SampleRequesterWaitable requester;

    private static final String PROV_PROT_VERSION = NSIUtil.getProviderProtocolVersion();

    /**
     * Creates NSI2Client without authorization. Starts ConnectionProviderPort
     * at requesterURI if it's specified.
     * 
     * <p>
     * If you are behind NAT, set requesterURI=null.
     * 
     * <p>
     * This constructor doesn't set any authorization settings.
     * 
     * <p>
     * If you want to handle dataPlaneStateChange and errorEvent notifications,
     * implement EventListener interface, and specify it to listener. Set
     * listener=null if you don't care about these messages.
     * 
     * @param providerNSA
     *            target provider NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param providerURI
     *            target provider URI (ex.
     *            "http://127.0.0.1:8080/provider/services/ConnectionProvider")
     * @param requesterNSA
     *            requester NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param requesterURI
     *            requester port URI (ex.
     *            "http://127.0.0.1:8081/requester/services/ConnectionRequester"
     *            or null)
     * @param replyWaitMsec
     *            timeout of waiting XxxConfirmed/Failed messages [msec]
     * @param listener
     *            EventListener implementation (can be null). See
     *            {@link SampleEventListener}.
     * 
     * @throws Exception
     */
    public NSI2Client(String providerNSA, String providerURI, String requesterNSA,
            String requesterURI, long replyWaitMsec, EventListener listener) {
        this.provider = NSIUtil.getProviderPort(providerURI);
        this.providerNSA = providerNSA;
        if (requesterURI != null) {
            this.requester = new SampleRequesterWaitable(listener);
            SecurityUtil.publish(requesterURI, this.requester);
        } else {
            this.requester = null;
        }
        this.replyWaitMsec = replyWaitMsec;
        this.replyTo = requesterURI;
        this.requesterNSA = requesterNSA;
    }

    /**
     * Creates NSI2Client with HTTP Basic authorization. Starts
     * ConnectionProviderPort at requesterURI if it's specified.
     * 
     * <p>
     * If you are behind NAT, set requesterURI=null.
     * 
     * <p>
     * If target provider requires HTTP basic authentication, specify httpUser
     * and httpPassword correctly. Set both of them null means no
     * authentication.
     * 
     * <p>
     * If you want to handle dataPlaneStateChange and errorEvent notifications,
     * implement EventListener interface, and specify it to listener. Set
     * listener=null if you don't care about these messages.
     * 
     * @param providerNSA
     *            target provider NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param providerURI
     *            target provider URI (ex.
     *            "http://127.0.0.1:8080/provider/services/ConnectionProvider")
     * @param requesterNSA
     *            requester NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param requesterURI
     *            requester port URI (ex.
     *            "http://127.0.0.1:8081/requester/services/ConnectionRequester"
     *            or null)
     * @param replyWaitMsec
     *            timeout of waiting XxxConfirmed/Failed messages [msec]
     * @param httpUser
     *            username for HTTP Basic authentication (can be null)
     * @param httpPassword
     *            password for HTTP Basic authentication (can be null)
     * @param listener
     *            EventListener implementation (can be null). See
     *            {@link SampleEventListener}.
     * 
     * @throws Exception
     */
    public NSI2Client(String providerNSA, String providerURI, String requesterNSA,
            String requesterURI, long replyWaitMsec, String httpUser, String httpPassword,
            EventListener listener) {
        this(providerNSA, providerURI, requesterNSA, requesterURI, replyWaitMsec, listener);
        NSIUtil.setUserPass((BindingProvider) provider, httpUser, httpPassword);
    }

    /**
     * Creates NSI2Client with OAuth2 authorization. Starts
     * ConnectionProviderPort at requesterURI if it's specified.
     * 
     * <p>
     * If you are behind NAT, set requesterURI=null.
     * 
     * <p>
     * If target provider requires OAuth2 authentication, specify oauth2token.
     * 
     * <p>
     * If you want to handle dataPlaneStateChange and errorEvent notifications,
     * implement EventListener interface, and specify it to listener. Set
     * listener=null if you don't care about these messages.
     * 
     * @param providerNSA
     *            target provider NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param providerURI
     *            target provider URI (ex.
     *            "http://127.0.0.1:8080/provider/services/ConnectionProvider")
     * @param requesterNSA
     *            requester NSA identifier (ex.
     *            "urn:ogf:network:aist.go.jp:2013:nsa")
     * @param requesterURI
     *            requester port URI (ex.
     *            "http://127.0.0.1:8081/requester/services/ConnectionRequester"
     *            or null)
     * @param replyWaitMsec
     *            timeout of waiting XxxConfirmed/Failed messages [msec]
     * @param oauth2token
     *            OAuth2 access token (can be null)
     * @param listener
     *            EventListener implementation (can be null). See
     *            {@link SampleEventListener}.
     * 
     * @throws Exception
     */
    public NSI2Client(String providerNSA, String providerURI, String requesterNSA,
            String requesterURI, long replyWaitMsec, String oauth2token, EventListener listener) {
        this(providerNSA, providerURI, requesterNSA, requesterURI, replyWaitMsec, listener);
        NSIUtil.setOAuth2Token((BindingProvider) provider, oauth2token);
    }

    private CommonHeaderType makeCommonHeader() {
        CommonHeaderType header = new CommonHeaderType();
        header.setProtocolVersion(PROV_PROT_VERSION);
        header.setCorrelationId(NSIUtil.getNewCorrelationId());
        header.setRequesterNSA(requesterNSA);
        header.setProviderNSA(providerNSA);
        header.setReplyTo(replyTo);
        return header;
    }

    private Object waitReply(String correlationId, Class<?> okClass, Class<?> ngClass)
            throws ServiceException {
        Object o = requester.waitReply(correlationId, replyWaitMsec);
        if (o != null) {
            if (o.equals(SampleRequesterWaitable.CONFIRMED)) {
                return o;
            }
            Class<?> cls = o.getClass();
            if (cls.equals(okClass) || cls.equals(ngClass)) {
                return o;
            } else {
                throw new ServiceException("PROGRAM ERROR: unknown reply: "
                        + o.getClass().getCanonicalName());
            }
        } else {
            throw new ServiceException("TIMEOUT: cannot receive reply in " + replyWaitMsec
                    + " [msec]");
        }
    }

    private Object waitReply(String correlationId) throws ServiceException {
        return waitReply(correlationId, null, null);
    }

    private ServiceException makeServiceException(String nsaId, String connectionId, ServiceException ex) {
        ServiceExceptionType exType =
                (ex.getFaultInfo() != null ? ex.getFaultInfo() : new ServiceExceptionType());
        ServiceException exception = new ServiceException(ex.getMessage(), exType);
        if (exType.getNsaId() == null) {
            exType.setNsaId(nsaId);
        }
        if (exType.getErrorId() == null) {
            exType.setErrorId("");
        }
        if (exType.getText() == null) {
            exType.setText(ex.getMessage());
        }
        if (exType.getConnectionId() == null) {
            exType.setConnectionId(connectionId);
        }
        return exception;
    }

    /**
     * Sends Reserve request to the provider, waits ReserveConfirmed or
     * reserveFailed message.
     * 
     * <p>
     * For first reservation, you must call connectionId=null. You can get new
     * allocated reservationId by {@link ReserveReply#getConnectionId()}.
     * 
     * <p>
     * For modification of the reservation, you must set the connectionId of it.
     * 
     * <p>
     * If replyTo (i.e. requesterURI of
     * {@link NSI2Client#NSI2Client(String, String, String, String, long, String, String, EventListener)}
     * ) is not null, wait reply of the reservation. It will throw
     * ServiceException if cannot receive any reply message of the request
     * within replyWaitMsec [msec] (see the constructor of this class).
     * 
     * <p>
     * When replyTo is not null, if the operation succeeded, you can get
     * connectionId by calling {@link ReserveReply#getConnectionId()} and
     * ReservationConfirmCriteriaType by {@link ReserveReply#getConfirm()}. If
     * failed, you can get the parameters of reserveFailed message by calling
     * {@link ReserveReply#getServiceException()} and
     * {@link ReserveReply#getConnectionStates()}.
     * 
     * <p>
     * When replyTo is null, you can use {@link ReserveReply#getConnectionId()}
     * only, and call {@link NSI2Client#querySummarySync(QueryType)} to get
     * reservation status.
     * 
     * @param connectionId
     *            connectionId to call NSI2 reserve (null for first reservation,
     *            not null for modification)
     * @param globalReservationId
     *            globalReservationId to call NSI2 reserve (can be null)
     * @param description
     *            description to call NSI2 reserve (can be null)
     * @param criteria
     *            criteria to call NSI2 reserve
     * @return ReserveReply object which contains connectionId,
     *         ReservationConfirmCriteriaType, and FailedMessage (contains
     *         ConnectionStatesType and serviceException).
     * @throws ServiceException
     */
    public ReserveReply reserve(String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        Holder<String> holder = new Holder<String>();
        holder.value = connectionId;
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.reserve(holder, globalReservationId, description, criteria);
        if (replyTo != null) {
            try {
                Object o =
                        waitReply(header.getCorrelationId(), ReservationConfirmCriteriaType.class,
                                FailedMessage.class);
                if (o instanceof ReservationConfirmCriteriaType) {
                    return new ReserveReply(holder.value, (ReservationConfirmCriteriaType) o);
                } else {
                    return new ReserveReply(holder.value, (FailedMessage) o);
                }
            } catch (ServiceException e) {
                throw makeServiceException(header.getProviderNSA(), holder.value, e);
            }
        } else {
            return new ReserveReply(holder.value);
        }
    }

    /**
     * Sends ReserveCommit request to the provider, waits ReserveCommitConfirmed
     * or ReserveCommitFailed message.
     * 
     * <p>
     * connectionId must be the value of {@link ReserveReply#getConnectionId()}
     * of reserve().
     * 
     * <p>
     * Waits reply message same as reserve().
     * 
     * <p>
     * If the operation succeeded,
     * {@link ReserveCommitReply#getServiceException()} is null. If the
     * operation failed, {@link ReserveCommitReply#getServiceException()} and
     * {@link ReserveCommitReply#getConnectionStates()} will the parameters of
     * NSI2 reserveCommitFailed.
     * 
     * @param connectionId
     *            connectionId to call NSI2 reserveCommit
     * @return ReserveCommitReply object which FailedMessage (contains
     *         ConnectionStatesType and serviceException).
     * @throws ServiceException
     */
    public ReserveCommitReply reserveCommit(String connectionId) throws ServiceException {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.reserveCommit(connectionId);
        if (replyTo != null) {
            Object o = waitReply(header.getCorrelationId(), null, FailedMessage.class);
            if (SampleRequesterWaitable.CONFIRMED.equals(o)) {
                return new ReserveCommitReply();
            } else {
                return new ReserveCommitReply((FailedMessage) o);
            }
        } else {
            return new ReserveCommitReply();
        }
    }

    /**
     * Sends ReserveAbort request to the provider, waits ReserveAbortConfirmed
     * message.
     * 
     * <p>
     * connectionId must be the value of {@link ReserveReply#getConnectionId()}
     * of reserve().
     * 
     * <p>
     * Waits reply message same as reserve().
     * 
     * <p>
     * NSI2 reserveAbort always replies reserveAbortConfirmed, there isn't
     * reserveAbortFailed. So this method doesn't have a return value.
     * 
     * @param connectionId
     *            connectionId to call NSI2 reserveAbort
     * @throws ServiceException
     */
    public void reserveAbort(String connectionId) throws ServiceException {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.reserveAbort(connectionId);
        if (replyTo != null) {
            waitReply(header.getCorrelationId());
        }
    }

    /**
     * Sends Provision request to the provider, waits ProvisionConfirmed
     * message.
     * 
     * <p>
     * connectionId must be the value of {@link ReserveReply#getConnectionId()}
     * of reserve().
     * 
     * <p>
     * Waits reply message same as reserve().
     * 
     * <p>
     * NSI2 provision always replies provisionConfirmed, there isn't
     * provisionFailed. So this method doesn't have a return value.
     * 
     * @param connectionId
     *            connectionId to call NSI2 provision
     * @throws ServiceException
     */
    public void provision(String connectionId) throws ServiceException {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.provision(connectionId);
        if (replyTo != null) {
            waitReply(header.getCorrelationId());
        }
    }

    /**
     * Sends Release request to the provider, waits ReeleaseConfirmed message.
     * 
     * <p>
     * connectionId must be the value of {@link ReserveReply#getConnectionId()}
     * of reserve().
     * 
     * <p>
     * Waits reply message same as reserve().
     * 
     * <p>
     * NSI2 release always replies releaseConfirmed, there isn't releaseFailed.
     * So this method doesn't have a return value.
     * 
     * @param connectionId
     *            connectionId to call NSI2 release
     * @throws ServiceException
     */
    public void release(String connectionId) throws ServiceException {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.release(connectionId);
        if (replyTo != null) {
            waitReply(header.getCorrelationId());
        }
    }

    /**
     * Sends Terminate request to the provider, waits TerminateConfirmed
     * message.
     * 
     * <p>
     * connectionId must be the value of {@link ReserveReply#getConnectionId()}
     * of reserve().
     * 
     * <p>
     * Waits reply message same as reserve().
     * 
     * <p>
     * NSI2 terminate always replies terminateConfirmed, there isn't
     * terminateFailed. So this method doesn't have a return value.
     * 
     * @param connectionId
     *            connectionId to call NSI2 terminate
     * @throws ServiceException
     */
    public void terminate(String connectionId) throws ServiceException {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.terminate(connectionId);
        if (replyTo != null) {
            waitReply(header.getCorrelationId());
        }
    }

    /**
     * Sends QuerySummary request to the provider, waits QuerySummaryConfirmed
     * or QuerySummaryFailed message.
     * 
     * <p>
     * You can't use this method if replyTo (i.e. requesterURI of the
     * constructor) is null because cannot receive reply, use
     * {@link #querySummarySync}.
     * 
     * @param querySummary
     *            querySummary to call NSI2 querySummary
     * @return QueryReply object which contains
     *         List&lt;QuerySummaryResultType&gt; (if succeeded), or
     *         ServiceExceptionType (if failed). Use
     *         {@link QueryReply#getSummary()} and
     *         {@link QueryReply#getException()}.
     * @throws ServiceException
     */
    public QueryReply querySummary(QueryType querySummary) throws ServiceException {
        if (replyTo == null) {
            throw new ServiceException(
                    "replyTo is null. You cannot get query reply! Use querySummarySync()");
        }
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.querySummary(querySummary);
        Object o =
                waitReply(header.getCorrelationId(), ArrayList.class, ServiceExceptionType.class);
        if (o instanceof List) {
            @SuppressWarnings("unchecked")
            List<QuerySummaryResultType> summary = (ArrayList<QuerySummaryResultType>) o;
            return new QueryReply(summary, null);
        } else {
            return new QueryReply((ServiceExceptionType) o);
        }
    }

    /**
     * Sends QuerySummarySync request to the provider, returns
     * QuerySummaryConfirmedType.
     * 
     * <p>
     * NSI2 querySummarySync is a sync method. There is not waiting of the
     * reply.
     * 
     * @param querySummarySync
     *            querySummarySync to call NSI2 querySummarySync
     * @return QuerySummaryConfirmedType, the return value of NSI2
     *         querySummarySync method.
     * @throws org.ogf.schemas.nsi._2013._12.connection._interface.Error
     * @throws QuerySummarySyncFailed
     */
    public QuerySummaryConfirmedType querySummarySync(QueryType querySummarySync) throws Error {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        return port.querySummarySync(querySummarySync);
    }

    /**
     * Sends QueryRecursive request to the provider, waits
     * queryRecursiveConfirmed or queryRecursiveFailed message.
     * 
     * <p>
     * You can't use this method if replyTo (i.e. requesterURI of the
     * constructor) is null because cannot receive reply.
     * 
     * @param queryRecursive
     *            queryRecursive to call NSI2 queryRecursive
     * @return QueryReply object which contains
     *         List&lt;QueryRecursiveResultType&gt; (if succeeded), or
     *         ServiceExceptionType (if failed). Use
     *         {@link QueryReply#getRecursive()} and
     *         {@link QueryReply#getException()}.
     * @throws ServiceException
     */
    public QueryReply queryRecursive(QueryType queryRecursive) throws ServiceException {
        if (replyTo == null) {
            throw new ServiceException("replyTo is null. you cannot get query reply!");
        }
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.queryRecursive(queryRecursive);
        Object o =
                waitReply(header.getCorrelationId(), ArrayList.class, ServiceExceptionType.class);
        if (o instanceof List) {
            @SuppressWarnings("unchecked")
            List<QueryRecursiveResultType> recursive = (ArrayList<QueryRecursiveResultType>) o;
            return new QueryReply(null, recursive);
        } else {
            return new QueryReply((ServiceExceptionType) o);
        }
    }

    /**
     * Sends QueryNotification request to the provider, waits
     * QueryNotificationConfirmed or QueryNotificationFailed message.
     * 
     * <p>
     * You can't use this method if replyTo (i.e. requesterURI of the
     * constructor) is null because cannot receive reply, use
     * {@link #queryNotificationSync}.
     * 
     * @param type
     *            QueryNotificationType to call NSI2 querySummary (see
     *            {@link #queryNotificationSync})
     * @return QueryNotificationReply object which contains
     *         QueryNotificationConfirmedType (if succeeded), or
     *         ServiceExceptionType (if failed). Use
     *         {@link QueryNotificationReply#getConfirmed()} and
     *         {@link QueryNotificationReply#getException()}.
     * @throws ServiceException
     */
    public QueryNotificationReply queryNotification(QueryNotificationType type)
            throws ServiceException {
        if (replyTo == null) {
            throw new ServiceException("replyTo is null. you cannot get query reply!");
        }
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        port.queryNotification(type.getConnectionId(), type.getStartNotificationId(),
                type.getEndNotificationId());
        Object o =
                waitReply(header.getCorrelationId(), QueryNotificationConfirmedType.class,
                        ServiceExceptionType.class);
        if (o instanceof QueryNotificationConfirmedType) {
            return new QueryNotificationReply((QueryNotificationConfirmedType) o);
        } else {
            return new QueryNotificationReply((ServiceExceptionType) o);
        }

    }

    /**
     * Sends QueryNotificationSync request to the provider, returns
     * QueryNotificationConfirmedType.
     * 
     * <p>
     * NSI2 queryNotificationSync is a sync method. There is not waiting of the
     * reply.
     * 
     * @param type
     *            type to call NSI2 queryNotificationSync
     * @return QueryNotificationConfirmedType, the return value of NSI2
     *         queryNotificationSync method.
     * @throws QueryNotificationSyncFailed
     */
    public QueryNotificationConfirmedType queryNotificationSync(QueryNotificationType type)
            throws Error {
        CommonHeaderType header = makeCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);
        return port.queryNotificationSync(type);
    }
}
