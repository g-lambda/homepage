/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

public class NSIClientUtil {

    public static void printHelp(String cmdName, Options options) {
        HelpFormatter help = new HelpFormatter();
        help.printHelp(cmdName, options, true);
    }

    public static CommandLine args2cmd(String cmdName, String[] args, Options options) {
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;

        try {
            cmd = parser.parse(options, args);
            return cmd;
        } catch (ParseException e) {
            NSIClientUtil.printHelp(cmdName, options);
            return null;
        }
    }

}
