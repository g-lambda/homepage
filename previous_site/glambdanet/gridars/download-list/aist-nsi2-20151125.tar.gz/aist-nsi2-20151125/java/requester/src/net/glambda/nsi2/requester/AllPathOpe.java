/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import net.glambda.nsi2.topology.AllPathFinder;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.util.StpidVlan;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;

public class AllPathOpe extends OpeBase {

    private final AllPathFinder finder = new AllPathFinder();
    private final List<List<Term>> pathList = new ArrayList<List<Term>>();

    @Override
    protected void addOptions(Options options) {
        OptionBuilder.hasOptionalArgs(2);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid vlanX");
        OptionBuilder.withDescription("sourceSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_SRCSTP));

        OptionBuilder.hasOptionalArgs(2);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid vlanY");
        OptionBuilder.withDescription("destinationSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_DSTSTP));
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        pathList.clear();
        StpidVlan src = makeSTP(cmd, OPT_SRCSTP);
        StpidVlan dst = makeSTP(cmd, OPT_DSTSTP);
        if (src.vlan == 0 || dst.vlan == 0) {
            throw new Exception("missing vlan parameter");
        }
        int minVlan, maxVlan;
        if (src.vlan < dst.vlan) {
            minVlan = src.vlan;
            maxVlan = dst.vlan;
        } else {
            minVlan = dst.vlan;
            maxVlan = src.vlan;
        }
        for (int vlan = minVlan; vlan <= maxVlan; vlan++) {
            log(cmd, "######### Find path for vlan=" + vlan + " #########");
            try {
                List<List<Term>> list = finder.search(null, src.stpid, dst.stpid, vlan);
                AllPathFinder.output(list, pathList.size());
                pathList.addAll(list);
            } catch (Exception e) {
                log(cmd, "cannot find path for vlan=" + vlan);
            }
            log(cmd, "");
        }
    }

    public LinkedList<Term> getPath(int idx) throws Exception {
        if (0 <= idx && idx < pathList.size()) {
            // always copy the list
            return new LinkedList<Term>(pathList.get(idx));
        } else {
            throw new Exception("invalid path index: " + idx);
        }
    }

}
