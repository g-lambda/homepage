/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.pathfinder.sample;

import java.rmi.RemoteException;
import java.util.LinkedList;

import net.glambda.pathfinder.IFTYPE;
import net.glambda.pathfinder.Path;
import net.glambda.pathfinder.PathFinder;
import net.glambda.pathfinder.PathFindingCriteria;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.pathfinder.STP;
import net.glambda.pathfinder.SUPERNETWORK;

public class PathFinderImpl implements PathFinder {

    @Override
    public PathFindingResult query(PathFindingCriteria criteria) throws RemoteException {
        PathFindingResult result = null;
        LinkedList<Path> ero = new LinkedList<Path>();

        if (criteria.superNetworkType == SUPERNETWORK.ODUNW) {
            STP stp2 = new STP("net1", "local2", IFTYPE.ODU, "1", 1);
            STP stp3 = new STP("net2", "local1", IFTYPE.ODU, "1", 1);
            Path path1 = new Path(criteria.srcStp, stp2);
            Path path2 = new Path(stp3, criteria.dstStp);
            ero.add(path1);
            ero.add(path2);
            result = new PathFindingResult(criteria.queryId, ero);

        } else { // criteria.superNetworkType == SUPERNETWORK.LAMBDA
            STP stp2 = new STP("net1", "local2", IFTYPE.LAMBDA, "5", 1);
            STP stp3 = new STP("net2", "local1", IFTYPE.LAMBDA, "5", 1);
            Path path1 = new Path(criteria.srcStp, stp2);
            Path path2 = new Path(stp3, criteria.protectionSrcSTP);
            Path path3 = new Path(criteria.protectionDstSTP, criteria.dstStp);
            ero.add(path1);
            ero.add(path2);
            ero.add(path3);

            // protection
            LinkedList<Path> primary = new LinkedList<Path>();
            LinkedList<Path> secondary = new LinkedList<Path>();
            STP stpA2 = new STP("netA", "local2", IFTYPE.LAMBDA, "5", 1);
            STP stpA3 = new STP("netA", "local3", IFTYPE.LAMBDA, "5", 1);
            STP stpB1 = new STP("netB", "local1", IFTYPE.LAMBDA, "5", 1);
            STP stpB2 = new STP("netB", "local2", IFTYPE.LAMBDA, "5", 1);
            STP stpC1 = new STP("netC", "local1", IFTYPE.LAMBDA, "5", 1);
            STP stpC2 = new STP("netC", "local2", IFTYPE.LAMBDA, "5", 1);
            STP stpD1 = new STP("netD", "local1", IFTYPE.LAMBDA, "5", 1);
            STP stpD2 = new STP("netD", "local2", IFTYPE.LAMBDA, "5", 1);
            // primary
            primary.add(new Path(criteria.protectionSrcSTP, stpA2));
            primary.add(new Path(stpB1, stpB2));
            primary.add(new Path(stpD1, criteria.protectionDstSTP));
            // secondary
            secondary.add(new Path(criteria.protectionSrcSTP, stpA3));
            secondary.add(new Path(stpC1, stpC2));
            secondary.add(new Path(stpD2, criteria.protectionDstSTP));

            result = new PathFindingResult(criteria.queryId, ero, primary, secondary);
        }
        return result;
    }

}
