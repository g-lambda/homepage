/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator.ope;

import java.util.Calendar;

import net.glambda.nsi2.aggregator.OperationInvoker;
import net.glambda.nsi2.aggregator.ProviderConfig;
import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.impl.SampleRequesterWaitable;
import net.glambda.nsi2.impl.SampleRequesterWaitable.FailedMessage;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSIPortManager;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.NSIUtil;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

public abstract class OpeBase implements Runnable {

    protected static final Log logger = AbstractLog.getLog(OpeBase.class);
    private static final NSIProperties nsiProp = NSIProperties.getInstance();
    private static final String PROV_PROT_VERSION = NSIUtil.getProviderProtocolVersion();
    private static final String REQUESTER_NSA_NAME = nsiProp.getMyRequesterNSA();
    private static String REQUESTER_URL = nsiProp.getAggregatorRequesterURL();
    private static String DUMMYPROV_URL = nsiProp.getProperty("nsi.aist.aggr.dummyprovider");
    private static final int REPLY_WAIT_TIMEOUT_SEC = nsiProp.replyTimeoutSec();
    private static final long REPLY_WAIT_TIMEOUT_MSEC = 1000L * REPLY_WAIT_TIMEOUT_SEC;
    private static final ProviderConfig PROV_CONF = new ProviderConfig();
    private Calendar startTime = null, endTime = null;

    public static void setRequesterURL(String url) {
        REQUESTER_URL = url;
        DUMMYPROV_URL = null;
    }

    private final SampleRequesterWaitable requester;
    private final NSA nsa, orgNsa;
    private final String nsaName;
    private OperationInvoker<? extends OpeBase> invoker = null;
    private Exception opeEx = null;

    protected static final NSIPortManager portMgr = NSIPortManager.getInstance();
    private String connectionId;
    private CommonHeaderType header;

    protected OpeBase(SampleRequesterWaitable requester, NSA nsa, String connectionId) {
        this.requester = requester;
        this.orgNsa = nsa;
        this.nsa = PROV_CONF.getNSA(nsa);
        if (this.nsa == this.orgNsa) {
            this.nsaName = this.nsa.name();
        } else {
            this.nsaName = this.orgNsa.name() + " (-> " + this.nsa.name() + ")";
        }
        this.connectionId = connectionId;
    }

    protected OpeBase(OpeBase ope) {
        this.requester = ope.requester;
        this.orgNsa = ope.orgNsa;
        this.nsa = ope.nsa;
        this.nsaName = ope.nsaName;
        this.connectionId = ope.connectionId;
    }

    public NSA nsa() {
        return nsa;
    }

    public NSA originalTargetNsa() {
        return orgNsa;
    }

    public String getNsaName() {
        return nsaName;
    }

    protected void setConnectionId(String connectionId) {
        logger.info("set connId=" + connectionId + ", nsa=" + nsa.name());
        this.connectionId = connectionId;
    }

    public String connectionId() {
        return connectionId;
    }

    protected CommonHeaderType makeCommonHeader() {
        header = new CommonHeaderType();
        header.setProtocolVersion(PROV_PROT_VERSION);
        header.setCorrelationId(NSIUtil.getNewCorrelationId());
        header.setRequesterNSA(REQUESTER_NSA_NAME);
        header.setProviderNSA(nsa.name());
        header.setReplyTo(REQUESTER_URL);
        return header;
    }

    public CommonHeaderType header() {
        return header;
    }

    public void setOperationInvoker(OperationInvoker<? extends OpeBase> invoker) {
        this.invoker = invoker;
    }

    protected Object waitReply(CommonHeaderType header) throws ServiceException {
        Object o = requester.waitReply(header.getCorrelationId(), REPLY_WAIT_TIMEOUT_MSEC);
        if (o == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.INTERNAL_NRM_ERROR, connectionId,
                    "TIMEOUT: cannot receive reply from " + header.getProviderNSA()
                            + " of correlationId=" + header.getCorrelationId() + " in "
                            + REPLY_WAIT_TIMEOUT_SEC + "[sec]");
        } else if (o instanceof ServiceExceptionType) {
            throw NSIExceptionUtil.type2ex((ServiceExceptionType) o);
        } else if (o instanceof FailedMessage) {
            FailedMessage f = (FailedMessage) o;
            ServiceExceptionType ex = f.getServiceExceptionType();
            throw NSIExceptionUtil.type2ex(ex);
        } else {
            return o;
        }
    }

    protected ConnectionProviderPort getProviderPort(CommonHeaderType header)
            throws ServiceException {
        NSA nsa = NSA.findNSA(header.getProviderNSA());
        if (nsa != null) {
            String url = (DUMMYPROV_URL != null ? DUMMYPROV_URL : nsa.csEndpoint());
            return new ProviderPortWithHeader(header, portMgr.getProviderPort(url));
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "unknown provider: " + header.getProviderNSA());
        }
    }

    protected abstract void operation() throws Exception;

    public boolean isSucceeded() {
        return (opeEx == null);
    }

    public Exception getException() {
        return opeEx;
    }

    public String toString() {
        return this.getClass().getSimpleName() + " to " + nsaName + ", connID=" + connectionId;
    }

    protected void startLog(String msg, String reqName) {
        logger.info(NSITextDump.addTab(msg, reqName + " to " + nsaName + " [" + nsa.csEndpoint()
                + "]", false));
    }

    public Calendar startTime() {
        return startTime;
    }

    public Calendar endTime() {
        return endTime;
    }

    @Override
    public void run() {
        try {
            logger.info("start " + toString());
            startTime = Calendar.getInstance();
            operation();
            endTime = Calendar.getInstance();
            logger.info("finish " + toString());
        } catch (Exception e) {
            endTime = Calendar.getInstance();
            logger.warn("failed " + toString(), e);
            opeEx = e;
        }
        if (invoker != null) {
            logger.info(invoker.status(this));
        }
    }
}
