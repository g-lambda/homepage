/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.LinkedList;
import java.util.List;

import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.SamplePathFinder;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.topology.TopologyLoader;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;
import org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType;

public class PathPlannerImpl implements PathPlanner {

    protected static final Log logger = AbstractLog.getLog(PathPlannerImpl.class);

    private final SamplePathFinder pathFinder;

    public PathPlannerImpl() throws Exception {
        LinkedList<NSA> nsaList = TopologyLoader.loadAll();
        this.pathFinder = new SamplePathFinder(nsaList);
    }

    @Override
    public List<List<Term>> makePlans(String connectionId, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        P2PServiceBaseType p2p = TypesBuilder.getP2PServiceBaseType(criteria);
        if (p2p.getEro() == null) {
            return makeSimplePlan(connectionId, p2p);
        } else {
            return makePlanByERO(connectionId, p2p);
        }
    }

    private List<List<Term>> makeSimplePlan(String connectionId, P2PServiceBaseType p2p)
            throws ServiceException {
        StpidVlan src = new StpidVlan(p2p.getSourceSTP());
        StpidVlan dst = new StpidVlan(p2p.getDestSTP());
        LinkedList<Term> stpPath;
        try {
            stpPath = pathFinder.search(src.stpid, src.vlan, dst.stpid, dst.vlan);
            List<List<Term>> plans = new LinkedList<List<Term>>();
            plans.add(stpPath);
            return plans;
        } catch (ServiceException e) {
            logger.warn(e);
            e.getFaultInfo().setConnectionId(connectionId);
            throw e;
        }
    }

    private void checkSTPname(String connectionId, String stpid) throws ServiceException {
        STP stp = STP.findSTP(stpid);
        if (stp == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNKNOWN_STP, connectionId, stpid);
        }
    }

    private void checkSTPterminal(String connectionId, String stp1, String stp2)
            throws ServiceException {
        if (stp1.equals(stp2)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "ERO includes the Path src/end: " + stp1);
        }
    }

    private Term stpid2term(String connectionId, String stpid) throws ServiceException {
        StpidVlan sv = new StpidVlan(stpid);
        STP stp = STP.findSTP(sv.stpid);
        if (stp == null) {
            throw NSIExceptionUtil
                    .makeServiceException(ErrorID.UNKNOWN_STP, connectionId, sv.stpid);
        }
        return new Term(stp, sv.vlan);
    }

    private List<List<Term>> makePlanByERO(String connectionId, P2PServiceBaseType p2p)
            throws ServiceException {
        List<OrderedStpType> stplist = p2p.getEro().getOrderedSTP();
        if (stplist.isEmpty()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "ERO is empty");
        }
        if ((stplist.size() % 2) != 0) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "stplist.size() is " + stplist.size() + ", must be even number");
        }
        for (int i = 0; i < stplist.size(); i++) {
            checkSTPname(connectionId, stplist.get(i).getStp());
        }
        checkSTPterminal(connectionId, p2p.getSourceSTP(), stplist.get(0).getStp());
        checkSTPterminal(connectionId, p2p.getDestSTP(), stplist.get(stplist.size() - 1).getStp());
        for (int i = 1; i < stplist.size() - 1; i += 2) {
            STP src = STP.findSTP(stplist.get(i).getStp());
            STP dst = STP.findSTP(stplist.get(i + 1).getStp());
            if (src.nsa() != dst.nsa()) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                        connectionId,
                        "invalid stp pair, must be in the same NSA: src=" + src.stpid() + ", dst="
                                + dst.stpid());
            }
        }
        List<List<Term>> plans = new LinkedList<List<Term>>();
        List<Term> stpPath = new LinkedList<Term>();
        plans.add(stpPath);
        stpPath.add(stpid2term(connectionId, p2p.getSourceSTP()));
        for (OrderedStpType ostp : stplist) {
            stpPath.add(stpid2term(connectionId, ostp.getStp()));
        }
        stpPath.add(stpid2term(connectionId, p2p.getDestSTP()));
        dumpPathList(p2p.getSourceSTP(), p2p.getDestSTP(), stpPath);
        return plans;
    }

    private void dumpPathList(String start, String end, List<Term> path) {
        StringBuilder sb = new StringBuilder();
        sb.append("[" + start + " - " + end + "] = {\n");
        for (Term term : path) {
            sb.append("\t");
            sb.append(term.stpid());
            sb.append("\n");
        }
        sb.append("}");
        logger.info(sb.toString());
    }
}
