/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType;
import org.ogf.schemas.nsi._2013._12.framework.types.VariablesType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;
import org.ogf.schemas.nsi._2013._12.services.types.StpListType;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.SecurityUtil;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.nsi2.aggregator.ope.OperationSet;
import net.glambda.nsi2.aggregator.ope.ProvisionOpe;
import net.glambda.nsi2.aggregator.ope.ReleaseOpe;
import net.glambda.nsi2.aggregator.ope.ReserveAbortOpe;
import net.glambda.nsi2.aggregator.ope.ReserveCommitOpe;
import net.glambda.nsi2.aggregator.ope.ReserveOpe;
import net.glambda.nsi2.aggregator.ope.TerminateOpe;
import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.impl.ProviderArgument;
import net.glambda.nsi2.impl.SampleProviderHandler;
import net.glambda.nsi2.impl.StateMachineManager;
import net.glambda.nsi2.topology.DopnPathFinderUtil;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.Term;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.schemas._2013._12.services.dopn.LambdaType;
import net.glambda.schemas._2013._12.services.dopn.ODUType;

public class NSIAggregatorHandler extends SampleProviderHandler {

    protected static final Log logger = AbstractLog.getLog(NSIAggregatorHandler.class);
    private static final NSIProperties nsiProp = NSIProperties.getInstance();
    private static final String AIST_REQ_URL = nsiProp.getAggregatorRequesterURL();

    private static final boolean WAIT_ABORT_COMPLETE = false;

    private static NSA OTHER_NSA;

    static {
        String prov = nsiProp.getProperty("nsi.othernsa.name");
        String url = nsiProp.getProperty("nsi.othernsa.url");
        if (prov != null & url != null) {
            OTHER_NSA = new NSA(prov, url);
        } else {
            OTHER_NSA = null;
        }
    }

    private final AggregatorRequester requester;
    private final OperationBuilder opeBuilder;
    private final PathPlanner planner;
    private final DopnPathFinder dopnFinder;

    public NSIAggregatorHandler() throws Exception {
        super();
        this.requester = new AggregatorRequester(this);
        // this.planner = new PathPlannerImpl(); // new
        // PathPlannerWithEROImpl();
        this.planner = new PathPlannerWithStaticConf();
        this.dopnFinder = new DopnPathFinder();
        this.opeBuilder = new OperationBuilder(requester);
        SecurityUtil.publish(AIST_REQ_URL, requester);
        logger.info("start " + requester.getClass().getName() + " at " + AIST_REQ_URL);
    }

    private void abortAfterReserveFailed(OperationSet<ReserveOpe> rsvOpeSet) {
        OperationSet<ReserveAbortOpe> opeSet = opeBuilder.abortAfterReserveFailed(rsvOpeSet);
        if (opeSet == null) {
            return;
        }
        OperationInvoker<ReserveAbortOpe> invoker = new OperationInvoker<ReserveAbortOpe>(opeSet);
        invoker.startAll();
        if (WAIT_ABORT_COMPLETE) {
            try {
                invoker.waitAll();
            } catch (Exception e) {
                logger.warn("cannot abort after reservation failed, ignore", e);
            }
        }
    }

    private OperationSet<ReserveOpe> tryReservePlan(String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, List<Term> stpPath, long capacity)
            throws ServiceException {
        OperationSet<ReserveOpe> opeSet =
                opeBuilder.reserve(connectionId, globalReservationId, description, criteria,
                        stpPath, capacity);
        putReserveOpeSet(connectionId, opeSet);
        OperationInvoker<ReserveOpe> invoker = new OperationInvoker<ReserveOpe>(opeSet);
        invoker.startAll();
        try {
            invoker.waitAll();
            return opeSet;
        } catch (ServiceException e) {
            logger.warn(e);
            abortAfterReserveFailed(opeSet);
            throw e;
        }
    }

    private OperationSet<ReserveOpe> tryReservePlan(String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, P2PServiceBaseType p2p, List<Term> stpPath)
            throws ServiceException {
        OperationSet<ReserveOpe> opeSet;
        try {
            opeSet =
                    tryReservePlan(connectionId, globalReservationId, description, criteria,
                            stpPath, p2p.getCapacity());
            putReserveOpeSet(connectionId, opeSet);
            return opeSet;
        } catch (ServiceException e) {
            logger.warn(e);
            throw e;
        }
    }

    private final HashMap<String, OperationSet<ReserveOpe>> rsvOpeSetMap =
            new HashMap<String, OperationSet<ReserveOpe>>();

    private final HashMap<String, String> child2parentMap = new HashMap<String, String>();

    synchronized void putReserveOpeSet(String connectionId, OperationSet<ReserveOpe> opeSet)
            throws ServiceException {
        // connectionId : parent id
        rsvOpeSetMap.put(connectionId, opeSet);
        for (ReserveOpe ope : opeSet.opes()) {
            if (ope.connectionId() != null) {
                // ope.connectionId() : children id
                child2parentMap.put(ope.connectionId(), connectionId);
            }
        }
    }

    synchronized void removeReserveOpeSet(String connectionId) {
        OperationSet<ReserveOpe> opeSet = rsvOpeSetMap.remove(connectionId);
        if (opeSet != null) {
            for (ReserveOpe ope : opeSet.opes()) {
                if (ope.connectionId() != null) {
                    child2parentMap.remove(ope.connectionId());
                }
            }
            logger.info("remove reserveOpeSet of connId=" + connectionId);
        }
    }

    OperationSet<ReserveOpe> getReserveOpeSet(String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> opeSet = rsvOpeSetMap.get(connectionId);
        if (opeSet != null) {
            return opeSet;
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.CONNECTION_NONEXISTENT,
                    connectionId);
        }
    }

    String getParentConnectionId(String childConnectionId) throws ServiceException {
        String id = child2parentMap.get(childConnectionId);
        if (id != null) {
            return id;
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.CONNECTION_NONEXISTENT,
                    childConnectionId);
        }
    }

    private void reserveP2PwithPlans(ProviderArgument arg, String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, P2PServiceBaseType p2p, List<List<Term>> plans)
            throws ServiceException {
        int i = 0;
        ServiceException lastEx = null;
        for (List<Term> stpPath : plans) {
            try {
                logger.info("Try plan " + i + ", parent connId=" + connectionId);
                OperationSet<ReserveOpe> opeSet =
                        tryReservePlan(connectionId, globalReservationId, description, criteria,
                                p2p, stpPath);
                if (opeSet != null) {
                    logger.info("plan " + i + " succeeded, parent connId=" + connectionId);
                    return;
                } else {
                    logger.warn("plan " + i + " failed, parent connId=" + connectionId);
                }
                i++;
            } catch (ServiceException e) {
                lastEx = e;
            }
        }
        if (lastEx != null) {
            throw lastEx;
        }
    }

    private void reserveP2PbyOtherPA(ProviderArgument arg, String connectionId,
            String globalReservationId, String description, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        ReserveOpe ope =
                new ReserveOpe(requester, OTHER_NSA, globalReservationId, description, criteria);
        LinkedList<ReserveOpe> opeList = new LinkedList<ReserveOpe>();
        opeList.add(ope);
        OperationSet<ReserveOpe> opeSet = new OperationSet<ReserveOpe>(connectionId, opeList);
        putReserveOpeSet(connectionId, opeSet);
        OperationInvoker<ReserveOpe> invoker = new OperationInvoker<ReserveOpe>(opeSet);
        invoker.startAll();
        try {
            invoker.waitAll();
        } catch (ServiceException e) {
            logger.warn(e);
            throw e;
        }
    }

    private void dumpPathList(StringBuilder sb, List<Term> path) {
        sb.append("{\n");
        for (Term stp : path) {
            sb.append("\t");
            sb.append(stp.stpid());
            sb.append("\n");
        }
        sb.append("}");
    }

    private void dumpPathList(List<List<Term>> plans) {
        StringBuilder sb = new StringBuilder();
        for (List<Term> path : plans) {
            dumpPathList(sb, path);
            sb.append("\n");
        }
        logger.info(sb.toString().trim());
    }

    private void reserveP2P(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria, P2PServiceBaseType p2p)
            throws ServiceException {
        ServiceException ex = null;
        List<List<Term>> plans = null;
        try {
            plans = planner.makePlans(connectionId, criteria);
        } catch (ServiceException e) {
            logger.warn(e);
            ex = e;
        }
        if (plans != null) {
            dumpPathList(plans);
            reserveP2PwithPlans(arg, connectionId, globalReservationId, description, criteria, p2p,
                    plans);
        } else if (OTHER_NSA != null) {
            reserveP2PbyOtherPA(arg, connectionId, globalReservationId, description, criteria);
        } else {
            throw ex;
        }
    }

    private void reserveDopn(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        if (globalReservationId == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "globalReservationId");
        }
        PathFindingResult result = dopnFinder.query(globalReservationId, criteria);
        LinkedList<ReservationRequestCriteriaType> critList =
                DopnPathFinderUtil.makeCriteriaList(criteria, result);
        if (critList == null || critList.isEmpty()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.NO_PATH_FOUND, connectionId);
        }
        OperationSet<ReserveOpe> opeSet =
                opeBuilder.reserve(connectionId, globalReservationId, description, critList);
        putReserveOpeSet(connectionId, opeSet);
        OperationInvoker<ReserveOpe> invoker = new OperationInvoker<ReserveOpe>(opeSet);
        invoker.startAll();
        try {
            invoker.waitAll();
        } catch (ServiceException e) {
            logger.warn(e);
            // abortAfterReserveFailed(opeSet);
            throw e;
        }
        putReserveOpeSet(connectionId, opeSet); // re-set
    }

    @Override
    public void reserve(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        super.reserve(arg, connectionId, globalReservationId, description, criteria);
        Object o = TypesBuilder.getObject(criteria.getAny());
        if (o instanceof P2PServiceBaseType) {
            P2PServiceBaseType p2p = (P2PServiceBaseType) o;
            reserveP2P(arg, connectionId, globalReservationId, description, criteria, p2p);
        } else if (o instanceof ODUType) {
            reserveDopn(arg, connectionId, globalReservationId, description, criteria);
        } else if (o instanceof LambdaType) {
            reserveDopn(arg, connectionId, globalReservationId, description, criteria);
        } else if (o != null) {
            throw NSIExceptionUtil.makeServiceException("unsupported Criteria : "
                    + o.getClass().getName());
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "criteria");
        }
    }

    private void addExceptionText(TypeValuePairType pair, ServiceException ex) {
        if (ex.getFaultInfo() == null) {
            return;
        }
        for (ServiceExceptionType child : ex.getFaultInfo().getChildException()) {
            if (child == null) {
                continue;
            }
            if (child.getText() != null) {
                pair.getValue().add(child.getText());
            }
            if (child.getVariables() == null) {
                continue;
            }
            for (TypeValuePairType childPair : child.getVariables().getVariable()) {
                if (childPair != null && childPair.getValue() != null) {
                    pair.getValue().addAll(childPair.getValue());
                }
            }
        }
    }

    @Override
    protected ServiceExceptionType makeReserveFailedExecption(String connectionId, Exception e) {
        ServiceExceptionType ex = super.makeReserveFailedExecption(connectionId, e);
        OperationSet<ReserveOpe> rsvOpeSet = null;
        try {
            rsvOpeSet = getReserveOpeSet(connectionId);
        } catch (ServiceException e1) {
            return ex;
        }
        VariablesType var = new VariablesType();
        for (ReserveOpe ope : rsvOpeSet.opes()) {
            TypeValuePairType pair = new TypeValuePairType();
            pair.setType(ope.getNsaName());
            if (ope.getConfirmed() != null) {
                pair.getValue().add("OK");
            } else if (ope.getException() != null) {
                pair.getValue().add("FAILED");
                if (ope.getException().getMessage() != null) {
                    pair.getValue().add(ope.getException().getMessage());
                    if (ope.getException() instanceof ServiceException) {
                        addExceptionText(pair, (ServiceException) ope.getException());
                    }
                }
            } else {
                pair.getValue().add("TIMEOUT");
            }
            var.getVariable().add(pair);
        }
        //
        ServiceExceptionType sEx =
                NSIExceptionUtil.makeServiceExceptionType(ErrorID.INTERNAL_NRM_ERROR, connectionId);
        sEx.setText("summary status");
        sEx.setVariables(var);
        ex.getChildException().add(sEx);
        return ex;
    }

    @Override
    public void modify(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        super.modify(arg, connectionId, globalReservationId, description, criteria);
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        OperationSet<ReserveOpe> opeSet =
                opeBuilder.modify(rsvOpeSet, connectionId, globalReservationId, description,
                        criteria);
        putReserveOpeSet(connectionId, opeSet);
        OperationInvoker<ReserveOpe> invoker = new OperationInvoker<ReserveOpe>(opeSet);
        invoker.startAll();
        invoker.waitAll();
    }

    private StpListType makeStpList(LinkedList<ReserveOpe> opeList) throws ServiceException {
        if (opeList.size() <= 1) {
            return null;
        }
        LinkedList<String> stps = new LinkedList<String>();
        int i = 0, last = opeList.size() - 1;
        for (ReserveOpe ope : opeList) {
            ReservationConfirmCriteriaType conf = ope.getConfirmed();
            if (conf == null) {
                throw NSIExceptionUtil
                        .makeServiceException(ErrorID.INTERNAL_ERROR, ope.connectionId(),
                                "PROGRAM ERROR: ReservationConfirmCriteriaType is null");
            }
            String src, dst;
            Object o = TypesBuilder.getObject(conf.getAny());
            if (o instanceof P2PServiceBaseType) {
                P2PServiceBaseType p2p = (P2PServiceBaseType) o;
                src = p2p.getSourceSTP();
                dst = p2p.getDestSTP();
            } else if (o instanceof ODUType) {
                ODUType odu = (ODUType) o;
                src = odu.getSourceSTP();
                dst = odu.getDestSTP();
            } else {
                logger.warn("unknown Criteria type: " + o.getClass().getName());
                continue;
            }
            if (i > 0) {
                stps.add(src);
            }
            if (i < last) {
                stps.add(dst);
            }
            i++;
        }
        return TypesBuilder.stps2list(stps);
    }

    private static class TripleList {
        final LinkedList<String> route = new LinkedList<String>();
        final LinkedList<String> primary = new LinkedList<String>();
        final LinkedList<String> secondary = new LinkedList<String>();

        private StpListType getStpList(LinkedList<String> list) {
            if (list.size() < 2) {
                return null;
            }
            StpListType result =
                    TypesBuilder.stps2list(list.subList(1, list.size() - 1).toArray(new String[0]));
            return result;
        }

        private StpListType[] getStpList() {
            StpListType[] result = new StpListType[3];
            result[0] = getStpList(route);
            result[1] = getStpList(primary);
            result[2] = getStpList(secondary);
            return result;
        }
    }

    private StpListType[] makeStpListForLambda(LinkedList<ReserveOpe> opeList)
            throws ServiceException {
        TripleList result = new TripleList();
        LambdaType psrc = null, pdst = null;
        for (ReserveOpe ope : opeList) {
            ReservationConfirmCriteriaType conf = ope.getConfirmed();
            if (conf == null) {
                throw NSIExceptionUtil
                        .makeServiceException(ErrorID.INTERNAL_ERROR, ope.connectionId(),
                                "PROGRAM ERROR: ReservationConfirmCriteriaType is null");
            }
            String src, dst;
            Object o = TypesBuilder.getObject(conf.getAny());
            if (!(o instanceof LambdaType)) {
                continue;
            }
            LambdaType lambda = (LambdaType) o;
            src = lambda.getSourceSTP();
            dst = lambda.getDestSTP();
            switch (lambda.getPathType()) {
            case ERO_1:
            case ERO_2:
                result.route.add(src);
                result.route.add(dst);
                break;
            case PSRC:
                psrc = lambda;
                break;
            case PDST:
                pdst = lambda;
                break;
            case PRIMARY:
                result.primary.add(src);
                result.primary.add(dst);
                break;
            case SECONDARY:
                result.secondary.add(src);
                result.secondary.add(dst);
                break;
            }
        }
        if (psrc != null) {
            result.primary.addFirst(psrc.getDestSTP());
            result.primary.addFirst(psrc.getSourceSTP());
            result.secondary.addFirst(psrc.getSecondaryDestSTP());
            result.secondary.addFirst(psrc.getSourceSTP());
        }
        if (pdst != null) {
            result.primary.addLast(pdst.getSourceSTP());
            result.primary.addLast(pdst.getDestSTP());
            result.secondary.addLast(pdst.getSecondarySourceSTP());
            result.secondary.addLast(pdst.getDestSTP());
        }
        return result.getStpList();
    }

    protected ReservationConfirmCriteriaType makeReservationConfirmCriteria(
            ReservationRequestCriteriaType criteria, String connectionId, int version) {
        ReservationConfirmCriteriaType conf =
                super.makeReservationConfirmCriteria(criteria, connectionId, version);
        try {
            OperationSet<ReserveOpe> opeSet = getReserveOpeSet(connectionId);
            LinkedList<ReserveOpe> opeList = opeSet.opes();
            Object o = TypesBuilder.getObject(conf.getAny());
            if (o instanceof P2PServiceBaseType) {
                P2PServiceBaseType p2p = (P2PServiceBaseType) o;
                p2p.setEro(makeStpList(opeList));
            } else if (o instanceof ODUType) {
                ODUType odu = (ODUType) o;
                odu.setEro(makeStpList(opeList));
            } else if (o instanceof LambdaType) {
                LambdaType lambda = (LambdaType) o;
                StpListType[] routes = makeStpListForLambda(opeList);
                lambda.setEro(routes[0]);
                lambda.setPrimary(routes[1]);
                lambda.setSecondary(routes[2]);
            }
        } catch (ServiceException e) {
            logger.warn(e);
        }
        return conf;
    }

    @Override
    public void reserveCommit(ProviderArgument arg, String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        super.provision(arg, connectionId);
        OperationSet<ReserveCommitOpe> opeSet = opeBuilder.reserveCommit(rsvOpeSet);
        OperationInvoker<ReserveCommitOpe> invoker = new OperationInvoker<ReserveCommitOpe>(opeSet);
        invoker.startAll();
        invoker.waitAll();
    }

    @Override
    public void reserveAbort(ProviderArgument arg, String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        super.provision(arg, connectionId);
        OperationSet<ReserveAbortOpe> opeSet = opeBuilder.reserveAbort(rsvOpeSet);
        OperationInvoker<ReserveAbortOpe> invoker = new OperationInvoker<ReserveAbortOpe>(opeSet);
        invoker.startAll();
        invoker.waitAll();
    }

    @Override
    public void provision(ProviderArgument arg, String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        super.provision(arg, connectionId);
        OperationSet<ProvisionOpe> opeSet = opeBuilder.provision(rsvOpeSet);
        OperationInvoker<ProvisionOpe> invoker = new OperationInvoker<ProvisionOpe>(opeSet);
        invoker.startAll();
        invoker.waitAll();
    }

    @Override
    public void release(ProviderArgument arg, String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        super.release(arg, connectionId);
        OperationSet<ReleaseOpe> opeSet = opeBuilder.release(rsvOpeSet);
        OperationInvoker<ReleaseOpe> invoker = new OperationInvoker<ReleaseOpe>(opeSet);
        invoker.startAll();
        invoker.waitAll();
    }

    @Override
    public void terminate(ProviderArgument arg, String connectionId) throws ServiceException {
        OperationSet<ReserveOpe> rsvOpeSet = getReserveOpeSet(connectionId);
        super.terminate(arg, connectionId);
        OperationSet<TerminateOpe> opeSet = opeBuilder.terminate(rsvOpeSet);
        OperationInvoker<TerminateOpe> invoker = new OperationInvoker<TerminateOpe>(opeSet);
        try {
            invoker.startAll();
            invoker.waitAll();
        } finally {
            removeReserveOpeSet(connectionId);
            requester.getNotificationManager().clearDataMap(rsvOpeSet);
        }
    }

    private ChildSummaryType reserve2childSummary(ReserveOpe ope, int order) {
        ChildSummaryType child = new ChildSummaryType();
        ReservationRequestCriteriaType reqCrit = ope.getRequest();
        // NOTE: connectionId is required field, must not be null
        child.setConnectionId(ope.connectionId());
        child.setProviderNSA(ope.nsa().name());
        child.setOrder(order);
        if (reqCrit != null) {
            child.setServiceType(reqCrit.getServiceType());
            child.getAny().addAll(reqCrit.getAny());
            child.getOtherAttributes().putAll(reqCrit.getOtherAttributes());
        }
        return child;
    }

    @Override
    public QuerySummaryResultType querySummary(ProviderArgument arg, StateMachineManager smMgr,
            String connectionId) throws ServiceException {
        QuerySummaryResultType summary = super.querySummary(arg, smMgr, connectionId);
        for (QuerySummaryResultCriteriaType criteria : summary.getCriteria()) {
            OperationSet<ReserveOpe> rsvOpeSet;
            try {
                rsvOpeSet = getReserveOpeSet(connectionId);
            } catch (ServiceException e) {
                // path finding had failed and not reserved. ignore.
                continue;
            }
            ChildSummaryListType children = new ChildSummaryListType();
            criteria.setChildren(children);
            int order = NSIConstants.INITIAL_ORDER;
            for (ReserveOpe ope : rsvOpeSet.opes()) {
                if (ope.connectionId() != null) {
                    children.getChild().add(reserve2childSummary(ope, order));
                }
                order++;
            }
        }
        return summary;
    }

}
