/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.Calendar;

import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class DataPlaneStatusChangeData {

    private final CommonHeaderType header;
    private final String connectionId;
    private final long notificationId;
    private final Calendar timeStamp;
    private final DataPlaneStatusType dataPlaneStatus;
    private final Calendar recvTime;

    public DataPlaneStatusChangeData(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, DataPlaneStatusType dataPlaneStatus) {
        this.header = header;
        this.connectionId = connectionId;
        this.notificationId = notificationId;
        this.timeStamp = timeStamp;
        this.dataPlaneStatus = dataPlaneStatus;
        this.recvTime = Calendar.getInstance();
    }

    public CommonHeaderType getHeader() {
        return header;
    }

    public String getConnectionId() {
        return connectionId;
    }

    public long getNotificationId() {
        return notificationId;
    }

    public Calendar getTimeStamp() {
        return timeStamp;
    }

    public DataPlaneStatusType getDataPlaneStatus() {
        return dataPlaneStatus;
    }

    public Calendar getReceiveTime() {
        return recvTime;
    }

}
