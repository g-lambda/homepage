/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import net.glambda.nsi2.aggregator.ope.OpeBase;
import net.glambda.nsi2.aggregator.ope.OperationSet;
import net.glambda.nsi2.aggregator.ope.ReserveOpe;
import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSITextDump;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType;
import org.ogf.schemas.nsi._2013._12.framework.types.VariablesType;

public class OperationInvoker<T extends OpeBase> {

    private static final Log logger = LogFactory.getLog(OperationInvoker.class.getName());
    private static final NSIProperties nsiProp = NSIProperties.getInstance();

    private static final ExecutorService executor = Executors.newCachedThreadPool();

    private final OperationSet<T> opeSet;
    private final HashMap<Future<?>, OpeBase> futureMap = new LinkedHashMap<Future<?>, OpeBase>();

    private static final int FORK_TIMEOUT_SEC = (nsiProp.replyTimeoutSec() + 10);
    private static final long FORK_TIMEOUT_MILLISEC = 1000L * FORK_TIMEOUT_SEC;

    public OperationInvoker(OperationSet<T> opeSet) {
        this.opeSet = opeSet;
    }

    public synchronized void startAll() {
        futureMap.clear();
        for (OpeBase ope : opeSet.opes()) {
            Future<?> future = executor.submit(ope);
            futureMap.put(future, ope);
            ope.setOperationInvoker(this);
        }
    }

    public synchronized void waitAll() throws ServiceException {
        long deadline = System.currentTimeMillis() + FORK_TIMEOUT_MILLISEC;
        ServiceExceptionType opeEx = null;
        for (Entry<Future<?>, OpeBase> e : futureMap.entrySet()) {
            Future<?> future = e.getKey();
            OpeBase ope = e.getValue();
            try {
                future.get((deadline - System.currentTimeMillis()), TimeUnit.MILLISECONDS);
            } catch (InterruptedException e1) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.INTERNAL_NRM_ERROR,
                        ope.connectionId(), "operation thread interrupted!");
            } catch (TimeoutException e2) {
                String msg =
                        "TIMEOUT: " + ope.toString() + " didn't finish in " + FORK_TIMEOUT_SEC
                                + "[sec]";
                logger.error(msg);
                throw NSIExceptionUtil.makeServiceException(ErrorID.INTERNAL_NRM_ERROR,
                        ope.connectionId(), msg);
            } catch (ExecutionException e3) {
                logger.error("OpeException: " + ope.toString() + " is not finished", e3);
                throw NSIExceptionUtil.makeServiceException(ErrorID.INTERNAL_NRM_ERROR,
                        ope.connectionId(), "operation thread exception!");
            }
            //
            Exception ex = ope.getException();
            if (ex != null) {
                logger.warn("operation failed: " + ope.toString(), ex);
                if (opeEx == null) {
                    opeEx = new ServiceExceptionType();
                }
                opeEx.getChildException().add(makeServiceExceptionType(ope, ex));
            }
        }
        if (opeEx != null) {
            StringBuilder sb = new StringBuilder();
            for (ServiceExceptionType se : opeEx.getChildException()) {
                sb.append(se.getNsaId() + ": " + se.getText() + "\n");
            }
            throw NSIExceptionUtil.makeServiceException(ErrorID.INTERNAL_NRM_ERROR, null, sb
                    .toString().trim());
        }
    }

    public String status(OpeBase done) {
        StringBuilder sb = new StringBuilder();
        sb.append("operation summary of ");
        sb.append(futureMap.values().iterator().next().getClass().getSimpleName());
        sb.append("\n");
        for (Entry<Future<?>, OpeBase> e : futureMap.entrySet()) {
            Future<?> future = e.getKey();
            OpeBase ope = e.getValue();
            String status;
            String ex = null;
            if (ope != done && future.isDone() == false) {
                status = "  RUNNING ";
            } else if (ope.isSucceeded()) {
                status = "  OK      ";
            } else {
                status = "  FAILED  ";
                ex = ope.getException().getMessage();
            }
            sb.append(status);
            sb.append(ope.getNsaName());
            if (ope.startTime() != null && ope.endTime() != null) {
                sb.append(String
                        .format(Locale.US,
                                "\n\t\tstart = %1$tH:%1$tM:%1$tS.%1$tL, end = %2$tH:%2$tM:%2$tS.%2$tL, %3$.3f[sec]",
                                ope.startTime(), ope.endTime(),
                                (ope.endTime().getTimeInMillis() - ope.startTime()
                                        .getTimeInMillis()) / 1000.0));
            }
            sb.append("\n\t\tcorr = ");
            sb.append(ope.header().getCorrelationId());
            sb.append("\n\t\tconn = ");
            sb.append(ope.connectionId());
            if (ex != null) {
                sb.append("\n\t\terr  = ");
                sb.append(ex);
            }
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    private static TypeValuePairType makePair(String type, String value) {
        TypeValuePairType pair = new TypeValuePairType();
        pair.setType(type);
        pair.getValue().add(value);
        return pair;
    }

    private static String formatText(String txt) {
        txt = "\n" + txt.trim().replace("\t", "    ");
        return txt.replace("\n", "\n              ");
    }

    public static ServiceExceptionType makeServiceExceptionType(OpeBase ope, Exception e) {
        ServiceExceptionType nsiEx = new ServiceExceptionType();
        nsiEx.setNsaId(ope.nsa().name());
        nsiEx.setConnectionId(ope.connectionId());
        nsiEx.setErrorId("");
        nsiEx.setText(e.getMessage());
        VariablesType var = new VariablesType();
        nsiEx.setVariables(var);
        var.getVariable().add(makePair("CorrelationId", ope.header().getCorrelationId()));
        if (ope instanceof ReserveOpe) {
            ReservationRequestCriteriaType criteria = ((ReserveOpe) ope).getRequest();
            var.getVariable().add(
                    makePair("ReservationRequestCriteriaType",
                            formatText(NSITextDump.toString(criteria))));
        }
        var.getVariable().add(makePair("Exception", formatText(AbstractLog.abstractTrace(e))));
        return nsiEx;
    }

}
