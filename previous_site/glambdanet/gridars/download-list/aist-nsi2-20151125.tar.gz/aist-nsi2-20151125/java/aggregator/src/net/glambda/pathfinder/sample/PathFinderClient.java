/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.pathfinder.sample;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Calendar;

import net.glambda.pathfinder.IFTYPE;
import net.glambda.pathfinder.PathFinder;
import net.glambda.pathfinder.PathFindingCriteria;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.pathfinder.STP;
import net.glambda.pathfinder.SUPERNETWORK;

public class PathFinderClient {

    public static void main(String[] args) {
        try {
            Registry registry =
                    LocateRegistry.getRegistry(PathFinderServer.PATHFINDER_ADDR,
                            PathFinderServer.PATHFINDER_PORT);
            PathFinder finder = (PathFinder) registry.lookup(PathFinderServer.BIND_NAME);

            System.out.println("===== example: ODU =====");
            String queryId = "reservationId-1-2-3";
            STP src = new STP("net1", "local1", IFTYPE.ODU, "1", 1);
            STP dst = new STP("net2", "local2", IFTYPE.ODU, "1", 1);
            Calendar start = Calendar.getInstance();
            Calendar end = Calendar.getInstance();
            end.add(Calendar.MINUTE, 10);
            PathFindingCriteria criteria =
                    new PathFindingCriteria(queryId, SUPERNETWORK.ODUNW, start, end, src, dst,
                            false);
            System.out.println("* Criteria");
            System.out.println(criteria.toString());
            PathFindingResult result = finder.query(criteria);
            System.out.println("* Result");
            System.out.println(result.toString());

            System.out.println("===== example: LAMBDA w/ protection =====");
            queryId = "reservationId-1-2-4";
            src = new STP("net3", "local1", IFTYPE.LAMBDA, "5", 1);
            dst = new STP("net4", "local2", IFTYPE.LAMBDA, "5", 1);
            STP psrc = new STP("net5", "local1", IFTYPE.LAMBDA, "5", 1);
            STP pdst = new STP("net6", "local3", IFTYPE.LAMBDA, "5", 1);
            criteria =
                    new PathFindingCriteria(queryId, SUPERNETWORK.LAMBDANW, start, end, src, dst,
                            true, psrc, pdst);
            System.out.println("* Criteria");
            System.out.println(criteria.toString());
            result = finder.query(criteria);
            System.out.println("* Result");
            System.out.println(result.toString());

        } catch (Exception e) {
            System.err.println("Client exception:" + e.toString());
            e.printStackTrace();
        }
    }
}
