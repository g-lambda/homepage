/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.ArrayList;
import java.util.List;

import net.glambda.nsi2.topology.AllPathFinder;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;
import org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType;
import org.ogf.schemas.nsi._2013._12.services.types.StpListType;

public class PathPlannerWithEROImpl implements PathPlanner {

    protected static final Log logger = AbstractLog.getLog(PathPlannerWithEROImpl.class);

    private final AllPathFinder finder;

    public PathPlannerWithEROImpl() throws Exception {
        this.finder = new AllPathFinder();
    }

    @Override
    public List<List<Term>> makePlans(String connectionId, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        P2PServiceBaseType p2p = TypesBuilder.getP2PServiceBaseType(criteria);
        StpidVlan src = new StpidVlan(p2p.getSourceSTP());
        StpidVlan dst = new StpidVlan(p2p.getDestSTP());
        if (src.vlan != dst.vlan) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.VLANID_INTERCANGE_NOT_SUPPORTED,
                    connectionId, "cannot find path [" + src.stpid + ", " + dst.stpid
                            + "] because srcvlan=" + src.vlan + " != destvlan" + dst.vlan);
        }
        //
        List<List<Term>> pathList;
        try {
            pathList = finder.search(connectionId, src.stpid, dst.stpid, src.vlan);
        } catch (Exception e) {
            logger.warn(e, e.getCause());
            throw NSIExceptionUtil.makeServiceException(connectionId, e);
        }
        //
        if (p2p.getEro() == null) {
            return pathList;
        }
        List<Term> ero = ero2list(connectionId, p2p.getEro());
        return selectByERO(connectionId, pathList, ero);
    }

    private List<Term> ero2list(String connectionId, StpListType ero) throws ServiceException {
        List<Term> list = new ArrayList<Term>();
        for (OrderedStpType ostp : ero.getOrderedSTP()) {
            StpidVlan sv = new StpidVlan(ostp.getStp());
            STP stp = STP.findSTP(sv.stpid);
            if (stp != null) {
                list.add(new Term(stp, sv.vlan));
            } else {
                throw NSIExceptionUtil.makeServiceException(ErrorID.UNKNOWN_STP, connectionId,
                        ostp.getStp());
            }
        }
        return list;
    }

    private List<List<Term>> selectByERO(String connectionId, List<List<Term>> pathList,
            List<Term> ero) throws ServiceException {
        List<List<Term>> result = new ArrayList<List<Term>>();
        for (List<Term> path : pathList) {
            if (matchByERO(path, ero)) {
                result.add(path);
            }
        }
        if (result.isEmpty()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "cannot find any ERO matching path");
        } else {
            return result;
        }
    }

    private int indexOf(List<Term> path, Term stp, int index) {
        for (int i = index; i < path.size(); i++) {
            Term entry = path.get(i);
            if (entry.stp() == stp.stp()) {
                return i;
            }
        }
        return -1;
    }

    private boolean matchByERO(List<Term> path, List<Term> ero) {
        if (path.size() < ero.size()) {
            return false;
        }
        int index = 0;
        for (Term stp : ero) {
            index = indexOf(path, stp, index);
            if (index < 0) {
                return false;
            }
            index++;
        }
        return true;
    }

}
