/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.STPGroup;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.topology.VLanRange;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;

public class PathPlannerWithStaticConf extends PathPlannerImpl {

    protected static final Log logger = AbstractLog.getLog(PathPlannerWithStaticConf.class);

    private static final NSIProperties prop = NSIProperties.getInstance();
    private static final String PATH_CONF = prop.getProperty("nsi.staticpath.conf");
    private final File confFile;
    private long lastUpdate;
    private final HashMap<String, LinkedList<Term>> pathMap =
            new HashMap<String, LinkedList<Term>>();

    public PathPlannerWithStaticConf() throws Exception {
        super();
        this.confFile = new File(PATH_CONF);
        this.lastUpdate = -1;
        reload();
    }

    private void reload() {
        if (!confFile.canRead()) {
            return;
        }
        if (confFile.lastModified() > lastUpdate) {
            lastUpdate = confFile.lastModified();
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(lastUpdate);
            logger.info(String.format(Locale.US, "reload %s (updated at %tc)", PATH_CONF, c));
            updateMap();
        }
    }

    private String hashKey(String src, String dst) {
        return src + "#" + dst;
    }

    private String hashKey(Term src, Term dst) {
        return hashKey(src.stpid(), dst.stpid());
    }

    private void dump(String head, LinkedList<Term> stpPath) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        if (head != null) {
            sb.append(head);
            sb.append("\n");
        }
        for (Term stp : stpPath) {
            sb.append("\t");
            sb.append(stp.stpid());
            sb.append("\n");
        }
        logger.info(sb.toString());
    }

    private void putPath(LinkedList<Term> stpPath) {
        dump("static path", stpPath);
        //
        pathMap.put(hashKey(stpPath.getFirst(), stpPath.getLast()), stpPath);
        //
        LinkedList<Term> reverseList = new LinkedList<Term>();
        reverseList.addAll(stpPath);
        Collections.reverse(reverseList);
        pathMap.put(hashKey(reverseList.getFirst(), reverseList.getLast()), reverseList);
    }

    private LinkedList<Term> makeStpPath(LinkedList<String> path) {
        boolean valid = true;
        LinkedList<Term> stpPath = new LinkedList<Term>();
        STP prev = null;
        for (String name : path) {
            StpidVlan sv = new StpidVlan(name);
            STP stp = STP.findSTP(sv.stpid);
            if (stp != null) {
                if (sv.vlan > 0 && !stp.vlans().hasVlan(sv.vlan)) {
                    logger.warn("invalid static path: " + name + ", vlan must be in "
                            + stp.vlans().vlans());
                }
                if (prev != null && prev.nsa() != stp.nsa() && (prev instanceof STPGroup)
                        && (stp instanceof STPGroup)) {
                    STPGroup src = (STPGroup) prev;
                    STPGroup dst = (STPGroup) stp;
                    if (!src.isConnectedTo(dst)) {
                        logger.warn(src.stpid() + " doesn't connected to " + dst.stpid());
                    }
                    if (!dst.isConnectedTo(src)) {
                        logger.warn(dst.stpid() + " doesn't connected to " + src.stpid());
                    }
                }
                stpPath.add(new Term(stp, sv.vlan));
            } else {
                logger.warn("invalid static path: drop unknown STP: " + name);
                valid = false;
            }
            prev = stp;
        }
        if (valid) {
            return stpPath;
        } else {
            return null;
        }
    }

    private void updateMap() {
        LinkedList<LinkedList<String>> pathList;
        try {
            pathList = readFile();
        } catch (Exception e) {
            logger.warn(e);
            return;
        }
        pathList = expandVlanRange(pathList);
        synchronized (pathMap) {
            pathMap.clear();
            for (LinkedList<String> path : pathList) {
                LinkedList<Term> stpPath = makeStpPath(path);
                if (stpPath != null) {
                    putPath(stpPath);
                }
            }
        }
    }

    private VLanRange getVlan(String stp) {
        int idx = stp.indexOf(TypesBuilder.VLAN_MARK);
        if (idx > 0) {
            return new VLanRange(stp.substring(idx + TypesBuilder.VLAN_MARK.length()));
        } else {
            return new VLanRange("");
        }
    }

    private String[] splitStpid(String stp) {
        int idx = stp.indexOf(TypesBuilder.VLAN_MARK);
        if (idx > 0) {
            return new String[] { stp.substring(0, idx),
                    stp.substring(idx + TypesBuilder.VLAN_MARK.length()) };
        } else {
            return new String[] { stp, "" };
        }
    }

    private LinkedList<LinkedList<String>> expandVlanRange(LinkedList<LinkedList<String>> paths) {
        LinkedList<LinkedList<String>> result = new LinkedList<LinkedList<String>>();
        for (LinkedList<String> path : paths) {
            Integer[] range = getVlan(path.peekFirst()).range();
            if (range.length < 2) {
                result.add(path);
                continue;
            }
            for (int vlan : range) {
                LinkedList<String> newPath = new LinkedList<String>();
                for (String stp : path) {
                    String[] v = splitStpid(stp);
                    if (v[1].equals("*") || v[1].contains("-")) {
                        newPath.add(TypesBuilder.makeStpWithVlan(v[0], vlan));
                    } else {
                        newPath.add(stp);
                    }
                }
                result.add(newPath);
            }

        }
        return result;
    }

    private LinkedList<LinkedList<String>> readFile() throws Exception {
        InputStream in = new FileInputStream(confFile);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;
        LinkedList<LinkedList<String>> result = new LinkedList<LinkedList<String>>();
        LinkedList<String> path = null;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.startsWith("#")) {
                continue;
            }
            if (line.isEmpty()) {
                if (path != null) {
                    path = null;
                }
            } else {
                if (path == null) {
                    path = new LinkedList<String>();
                    result.add(path);
                }
                path.add(line);
            }
        }
        br.close();
        return result;
    }

    @Override
    public List<List<Term>> makePlans(String connectionId, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        reload();
        //
        P2PServiceBaseType p2p = TypesBuilder.getP2PServiceBaseType(criteria);
        String key = hashKey(p2p.getSourceSTP(), p2p.getDestSTP());
        LinkedList<Term> path = pathMap.get(key);
        if (path != null) {
            dump("use static path", path);
            List<List<Term>> plans = new LinkedList<List<Term>>();
            plans.add(path);
            return plans;
        } else {
            return super.makePlans(connectionId, criteria);
        }
    }

}
