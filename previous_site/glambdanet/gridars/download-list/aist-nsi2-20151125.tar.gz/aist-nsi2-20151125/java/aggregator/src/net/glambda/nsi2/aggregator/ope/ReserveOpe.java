/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator.ope;

import javax.xml.ws.Holder;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

import net.glambda.nsi2.impl.SampleRequesterWaitable;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.Term;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.TypesBuilder;

public class ReserveOpe extends OpeBase {

    private final String globalReservationId, description;
    private final ReservationRequestCriteriaType criteria;

    private ReservationConfirmCriteriaType confirmedCriteria = null;

    public ReserveOpe(SampleRequesterWaitable requester, NSA nsa, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria, Term src, Term dest,
            long capacity) {
        super(requester, nsa, null);
        this.globalReservationId = globalReservationId;
        this.description = description;
        this.criteria = makeSubCriteria(criteria, src, dest, capacity);
    }

    public ReserveOpe(SampleRequesterWaitable requester, NSA nsa, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) {
        super(requester, nsa, null);
        this.globalReservationId = globalReservationId;
        this.description = description;
        this.criteria = criteria;
    }

    public ReserveOpe(SampleRequesterWaitable requester, NSA nsa, String connectionId,
            String globalReservationId, String description, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        super(requester, nsa, connectionId);
        this.globalReservationId = globalReservationId;
        this.description = description;
        switch (criteria.getAny().size()) {
        case 0:
            // modify schedule only
            this.criteria = makeSubCriteria(criteria, 0);
            break;
        case 1:
            // modify schedule and/or capacity
            Long capacity = TypesBuilder.getLong(criteria.getAny());
            this.criteria = makeSubCriteria(criteria, capacity);
            break;
        default:
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "criteria.getAny() has " + criteria.getAny().size()
                            + " elements, must be 0 or 1");
        }
    }

    private ReservationRequestCriteriaType makeSubCriteria(ReservationRequestCriteriaType criteria,
            Term src, Term dest, long capacity) {
        return makeSubCriteria(criteria, src.stp().stpid(), src.vlan(), dest.stp().stpid(),
                dest.vlan(), capacity);
    }

    private ReservationRequestCriteriaType makeSubCriteria(ReservationRequestCriteriaType criteria,
            long capacity) {
        return makeSubCriteria(criteria, (String) null, NSIConstants.VLANID_NOTUSE, (String) null,
                NSIConstants.VLANID_NOTUSE, capacity);
    }

    private ReservationRequestCriteriaType makeSubCriteria(ReservationRequestCriteriaType criteria,
            String src, int srcvlan, String dst, int dstvlan, long capacity) {
        ReservationRequestCriteriaType subCriteria =
                TypesBuilder.makeReservationRequestCriteriaType(criteria.getSchedule(), src,
                        srcvlan, dst, dstvlan, capacity);
        subCriteria.setVersion(criteria.getVersion());
        subCriteria.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return subCriteria;
    }

    @Override
    protected void operation() throws Exception {
        CommonHeaderType header = makeCommonHeader();
        ConnectionProviderPort port = getProviderPort(header);

        Holder<String> holder = new Holder<String>();
        String connectionId = holder.value = connectionId();
        startLog(NSITextDump.toString(header, globalReservationId, description, connectionId,
                criteria), "ReserveRequest");
        port.reserve(holder, globalReservationId, description, criteria);
        if (connectionId() == null) {
            if (holder.value != null) {
                setConnectionId(holder.value);
            } else {
                logger.error("NSA " + nsa().name()
                        + " didn't reply connectionId for correrationId="
                        + header.getCorrelationId());
            }
        }

        Object o = waitReply(header);
        if (o instanceof ReservationConfirmCriteriaType) {
            confirmedCriteria = (ReservationConfirmCriteriaType) o;
        }
    }

    public ReservationRequestCriteriaType getRequest() {
        return criteria;
    }

    public ReservationConfirmCriteriaType getConfirmed() {
        // NOTE: some NSA doesn't fill all information
        return confirmedCriteria;
    }

    public boolean isSucceeded() {
        return super.isSucceeded() && (getConfirmed() != null);
    }

}
