/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.LinkedList;
import java.util.List;

import net.glambda.nsi2.aggregator.ope.OperationSet;
import net.glambda.nsi2.aggregator.ope.ProvisionOpe;
import net.glambda.nsi2.aggregator.ope.ReleaseOpe;
import net.glambda.nsi2.aggregator.ope.ReserveAbortOpe;
import net.glambda.nsi2.aggregator.ope.ReserveCommitOpe;
import net.glambda.nsi2.aggregator.ope.ReserveOpe;
import net.glambda.nsi2.aggregator.ope.TerminateOpe;
import net.glambda.nsi2.impl.SampleRequesterWaitable;
import net.glambda.nsi2.topology.DopnPathFinderUtil;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.Term;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;

public class OperationBuilder {

    private final SampleRequesterWaitable requester;

    public OperationBuilder(SampleRequesterWaitable requester) {
        this.requester = requester;
    }

    public OperationSet<ReserveOpe> reserve(String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria, List<Term> stpPath,
            long capacity) throws ServiceException {
        LinkedList<ReserveOpe> opeList = new LinkedList<ReserveOpe>();
        for (int i = 0; i < stpPath.size(); i += 2) {
            Term src = stpPath.get(i);
            Term dest = stpPath.get(i + 1);
            NSA nsa = src.stp().nsa();
            ReserveOpe ope =
                    new ReserveOpe(requester, nsa, globalReservationId, description, criteria, src,
                            dest, capacity);
            opeList.add(ope);
        }
        return new OperationSet<ReserveOpe>(connectionId, opeList);
    }

    public OperationSet<ReserveOpe> reserve(String connectionId, String globalReservationId,
            String description, LinkedList<ReservationRequestCriteriaType> subCriteriaList)
            throws ServiceException {
        LinkedList<ReserveOpe> opeList = new LinkedList<ReserveOpe>();
        for (ReservationRequestCriteriaType sub : subCriteriaList) {
            ReserveOpe ope =
                    new ReserveOpe(requester, DopnPathFinderUtil.DOPN_NSA, globalReservationId,
                            description, sub);
            opeList.add(ope);
        }
        return new OperationSet<ReserveOpe>(connectionId, opeList);
    }

    public OperationSet<ReserveOpe> modify(OperationSet<ReserveOpe> rsvOpeSet, String connectionId,
            String globalReservationId, String description, ReservationRequestCriteriaType criteria)
            throws ServiceException {
        LinkedList<ReserveOpe> opeList = new LinkedList<ReserveOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            ReserveOpe provOpe =
                    new ReserveOpe(requester, rsvOpe.nsa(), rsvOpe.connectionId(),
                            globalReservationId, description, criteria);
            opeList.add(provOpe);
        }
        return new OperationSet<ReserveOpe>(connectionId, opeList);
    }

    public OperationSet<ProvisionOpe> provision(OperationSet<ReserveOpe> rsvOpeSet) {
        LinkedList<ProvisionOpe> opeList = new LinkedList<ProvisionOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            ProvisionOpe provOpe = new ProvisionOpe(rsvOpe);
            opeList.add(provOpe);
        }
        return new OperationSet<ProvisionOpe>(rsvOpeSet.connectionId(), opeList);
    }

    public OperationSet<ReleaseOpe> release(OperationSet<ReserveOpe> rsvOpeSet) {
        LinkedList<ReleaseOpe> opeList = new LinkedList<ReleaseOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            ReleaseOpe relOpe = new ReleaseOpe(rsvOpe);
            opeList.add(relOpe);
        }
        return new OperationSet<ReleaseOpe>(rsvOpeSet.connectionId(), opeList);
    }

    public OperationSet<TerminateOpe> terminate(OperationSet<ReserveOpe> rsvOpeSet) {
        LinkedList<TerminateOpe> opeList = new LinkedList<TerminateOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            TerminateOpe termOpe = new TerminateOpe(rsvOpe);
            opeList.add(termOpe);
        }
        return new OperationSet<TerminateOpe>(rsvOpeSet.connectionId(), opeList);
    }

    public OperationSet<ReserveCommitOpe> reserveCommit(OperationSet<ReserveOpe> rsvOpeSet) {
        LinkedList<ReserveCommitOpe> opeList = new LinkedList<ReserveCommitOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            ReserveCommitOpe cmtOpe = new ReserveCommitOpe(rsvOpe);
            opeList.add(cmtOpe);
        }
        return new OperationSet<ReserveCommitOpe>(rsvOpeSet.connectionId(), opeList);
    }

    public OperationSet<ReserveAbortOpe> reserveAbort(OperationSet<ReserveOpe> rsvOpeSet) {
        return reserveAbort(rsvOpeSet, true);

    }

    public OperationSet<ReserveAbortOpe> abortAfterReserveFailed(OperationSet<ReserveOpe> rsvOpeSet) {
        return reserveAbort(rsvOpeSet, false);
    }

    private OperationSet<ReserveAbortOpe> reserveAbort(OperationSet<ReserveOpe> rsvOpeSet,
            boolean bAllNSA) {
        LinkedList<ReserveAbortOpe> opeList = new LinkedList<ReserveAbortOpe>();
        for (ReserveOpe rsvOpe : rsvOpeSet.opes()) {
            if (bAllNSA || rsvOpe.isSucceeded()) {
                // NOTE: abort all or NSA which reservation has succeeded
                ReserveAbortOpe abtOpe = new ReserveAbortOpe(rsvOpe);
                opeList.add(abtOpe);
            }
        }
        if (opeList.isEmpty()) {
            return null;
        } else {
            return new OperationSet<ReserveAbortOpe>(rsvOpeSet.connectionId(), opeList);
        }
    }

}
