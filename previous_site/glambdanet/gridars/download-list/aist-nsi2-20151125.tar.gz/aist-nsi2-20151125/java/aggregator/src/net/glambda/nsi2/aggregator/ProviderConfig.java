/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.TopologyLoader;
import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;

public class ProviderConfig {

    protected static final Log logger = AbstractLog.getLog(ProviderConfig.class);
    private static final String CONF_FILE = "etc/provider.conf";
    private final HashMap<String, NSA> confMap = new LinkedHashMap<String, NSA>();

    public ProviderConfig() {
        load();
    }

    private void load() {
        InputStream is = null;
        BufferedReader br = null;
        LinkedList<NSA> netList = TopologyLoader.loadAll();
        boolean bOrig = false, bProxy = false;
        HashSet<String> orgs = new HashSet<String>();
        try {
            is = this.getClass().getResourceAsStream("/" + CONF_FILE);
            if (is == null) {
                is = new FileInputStream(CONF_FILE);
            }
            br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                if (line.startsWith("#")) {
                    continue;
                }
                if (line.equals("ORIGINAL")) {
                    bOrig = true;
                    bProxy = false;
                    continue;
                }
                if (line.equals("PROXY")) {
                    bOrig = false;
                    bProxy = true;
                    continue;
                }
                String[] v = line.split(" *, *");
                if (v.length >= 2) {
                    NSA src = NSA.findNSA(v[0]);
                    if (src == null) {
                        logger.warn("invalid NSA name in " + CONF_FILE + " , ignore : " + v[0]);
                        continue;
                    }
                    NSA dst;
                    if (v.length >= 3) {
                        dst = new NSA(v[1], v[2]);
                    } else {
                        dst = NSA.findNSA(v[1]);
                        if (dst == null) {
                            logger.warn("invalid NSA name in " + CONF_FILE + " , ignore : " + v[1]);
                            continue;
                        }
                    }
                    confMap.put(src.name(), dst);
                    logger.info("send request for " + src.name() + " -> " + dst.name() + ", "
                            + dst.csEndpoint());
                } else if (v.length == 1) {
                    if (bOrig) {
                        orgs.add(line);
                    } else if (bProxy) {
                        bProxy = false;
                        NSA dst = NSA.findNSA(line);
                        if (dst == null) {
                            logger.warn("invalid NSA name in " + CONF_FILE + " , ignore : " + line);
                            continue;
                        }
                        for (NSA nsa : netList) {
                            if (!orgs.contains(nsa.name())) {
                                confMap.put(nsa.name(), dst);
                                logger.info("send request for " + nsa.name() + " -> " + dst.name()
                                        + ", " + dst.csEndpoint());
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            logger.warn("cannot read " + CONF_FILE, e);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    logger.warn("cannot close " + CONF_FILE, e);
                }
            } else if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    logger.warn("cannot close " + CONF_FILE, e);
                }
            }
        }
    }

    public NSA getNSA(NSA src) {
        NSA dst = confMap.get(src.name());
        if (dst != null) {
            return dst;
        } else {
            return src;
        }
    }
}
