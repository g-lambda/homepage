/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.util.Calendar;
import java.util.HashMap;

import net.glambda.nsi2.aggregator.ope.OperationSet;
import net.glambda.nsi2.aggregator.ope.ReserveOpe;
import net.glambda.nsi2.impl.SampleNotifier;
import net.glambda.nsi2.impl.StateMachine;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.rms.DataPlaneState;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class NotificationManager {

    protected static final Log logger = AbstractLog.getLog(NotificationManager.class);

    private final NSIAggregatorHandler handler;
    private final SampleNotifier notifier;
    private final HashMap<String, DataPlaneStatusChangeData> dataMap =
            new HashMap<String, DataPlaneStatusChangeData>();

    public NotificationManager(NSIAggregatorHandler handler) {
        this.handler = handler;
        this.notifier = new SampleNotifier(handler);
    }

    public synchronized void dataPlaneStateChange(CommonHeaderType header,
            String childConnectionId, long notificationId, Calendar timeStamp,
            DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        String parentConnectionId = handler.getParentConnectionId(childConnectionId);
        OperationSet<ReserveOpe> rsvOpeSet = handler.getReserveOpeSet(parentConnectionId);
        DataPlaneStatusChangeData data =
                new DataPlaneStatusChangeData(header, childConnectionId, notificationId, timeStamp,
                        dataPlaneStatus);
        dataMap.put(data.getConnectionId(), data);
        dump(parentConnectionId, rsvOpeSet);
        StateMachine sm = handler.getStatusMachineManager().getStateMachine(parentConnectionId);
        ConnectionStatesType connStates = sm.getConnectionStates();
        switch (connStates.getProvisionState()) {
        case PROVISIONING:
        case PROVISIONED:
            if (isReceivedAll(rsvOpeSet) && !connStates.getDataPlaneStatus().isActive()) {
                clearDataMap(rsvOpeSet);
                sendChange(parentConnectionId, rsvOpeSet, DataPlaneState.ACTIVE);
            } else {
                // wait another notifications
            }
            break;
        case RELEASING:
        case RELEASED:
            if (connStates.getDataPlaneStatus().isActive()) {
                sendChange(parentConnectionId, rsvOpeSet, DataPlaneState.INACTIVE);
            } else if (isReceivedAll(rsvOpeSet)) {
                clearDataMap(rsvOpeSet);
            } else {
                // already sent notification to client. ignore
            }
            break;
        }
    }

    private void dump(String parentConnectionId, OperationSet<ReserveOpe> rsvOpeSet) {
        StringBuilder sb = new StringBuilder();
        sb.append("notifications of parentConnId=");
        sb.append(parentConnectionId);
        sb.append("\n");
        for (ReserveOpe ope : rsvOpeSet.opes()) {
            String childId = ope.connectionId();
            DataPlaneStatusChangeData data = dataMap.get(childId);
            if (data == null) {
                sb.append("  not yet             ");
            } else {
                if (data.getDataPlaneStatus().isActive()) {
                    sb.append("  ACTIVE   ");
                } else {
                    sb.append("  INACTIVE ");
                }
                long start = ope.getRequest().getSchedule().getStartTime().getTimeInMillis();
                long recv = data.getReceiveTime().getTimeInMillis();
                double elapse = (recv - start) / 1000.0;
                if (elapse < 1000) {
                    sb.append(String.format("%6.3f[s]  ", elapse));
                }
            }
            sb.append(ope.getNsaName());
            sb.append("\n");
        }
        logger.info(sb.toString().trim());
    }

    private boolean isReceivedAll(OperationSet<ReserveOpe> rsvOpeSet) {
        for (ReserveOpe ope : rsvOpeSet.opes()) {
            String childId = ope.connectionId();
            DataPlaneStatusChangeData data = dataMap.get(childId);
            if (data == null) {
                return false;
            }
        }
        return true;
    }

    public synchronized void clearDataMap(OperationSet<ReserveOpe> rsvOpeSet) {
        for (ReserveOpe ope : rsvOpeSet.opes()) {
            String childId = ope.connectionId();
            dataMap.remove(childId);
        }
    }

    private boolean isConsistent(OperationSet<ReserveOpe> rsvOpeSet) {
        int prevVer = -1;
        for (ReserveOpe ope : rsvOpeSet.opes()) {
            String childId = ope.connectionId();
            DataPlaneStatusChangeData data = dataMap.get(childId);
            if (data != null) {
                if (prevVer < 0) {
                    prevVer = data.getDataPlaneStatus().getVersion();
                } else if (prevVer != data.getDataPlaneStatus().getVersion()) {
                    return false;
                }
            }
        }
        return true;
    }

    private void sendChange(String parentConnectionId, OperationSet<ReserveOpe> rsvOpeSet,
            DataPlaneState state) {
        notifier.dataPlaneStateChange(parentConnectionId, state, isConsistent(rsvOpeSet));
    }
}
