/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.aggregator;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.pathfinder.IFTYPE;
import net.glambda.pathfinder.PathFinder;
import net.glambda.pathfinder.PathFindingCriteria;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.pathfinder.STP;
import net.glambda.pathfinder.SUPERNETWORK;
import net.glambda.rms.types.StpType;
import net.glambda.schemas._2013._12.services.dopn.LambdaType;
import net.glambda.schemas._2013._12.services.dopn.ODUType;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType;
import org.ogf.schemas.nsi._2013._12.services.types.StpListType;

public class DopnPathFinder {

    protected static final Log logger = AbstractLog.getLog(DopnPathFinder.class);

    private static final String PROPKEY_PATHFINDER = "nsi.dopn.pathfinder";

    private PathFinder connect() {
        NSIProperties prop = NSIProperties.getInstance();
        String v = prop.getProperty(PROPKEY_PATHFINDER);
        if (v == null) {
            logger.info("missing " + PROPKEY_PATHFINDER);
            return null;
        }
        String[] t = v.split(":");
        if (t.length != 3) {
            logger.error("invalid " + PROPKEY_PATHFINDER + ": " + v);
            return null;
        }
        logger.info("try to connect to RMI PathFinder: " + v);
        try {
            Registry registry = LocateRegistry.getRegistry(t[0], Integer.parseInt(t[1]));
            PathFinder finder = (PathFinder) registry.lookup(t[2]);
            logger.info("connected to RMI PathFinder: " + v);
            return finder;
        } catch (Exception e) {
            logger.error("cannot connect to RMI PathFinder", e);
            return null;
        }
    }

    private PathFindingCriteria oduToCriteria(String globalReservationId,
            ReservationRequestCriteriaType criteria, ODUType odu) throws ServiceException {
        Calendar start = criteria.getSchedule().getStartTime();
        Calendar end = criteria.getSchedule().getEndTime();
        StpType nsiSrc = TypesBuilder.makeStpType(odu.getSourceSTP());
        StpType nsiDst = TypesBuilder.makeStpType(odu.getDestSTP());
        IFTYPE iftype = IFTYPE.ODU;
        String id = odu.getSourceTsId();
        int width = odu.getTsWidth();
        net.glambda.pathfinder.STP src =
                new net.glambda.pathfinder.STP(nsiSrc.getNetworkId(), nsiSrc.getLocalId(), iftype,
                        id, width);
        net.glambda.pathfinder.STP dst =
                new net.glambda.pathfinder.STP(nsiDst.getNetworkId(), nsiDst.getLocalId(), iftype,
                        id, width);
        PathFindingCriteria crit =
                new PathFindingCriteria(globalReservationId, SUPERNETWORK.ODUNW, start, end, src,
                        dst, false);
        crit.ero = makeStplist(odu.getEro(), iftype, id, width);
        return crit;
    }

    private List<STP> makeStplist(StpListType nsiList, IFTYPE iftype, String id, int width) {
        if (nsiList == null) {
            return null;
        }
        List<STP> list = new LinkedList<STP>();
        for (OrderedStpType ostp : nsiList.getOrderedSTP()) {
            StpType nsiStp = TypesBuilder.makeStpType(ostp.getStp());
            STP stp = new STP(nsiStp.getNetworkId(), nsiStp.getLocalId(), iftype, id, width);
            list.add(stp);
        }
        return list;
    }

    private PathFindingCriteria lambdaToCriteria(String globalReservationId,
            ReservationRequestCriteriaType criteria, LambdaType lambda) throws ServiceException {
        Calendar start = criteria.getSchedule().getStartTime();
        Calendar end = criteria.getSchedule().getEndTime();
        StpType nsiSrc = TypesBuilder.makeStpType(lambda.getSourceSTP());
        StpType nsiDst = TypesBuilder.makeStpType(lambda.getDestSTP());
        IFTYPE iftype = IFTYPE.LAMBDA;
        String id = lambda.getSourceLambdaId();
        int width = lambda.getLambdaWidth();
        net.glambda.pathfinder.STP src =
                new net.glambda.pathfinder.STP(nsiSrc.getNetworkId(), nsiSrc.getLocalId(), iftype,
                        id, width);
        net.glambda.pathfinder.STP dst =
                new net.glambda.pathfinder.STP(nsiDst.getNetworkId(), nsiDst.getLocalId(), iftype,
                        id, width);
        //
        boolean isProtection = lambda.isIsProtection();
        StpType nsiProtSrc = TypesBuilder.makeStpType(lambda.getProtectionSourceSTP());
        net.glambda.pathfinder.STP protSrc;
        if (nsiProtSrc != null) {
            protSrc =
                    new net.glambda.pathfinder.STP(nsiProtSrc.getNetworkId(),
                            nsiProtSrc.getLocalId(), iftype, id, width);
        } else {
            protSrc = null;
        }
        StpType nsiProtDst = TypesBuilder.makeStpType(lambda.getProtectionDestSTP());
        net.glambda.pathfinder.STP protDst;
        if (nsiProtDst != null) {
            protDst =
                    new net.glambda.pathfinder.STP(nsiProtDst.getNetworkId(),
                            nsiProtDst.getLocalId(), iftype, id, width);
        } else {
            protDst = null;
        }

        PathFindingCriteria crit =
                new PathFindingCriteria(globalReservationId, SUPERNETWORK.LAMBDANW, start, end,
                        src, dst, isProtection, protSrc, protDst);
        crit.primary = makeStplist(lambda.getPrimary(), iftype, id, width);
        crit.secondary = makeStplist(lambda.getSecondary(), iftype, id, width);
        crit.ero = makeStplist(lambda.getEro(), iftype, id, width);
        return crit;
    }

    public PathFindingResult query(String globalReservationId,
            ReservationRequestCriteriaType criteria) throws ServiceException {
        PathFinder finder = connect();
        if (finder == null) {
            throw NSIExceptionUtil.makeServiceException("cannot connect to PathFinder");
        }
        Object o = TypesBuilder.getObject(criteria.getAny());
        PathFindingCriteria findCriteria = null;
        if (o instanceof ODUType) {
            findCriteria = oduToCriteria(globalReservationId, criteria, (ODUType) o);
        } else if (o instanceof LambdaType) {
            findCriteria = lambdaToCriteria(globalReservationId, criteria, (LambdaType) o);
        } else {
            throw NSIExceptionUtil.makeServiceException("unsupported Criteria type: "
                    + o.getClass().getName());
        }
        logger.info("try path finding");
        logger.info(NSITextDump.toString(findCriteria));
        long start = System.currentTimeMillis();
        try {
            PathFindingResult result = finder.query(findCriteria);
            long elapse = System.currentTimeMillis() - start;
            if (elapse >= 10000) {
                logger.warn(globalReservationId + " path finding in " + elapse + "[msec]");
            } else {
                logger.info(globalReservationId + " path finding in " + elapse + "[msec]");
            }
            logger.info(NSITextDump.toString(result));
            return result;
        } catch (Exception e) {
            logger.error("PathFinder failed", e);
            throw NSIExceptionUtil
                    .makeServiceException(ErrorID.NO_PATH_FOUND, null, e.getMessage());
        }
    }

}
