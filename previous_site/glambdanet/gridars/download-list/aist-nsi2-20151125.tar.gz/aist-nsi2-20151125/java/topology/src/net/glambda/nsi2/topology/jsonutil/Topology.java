/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology.jsonutil;

import java.util.LinkedList;

import net.arnx.jsonic.JSONHint;

public class Topology {

    private String nsa;
    private String name;
    private LinkedList<String> port = new LinkedList<String>();
    private LinkedList<String> terminal = new LinkedList<String>();

    public Topology() {
        this(null, null);
    }

    public Topology(String nsa, String name) {
        this.nsa = nsa;
        this.name = name;
    }

    @JSONHint(ordinal = 0)
    public String getNsa() {
        return nsa;
    }

    public void setNsa(String nsa) {
        this.nsa = nsa;
    }

    @JSONHint(ordinal = 1)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JSONHint(ordinal = 2)
    public LinkedList<String> getPort() {
        return port;
    }

    public void setPort(LinkedList<String> port) {
        this.port = port;
    }

    @JSONHint(ordinal = 3)
    public LinkedList<String> getTerminal() {
        return terminal;
    }

    public void setTerminal(LinkedList<String> terminal) {
        this.terminal = terminal;
    }
}
