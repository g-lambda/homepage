/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;

public class STP {

    public enum STPType {
        BI, IN, OUT;
    }

    protected static final Log logger = AbstractLog.getLog(STP.class);

    private final String stpid, connectedTo;
    private final VLanRange vlanRange;
    private final STPType type;
    private NSA nsa;

    private static final boolean USE_SHORT_NAME = false;

    public STP(String stpid, String vlans, String connectedTo, STPType type) {
        this.stpid = stpid.trim();
        if (vlans != null) {
            this.vlanRange = new VLanRange(vlans);
        } else {
            this.vlanRange = null;
        }
        this.type = type;
        if (connectedTo != null) {
            this.connectedTo = connectedTo.trim();
        } else {
            this.connectedTo = null;
        }
        stpMap.put(stpid, this);
        String shortName = shortName(stpid);
        if (!shortName.equals(stpid)) {
            stpMap.put(shortName, this);
        }
        this.nsa = null;
    }

    public STP(String stpid, NSA nsa) {
        this.stpid = stpid.trim();
        this.connectedTo = null;
        this.vlanRange = null;
        this.type = STPType.BI;
        this.nsa = nsa;
    }

    public STP(STP stp) {
        this.stpid = stp.stpid;
        this.vlanRange = stp.vlanRange;
        this.type = stp.type;
        this.connectedTo = stp.connectedTo;
        this.nsa = stp.nsa;
        // don't put to stpMap
    }

    private static final HashMap<String, STP> stpMap = new HashMap<String, STP>();

    public static STP findSTP(String stpname) {
        STP stp = stpMap.get(stpname);
        if (USE_SHORT_NAME) {
            if (stp == null) {
                stp = stpMap.get(shortName(stpname));
            }
        }
        return stp;
    }

    public STPType type() {
        return type;
    }

    void setNSA(NSA nsa) {
        this.nsa = nsa;
    }

    public NSA nsa() {
        return nsa;
    }

    public String stpid() {
        return stpid;
    }

    public static final Pattern NAME = Pattern
            .compile("urn:ogf:network:([^\\.:]+)[^:]*:[^:]+:(.+)");

    public static String shortName(String name) {
        Matcher m = NAME.matcher(name);
        if (m.find()) {
            return m.group(1) + ":" + m.group(2);
        } else {
            return name;
        }
    }

    private static final HashSet<String> invalidNames = new HashSet<String>();

    public STP connectedTo() {
        if (connectedTo != null) {
            STP conn = findSTP(connectedTo);
            if (conn == null) {
                if (!invalidNames.contains(connectedTo)) {
                    invalidNames.add(connectedTo);
                    String msg = "cannot find STP entry of " + connectedTo;
                    System.err.println(msg);
                    logger.warn(msg);
                }
            }
            return conn;
        } else {
            return null;
        }
    }

    public String connectedToSTPName() {
        return connectedTo;
    }

    public NSA connectedToNSA() {
        STP conn = connectedTo();
        if (conn != null) {
            return conn.nsa();
        } else {
            return null;
        }
    }

    public boolean isConnected() {
        return (connectedTo != null);
    }

    public VLanRange vlans() {
        return vlanRange;
    }

    public String toString() {
        return "STP(" + type + ") " + stpid + ", connTo=" + connectedTo + ", vlan=" + vlans();
    }

}
