/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VLanRange {

    private final String vlans;
    private final TreeSet<Integer> range;

    private static final HashMap<String, TreeSet<Integer>> rangeMap =
            new HashMap<String, TreeSet<Integer>>();

    private static final Pattern RANGE = Pattern.compile("([0-9]+)-?([0-9]+)?");

    private static final VLanRange DEFAULT_RANGE = new VLanRange("");

    public VLanRange(String vlans) {
        this.vlans = vlans;
        TreeSet<Integer> set = rangeMap.get(vlans);
        if (set == null) {
            range = makeRange(vlans);
            rangeMap.put(vlans, range);
        } else {
            range = set;
        }
    }

    public static VLanRange getDefaultRange() {
        return DEFAULT_RANGE;
    }

    private TreeSet<Integer> makeRange(String vlans) {
        TreeSet<Integer> set = new TreeSet<Integer>();
        Matcher m = RANGE.matcher(vlans);
        while (m.find()) {
            int min = Integer.parseInt(m.group(1));
            int max;
            if (m.group(2) != null) {
                max = Integer.parseInt(m.group(2));
            } else {
                max = min;
            }
            int len = max - min + 1;
            if (len > 0) {
                for (int vlanid = min; vlanid <= max; vlanid++) {
                    set.add(vlanid);
                }
            } else {
                System.err.println("FATAL: invalid range : " + vlans);
            }
        }
        return set;
    }

    public Integer[] range() {
        return range.toArray(new Integer[0]);
    }

    public boolean hasVlan(int vlan) {
        return range.contains(vlan);
    }

    public String vlans() {
        return vlans;
    }

    public boolean partialMatch(VLanRange other) {
        for (int myvlan : range) {
            for (int othervlan : other.range) {
                if (myvlan == othervlan) {
                    return true;
                }
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (range.size() < 100) {
            for (int v : range) {
                sb.append(v);
                sb.append(" ");
            }
        } else {
            sb.append(range.first());
            sb.append(" ... ");
            sb.append(range.last());
        }
        return "{" + vlans + "=" + sb.toString().trim() + "}";
    }

    public static void main(String args[]) throws Exception {
        System.out.println(new VLanRange(""));
        System.out.println(new VLanRange("1780-1783"));
        System.out.println(new VLanRange("1780"));
        System.out.println(new VLanRange("1779,1785-1799"));
        System.out.println(new VLanRange("1779-1782,1785-1799"));
    }
}
