/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology.jsonutil;

import java.util.HashSet;
import java.util.LinkedList;

import net.arnx.jsonic.JSONHint;
import net.glambda.nsi2.util.NSIUtil;

public class DDSTopology {

    public LinkedList<Topology> topology = new LinkedList<Topology>();
    public LinkedList<String[]> relation = new LinkedList<String[]>();

    private final HashSet<String> relSet = new HashSet<String>();

    @JSONHint(ordinal = 0)
    public LinkedList<Topology> getTopology() {
        return topology;
    }

    public void setTopology(LinkedList<Topology> topology) {
        this.topology = topology;
    }

    @JSONHint(ordinal = 1)
    public LinkedList<String[]> getRelation() {
        return relation;
    }

    public void setRelation(LinkedList<String[]> relation) {
        this.relation = relation;
    }

    private String relName(String src, String dst) {
        return src + "$" + dst;
    }

    public void addRelation(String src, String dst) {
        if (src.equals(dst)) {
            return;
        }
        String[] v = new String[2];
        v[0] = NSIUtil.dropPrefix(src);
        v[1] = NSIUtil.dropPrefix(dst);
        if (!relSet.contains(relName(v[0], v[1])) && !relSet.contains(relName(v[1], v[0]))) {
            relation.add(v);
            relSet.add(relName(v[0], v[1]));
        }
    }

}
