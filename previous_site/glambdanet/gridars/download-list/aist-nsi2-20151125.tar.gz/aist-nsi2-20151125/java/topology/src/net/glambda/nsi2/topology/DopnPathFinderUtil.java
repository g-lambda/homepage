/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.pathfinder.Path;
import net.glambda.pathfinder.STP;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.schemas._2013._12.services.dopn.LambdaType;
import net.glambda.schemas._2013._12.services.dopn.ODUType;
import net.glambda.schemas._2013._12.services.dopn.PathType;

public class DopnPathFinderUtil {

    protected static final Log logger = AbstractLog.getLog(DopnPathFinderUtil.class);

    public static final NSA DOPN_NSA;

    static {
        NSIProperties prop = NSIProperties.getInstance();
        String url = prop.getProperty("nsi.dopn.nrm");
        LinkedList<net.glambda.nsi2.topology.STP> emptyList =
                new LinkedList<net.glambda.nsi2.topology.STP>();
        DOPN_NSA = new NSA("DOPN_NRM", "DOPN_NRM", url, emptyList, emptyList, emptyList, null);
    }

    private static class PathOrderManager {
        private final HashMap<PathType, Integer> orderMap = new HashMap<PathType, Integer>();

        int getOrder(PathType type) {
            switch (type) {
            case PSRC:
            case PDST:
                return -1;
            default:
                break;
            }
            Integer v = orderMap.get(type);
            if (v == null) {
                orderMap.put(type, 1);
                return 0;
            } else {
                orderMap.put(type, v + 1);
                return v;
            }
        }
    }

    private static void dumpOdu(ODUType odu) {
        logger.info("type=" + odu.getPathType() + ", order=" + odu.getPathOrder() + ", src="
                + odu.getSourceSTP() + ", dst=" + odu.getDestSTP());
    }

    private static void dumpLambda(LambdaType lambda) {
        logger.info("type=" + lambda.getPathType() + ", order=" + lambda.getPathOrder() + ", src="
                + lambda.getSourceSTP() + ", dst=" + lambda.getDestSTP() + ", src2="
                + lambda.getSecondarySourceSTP() + ", dst2=" + lambda.getSecondaryDestSTP()
                + ", isProt=" + lambda.isIsProtection());
    }

    private static final net.glambda.schemas._2013._12.services.dopn.ObjectFactory DOPN_FACTORY =
            new net.glambda.schemas._2013._12.services.dopn.ObjectFactory();

    private static LinkedList<ReservationRequestCriteriaType> makeCriteriaListWithoutProtection(
            ReservationRequestCriteriaType baseCriteria, PathFindingResult result) {
        LinkedList<ReservationRequestCriteriaType> list =
                new LinkedList<ReservationRequestCriteriaType>();
        int order = NSIConstants.INITIAL_ORDER;
        for (Path path : result.ero) {
            if (path.srcStp.ifType != path.dstStp.ifType) {
                logger.warn("path.srcStp.ifType=" + path.srcStp.ifType + ", path.dstStp.ifType="
                        + path.dstStp.ifType);
                continue;
            }
            ReservationRequestCriteriaType sub = new ReservationRequestCriteriaType();
            sub.setSchedule(baseCriteria.getSchedule());
            sub.setServiceType(baseCriteria.getServiceType());
            sub.setVersion(baseCriteria.getVersion());
            sub.getOtherAttributes().putAll(baseCriteria.getOtherAttributes());
            STP src = path.srcStp;
            STP dst = path.dstStp;
            switch (path.srcStp.ifType) {
            case ODU:
                ODUType odu = new ODUType();
                odu.setSourceSTP(TypesBuilder.makeStpId(src.networkId, src.localId));
                odu.setDestSTP(TypesBuilder.makeStpId(dst.networkId, dst.localId));
                odu.setEro(null);
                odu.setPathType(PathType.ERO_1);
                odu.setPathOrder(order++);
                odu.setSourceTsId(src.tsId);
                odu.setDestTsId(dst.tsId);
                odu.setTsWidth(src.tsWidth);
                if (src.tsWidth != dst.tsWidth) {
                    logger.warn("src.tsWidth=" + src.tsWidth + "  !=  dst.tsWidth=" + dst.tsWidth);
                }
                sub.getAny().add(DOPN_FACTORY.createOdus(odu));
                dumpOdu(odu);
                break;
            case LAMBDA:
                LambdaType lambda = new LambdaType();
                lambda.setSourceSTP(TypesBuilder.makeStpId(src.networkId, src.localId));
                lambda.setDestSTP(TypesBuilder.makeStpId(dst.networkId, dst.localId));
                lambda.setEro(null);
                lambda.setPathType(PathType.ERO_1);
                lambda.setPathOrder(order++);
                lambda.setSourceLambdaId(src.lambdaId);
                lambda.setDestLambdaId(dst.lambdaId);
                lambda.setLambdaWidth(src.lambdaWidth);
                if (src.lambdaWidth != dst.lambdaWidth) {
                    logger.warn("src.lambdaWidth=" + src.lambdaWidth + "  !=  dst.lambdaWidth="
                            + dst.lambdaWidth);
                }
                dumpLambda(lambda);
                sub.getAny().add(DOPN_FACTORY.createLambdas(lambda));
                break;
            default:
                break;
            }
            list.add(sub);
        }
        return list;
    }

    private static class ProtectionPath {
        private Path normal, primary, secondary;
        private boolean isERO1 = false;

        private LambdaType makeLambdaType(Path path, PathType pathType, PathOrderManager poMgr) {
            LambdaType lambda = new LambdaType();
            lambda.setSourceSTP(TypesBuilder.makeStpId(path.srcStp.networkId, path.srcStp.localId));
            lambda.setDestSTP(TypesBuilder.makeStpId(path.dstStp.networkId, path.dstStp.localId));
            lambda.setEro(null);
            lambda.setPathType(pathType);
            lambda.setPathOrder(poMgr.getOrder(pathType));
            lambda.setSourceLambdaId(path.srcStp.lambdaId);
            lambda.setDestLambdaId(path.dstStp.lambdaId);
            lambda.setLambdaWidth(path.srcStp.lambdaWidth);
            if (path.srcStp.lambdaWidth != path.dstStp.lambdaWidth) {
                logger.warn("src.lambdaWidth=" + path.srcStp.lambdaWidth + "  !=  dst.lambdaWidth="
                        + path.dstStp.lambdaWidth);
            }
            return lambda;
        }

        private ReservationRequestCriteriaType makeSimpleCriteria(
                ReservationRequestCriteriaType baseCriteria) {
            ReservationRequestCriteriaType sub = new ReservationRequestCriteriaType();
            sub.setSchedule(baseCriteria.getSchedule());
            sub.setServiceType(baseCriteria.getServiceType());
            sub.setVersion(baseCriteria.getVersion());
            sub.getOtherAttributes().putAll(baseCriteria.getOtherAttributes());
            return sub;
        }

        private LambdaType addCriteria(LinkedList<ReservationRequestCriteriaType> list,
                ReservationRequestCriteriaType baseCriteria, Path path, PathType pathType,
                PathOrderManager poMgr) {
            ReservationRequestCriteriaType sub = makeSimpleCriteria(baseCriteria);
            LambdaType lambda = makeLambdaType(path, pathType, poMgr);
            sub.getAny().add(DOPN_FACTORY.createLambdas(lambda));
            list.add(sub);
            return lambda;
        }

        private void addCriteria(LinkedList<ReservationRequestCriteriaType> list,
                ReservationRequestCriteriaType baseCriteria, PathOrderManager poMgr) {
            LambdaType lambda;
            if (normal != null && primary == null && secondary == null) {
                PathType pt = (isERO1 ? PathType.ERO_1 : PathType.ERO_2);
                lambda = addCriteria(list, baseCriteria, normal, pt, poMgr);
                dumpLambda(lambda);
            } else if (normal == null && primary != null && secondary != null) {
                boolean bSameSrc = primary.srcStp.localId.equals(secondary.srcStp.localId);
                boolean bSameDst = primary.dstStp.localId.equals(secondary.dstStp.localId);
                if (bSameSrc && !bSameDst) {
                    lambda = addCriteria(list, baseCriteria, primary, PathType.PSRC, poMgr);
                    lambda.setSecondaryDestSTP(TypesBuilder.makeStpId(secondary.dstStp.networkId,
                            secondary.dstStp.localId));
                    lambda.setIsProtection(true);
                    dumpLambda(lambda);
                } else if (!bSameSrc && bSameDst) {
                    lambda = addCriteria(list, baseCriteria, primary, PathType.PDST, poMgr);
                    lambda.setSecondarySourceSTP(TypesBuilder.makeStpId(secondary.srcStp.networkId,
                            secondary.srcStp.localId));
                    lambda.setIsProtection(true);
                    dumpLambda(lambda);
                } else if (!bSameSrc && !bSameDst) {
                    lambda = addCriteria(list, baseCriteria, primary, PathType.PRIMARY, poMgr);
                    dumpLambda(lambda);
                    lambda = addCriteria(list, baseCriteria, secondary, PathType.SECONDARY, poMgr);
                    dumpLambda(lambda);
                } else {
                    logger.warn("primary==seconday: primary=" + primary);
                }
            } else if (normal == null && primary != null && secondary == null) {
                lambda = addCriteria(list, baseCriteria, primary, PathType.PRIMARY, poMgr);
                dumpLambda(lambda);
            } else if (normal == null && primary == null && secondary != null) {
                lambda = addCriteria(list, baseCriteria, secondary, PathType.SECONDARY, poMgr);
                dumpLambda(lambda);
            } else {
                logger.warn("normal=" + normal + ", primary=" + primary + ", secondary="
                        + secondary);
            }
        }

    }

    private static ProtectionPath getPath(LinkedHashMap<String, ProtectionPath> pathMap, Path path) {
        if (path == null || path.srcStp == null || path.dstStp == null) {
            return null;
        }
        if (!path.srcStp.networkId.equals(path.dstStp.networkId)) {
            return null;
        }
        String networkId = path.srcStp.networkId;
        ProtectionPath propPath = pathMap.get(networkId);
        if (propPath == null) {
            propPath = new ProtectionPath();
            pathMap.put(networkId, propPath);
        }
        return propPath;
    }

    private static LinkedList<ReservationRequestCriteriaType> makeCriteriaListWithProtection(
            ReservationRequestCriteriaType baseCriteria, PathFindingResult result) {
        LinkedHashMap<String, ProtectionPath> pathMap = new LinkedHashMap<String, ProtectionPath>();
        boolean isERO1 = true;
        for (Path path : result.ero) {
            ProtectionPath protPath = getPath(pathMap, path);
            if (protPath != null) {
                protPath.normal = path;
                protPath.isERO1 = isERO1;
            } else {
                isERO1 = false;
            }
        }
        for (Path path : result.primary) {
            ProtectionPath protPath = getPath(pathMap, path);
            if (protPath != null) {
                protPath.primary = path;
            }
        }
        for (Path path : result.secondary) {
            ProtectionPath protPath = getPath(pathMap, path);
            if (protPath != null) {
                protPath.secondary = path;
            }
        }
        LinkedList<ReservationRequestCriteriaType> list =
                new LinkedList<ReservationRequestCriteriaType>();
        PathOrderManager poMgr = new PathOrderManager();
        for (ProtectionPath protPath : pathMap.values()) {
            protPath.addCriteria(list, baseCriteria, poMgr);
        }
        return list;
    }

    public static LinkedList<ReservationRequestCriteriaType> makeCriteriaList(
            ReservationRequestCriteriaType baseCriteria, PathFindingResult result) {
        if (result.ero == null) {
            return null;
        }
        if (result.primary == null && result.secondary == null) {
            return makeCriteriaListWithoutProtection(baseCriteria, result);
        } else if (result.primary != null && result.secondary != null) {
            return makeCriteriaListWithProtection(baseCriteria, result);
        } else {
            logger.warn("result.primary=" + result.primary + ", result.secondary="
                    + result.secondary);
            return null;
        }
    }
}
