/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoints;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.EndpointType;
import net.glambda.nrm.types.Equipments;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;
import net.glambda.nrm.types.InterfaceType;

import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;

public class Paths
{
    public static final String prog = "Paths";
    private static Hashtable<String, Paths> pathMgr = 
	new Hashtable<String, Paths>();
	
    private Endpoint endpointA;
    private Endpoint endpointZ;
    private List<Path> paths;
	
    private Paths(Endpoint endpointA, Endpoint endpointZ) 
    {
	this.endpointA = endpointA;
	this.endpointZ = endpointZ;
    }

    public List<Path> getPaths() 
    {
        if (paths == null) {
            paths = new ArrayList<Path>();
        }
        return paths;
    }

    public static Paths findPaths(Endpoint endpointA, Endpoint endpointZ)
    {
	String key1 = endpointA.getName() + "-*-" + endpointZ.getName();
	Paths p = pathMgr.get(key1);
	if (p != null) return p;

	String key2 = endpointZ.getName() + "-*-" + endpointA.getName();
	p = pathMgr.get(key2);
	if (p != null) return p;

	p = new Paths(endpointA, endpointZ);
	pathMgr.put(key1, p);
	return p;
    }

    public String toString()
    {
	String s = "";
	s += endpointA.getName() + ", " + endpointZ.getName() + "\t";
	for (Path path: paths) {
	    s += path.toString();
	}
	return s;
    }

    public static String dump()
    {
	String s = "\n";
	for (String key: pathMgr.keySet()) {
	    Paths paths = pathMgr.get(key);
	    s += paths.toString();
	}
	return s;
    }

    public static String getTableSize()
    {
	String s = prog + ": paths=" + pathMgr.size();
	return s;
    }
}
