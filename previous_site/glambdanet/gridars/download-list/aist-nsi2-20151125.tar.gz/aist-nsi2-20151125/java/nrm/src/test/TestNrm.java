/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package test;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.scheduler.ResourceManager;
import net.glambda.nrm.scheduler.Topology;
import net.glambda.nrm.nsi2.Nrm;

import net.glambda.rms.Notifier;
import net.glambda.rms.NSI2ResourceManagerBase;

import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.StpType;
import net.glambda.rms.types.DirectionalityType;
import net.glambda.rms.types.TypeValuePairListType;
import net.glambda.rms.types.TypeValuePairType;

import java.util.Calendar;
import java.util.List;

public class TestNrm 
{
    public static int serial = 1;
    public static String networkId = Parameter.getNetworkId();

    public Topology topology = null;
    public Nrm nrm = null;

    public static String namebase = "urn:ogf:network:";
    public static String site = "aruba";
    // public static String site = "bonaire";
    // public static String site = "curacao";
    // public static String site = "dominica";
    public static String nameend = ".example:2013:port";
	
    public String nameA = namebase + site + nameend + "1";
    public String nameZ = namebase + site + nameend + "3";
    public String nameV = namebase + site + nameend + "5";
    public String name1 = namebase + site + nameend + "1";
    public String name2 = namebase + site + nameend + "2";
    public String name3 = namebase + site + nameend + "3";
    public String name4 = namebase + site + nameend + "4";
    public String name5 = namebase + site + nameend + "5";
    public String name6 = namebase + site + nameend + "6";
    /*
    public String name1 = "urn:ogf:network:ets.aruba.ex:2013:port1";
    public String name2 = "urn:ogf:network:ets.aruba.ex:2013:port2";
    public String name3 = "urn:ogf:network:ets.aruba.ex:2013:port3";
    public String name4 = "urn:ogf:network:ets.aruba.ex:2013:port4";
    public String name5 = "urn:ogf:network:ets.aruba.ex:2013:port5";
    public String name6 = "urn:ogf:network:ets.aruba.ex:2013:port6";
    */

    public long bandwidth = 200;
    public int stime = 10;
    public int dtime = 10;

    
    public TestNrm() 
    {
	topology = Topology.getInstance();
	nrm = new Nrm();
	nrm.setNotifier(new test.Notifier());
    }

    public static synchronized String getConnectionId()
    {
	if (false && serial == 0) {
	    Exception ex = new Exception("stop");
	    ex.printStackTrace();
	}

	String s = "CID-" + serial;
	serial ++;
	return s;
    }

    public void reserveOnly_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),EndTime,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	try {
	    Thread.sleep(3000);
	    nrm.reserve(null, cid, null, null, criteria);
	    System.err.println("====== reserve() is OK");
	    Thread.sleep(20000);
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	    Thread.sleep(5000);
	    nrm.terminate(null, cid);
	    System.err.println("====== terminate() is OK");
	    Thread.sleep(5000);
	} catch (Exception ex) {
	    Thread.sleep(5000);
	    nrm.terminate(null, cid);
	    System.err.println("====== terminate() is OK");
	    Thread.sleep(5000);
	}
    }

    public void reserveOnly_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),TIMEOUT,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime+30, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(3000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(43000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");
	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	Thread.sleep(5000);
    }

    public void reserveOnly_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),TIMEOUT");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(3000);
	try {
	    nrm.reserve(null, cid, null, null, criteria);
	    System.err.println("====== reserve() is OK");
	} catch (Exception ex) {
	    System.err.println("====== reserve() is FAIL, not error. ex=" + ex);
	}
    }

    public void reserveOnly_D(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),abort()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	try {
	    nrm.reserve(null, cid, null, null, criteria);
	    System.err.println("====== reserve() is OK");
	} catch (Exception ex) {
	    System.err.println("====== reserve() is FAIL, not error. ex=" + ex);
	}
	Thread.sleep(2000);
	try {
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	} catch (Exception ex) {
	    System.err.println("====== abort() is FAIL, error. ex=" + ex);
	}
    }

    public void reserveCommit_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),commit(),terminate(),StartTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommit_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),StartTime,commit(),EndTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommit_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),EndTime,commit(),abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(20000);
	try {
	    nrm.commit(null, cid);
	    System.err.println("====== commit() is OK");
	} catch (Exception ex) {
	    System.err.println("====== commit() is FAIL::: not error");
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	}

	Thread.sleep(3000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommit_D(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),EndTime,commit(), not terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(50000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
    }

    public void reserveCommit_E(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),commit(),terminate(),EndTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime+300, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(10000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
    }

    public void reserveAbort_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),abort(),terminate(),StartTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveAbort_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),StartTime,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(5000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveAbort_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),EndTime,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(20000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void ReserveCommitProvision(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision()/release(),commit(),provision()/release(),abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(1000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.release(null, cid);
	System.err.println("====== release() is OK");
	nrm.provision(null, cid);
	System.err.println("====== release() is OK");
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	nrm.release(null, cid);
	System.err.println("====== release() is OK");
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(5000);
	nrm.release(null, cid);
	System.err.println("====== release() is OK");
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	nrm.release(null, cid);
	System.err.println("====== release() is OK");
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(5000);
	nrm.release(null, cid);
	System.err.println("====== release() is OK");

	Thread.sleep(5000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveTerminate_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),terminate(),StartTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(3000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(3000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveTerminate_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),StartTime,terminate(),EndTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(3000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(10000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveTerminate_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),EndTime,TIMEOUT,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(3000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitTerminate_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),terminate(),StartTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitTerminate_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),StartTime,terminate(),EndTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameV, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(8000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(10000);
    }

    public void reserveCommitTerminate_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),EndTime,TIMEOUT,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveModify_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),modify(),StartTime,modify(),EndTime,modify(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+5, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);

	try {
	    nrm.modify(null, cid, null, null, mcriteria);
	    System.err.println("====== modify() is OK");
	} catch (Exception ex) {
	    System.err.println("====== modify() is FAIL::: not error");
	}

	Thread.sleep(10000);
	try {
	    nrm.modify(null, cid, null, null, mcriteria);
	    System.err.println("====== modify() is OK");
	} catch (Exception ex) {
	    System.err.println("====== modify() is FAIL::: not error");
	}

	Thread.sleep(10000);
	try {
	    nrm.modify(null, cid, null, null, mcriteria);
	    System.err.println("====== modify() is OK");
	} catch (Exception ex) {
	    System.err.println("====== modify() is FAIL::: not error");
	}

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModify_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),StartTime,EndTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+5, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModify_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),StartTime,modify(),EndTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime, dtime+5, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(15000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModify_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),EndTime,modify(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime, dtime+5, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(20000);
	try {
	    nrm.modify(null, cid, null, null, mcriteria);
	    System.err.println("====== modify() is OK");
	} catch (Exception ex) {
	    System.err.println("====== modify() is FAIL::: not error");
	}

	Thread.sleep(5000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModify_D(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),StartTime, EndTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime+30+180, bandwidth, nameA, nameZ, vlan);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime, dtime+100, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),commit(),StartTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+10, dtime+5, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(15000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),StartTime,modify(),commit(),EndTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime, dtime+10, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(10000);

	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyAbort_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),abort(),StartTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+10, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+10, dtime+5, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(2000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(25000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyAbort_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),StartTime,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+5, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(7000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(15000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyAbort_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),EndTime,abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+5, bandwidth+100); 


	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(17000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(10000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyTerminate_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),terminate(),StartTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+5, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyTerminate_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),StartTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime+5, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+10, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(8000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyTerminate_C(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),modify(),EndTime, terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime+5, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+10, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(25000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitReserve(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),reserve(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	try {
	    nrm.reserve(null, cid, null, null, criteria);
	    System.err.println("====== reserve() is OK");
	} catch (Exception ex) {
	    System.err.println("====== reserve() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitCommit(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),commit(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	try {
	    nrm.commit(null, cid);
	    System.err.println("====== commit() is OK");
	} catch (Exception ex) {
	    System.err.println("====== commit() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitAbort(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),commit(),abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	try {
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	} catch (Exception ex) {
	    System.err.println("====== abort() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveAbortReserve(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),abort(),reserve(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(2000);
	try {
	    nrm.reserve(null, cid, null, null, criteria);
	    System.err.println("====== reserve() is OK");
	} catch (Exception ex) {
	    System.err.println("====== reserve() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveAbortCommit(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),abort(),commit(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(2000);
	try {
	    nrm.commit(null, cid);
	    System.err.println("====== commit() is OK");
	} catch (Exception ex) {
	    System.err.println("====== commit() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveAbortAbort(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),abort(),abort(),terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(2000);
	try {
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	} catch (Exception ex) {
	    System.err.println("====== abort() FAIL is OK");
	}

	Thread.sleep(2000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void commitAbortTerminate(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= commit(),abort(),terminate");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	try {
	    nrm.commit(null, cid);
	    System.err.println("====== commit() is OK");
	} catch (Exception ex) {
	    System.err.println("====== commit() FAIL is OK");
	}

	Thread.sleep(2000);
	try {
	    nrm.abort(null, cid);
	    System.err.println("====== abort() is OK");
	} catch (Exception ex) {
	    System.err.println("====== abort() FAIL is OK");
	}

	Thread.sleep(2000);
	try {
	    nrm.terminate(null, cid);
	    System.err.println("====== terminate() is OK");
	} catch (Exception ex) {
	    System.err.println("====== terminate() FAIL is OK");
	}

	Thread.sleep(5000);
    }

    public void Modify(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= modify()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime+5, dtime+5, bandwidth, nameA, nameZ, vlan);

	EthernetCriteria mcriteria = modifyCriteria
	    (cid, stime+5, dtime+10, bandwidth+100); 

	Thread.sleep(2000);
	try {
	    nrm.modify(null, cid, null, null, mcriteria);
	    System.err.println("====== modify() is OK");
	} catch (Exception ex) {
	    System.err.println("====== modify() FAIL is OK");
	}

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit2(int type, int vlan)
	throws Exception
    {
	String cid = getConnectionId();

	/*
	            15  30  45  60  75  90  105
	                 S       E
	  (1) CID-1:Rspec-B
	  ---RPC---------+-------+-----------------------------
	  -------MC--+-------+--------------------------------
	  (2) CID-12:Rspec-B
	  ---RC----------+-------+-----------------------------
	  -------MPC-+-------+---------------------------------
	  (3) CID-23:Rspec-B, abort
	  ---RC----------+-------+-----------------------------
	  -------MPA-+-------+---------------------------------
	  (4) CID-34:Rspec-D
	  ---RCP---------+-------+-----------------------------
	  -------MC----------+-------+-------------------------
	  (5) CID-45:Rspec-E
	  ---RCP---------+-------+-----------------------------
	  -------MC------------------+-------+-----------------
	  (6) CID-56:Rspec-C
	  ---RCP---------+-------+-----------------------------
	  -------MC--------+--+--------------------------------
	  (7) CID-67:Rspec-F
	  ---RCP---------+-------+-----------------------------
	  -------MC---+--------------+-------------------------
	  (8) CID-78:Rspec-A
	  ---RCP---------+-------+-----------------------------
	  -------MC-+--+---------------------------------------
	  (9) CID-89: error case
	  ---RCP---------+-------+-----------------------------
	  -----------------MC-+------+-------------------------
	  (10) CID-100:Rspec-D
	  ---RCP---------+-------+-----------------------------
	  ---------------+-MC--------+-------------------------
	  (11) CID-111:Rspec-C
	  ---RCP---------+-------+-----------------------------
	  ---------------+-MC--+-------------------------------
	  (12) CID-122: error case
	  ---RCP---------+-------+-----------------------------
	  ---------------------------MC--+----+----------------
	*/

	EthernetCriteria criteria = createCriteria
	    (cid, 30, 30, 400, nameA, nameZ, vlan);
	EthernetCriteria mcriteria1 = modifyCriteria(cid, 15, 30, 800); 
	EthernetCriteria mcriteria2 = modifyCriteria(cid, 45, 30, 800); 
	EthernetCriteria mcriteria3 = modifyCriteria(cid, 75, 30, 800); 
	EthernetCriteria mcriteria4 = modifyCriteria(cid, 35, 20, 800); 
	EthernetCriteria mcriteria5 = modifyCriteria(cid, 15, 60, 800); 
	EthernetCriteria mcriteria6 = modifyCriteria(cid,  0, 15, 800); 
	EthernetCriteria mcriteria7 = modifyCriteria(cid, 30, 45, 800); 
	EthernetCriteria mcriteria8 = modifyCriteria(cid, 30, 25, 800); 
	EthernetCriteria mcriteria9 = modifyCriteria(cid, 75, 30, 800); 
	
	switch (type) {
	    case 1:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);
		
		nrm.modify(null, cid, null, null, mcriteria1);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(10000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;
		
	    case 2:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);
		
		nrm.modify(null, cid, null, null, mcriteria1);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(10000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 3:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria1);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.abort(null, cid);
		System.err.println("====== modifyAbort() is OK");
		Thread.sleep(2000);

		Thread.sleep(10000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 4:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria2);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(60000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 5:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria3);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(90000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 6:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria4);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(60000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 7:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria5);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(60000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 8:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(2000);

		nrm.modify(null, cid, null, null, mcriteria6);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(20000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 9:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(35000);

		try {
		    nrm.modify(null, cid, null, null, mcriteria2);
		    System.err.println("====== modify() is OK");
		    Thread.sleep(2000);
		    nrm.commit(null, cid);
		    System.err.println("====== modifyCommit() is OK");
		} catch (Exception ex) {
		    System.err.println("====== modify() is FAIL::: not error");
		}
		Thread.sleep(2000);

		Thread.sleep(20000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 10:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(35000);

		nrm.modify(null, cid, null, null, mcriteria7);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(20000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 11:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(35000);

		nrm.modify(null, cid, null, null, mcriteria8);
		System.err.println("====== modify() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== modifyCommit() is OK");
		Thread.sleep(2000);

		Thread.sleep(20000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;

	    case 12:
		nrm.reserve(null, cid, null, null, criteria);
		System.err.println("====== reserve() is OK");
		Thread.sleep(2000);
		nrm.provision(null, cid);
		System.err.println("====== provision() is OK");
		Thread.sleep(2000);
		nrm.commit(null, cid);
		System.err.println("====== reserveCommit() is OK");
		Thread.sleep(65000);

		try {
		    nrm.modify(null, cid, null, null, mcriteria9);
		    System.err.println("====== modify() is OK");
		    Thread.sleep(2000);
		    nrm.commit(null, cid);
		    System.err.println("====== modifyCommit() is OK");
		} catch (Exception ex) {
		    System.err.println("====== modify() is FAIL::: not error");
		}
		Thread.sleep(2000);

		Thread.sleep(5000);
		nrm.terminate(null, cid);
		System.err.println("====== terminate() is OK");

		Thread.sleep(5000);
		break;
	}
    }

    public static EthernetCriteria modifyCriteria
	(String cid, int start, int duration, long bandwidth)
    {
	EthernetCriteria criteria = new EthernetCriteria();
	criteria.setVersion(new Integer(serial++));

        Calendar startTime = Calendar.getInstance();
	startTime.add(Calendar.SECOND, start);
	criteria.setStartTime(startTime);
	Calendar endTime = (Calendar) startTime.clone();
	endTime.add(Calendar.SECOND, duration);
	criteria.setEndTime(endTime);

	criteria.setCapacity(new Long(bandwidth));
	return criteria;
    }

    public static EthernetCriteria modifyCriteria
	(String cid, int duration, long bandwidth)
    {
	EthernetCriteria criteria = new EthernetCriteria();
	criteria.setVersion(new Integer(serial++));

        Calendar endTime = Calendar.getInstance();
	endTime.add(Calendar.SECOND, duration);
	criteria.setEndTime(endTime);

	criteria.setCapacity(new Long(bandwidth));
	return criteria;
    }

    public static EthernetCriteria createCriteria
	(String cid, int start, int duration, long bandwidth,
	 String srcLocal, String dstLocal, int vlan)
    {
	EthernetCriteria criteria = new EthernetCriteria();
	criteria.setVersion(new Integer(serial++));

        Calendar startTime = Calendar.getInstance();
	startTime.add(Calendar.SECOND, start);
	criteria.setStartTime(startTime);
	Calendar endTime = (Calendar) startTime.clone();
	endTime.add(Calendar.SECOND, duration);
	criteria.setEndTime(endTime);

	criteria.setCapacity(new Long(bandwidth));
	
	DirectionalityType direction = DirectionalityType.BIDIRECTIONAL;
	criteria.setDirectionality(direction);
	criteria.setSymmetricPath(true);

	StpType src = new StpType();
	criteria.setSourceSTP(src);
	src.setNetworkId(networkId);
	src.setLocalId(srcLocal);

	StpType dst = new StpType();
	criteria.setDestSTP(dst);
	dst.setNetworkId(networkId);
	dst.setLocalId(dstLocal);

	criteria.setSourceVLAN(vlan);
	criteria.setDestVLAN(vlan);

	/*
	TypeValuePairListType values =  new TypeValuePairListType();
	List<TypeValuePairType> list = values.getAttribute();
	TypeValuePairType pair = new TypeValuePairType();
	list.add(pair);
	pair.setType("vlan");
	List <String> value = pair.getValue();
	value.add("" + vlan);

	src.setLabels(values);
	dst.setLabels(values);
	*/
	return criteria;
    }

    public void loadtest(int vlan)
    {
	if (true) {
	    while(true) {
		reserveCommitAll(vlan);
		try {
		    if (false) Thread.sleep(2000);
		} catch (Exception ex) {}
	    }
	}
    }

    public void reserveCommitAll(int vlan)
    {
	int k = 0;

	String[] names = new String[6];
	names[0] = name1;
	names[1] = name2;
	names[2] = name3;
	names[3] = name4;
	names[4] = name5;
	names[5] = name6;
	
	for (int a = 0; a < 6; a++) {
	    for (int z = a+1; z < 6; z++) {
		String cid = getConnectionId();
		EthernetCriteria criteria = createCriteria
		    (cid, 10, 30, 200, names[z], names[a], vlan);
		EthernetCriteria mcriteria = modifyCriteria
		    (cid, 10, 40, 250); 
		
		try {
		    nrm.reserve(null, cid, null, null, criteria);
		    System.err.println("====== reserve() is OK");
		    Thread.sleep(2000);
		    nrm.commit(null, cid);
		    System.err.println("====== reserveCommit() is OK");
		    Thread.sleep(2000);
		    nrm.provision(null, cid);
		    System.err.println("====== provision() is OK");
		    Thread.sleep(10000);
		    nrm.modify(null, cid, null, null, mcriteria);
		    System.err.println("====== modify() is OK");
		    Thread.sleep(2000);
		    nrm.commit(null, cid);
		    System.err.println("====== modifyCommit() is OK");
		    Thread.sleep(10000);
		    nrm.terminate(null, cid);
		    System.err.println("====== terminate() is OK");
		    Thread.sleep(2000);

		    continue;
		} catch (Exception ex) {
		    System.err.println("##################################");
		    System.err.println("ex=" + ex);
		    // ex.printStackTrace();
		    System.err.println("##################################");
		    try {
			nrm.terminate(null, cid);
		    } catch (Exception e) {}
		    try {
			Thread.sleep(10000);
		    } catch (Exception e) {}
		} 
	    }
	}
    }
    
    public void reserveCommitAll()
    {
	int vlanbase = 1780;
	int k = 0;

	String[] names = new String[6];
	names[0] = name1;
	names[1] = name4;
	names[2] = name3;
	names[3] = name2;
	names[4] = name5;
	names[5] = name6;
	
	for (int a = 0; a < 6; a++) {
	    for (int z = a+1; z < 6; z++) {
		int vlan = 1780 + (k % 4);
		String cid = getConnectionId();
		EthernetCriteria criteria = createCriteria
		    (cid, 10, 30, 400, names[z], names[a], vlan);
		
		try {
		    nrm.reserve(null, cid, null, null, criteria);
		    System.err.println("====== reserve() is OK");
		    Thread.sleep(2000);
		    nrm.commit(null, cid);
		    System.err.println("====== reserveCommit() is OK");
		    Thread.sleep(2000);
		    nrm.provision(null, cid);
		    System.err.println("====== provision() is OK");
		    Thread.sleep(10000);
		    nrm.terminate(null, cid);
		    System.err.println("====== provision() is OK");
		    Thread.sleep(2000);
		    k++;
		    continue;
		} catch (Exception ex) {
		    System.err.println("##################################");
		    System.err.println("ex=" + ex);
		    // ex.printStackTrace();
		    System.err.println("##################################");
		    try {
			Thread.sleep(5000);
		    } catch (Exception e) {}
		}
	    }
	}
    }

    public static TestNrm test = null;
    public static int ivlan = 0;

    public static void main (String[] argv)
    {
	test = new TestNrm();

	try {
	    if (false) for (int i = 0; i < 4; i++) {
		ivlan = i;
		Thread thread = new Thread(new Runnable() {
			final int iivlan = ivlan;
			public void run() {
			    while (true) {
				try {
				    Thread.sleep(2000);
				} catch (InterruptedException ex) {
				    ex.printStackTrace();
				}
				test.loadtest(1780 + iivlan);
			    }
			}
		    });
		thread.start();
	    }
	    
	    // test.loadtest();
	    // test.reserveCommitModify_D(1780);
	    // test.reserveCommit_D(1780);
	    // test.reserveCommit_E(1780);
	    test.reserveOnly_C(1782);
	    test.reserveOnly_D(1782);

	    if (false) {
		/* 1 */
		// test.reserveOnly_A(1777);
		test.reserveOnly_A(1780);
		test.reserveOnly_B(1780);

		/* 5 */
		test.reserveCommit_A(1780);
		test.reserveCommit_B(1780);
		test.reserveCommit_C(1780); /* error */

		/* 11 */
		test.reserveAbort_A(1780);
		test.reserveAbort_B(1780);
		test.reserveAbort_C(1780);

		/* 17 */
		test.ReserveCommitProvision(1780);

		/* 19 */
		test.reserveTerminate_A(1780);
		test.reserveTerminate_B(1780);
		test.reserveTerminate_C(1780);

		/* 25 */
		test.reserveCommitTerminate_A(1780);
		test.reserveCommitTerminate_B(1780);
		test.reserveCommitTerminate_C(1780);

		/* 31 */
		test.reserveModify_A(1780);

		/* 33 */
		test.reserveCommitModify_A(1780);
		test.reserveCommitModify_B(1780);
		test.reserveCommitModify_C(1781); /* error */

		/* 42 */
		test.reserveCommitModifyCommit_A(1780);
		test.reserveCommitModifyCommit_B(1780);

		/* 48 */
		test.reserveCommitModifyAbort_A(1780);
		test.reserveCommitModifyAbort_B(1780);
		test.reserveCommitModifyAbort_C(1780);

		/* 57 */
		test.reserveCommitModifyTerminate_A(1780);
		test.reserveCommitModifyTerminate_B(1780);
		test.reserveCommitModifyTerminate_C(1780);
	    }

	    if (false) { // error
		test.reserveCommitReserve(1780);
		test.reserveAbortReserve(1780);

		test.reserveCommitCommit(1780);
		test.reserveCommitAbort(1780);
		test.reserveAbortCommit(1780);
		test.reserveAbortAbort(1780);

		test.commitAbortTerminate(1780);
		test.Modify(1780);
	    }

	    if (false) {
		for (int i = 1; i < 13; i++) {
		    test.reserveCommitModifyCommit2(i, 1780);
		}
	    }

	    while (true) {
		break;
	    }

	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(-1);
	}
	// System.exit(0);
    }
}
