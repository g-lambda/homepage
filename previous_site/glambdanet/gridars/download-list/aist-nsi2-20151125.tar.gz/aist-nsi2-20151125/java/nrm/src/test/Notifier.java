/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package test;

import net.glambda.nrm.util.Logger;

import net.glambda.rms.types.EventEnumType;
import net.glambda.rms.types.TypeValuePairListType;
import net.glambda.rms.types.ServiceExceptionType;
import net.glambda.rms.DataPlaneState;

public class Notifier implements net.glambda.rms.Notifier
{
    public static final String prog = "Notifier";
    public Notifier () {}

    public void dataPlaneStateChange
	(String connectionId, DataPlaneState state)
    {
	Logger.einfo(prog, "dataPlaneStateChange:" + connectionId + 
		     ":" + state);
    }

    public void errorEvent
	(String connectionId, EventEnumType event,
	 TypeValuePairListType additionalInfo, 
	 ServiceExceptionType serviceException)
	{
	    Logger.einfo(prog, "errorEvent:" + connectionId);
	}

    public void reserveTimeout
	(String connectionId, int timeoutValue)
    {
	Logger.einfo(prog, "reserveTimeout:" + connectionId + 
		     ":" + timeoutValue);
    }
}