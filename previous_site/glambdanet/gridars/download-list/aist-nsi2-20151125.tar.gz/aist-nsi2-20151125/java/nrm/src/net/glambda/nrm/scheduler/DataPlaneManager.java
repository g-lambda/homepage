/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.Nrm;
import net.glambda.nrm.nsi2.ResourceRequest;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.LifecycleStatus;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;

import net.glambda.rms.types.ServiceException;
import net.glambda.rms.DataPlaneState;
import net.glambda.rms.Notifier;
import net.glambda.rms.types.EventEnumType;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.ArrayList;

public class DataPlaneManager
{
    private static final String prog = "DPManager";
    private static final int interval = Parameter.getTimeKeeperInterval();
    private static final int dumpInterval = Parameter.getDumpInterval();
    private static final Boolean dumpReduce = Parameter.isDumpReduce();
    private static boolean dump = false;

    private final Nrm nrm;
    private final ResourceManager manager;
    private final Notifier notifier;
    private Hashtable<Long, ArrayList<Long>> waitCmd = 
	new Hashtable<Long, ArrayList<Long>>();

    public DataPlaneManager(Nrm nrm, ResourceManager manager)
    {
	this.nrm = nrm;
	this.manager = manager;
	this.notifier = nrm.getNotifier();

	startKeeper();
    }

    private void startKeeper () 
    {
        Thread timeKeeper = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        try {
                            Thread.sleep(interval);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
			try {
			    update();
			    isCommandDone();
			} catch (Exception ex) {
                            ex.printStackTrace();
			}
                    }
                }
            });
        timeKeeper.start();
    }

    public synchronized void update() 
    {
	Long current = Time.getCurrentTime();

	Hashtable<Long, ResourceRequest> reserved = manager.reserved;
	Enumeration e = reserved.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    String cid = rr.getConnectionId();
	    ResourceSpec rs = rr.getReservedRspec();

	    Long startTime = rs.getStartTime();
	    Long endTime = rs.getEndTime();
	    DataPlaneStatus status = rs.getDataPlaneStatus();
	    LifecycleStatus lstatus = rs.getLifecycleStatus();
	    ReservationStatus rstatus = rs.getReservationStatus();

	    if (lstatus != LifecycleStatus.CREATED) {
		switch (status) {
		    case ACTIVE:
			rr.setDataPlaneStatus
			    (DataPlaneStatus.OPERATING_TEARDOWN);
			teardown(current, rr, rs);
			setDump();
			break;

		    case OPERATING_SETUP:
			/* wait setup, and teardown by update */
			rs.setEndTime(rs.getTerminateTime());
			break;
			
		    case OPERATING_TEARDOWN:
			/* wait setup, and teardown by update */
			break;

		    default:
			if (status != DataPlaneStatus.PASSED_END_TIME) {
			    rr.setDataPlaneStatus
				(DataPlaneStatus.PASSED_END_TIME);
			    Logger.info(prog, "Notify(PASSED_END_TIME) is sent now.");
			    notifier.dataPlaneStateChange
				(cid, DataPlaneState.PASSED_END_TIME);
			    setDump();
			}
		}
		continue;
	    }

	    if (current < startTime) continue;
	    if (startTime <= current && current <= endTime &&
		rstatus == ReservationStatus.RESERVED &&
		lstatus == LifecycleStatus.CREATED) {
		switch (status) {
		    case WAIT_START_TIME:
			rr.setDataPlaneStatus(DataPlaneStatus.INACTIVE);
			if (false) { // Don't nofity this.
			    Logger.info(prog, "Notify(INACTIVE) is sent now.");
			    notifier.dataPlaneStateChange
				(cid, DataPlaneState.INACTIVE);
			}
			if (rs.isProvision()) {
			    rr.setDataPlaneStatus
				(DataPlaneStatus.OPERATING_SETUP);
			    setup(current, rr, rs);
			    setDump();
			    /* when setup is done, DataPlaneStatus is changed.*/
			}
			break;

		    case OPERATING_SETUP:
		    case OPERATING_TEARDOWN:
		        break;

		    case ACTIVE:
			if (! rs.isProvision()) {
			    rr.setDataPlaneStatus
				(DataPlaneStatus.OPERATING_TEARDOWN);
			    teardown(current, rr, rs);
			    setDump();
			    /* when teardown is done, DataPlaneStatus is changed.*/
			}
			break;
			
		    case INACTIVE:
			if (rs.isProvision()) {
			    rr.setDataPlaneStatus
				(DataPlaneStatus.OPERATING_SETUP);
			    setup(current, rr, rs);
			    setDump();
			    /* when setup is done, DataPlaneStatus is changed.*/
			}
			break;
			
		    case PASSED_END_TIME:
		    case TERMINATED:
			Logger.warn(prog, "Internal error(DataPlaneStatus)");
			break;
		}
		continue;
	    }

	    if (endTime < current) {
		/* clean modify/reserve prepared request by Nrm.update */ 
		switch (status) {
		    case ACTIVE:
			rr.setDataPlaneStatus
			    (DataPlaneStatus.OPERATING_TEARDOWN);
			teardown(current, rr, rs);
			setDump();
			break;

		    case INACTIVE:
			rr.setDataPlaneStatus
			    (DataPlaneStatus.PASSED_END_TIME);
			Logger.info(prog, "Notify(PASSED_END_TIME) is sent now.");
			notifier.dataPlaneStateChange
			    (cid, DataPlaneState.PASSED_END_TIME);
			setDump();
			// through break, do next case;

		    case PASSED_END_TIME:
			try {
			    rr.terminateDone();
			} catch (ServiceException ex) {
			    Logger.warn(prog, "terminateDone() ex=" + ex);
			}
			break;
		}
	    }
	}

	/* garbege collection for Link Timetable */
	CableManager.garbage(current);
	L2swManager.garbage(current);
	OxcManager.garbage(current);

	/* garbege collection for Vlan Timetable */
	VlanManager.garbage(current);

	/* garbege collection for OXC port Timetable */
	PortManager.garbage(current);

	if (dumpReduce && (! isDump())) return;

	Hashtable<Long, ResourceRequest> requests = manager.requests;
	e = requests.elements();
	String s = "===== dump: " + TypesToString.time(current) +
	    ", size=" + requests.size() + ", " + reserved.size();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    ResourceSpec rs = rr.getReservedRspec();
	    if (rs == null) rs = rr.getOperationRspec();
	    if (rs == null) {
		continue;
	    }
	    ReservationStatus rvs = rs.getReservationStatus();
	    Long endTime = rs.getEndTime() + Parameter.getTimeKeeperDeleteWait();
	    if (endTime <= current &&
		rvs == ReservationStatus.TERMINATED) {
		requests.remove(new Long(rr.getSerial()));
		reserved.remove(new Long(rr.getSerial()));
		terminate(rs);
	    }

	    endTime = rs.getTerminateTime() + Parameter.getTimeKeeperDeleteWait();
	    if (endTime <= current &&
		rvs == ReservationStatus.TERMINATED) {
		requests.remove(new Long(rr.getSerial()));
		reserved.remove(new Long(rr.getSerial()));
		terminate(rs);
	    }


	    rs = rr.getReservedRspec();
	    if (rs != null) s += "\n\tReserved: " + TypesToString.resourceSpecUpdate(rs);
	    rs = rr.getOperationRspec();
	    if (rs != null) s += "\n\tOperation:" + TypesToString.resourceSpecUpdate(rs);
	}

	Logger.debug("", s);

	if (false) Logger.debug("Tablesize", nrm.getTableSize());
    }

    public boolean terminate (ResourceSpec rspec)
    {
	PathScheduler ps;
	try {
	    ps = PathScheduler.getScheduler(rspec);
	    ps.terminate();
	} catch (ServiceException ex) {
	    return false;
	} 
	return true;
    }

    public synchronized boolean setup 
	(long current, ResourceRequest rr, ResourceSpec rspec)
    {
	PathScheduler ps;
	try {
	    ps = PathScheduler.getScheduler(rspec);
	} catch (ServiceException ex) {
	    return false;
	} 

	Path path = ps.getUsedPath();
	ArrayList<Long> cmdIds = new ArrayList<Long> ();
	
	for (Link link: path.getLinks().getLinks()) {
	    LinkManager lm;
	    try {
		lm = LinkManager.getInstance(link);
	    } catch (ServiceException ex) {
		continue;
	    } 

	    if (lm instanceof CableManager) continue;
		
	    if (lm instanceof L2swManager) {
		L2swManager l2 = (L2swManager) lm;

		Equipment eq = l2.getEquipment();
		String name = eq.getName();
		String cmd = eq.getController();
		Command command = Command.getInstance(name);

		Endpoint ep_a = link.getEndpointA();
		String name_a = ep_a.getControlId();
		Endpoint ep_z = link.getEndpointZ();
		String name_z = ep_z.getControlId();

		String c = cmd + " " + name + " setup " 
		    + name_a + " " + name_z + " " 
		    + rspec.getBandwidth() + " "
		    + rspec.getVlan();
		Logger.info(prog, "setup command=" + c);

		Long cmdId = command.add(c, true, rspec);
		cmdIds.add(cmdId);

		// boolean ischange = lm.setup();
	    }

	    if (lm instanceof OxcManager) {
		OxcManager om = (OxcManager) lm;

		Equipment eq = om.getEquipment();
		String name = eq.getName();
		String cmd = eq.getController();

		Endpoint ep_a = link.getEndpointA();
		String name_a = ep_a.getControlId();
		Endpoint ep_z = link.getEndpointZ();
		String name_z = ep_z.getControlId();

		String c = cmd + " " + name + " setup " 
		    + name_a + " " + name_z + " "; 

		if (om.isSetup(current, rspec)) {
		    Command command = Command.getInstance(name);
		    Logger.info(prog, "setup command=" + c);
		    Long cmdId = command.add(c, true, rspec);
		    cmdIds.add(cmdId);
		} else {
		    Logger.info(prog, "skip setup command=" + c);
		    rr.setDataPlaneStatus(DataPlaneStatus.ACTIVE);
		    Logger.info(prog, "Notify(ACTIVE) is sent now.");
		    notifier.dataPlaneStateChange
			(rspec.getConnectionId(), DataPlaneState.ACTIVE);
		}
	    }
	}

	if (cmdIds.size() != 0) {
	    if (waitCmd.get(rspec.getSerialId()) == null)
		waitCmd.put(rspec.getSerialId(), cmdIds);
	    else 
		Logger.warn(prog, "Command is not null, there is a remain Command.");
	}

	return true;
    }

    public boolean teardown 
	(long current, ResourceRequest rr, ResourceSpec rspec)
    {
	PathScheduler ps;
	try {
	    ps = PathScheduler.getScheduler(rspec);
	} catch (ServiceException ex) {
	    return false;
	} 

	Path path = ps.getUsedPath();
	ArrayList<Long> cmdIds = new ArrayList<Long> ();

	for (Link link: path.getLinks().getLinks()) {
	    LinkManager lm;
	    try {
		lm = LinkManager.getInstance(link);
	    } catch (ServiceException ex) {
		continue;
	    } 

	    if (lm instanceof CableManager) continue;

	    if (lm instanceof L2swManager) {
		L2swManager l2 = (L2swManager) lm;

		Equipment eq = l2.getEquipment();
		String name = eq.getName();
		String cmd = eq.getController();
		Command command = Command.getInstance(name);

		Endpoint ep_a = link.getEndpointA();
		String name_a = ep_a.getControlId();
		Endpoint ep_z = link.getEndpointZ();
		String name_z = ep_z.getControlId();

		String c = cmd + " " + name + " teardown " 
		    + name_a + " " + name_z + " " 
		    + rspec.getBandwidth() + " "
		    + rspec.getVlan();
		Logger.info(prog, "teardown command=" + c);

		Long cmdId = command.add(c, false, rspec);
		cmdIds.add(cmdId);
		
		// boolean ischange = lm.teardown();
	    }

	    if (lm instanceof OxcManager) {
		OxcManager om = (OxcManager) lm;

		Equipment eq = om.getEquipment();
		String name = eq.getName();
		String cmd = eq.getController();

		Endpoint ep_a = link.getEndpointA();
		String name_a = ep_a.getControlId();
		Endpoint ep_z = link.getEndpointZ();
		String name_z = ep_z.getControlId();

		String c = cmd + " " + name + " teardown " 
		    + name_a + " " + name_z + " ";

		if (om.isTeardown(current, rspec)) {
		    Command command = Command.getInstance(name);
		    Logger.info(prog, "teardown command=" + c);
		    Long cmdId = command.add(c, false, rspec);
		    cmdIds.add(cmdId);
		} else {
		    Logger.info(prog, "skip teardown command=" + c);
		    rr.setDataPlaneStatus(DataPlaneStatus.INACTIVE);
		    Logger.info(prog, "Notify(INACTIVE) is sent now.");
		    notifier.dataPlaneStateChange
			(rspec.getConnectionId(), DataPlaneState.INACTIVE);
		}
	    }
	}

	if (cmdIds.size() != 0) {
	    if (waitCmd.get(rspec.getSerialId()) == null)
		waitCmd.put(rspec.getSerialId(), cmdIds);
	    else 
		Logger.warn(prog, "Command is not null, there is a remain Command.");
	}

	return true;
    }

    public synchronized void isCommandDone() 
    {
	Hashtable<Long, ResourceRequest> reqs = manager.reserved;
	Enumeration e = reqs.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    checkCommandDone(rr);
	}
	/*
	reqs = manager.requests;
	e = reqs.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    checkCommandDone(rr);
	}
	reqs = manager.terminated;
	e = reqs.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    checkCommandDone(rr);
	}
	*/
    }

    private void checkCommandDone (ResourceRequest rr)
    {
	String cid = rr.getConnectionId();
	ResourceSpec rs = rr.getReservedRspec();
	if (rs == null) return;
	DataPlaneStatus status = rs.getDataPlaneStatus();
	
	if (status != DataPlaneStatus.OPERATING_SETUP &&
	    status != DataPlaneStatus.OPERATING_TEARDOWN) return;
	
	PathScheduler ps;
	try {
	    ps = PathScheduler.getScheduler(rs);
	} catch (ServiceException ex) {
	    return;
	} 
	Path path = ps.getUsedPath();
	
	int i = 0;
	boolean allDone = true;
	boolean success = true;
	ArrayList<Long> list = waitCmd.get(rs.getSerialId());
	
	for (Link link: path.getLinks().getLinks()) {
	    LinkManager lm;
	    try {
		lm = LinkManager.getInstance(link);
	    } catch (ServiceException ex) {
		continue;
	    } 
		
	    if (lm instanceof CableManager) continue;

	    if (lm instanceof L2swManager) {
		L2swManager l2 = (L2swManager) lm;
		
		Equipment eq = l2.getEquipment();
		String name = eq.getName();
		Command command = Command.getInstance(name);

		if (list.size() <= 0) return;
		Boolean rc = command.isDone(list.get(i), false);
		if (rc == null) {
		    allDone = false;
		    success = false;
		} else {
		    if (! rc.booleanValue()) success = false;
		    i ++;
		}
	    }

	    if (lm instanceof OxcManager) {
		OxcManager om = (OxcManager) lm;
		
		Equipment eq = om.getEquipment();
		String name = eq.getName();
		Command command = Command.getInstance(name);

		if (list.size() <= 0) return;
		Boolean rc = command.isDone(list.get(i), false);
		if (rc == null) {
		    allDone = false;
		    success = false;
		} else {
		    if (! rc.booleanValue()) success = false;
		    i ++;
		}
	    }
	}

	i = 0;
	if (allDone) {
	    waitCmd.remove(rs.getSerialId());
	    
	    for (Link link: path.getLinks().getLinks()) {
		LinkManager lm;
		try {
		    lm = LinkManager.getInstance(link);
		} catch (ServiceException ex) {
		    continue;
		} 
		
		if (lm instanceof CableManager) continue;
		
		if (lm instanceof L2swManager) {
		    L2swManager l2 = (L2swManager) lm;
		    
		    Equipment eq = l2.getEquipment();
		    String name = eq.getName();
		    Command command = Command.getInstance(name);
		    
		    boolean r = command.isDone(list.get(i), true);
		}

		if (lm instanceof OxcManager) {
		    OxcManager om = (OxcManager) lm;
		    
		    Equipment eq = om.getEquipment();
		    String name = eq.getName();
		    Command command = Command.getInstance(name);
		    
		    boolean r = command.isDone(list.get(i), true);
		}

		i ++;
	    }

	    switch (status) {
		case OPERATING_SETUP:
		    if (success) {
			rr.setDataPlaneStatus(DataPlaneStatus.ACTIVE);
			Logger.info(prog, "Notify(ACTIVE) is sent now.");
			notifier.dataPlaneStateChange
			    (cid, DataPlaneState.ACTIVE);
		    } else {
			Logger.warn(prog, "fail to control, set INACTIVE");
			rr.setDataPlaneStatus(DataPlaneStatus.INACTIVE);
			Logger.info(prog, "Notify(ACTIVATE_FAILED) is sent now.");
			notifier.errorEvent
			    (cid, EventEnumType.ACTIVATE_FAILED, null, null);
		    }
		    setDump();
		    break;
		    
		case OPERATING_TEARDOWN:
		    if (success) {
			rr.setDataPlaneStatus(DataPlaneStatus.INACTIVE);
			Logger.info(prog, "Notify(INACTIVE) is sent now.");
			notifier.dataPlaneStateChange
			    (cid, DataPlaneState.INACTIVE);
		    } else {
			Logger.warn(prog, "fail to control, set ACTIVE");
			rr.setDataPlaneStatus(DataPlaneStatus.ACTIVE);
			Logger.info(prog, "Notify(DEACTIVATE_FAILED) is sent now.");
			notifier.errorEvent 
			    (cid, EventEnumType.DEACTIVATE_FAILED, null, null);
		    }
		    setDump();
		    break;
	    }
	}
    }

    public static synchronized boolean isDump()
    {
        if (dump == true) {
	    dump = false;
            return true;
        }
        return false;
    }

    public static synchronized void setDump()
    {
	dump = true;
    }
}
