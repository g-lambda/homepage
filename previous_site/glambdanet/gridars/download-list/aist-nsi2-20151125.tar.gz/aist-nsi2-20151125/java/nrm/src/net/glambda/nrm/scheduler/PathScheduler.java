/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.rms.types.ServiceException;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;

import java.util.ArrayList;
import java.util.Hashtable;

public class PathScheduler 
{
    public static String prog = "PathScheduler";
    private static Hashtable<Long, PathScheduler> schedulers = 
	new Hashtable<Long, PathScheduler>();
    // private static Hashtable<String, PathScheduler> schedulers = 
    // new Hashtable<String, PathScheduler>();

    private Endpoint endpointA = null;
    private Endpoint endpointZ = null;
    private Paths paths = null;
    private Long key = null;
    // private String key = null;
    private Path usedPath = null;

    public static PathScheduler getScheduler (ResourceSpec rspec)
	throws ServiceException
    {
	Long key = rspec.getSerialId();
	// String key = rspec.getConnectionId();
	PathScheduler scheduler = schedulers.get(key);
	if (scheduler == null) {
	    Logger.info(prog, "new PathScheduler. key=" + key + ":" + rspec);
	    scheduler = new PathScheduler(rspec);
	    schedulers.put(key, scheduler);
	}
	return scheduler;
    }

    public PathScheduler (ResourceSpec rspec)
	throws ServiceException
    {
	key = rspec.getSerialId();
	// key = rspec.getConnectionId();
	endpointA = Topology.getEndpoint(rspec.getSrcLocalId());
	endpointZ = Topology.getEndpoint(rspec.getDstLocalId());

	if (endpointA == null) 
	    Logger.error(prog, "Source endpoint is null. rspec=" + 
			 TypesToString.resourceSpec(rspec));
	if (endpointZ == null) 
	    Logger.error(prog, "Destination endpoint is null. rspec=" + 
			 TypesToString.resourceSpec(rspec));

	paths = Paths.findPaths(endpointA, endpointZ);
	if (paths.getPaths().size() == 0) 
	    Logger.error(prog, "This Path does not exist. rspec=" + 
			 TypesToString.resourceSpec(rspec));
	
	Path path = paths.getPaths().get(0);
	if (path.getLinks().getLinks().size() == 0) 
	    Logger.error(prog, "This Link does not exist. rspec=" + 
			 TypesToString.resourceSpec(rspec));
    }

    public synchronized Path getUsedPath ()
    {
	return usedPath;
    }
    
    public synchronized boolean reserve (ResourceSpec rspec)
	throws ServiceException
    {
	for (Path path: paths.getPaths()) {
	    boolean result = reserve_body(rspec, path);
	    if (result) {
		usedPath = path;
		return true;
	    }
	}

	Logger.error(prog, "There is no enough resource. rspec=" +
		     TypesToString.resourceSpec(rspec));
	return false;
    }

    public synchronized boolean reserve_body (ResourceSpec rspec, Path path)
	throws ServiceException
    {
	boolean result = true;
	for (Link link: path.getLinks().getLinks()) {
	    LinkManager lm = LinkManager.getInstance(link);
	    result = lm.reserve(false, rspec);
	    if (! result) break;
	}
	if (! result) return false;

	ArrayList<Link> reserved = new ArrayList<Link>();
	try {
	    for (Link link: path.getLinks().getLinks()) {
		LinkManager lm = LinkManager.getInstance(link);
		result = lm.reserve(true, rspec);
		reserved.add(link);
	    }
	} catch (ServiceException ex) {
	    throw ex;
	} finally {
	    if (! result) {
		for (Link rl: reserved) {
		    LinkManager lm = LinkManager.getInstance(rl);
		    
		    lm.release(true, rspec);
		}
	    }
	} 

	return true;
    }

    public synchronized boolean reserveCommit (ResourceSpec rspec)
	throws ServiceException
    {
	return true;
    }
    
    public synchronized boolean reserveAbort (ResourceSpec rspec)
	throws ServiceException
    {
	releaseCommit(rspec);
	terminate(); /* scheduler remove from schedulers hashtables*/
	return true;
    }
    
    public synchronized boolean release (ResourceSpec rspec)
	throws ServiceException
    {
	if (usedPath == null)
	    Logger.error(prog, "Reserved path does not exist. rspec=" +
			 TypesToString.resourceSpec(rspec));
	
	boolean result = true;
	for (Link link: usedPath.getLinks().getLinks()) {
	    LinkManager lm = LinkManager.getInstance(link);
	    result = lm.release(false, rspec);
	    if (! result) 
		Logger.error(prog, "Internal error in test release. rspec=" +
			     TypesToString.resourceSpec(rspec));
	}
	return true;
    }

    public synchronized boolean releaseCommit (ResourceSpec rspec)
	throws ServiceException
    {
	boolean r = release(rspec);
	if (! r) return false;

	boolean error = false;
	for (Link link: usedPath.getLinks().getLinks()) {
	    LinkManager lm = LinkManager.getInstance(link);
	    try {
		boolean result = lm.release(true, rspec);
		if (! result) error = true;
	    } catch (ServiceException ex) {
		error = true;
	    }
	}

	/* not remove here, call terminate operation */
	// schedulers.remove(key);
	if (error)
	    Logger.error(prog, "Internal Error in real release. rspec=" +
			 TypesToString.resourceSpec(rspec));
	return true;
    }
    
    public synchronized boolean releaseAbort (ResourceSpec rspec)
	throws ServiceException
    {
	return true;
    }

    public synchronized boolean modify (ResourceSpec[] rspecs)
	throws ServiceException
    {
	boolean[] results = new boolean[rspecs.length];
	ServiceException exception = null;

	for (int i = 0; i < rspecs.length; i ++) {
	    if (rspecs[i] == null) continue;
	    try {
		results[i] = reserve_body(rspecs[i], usedPath);
	    } catch (ServiceException ex) {
		if (exception == null) exception = ex;
		break;
	    }
	}

	if (exception != null) {
	    for (int i = 0; i < rspecs.length; i ++) {
		if (results[i]) releaseCommit(rspecs[i]);
	    }
	    throw exception;
	}

	return true;
    }
    
    public synchronized boolean modifyCommit 
	(ResourceSpec[] rspecs, ResourceSpec oldRspec, ResourceSpec newRspec)
	throws ServiceException
    {
	Path up = usedPath;
	boolean result = modifyAbort(rspecs, oldRspec);
	result = releaseCommit(oldRspec);
	// terminate(); /* old scheduler remove */

	result = reserve_body(newRspec, usedPath);
	/* new scheduler put */
	// schedulers.put(newRspec.getSerialId(), this); 
	return true;
    }

    public synchronized boolean modifyAbort 
	(ResourceSpec[] rspecs, ResourceSpec rspec)
	throws ServiceException
    {
	boolean[] results = new boolean[rspecs.length];
	ServiceException exception = null;

	for (int i = 0; i < rspecs.length; i ++) {
	    if (rspecs[i] == null) continue;
	    try {
		Logger.info(prog, "== modifyAbort:" + TypesToString.resourceSpec(rspecs[i]));
		results[i] = releaseCommit(rspecs[i]);
	    } catch (ServiceException ex) {
		if (exception == null) exception = ex;
	    }
	}

	/* scheduler not remove in releaseCommit, so re-put not need. */
	// schedulers.put(rspec.getSerialId(), this);

	if (exception != null) throw exception;
	return true;
    }

    public synchronized void terminate ()
    {
	schedulers.remove(key);
    }

    public void update()
    {
    }

    public void provision(boolean isProvision)
    {
    }

    public static String getTableSize()
    {
	String s = prog + ": schedulers=" + schedulers.size();
	return s;
    }
}