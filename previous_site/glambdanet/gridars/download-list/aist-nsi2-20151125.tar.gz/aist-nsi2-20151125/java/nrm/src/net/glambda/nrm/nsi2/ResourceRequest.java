/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.nsi2;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.Time;

import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.ResourceStatus;
import net.glambda.nrm.types.LifecycleStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.util.TypesToString;

import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.StpType;
import net.glambda.rms.types.DirectionalityType;
import net.glambda.rms.types.TypeValuePairListType;
import net.glambda.rms.types.TypeValuePairType;

import java.util.Hashtable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ResourceRequest
{
    public static final String prog = "ResourceRequest";
    public static long SERIAL = 1;
    public static String networkId = Parameter.getNetworkId();
    public static Hashtable<String, ResourceRequest> requests = 
	new Hashtable<String, ResourceRequest>();

    protected String connectionId = null;
    protected int version = -1;
    protected long serial = -1;
    protected EthernetCriteria criteria = null;
    protected ResourceSpec orgRspec = null;
    protected ResourceSpec opRspec = null;
    protected ResourceSpec reservedRspec = null;
    protected ResourceSpec[] modifiedRspec = null;

    private ResourceRequest
	(String connectionId, EthernetCriteria criteria)
    {
	this.connectionId = connectionId;
	this.criteria = criteria;

	synchronized (prog) {
	    this.serial = SERIAL;
	    SERIAL++;
	}
    }

    public static ResourceRequest create
	(String connectionId, EthernetCriteria criteria)
	throws ServiceException
    {
	if (connectionId == null) 
	    Logger.error(prog, "This connectionId is null at reserve().");

	ResourceRequest rr = requests.get(connectionId);
	if (rr != null) 
	    Logger.error(prog, "This connectionId already exist at reserve()." +
			 " id=" + connectionId);
	if (criteria == null)
	    Logger.error(prog, "This criteria is null at reserve()." +
			 " id=" + connectionId);

	rr = new ResourceRequest(connectionId, criteria);
	ResourceSpec rs = rr.createRspec();
	rr.setOperationRspec(rs);
	requests.put(connectionId, rr);
	return rr;
    }

    public static ResourceRequest modify
	(String connectionId, EthernetCriteria criteria)
	throws ServiceException
    {
	if (connectionId == null) 
	    Logger.error(prog, "This connectionId is null at modify().");
	ResourceRequest rr = requests.get(connectionId);
	if (rr == null) 
	    Logger.error(prog, "This reservation does not exist at modify()." +
			 " id=" + connectionId);
	if (criteria == null)
	    Logger.error(prog, "This criteria is null at modify()." +
			 " id=" + connectionId);

	ResourceSpec rs = rr.modifyRspec(criteria);
	return rr;
    }

    public static ResourceRequest get (String connectionId)
	throws ServiceException
    {
	ResourceRequest rr = requests.get(connectionId);
	return rr;
    }

    private ResourceSpec setOperationRspec(ResourceSpec rs)
    {
	opRspec = rs;
	if (orgRspec == null) orgRspec = opRspec;
	return opRspec;
    }
    
    public ResourceSpec getOperationRspec()
    {
	return opRspec;
    }
    
    public ResourceSpec getReservedRspec()
    {
	return reservedRspec;
    }

    public ResourceSpec getOriginalRspec()
    {
	return orgRspec;
    }

    protected ResourceSpec createRspec ()
	throws ServiceException
    {
	ResourceSpec rs = new ResourceSpec();
	// rs.setSerialId(getNewSerial());
	rs.setSerialId(serial);
	rs.setConnectionId(connectionId);

	Integer v = getVersion(criteria);
	rs.setVersion(v);
	version = v.intValue();

	rs.setStartTimeOrg(getStartTime(criteria));
	rs.setEndTimeOrg(getEndTime(criteria));
	rs.setStartTime(getStartTime(criteria) - Parameter.getGuardTimePre());
	rs.setEndTime(getEndTime(criteria) + Parameter.getGuardTimePost());
	rs.setBandwidth(getBandwidth(criteria));

	DirectionalityType direction = criteria.getDirectionality();
	if (direction != DirectionalityType.BIDIRECTIONAL)
	    Logger.error(prog, "BIDIRECTIONAL is only supported." +
			 " id=" + connectionId);
	Boolean b = criteria.getSymmetricPath();
	if (b == null || ! b.booleanValue())
	    Logger.error(prog, "SymmetricPath is only supported." +
			 " id=" + connectionId);

	StpType src = criteria.getSourceSTP();
	if (src == null)
	    Logger.error(prog, "The source STP is null." +
			 " id=" + connectionId);
	String srcNetworkId = src.getNetworkId();
	if (! networkId.equals(srcNetworkId))
	    Logger.error(prog, "The source NetworkId " + srcNetworkId +
			 " is not supported.");
	rs.setSrcNetworkId(srcNetworkId);

	String srcLocalId = src.getLocalId();
	if (srcLocalId == null)
	    Logger.error(prog, "The LocalId is null." +
			 " id=" + connectionId);
	rs.setSrcLocalId(srcLocalId);
	// Integer srcVlan = getVlan(src);
	Integer srcVlan = criteria.getSourceVLAN();

	StpType dest = criteria.getDestSTP();
	if (dest == null)
	    Logger.error(prog, "The dest STP is null." +
			 " id=" + connectionId);
	String destNetworkId = dest.getNetworkId();
	if (! networkId.equals(destNetworkId))
	    Logger.error(prog, "The dest NetworkId " + destNetworkId +
			 " is not supported.");
	rs.setDstNetworkId(destNetworkId);

	String destLocalId = dest.getLocalId();
	if (destLocalId == null)
	    Logger.error(prog, "The dest LocalId is null." +
			 " id=" + connectionId);
	rs.setDstLocalId(destLocalId);
	// Integer destVlan = getVlan(dest);
	Integer destVlan = criteria.getDestVLAN();

	if (! destVlan.equals(srcVlan))
	    Logger.error(prog, "The src vlan(" + srcVlan + 
			 ") and dest vlan(" + destVlan + ") are not equal.");
	rs.setVlan(destVlan);

	rs.setProvision(new Boolean(false));
	rs.setReservationStatus(ReservationStatus.INIT);
	rs.setDataPlaneStatus(DataPlaneStatus.WAIT_START_TIME);
	rs.setLifecycleStatus(LifecycleStatus.CREATED);
	rs.setResourceStatus(ResourceStatus.INIT);
	rs.setModified(new Boolean(false));
	rs.setHeldTime(new Long(0));
	rs.setTerminateTime(new Long(0));

	return rs;
    }

    protected ResourceSpec modifyRspec (EthernetCriteria newCriteria)
	throws ServiceException
    {
	if (reservedRspec == null)
	    Logger.error(prog, "The reservation for modify() is not avaival." +
			 " id=" + connectionId);
	
	if (opRspec != null)
	    Logger.error(prog, "The reservation for modify() need commet/abort. " +
			 " id=" + connectionId +
			 " status=" + opRspec.getReservationStatus());

	ResourceSpec newrs = new ResourceSpec();
	// newrs.setSerialId(getNewSerial());
	ResourceSpec oldrs = reservedRspec;

	copy(newrs, oldrs);

	Integer v = getVersion(newCriteria);
	if (v.intValue() - version <= 0)
	    Logger.error(prog, "New version ID is less then/equal old one." +
			 " new=" + v + " old=" + version +
			 " id=" + connectionId);
	newrs.setVersion(v);

	Long startTime = null;
	try {
	    startTime = getStartTime(newCriteria);
	} catch (ServiceException ex) {
	    Logger.debug(prog, "This startTime is null in modify criteria, not error.");
	    startTime = oldrs.getStartTimeOrg();

	    Calendar c = Calendar.getInstance();
	    c.setTime(new Date(startTime));
	    newCriteria.setStartTime(c);
	}

	if ((startTime.longValue() != oldrs.getStartTimeOrg().longValue()) &&
	    (oldrs.getStartTime() < Time.getCurrentTime())) 
	    Logger.error(prog, "The startTime can not be changed " + 
			 "in case original reservation is already started.");

	if (startTime != null) {
	    newrs.setStartTimeOrg(startTime);
	    newrs.setStartTime(startTime - Parameter.getGuardTimePre());
	}

	Long endTime = null;
	try {
	    endTime = getEndTime(newCriteria);
	} catch (ServiceException ex) {
	    Logger.debug(prog, "This endTime is null in modify criteria, not error.");
	    endTime = oldrs.getEndTimeOrg();
	    
	    Calendar c = Calendar.getInstance();
	    c.setTime(new Date(endTime));
	    newCriteria.setEndTime(c);
	}

	if (endTime != null) {
	    newrs.setEndTimeOrg(endTime);
	    newrs.setEndTime(endTime + Parameter.getGuardTimePost());
	}

	if (endTime.longValue() <= startTime.longValue()) {
	    Logger.error(prog, "This startTime is later/equal endTime." +
			 " id=" + connectionId +
			 " start=" + (new Date(startTime.longValue())) +
			 " end=" + (new Date(endTime.longValue())));
	}

	Long bandwidth = null;
	try {
	    bandwidth = getBandwidth(newCriteria);
	} catch (ServiceException ex) {
	    Logger.debug(prog, "This bandwidth is null in modify criteria, not error.");

	    bandwidth = oldrs.getBandwidth();
	    newCriteria.setCapacity(bandwidth);
	}
	if (bandwidth != null) newrs.setBandwidth(bandwidth);

	opRspec = newrs;
	return newrs;
    }

    public void copy (ResourceSpec newrs, ResourceSpec oldrs)
    { 
	newrs.setSerialId(oldrs.getSerialId());
	newrs.setConnectionId(oldrs.getConnectionId());
	newrs.setVersion(oldrs.getVersion());
	newrs.setStartTime(oldrs.getStartTime());
	newrs.setEndTime(oldrs.getEndTime());
	newrs.setStartTimeOrg(oldrs.getStartTimeOrg());
	newrs.setEndTimeOrg(oldrs.getEndTimeOrg());
	newrs.setTerminateTime(oldrs.getTerminateTime());
	newrs.setBandwidth(oldrs.getBandwidth());
	newrs.setVlan(oldrs.getVlan());
	newrs.setSrcNetworkId(oldrs.getSrcNetworkId());
	newrs.setSrcLocalId(oldrs.getSrcLocalId());
	newrs.setDstNetworkId(oldrs.getDstNetworkId());
	newrs.setDstLocalId(oldrs.getDstLocalId());
	newrs.setProvision(oldrs.isProvision());
	newrs.setReservationStatus(ReservationStatus.INIT);
	newrs.setDataPlaneStatus(oldrs.getDataPlaneStatus());
	newrs.setResourceStatus(ResourceStatus.INIT);
	newrs.setLifecycleStatus(LifecycleStatus.CREATED);
	newrs.setModified(true);
    }

    public ResourceSpec[] getAdditionalResourceSpec()
	throws ServiceException
    {
	if (opRspec == null)
	    Logger.error(prog, "This rspec for modify() is null.");
	if (reservedRspec == null)
	    Logger.error(prog, "This rspec for original reservation is null.");

	if (modifiedRspec != null) return modifiedRspec;
	
	modifiedRspec = new ResourceSpec[3];
	ResourceSpec[] list = modifiedRspec;
	list[0] = null;
	list[1] = null;
	list[2] = null;

	//list[n]   n: <----- 0 ----><------- 1 -------><---- 2 ----->
	// 
	//New Rspec-A: <----- 0 ---->
	//New Rspec-B:        <--0--><--1-->
	//New Rspec-C:                 <------1----->
	//New Rspec-D:                          <--1--><--2-->
	//New Rspec-E:                                  <------2----->
	//New Rspec-F:        <--0--><--------1-------><--2-->
	//Old Rspec  :               <---------------->

	long oldStart = reservedRspec.getStartTime().longValue();
	long oldEnd   = reservedRspec.getEndTime().longValue();
	long oldBW    = reservedRspec.getBandwidth().longValue();
	long newStart = opRspec.getStartTime().longValue();
	long newEnd   = opRspec.getEndTime().longValue();
	long newBW    = opRspec.getBandwidth().longValue();
	long deltaBW = newBW - oldBW;

	//New Rspec-A: <----- 0 ---->
	//Old Rspec:                 <---------------->
	if (newEnd <= oldStart) {
	    Logger.debug(prog, "New Rspec-A");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setModified(false);
	    list[0] = rs;
	    return list;
	}
	
	//New Rspec-B:        <--0--><--1-->
	//Old Rspec:                 <---------------->
	if (newStart < oldStart && newEnd <= oldEnd) {
	    Logger.debug(prog, "New Rspec-B");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setEndTime(new Long(oldStart));
	    rs.setModified(false);
	    list[0] = rs;

	    if (deltaBW <= 0) return list;

	    rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setStartTime(new Long(oldStart));
	    rs.setBandwidth(new Long(deltaBW));
	    rs.setModified(false);
	    list[1] = rs;
	    return list;
	}
	    
	//New Rspec-C:                 <------1----->
	//Old Rspec:                 <---------------->
	if (oldStart <= newStart && newEnd <= oldEnd) {
	    if (deltaBW <= 0) return list;

	    Logger.debug(prog, "New Rspec-C");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setBandwidth(new Long(deltaBW));
	    rs.setModified(false);
	    list[1] = rs;
	    return list;
	}

	//New Rspec-F:        <--0--><--------1-------><--2-->
	//Old Rspec:                 <---------------->
	if (newStart < oldStart && oldEnd < newEnd) {
	    Logger.debug(prog, "New Rspec-F");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setEndTime(new Long(oldStart));
	    rs.setModified(false);
	    list[0] = rs;

	    rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setStartTime(new Long(oldEnd));
	    rs.setModified(false);
	    list[2] = rs;

	    if (deltaBW <= 0) return list;
	    
	    rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setStartTime(new Long(oldStart));
	    rs.setEndTime(new Long(oldEnd));
	    rs.setBandwidth(new Long(deltaBW));
	    rs.setModified(false);
	    list[1] = rs;

	    return list;
	}

	//New Rspec-E:                                  <------2----->
	//Old Rspec:                 <---------------->
	if (oldEnd <= newStart) {
	    Logger.debug(prog, "New Rspec-E");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setModified(false);
	    list[2] = rs;

	    return list;
	}

	//New Rspec-D:                          <--1--><--2-->
	//Old Rspec:                 <---------------->
	if (oldStart <= newStart && oldEnd < newEnd) {
	    Logger.debug(prog, "New Rspec-D");
	    ResourceSpec rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setStartTime(new Long(oldEnd));
	    rs.setModified(false);
	    list[2] = rs;

	    if (deltaBW <= 0) return list;
	    
	    rs = new ResourceSpec();
	    // rs.setSerialId(getNewSerial());
	    copy(rs, opRspec);
	    rs.setEndTime(new Long(oldEnd));
	    rs.setBandwidth(new Long(deltaBW));
	    list[1] = rs;
	    rs.setModified(false);
	    return list;
	}
	    
	Logger.error(prog, "Internal Error: Unknown pattern at AdditionalResourceSpec.");
	return list;
    }

    private Integer getVersion (EthernetCriteria c)
	throws ServiceException
    {
	Integer v = c.getVersion();
	if (v == null) 
	    Logger.error(prog, "This version is null. id=" + connectionId);
	return v;
    }
    
    private Long getStartTime (EthernetCriteria c)
	throws ServiceException
    {
	Calendar calendar = c.getStartTime();
	if (calendar == null) Logger.error(prog, "This startTime is null." +
					   " id=" + connectionId);
	calendar.set(Calendar.MILLISECOND, 0);
	Date date = calendar.getTime();
	Long l = new Long(date.getTime());
	return l;
    }

    private Long getEndTime (EthernetCriteria c)
	throws ServiceException
    {
	Calendar calendar = c.getEndTime();
	if (calendar == null) Logger.error(prog, "This endTime is null." +
					   " id=" + connectionId);
	calendar.set(Calendar.MILLISECOND, 0);
	Date date = calendar.getTime();
	Long l = new Long(date.getTime());
	return l;
    }

    private Long getBandwidth (EthernetCriteria c)
	throws ServiceException
    {
	Long bandwidth = c.getCapacity();
	if (bandwidth == null || bandwidth.longValue() == 0) 
	    Logger.error(prog, "This bandwidth is null." +
			 " id=" + connectionId);
	return bandwidth;
    }
    
    private Integer getVlan (StpType stp)
	throws ServiceException
    {
	TypeValuePairListType values = stp.getLabels();
	Integer vlan = new Integer(0);

	List<TypeValuePairType> list = values.getAttribute();
	for (TypeValuePairType pair: list) {
	    String type = pair.getType();
	    if (type != null && type.equals("vlan")) {
		try {
		    vlan = new Integer(pair.getValue().get(0));
		} catch (Exception ex) {
		    Logger.error(prog, "This vlan is not supported." +
				 " id=" + connectionId +
				 " vlan=" + pair.getValue().get(0));
		}

	    }
	}

	if (vlan == null || vlan.intValue() == 0) 
	    Logger.error(prog, "This vlan == 0 is not supported.");
	return vlan;
    }

    public long getSerial()
    {
	return serial;
    }

    public long getNewSerial() 
    {
	synchronized (prog) {
	    long serial = SERIAL;
	    SERIAL++;
	    return serial;
	}
    }

    public String getConnectionId()
    {
	return connectionId;
    }

    public void setDataPlaneStatus(DataPlaneStatus status)
    {
	if (orgRspec != null) orgRspec.setDataPlaneStatus(status);
	if (opRspec != null) opRspec.setDataPlaneStatus(status);
	if (reservedRspec != null) reservedRspec.setDataPlaneStatus(status);
    }

    public void provision(boolean isProvision)
    {
	if (opRspec != null) 
	    opRspec.setProvision(new Boolean(isProvision));
	if (reservedRspec != null) 
	    reservedRspec.setProvision(new Boolean(isProvision));
    }

    public boolean isReserve()
    {
	if (opRspec == null) return false;
	
	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case INIT:
		break;
		
	    default:
		return false;
	}
	return true;
    }

    public boolean isModify()
    {
	if (reservedRspec == null) return false;

	ReservationStatus rvs = reservedRspec.getReservationStatus();
	switch (rvs) {
	    case RESERVED:
		break;

	    default:
		return false;
	}

	LifecycleStatus lfs = reservedRspec.getLifecycleStatus();
	switch (lfs) {
	    case CREATED:
		break;

	    default:
		return false;
	}
	return true;
    }

    public boolean isCommit()
    {
	if (reservedRspec == null) { 
	    /* modify commit */
	}
	if (opRspec == null) return false;

	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case RESERVE_PREPARED:	/* reserve commit */
	    case MODIFY_PREPARED:	/* modify commit */
		break;

	    default:
		return false;
	}
	return true;
    }

    public boolean isAbort()
    {
	if (reservedRspec != null) {
	    /* midify abort */
	}
	if (opRspec == null) return false;

	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case RESERVE_PREPARED:	/* reserve abort */
	    case MODIFY_PREPARED:	/* modify abort */
	    case RESERVE_FAILED:	/* reserve fail abort */
	    case MODIFY_FAILED:		/* modify fail abort */
	    case RESERVE_TIMEOUT:	/* reserve timeout abort */
	    case MODIFY_TIMEOUT:	/* modify timeout abort */
		break;

	    default:
		return false;
	}

	ResourceStatus rss = opRspec.getResourceStatus();
	switch (rss) {
	    case INIT:
	    case ALLOCATED:
	    case FREED:
		break;

	    default:
		return false;
	}
	return true;
    }

    public void reserveSuccess()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no HELD reservtion(opRspec) in reserve-success." +
			 " id=" + connectionId);

	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case INIT:
		opRspec.setReservationStatus
		    (ReservationStatus.RESERVE_PREPARED);
		opRspec.setHeldTime(Time.getCurrentTime());
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected at reserve-success." +
			     " id=" + connectionId + " status=" + rvs);
	}
		
	ResourceStatus rss = opRspec.getResourceStatus();
	switch (rss) {
	    case INIT:
		opRspec.setResourceStatus(ResourceStatus.ALLOCATED);
		break;

	    default:
		Logger.error(prog, "This resource status is unexpected at reserve-success." +
			     " id=" + connectionId + " status=" + rss);
	}
    }

    public void reserveFail()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "This can not reserve-fail in no HELD.");
	
	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case INIT:
		opRspec.setReservationStatus
		    (ReservationStatus.RESERVE_FAILED);
		opRspec.setHeldTime(Time.getCurrentTime());
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected." +
			     " id=" + connectionId + " status=" + rvs);
	}
   }

    public void modifySuccess()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no HELD reservtion(opRspec) in modify-success." +
			 " id=" + connectionId);
	if (reservedRspec == null) 
	    Logger.fatal(prog, "This is no original reservation in modify-success." +
			 " id=" + connectionId);

	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case INIT:
		opRspec.setReservationStatus
		    (ReservationStatus.MODIFY_PREPARED);
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected at modify-success." +
			     " id=" + connectionId + " status=" + rvs);
	}
		
	ResourceStatus rss = opRspec.getResourceStatus();
	switch (rss) {
	    case INIT:
		opRspec.setResourceStatus(ResourceStatus.ALLOCATED);
		opRspec.setHeldTime(Time.getCurrentTime());
		break;

	    default:
		Logger.error(prog, "This resource status is unexpected at modify-success." +
			     " id=" + connectionId + " status=" + rss);
	}
    }

    public void modifyFail()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no HELD reservtion(opRspec) in modify-fail." +
			 " id=" + connectionId);
	if (reservedRspec == null) 
	    Logger.fatal(prog, "This is no original reservation in modify-fail." +
			 " id=" + connectionId);

	ReservationStatus rvs = opRspec.getReservationStatus();
	switch (rvs) {
	    case INIT:
		opRspec.setReservationStatus(ReservationStatus.MODIFY_FAILED);
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected at modify-fail." +
			     " id=" + connectionId + " status=" + rvs);
	}
    }

    public void commitDone()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no HELD reservtion(opRspec) in commit." +
			 " id=" + connectionId);

	if (reservedRspec != null) orgRspec = reservedRspec;
	reservedRspec = opRspec;
	opRspec = null;
	modifiedRspec = null;

	ReservationStatus rvs = reservedRspec.getReservationStatus();
	switch (rvs) {
	    case RESERVE_PREPARED:
		reservedRspec.setReservationStatus
		    (ReservationStatus.RESERVED);
		reservedRspec.setHeldTime(new Long(0));
		break;

	    case MODIFY_PREPARED:
		orgRspec.setReservationStatus
		    (ReservationStatus.TERMINATED);
		reservedRspec.setReservationStatus
		    (ReservationStatus.RESERVED);
		reservedRspec.setHeldTime(new Long(0));
		reservedRspec.setModified(false);
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected at commit." +
			     " id=" + connectionId + " status=" + rvs);
	}

	ResourceStatus rss = orgRspec.getResourceStatus();
    }

    public void abortDone()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no HELD reservtion(opRspec) in abort." +
			 " id=" + connectionId);

	ResourceSpec rspec = opRspec;
	if (reservedRspec == null) reservedRspec = rspec;
	opRspec = null;
	modifiedRspec = null;
	
	ReservationStatus rvs = rspec.getReservationStatus();
	ResourceStatus rss = rspec.getResourceStatus();
	switch (rvs) {
	    case RESERVE_PREPARED:
		rspec.setReservationStatus(ReservationStatus.INIT);
		rspec.setHeldTime(new Long(0));
		    
		switch (rss) {
		    case ALLOCATED:
			rspec.setResourceStatus(ResourceStatus.FREED);
			break;

		    default:
			Logger.error(prog, "This resource status is unexpected at abort." +
				     " id=" + connectionId + " status=" + rvs +
				     "/" + rss);
		}
		break;

	    case RESERVE_TIMEOUT:
	    case RESERVE_FAILED:
		rspec.setReservationStatus(ReservationStatus.INIT);
		break;
		
	    case MODIFY_PREPARED:
		rspec.setReservationStatus(ReservationStatus.INIT);
		rspec.setHeldTime(new Long(0));

		switch (rss) {
		    case ALLOCATED:
			rspec.setResourceStatus(ResourceStatus.FREED);
			break;
			
		    default:
			Logger.error(prog, "This resource status is unexpected at abort." +
				     " id=" + connectionId + " status=" + rvs +
				     "/" + rss);
		}
		break;

	    case MODIFY_TIMEOUT:
	    case MODIFY_FAILED:
		rspec.setReservationStatus(ReservationStatus.INIT);
		break;

	    default:
		Logger.error(prog, "This status is unexpected at abort." +
			     " id=" + connectionId + " status=" + rvs);
	}
    }

    public void timeoutDone()
	throws ServiceException
    {
	if (opRspec == null) 
	    Logger.fatal(prog, "There is no reservtion(opRspec) in timeout." +
			 " id=" + connectionId);

	ResourceSpec rspec = opRspec;
	modifiedRspec = null;

	// Logger.debug(prog, "timeout rspec=" + TypesToString.resourceSpec(rspec));
	ReservationStatus rvs = rspec.getReservationStatus();
	ResourceStatus rss = rspec.getResourceStatus();
	switch (rvs) {
	    case RESERVE_PREPARED:
		rspec.setReservationStatus(ReservationStatus.RESERVE_TIMEOUT);
		
		switch (rss) {
		    case ALLOCATED:
			rspec.setResourceStatus(ResourceStatus.FREED);
			break;

		    default:
			Logger.error(prog, "This resource status is unexpected at timeout." +
				     " id=" + connectionId + " status=" + rvs +
				     "/" + rss);
		}
		break;

	    case MODIFY_PREPARED:
		rspec.setReservationStatus(ReservationStatus.MODIFY_TIMEOUT);

		switch (rss) {
		    case ALLOCATED:
			rspec.setResourceStatus(ResourceStatus.FREED);
			break;

		    default:
			Logger.error(prog, "This resource status is unexpected at timeout." +
				     " id=" + connectionId + " status=" + rvs +
				     "/" + rss);
		}
		break;

	    default:
		Logger.error(prog, "This status is unexpected at timeout." +
			     " id=" + connectionId + " status=" + rvs);
	}
	// Logger.debug(prog, "timeout rspec=" + TypesToString.resourceSpec(rspec));
    }

    public void passedEndTime()
	throws ServiceException
    {
	if (opRspec != null) 
	    Logger.fatal(prog, "There is a reservtion(opRspec) in PassedEndTime." +
			 " id=" + connectionId);

	if (reservedRspec == null) 
	    Logger.fatal(prog, "There is no reservtion(reservedRspec) in PassedEndTime." +
			 " id=" + connectionId);

	ResourceStatus rss = reservedRspec.getResourceStatus();
	switch (rss) {
	    case ALLOCATED:
		reservedRspec.setResourceStatus(ResourceStatus.FREED);
		break;

	    default:
		Logger.error(prog, "This status is unexpected at PassedEndTime." +
			     " id=" + connectionId + " status=" + rss );
	}

	LifecycleStatus ls = reservedRspec.getLifecycleStatus();
	switch (ls) {
	    case CREATED:
		reservedRspec.setLifecycleStatus(LifecycleStatus.PASSED_END_TIME);
		break;

	    default:
		/* not error */
	}
    }

    public void terminateDone()
	throws ServiceException
    {
	if (opRspec != null) {
	    Logger.info(prog, "There is a reservtion(opRspec) in terminate." +
			" id=" + connectionId);
	    abortDone();
	}

	if (reservedRspec == null) 
	    Logger.fatal(prog, "There is no reservtion(reservedRspec) in terminate." +
			 " id=" + connectionId);

	DataPlaneStatus ds = reservedRspec.getDataPlaneStatus();
	switch (ds) {
	    case ACTIVE:
	    case OPERATING_SETUP:
	    case OPERATING_TEARDOWN:
		reservedRspec.setReservationStatus
		    (ReservationStatus.TERMINATING);
		reservedRspec.setLifecycleStatus(LifecycleStatus.TERMINATING);
		break;

	    default:
		reservedRspec.setReservationStatus
		    (ReservationStatus.TERMINATED);
		reservedRspec.setLifecycleStatus(LifecycleStatus.TERMINATED);
		reservedRspec.setTerminateTime(Time.getCurrentTime());
		modifiedRspec = null;

		Logger.debug(prog, "This connectionId is now removed form requests." + 
			     " id=" + connectionId);
		requests.remove(connectionId);
	}
    }

    public String toString()
    {
	String s = connectionId + ":" + serial + ", addr=" +
	    "\n\t:OPE:" + opRspec + TypesToString.resourceSpec(opRspec) + 
	    "\n\t:RES:" + reservedRspec + TypesToString.resourceSpec(reservedRspec) + 
	    "\n\t:ORG:" + orgRspec + TypesToString.resourceSpec(orgRspec) +
	    "\n\t:MOD:" + modifiedRspec;
	return s;
    }

    public static String getTableSize()
    {
	String s = prog + ": reqs=" + requests.size();
	return s;
    }
}