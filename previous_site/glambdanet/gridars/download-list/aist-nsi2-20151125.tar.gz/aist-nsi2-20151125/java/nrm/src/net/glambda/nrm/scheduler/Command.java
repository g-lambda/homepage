/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.DataPlaneStatus;

import net.glambda.rms.DataPlaneState;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Hashtable;
import java.util.ArrayList;

public class Command extends Thread
{
    private static final String prog = "Command";
    private final String lock = "lock";
    private static Hashtable<String, Command> commands =
	new Hashtable<String, Command>();

    private final String name;
    private String cmd = null;
    private ResourceSpec rspec = null;
    private boolean isSetup;
    
    public ArrayList<String> cmds = new ArrayList<String>();
    public ArrayList<Boolean> isSetups = new ArrayList<Boolean>();
    public ArrayList<ResourceSpec> rspecs = new ArrayList<ResourceSpec>();
    public ArrayList<Long> serials = new ArrayList<Long>();
    private long serial = 0;
    private Hashtable<Long, Boolean> dones = 
	new Hashtable<Long, Boolean>();
    
    private Command(String name)
    {
	super();
	this.name = name;
	startThread();
    }

    public static Command getInstance(String name)
    {
	Command c = commands.get(name);
	if (c == null) {
	    c = new Command(name);
	    commands.put(name, c);
	    Logger.info(prog, "add new command. name=" + name);
	}
	return c;
    }

    private void startThread () 
    {
        Thread thread = new Thread(new Runnable() {
                public void run() {
		    Logger.debug(prog, "command thread is start now.");
                    while (true) {
			try {
			    done();
			} catch (Exception ex) {
			    Logger.warn(prog, "command thread throw exception. ex=" + ex);
			}
                    }
                }
            });
        thread.start();
    }

    public synchronized long add
	(String cmd, boolean isSetup, ResourceSpec rspec) 
    {
	try {
	    cmds.add(cmd);
	    isSetups.add(isSetup);
	    rspecs.add(rspec);
	    serial ++;
	    serials.add(new Long(serial));
	    notifyAll();
	} catch (Exception ex) {
	    Logger.warn(prog, "nofigyAll ex=" + ex);
	}
	return serial;
    }

    public synchronized void done()
	throws Exception
    {
	if (cmds.size() == 0) {
	    try {
		wait();
	    } catch (Exception ex) {
		Logger.warn(prog, "wait has a exception. ex=" + ex);
	    }
	}

	while (cmds.size() != 0) {
	    int rc = 0;
	    Vector<String> vi = null;
	    Vector<String> ve = null;
	    Process p = null;
	
	    try {
		String cmd = cmds.remove(0);
		Boolean isSetup = isSetups.remove(0);
		ResourceSpec rspec = rspecs.remove(0);
		Long serial = serials.remove(0);
	
		Logger.info(prog, "command start now:" + cmd);

		Runtime r = Runtime.getRuntime();
		p = r.exec(cmd);
		InputStream is = p.getInputStream();
		BufferedReader ib = 
		    new BufferedReader(new InputStreamReader(is));
		InputStream ie = p.getErrorStream();
		BufferedReader eb = 
		    new BufferedReader(new InputStreamReader(ie));
		
		String o = null;
		vi = new Vector<String>();
		while ((o = ib.readLine()) != null) {
		    vi.addElement(o);
		}
		ve = new Vector<String>();
		while ((o = eb.readLine()) != null) {
		    ve.addElement(o);
		}
		rc = p.waitFor();
		
		String s = "";
		for (Enumeration<String> e = vi.elements() ; e.hasMoreElements();) {
		    s += "\n\tSTDOUT: " + e.nextElement();
		}
		for (Enumeration<String> e = ve.elements() ; e.hasMoreElements();) {
		    s += "\n\tSTDERR: " + e.nextElement();
		}
		s += "\n\tEXITCODE: " + rc;
		Logger.info(prog, "stdio:" + s);

		Boolean f = null;
		if (rc == 0) 
		    f = new Boolean(true);
		else 
		    f = new Boolean(false);
		dones.put(serial, f);
		Logger.info(prog, "-------- put isDone=" + f + ", name=" + serial);
	    } catch (Exception ex) {
		Logger.warn(prog, "command exception=" + ex);
	    } finally {
		if (p != null) {
		    try {
			p.getErrorStream().close();
		    } catch (Exception e) {
			Logger.warn(prog, "close error stream. ex=" + e);
		    }
		    try {
			p.getInputStream().close();
		    } catch (Exception e) {
			Logger.warn(prog, "close input stream. ex=" + e);
		    }
		    try {
			p.getOutputStream().close();
		    } catch (Exception e) {
			Logger.warn(prog, "close output stream. ex=" + e);
		    }
		    try {
			p.destroy();
		    } catch (Exception e) {
			Logger.warn(prog, "destroy process. ex=" + e);
		    }
		}
	    }
	}
    }

    public Boolean isDone (Long serial, boolean isRemove) 
    {
	Boolean rc = null;
	if (isRemove) {
	    rc = dones.remove(serial);
	    Logger.debug(prog, "-------- remove isDone=" + rc + ", name=" + serial);
	} else {
	    rc = dones.get(serial);
	}
	// Logger.debug(prog, "-------- isDone=" + rc + ", name=" + serial);
	return rc;
    }
}
