/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.Enumeration;

public class ResourceManager
{
    private static ResourceManager manager = null;
    private static String prog = "ResourceMamanger";
    private static final String networkId = Parameter.getNetworkId();

    protected Hashtable<Long, ResourceRequest> requests = 
	new Hashtable<Long, ResourceRequest>();
    private Hashtable<Long, ResourceRequest> prepared = 
	new Hashtable<Long, ResourceRequest>();
    private Hashtable<Long, ResourceRequest> modified = 
	new Hashtable<Long, ResourceRequest>();
    protected Hashtable<Long, ResourceRequest> reserved = 
	new Hashtable<Long, ResourceRequest>();

    private ResourceManager() {}

    public static ResourceManager getInstance()
    {
	if (manager == null) manager = new ResourceManager();
	return manager;
    }

    public boolean reserve (ResourceRequest request)
	throws ServiceException
    {
	if (request == null) 
	    Logger.error(prog, "This request is null in reserve.");
	
	Long rkey =  new Long(request.getSerial());
	if (rkey.longValue() <= 0 ) 
	    Logger.error(prog, "This serialId is nagative in reserve.");

	ResourceRequest rr = requests.get(rkey);
	ResourceSpec rspec = request.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	switch (rs) {
	    case INIT:
		break;

	    default:
		Logger.error(prog, "This status is not INIT in reserve." +
			     " status=" + rs);
	}

	String srcNetworkId = rspec.getSrcNetworkId();
	if (! networkId.equals(srcNetworkId)) 
	    Logger.error(prog, "The src networkId is mismatch." +
			 " this:" + networkId + ", src:" + srcNetworkId);
	
	String srcLocalId = rspec.getSrcLocalId();
	Endpoint srcEndpoint = Topology.getEndpoint(srcLocalId);
	if (srcEndpoint == null) 
	    Logger.error(prog, "The src localId does not exist." +
			 " localId:" + srcLocalId);

	String dstNetworkId = rspec.getDstNetworkId();
	if (! networkId.equals(srcNetworkId)) 
	    Logger.error(prog, "The dst networkId is mismatch." +
			 " this:" + networkId + ", dst:" + dstNetworkId);

	String dstLocalId = rspec.getDstLocalId();
	Endpoint dstEndpoint = Topology.getEndpoint(dstLocalId);
	if (dstEndpoint == null) 
	    Logger.error(prog, "The dst localId does not exist." +
			 " localId:" + dstLocalId);

	long startTime = rspec.getStartTime().longValue();
	long endTime = rspec.getEndTime().longValue();
	long currentTime = Time.getCurrentTime();
	if (endTime <= startTime) 
	    Logger.error(prog, "endTime <= startTime, " +
			 "end:" + TypesToString.time(endTime) +
			 ", start:" + TypesToString.time(startTime));
	if (endTime <= currentTime) 
	    Logger.error(prog, "endtime <= currentTime, " +
			 "end:" + TypesToString.time(endTime) +
			 ", start:" + TypesToString.time(currentTime));

	int bandwidth = rspec.getBandwidth().intValue();
	if (bandwidth < 0) 
	    Logger.error(prog, "bandwidth < 0, bandwidth=" + bandwidth);

	int vlan = rspec.getVlan().intValue();
	if (vlan < 0) 
	    Logger.error(prog, "vlan < 0, vlan=" + vlan);

	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(rspec);
	    boolean result = scheduler.reserve(rspec);
	}
	    
	requests.put(rkey, request);
	prepared.put(rkey, request);
	return true;
    }

    public boolean reserveCommit (ResourceRequest request) 
	throws ServiceException
    {
	if (request == null)
	    Logger.error(prog, "This request is null in resvCommit.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null)
	    Logger.error
		(prog, "This reservation is already terminated. cid=" + cid);
	if (rr != request) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());
	
	ResourceSpec rspec = request.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	switch (rs) {
	    case RESERVE_PREPARED:
		break;

	    default:
		Logger.error
		    (prog, "Status is not RESERVE_PREPARED. status=" +rs);
	}
	
	rr = prepared.get(rkey);
	if (rr == null) {
	    Logger.warn(prog, "This request is already committed. id=" + cid);
	    return true;
	}
	
	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(rspec);
	    scheduler.reserveCommit(rspec);
	}

	prepared.remove(rkey);
	reserved.put(rkey, request);
	return true;
    }

    public boolean reserveAbort (ResourceRequest request) 
	throws ServiceException
    {
	if (request == null)
	    Logger.error(prog, "This request is null in resvAbort.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null)
	    Logger.error
		(prog, "This reservation is already terminated. cid=" + cid);
	if (rr != request) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());

	ResourceSpec rspec = request.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	switch (rs) {
	    case RESERVE_PREPARED:
		break;

	    case RESERVE_TIMEOUT:
		return true;	/* already aborted */

	    default:
		Logger.error
		    (prog, "Status is not RESERVE_PREPARED/TIMEOUT." +
		     " status=" + rs);
	}
	
	rr = prepared.get(rkey);
	if (rr == null) {
	    Logger.warn(prog, "This request is already aborted. id=" + cid);
	    return true;
	}

	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(rspec);
	    scheduler.reserveAbort(rspec);
	    scheduler.terminate();
	}

	rr = prepared.remove(rkey);
	return true;
    }

    public boolean modify (ResourceRequest request)
	throws ServiceException
    {
	if (request == null) 
	    Logger.error(prog, "This request is null in modify.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null) 
	    Logger.error
		(prog, "This reservation is already terminated. " + cid);
	if (rr != request) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());
	
	ResourceSpec oldr = request.getReservedRspec();
	ResourceSpec newr = request.getOperationRspec();
	ReservationStatus rs = oldr.getReservationStatus();
	switch (rs) {
	    case RESERVED:
		break;
		
	    default:
		Logger.error
		    (prog, "Status(oldr) is not RESERVED. status=" + rs);
	}

	rs = newr.getReservationStatus();
	switch (rs) {
	    case INIT:
		break;
		
	    default:
		Logger.error
		    (prog, "Status(newr) is not INIT. status=" + rs);
	}

	ResourceSpec[] rspecs = request.getAdditionalResourceSpec();
	if (true) {
	    for (int i = 0; rspecs != null && i < rspecs.length; i++) {
		Logger.debug(prog, "" + i + ":" + 
			     TypesToString.resourceSpec(rspecs[i]));
	    }
	}
	synchronized (prog) {
	    try {
		PathScheduler scheduler = PathScheduler.getScheduler(newr);
		scheduler.modify(rspecs);
	    } catch (ServiceException ex) {
		throw ex;
	    }
	}

	modified.put(rkey, request);
	return true;
    }

    public boolean modifyCommit (ResourceRequest request) 
	throws ServiceException
    {
	if (request == null) 
	    Logger.error(prog, "This request is null in modiCommit.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null) 
	    Logger.error
		(prog, "This request is already terminated. id=" + cid);
	if (request != rr) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());
    
	ResourceSpec newr = request.getOperationRspec();
	ResourceSpec oldr = request.getReservedRspec();
	ReservationStatus rs = oldr.getReservationStatus();
	switch (rs) {
	    case RESERVED:
		break;
		
	    default:
		Logger.error
		    (prog, "Status(oldr) is not RESERVED. status=" +
		     oldr.getReservationStatus());
	}
	
	rs = newr.getReservationStatus();
	switch (rs) {
	    case MODIFY_PREPARED:
		break;
	    
	    default:
		Logger.error
		    (prog, "Status(newr) is not MODIFY_PREPARED. status=" + rs);
	}

	rr = modified.get(rkey);
	if (rr == null) {
	    Logger.warn
		(prog, "This request is already committed(no HELD). id=" + cid);
	    return true;
	}

	ResourceSpec[] rspecs = request.getAdditionalResourceSpec();
	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(newr);
	    scheduler.modifyCommit(rspecs, oldr, newr);
	}
	
	modified.remove(rkey);
	reserved.put(rkey, rr);
	return true;
    }

    public boolean modifyAbort (ResourceRequest request) 
	throws ServiceException
    {
	if (request == null) 
	    Logger.error(prog, "This request is null in modify.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null) 
	    Logger.warn
		(prog, "This reservation is already terminated. " + cid);
	if (rr != request) 
	    Logger.warn
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());
	
	ResourceSpec newr = request.getOperationRspec();
	ResourceSpec oldr = request.getReservedRspec();
	ReservationStatus rs = oldr.getReservationStatus();
	switch (rs) {
	    case RESERVED:
		break;
		
	    default:
		Logger.error
		    (prog, "Status(oldr) is not RESERVED. status=" + rs);
	}

	rs = newr.getReservationStatus();
	switch (rs) {
	    case MODIFY_PREPARED:
		break;

	    case MODIFY_TIMEOUT:
		return true;	/* already aborted */

	    default:
		Logger.error
		    (prog, "Status is not MODIFY_PREPARED/TIMEOUT. status=" + rs);
	}

	rr = modified.get(rkey);
	if (rr == null) 
	    Logger.warn
		(prog, "This request is already aborted(no HELD). id=" + cid);

	ResourceSpec[] rspecs = request.getAdditionalResourceSpec();
	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(newr);
	    scheduler.modifyAbort(rspecs, newr);
	}

	modified.remove(rkey);
	return true;
    }

    public boolean terminate (ResourceRequest request)
	throws ServiceException
    {
	if (request == null)
	    Logger.error(prog, "This request is null in terminate.");

	String cid = request.getConnectionId();
	Long rkey =  new Long(request.getSerial());
	ResourceRequest rr = requests.get(rkey);
	if (rr == null) {
	    Logger.warn
		(prog, "This reservation is already terminated. cid=" + cid);
	    return true;
	}
	if (rr != request) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());

	rr = prepared.remove(rkey);
	if (rr != null)
	    Logger.warn
		(prog, "Internal error(forget resvAbort). " + cid);

	rr = modified.remove(rkey);
	if (rr != null) 
	    Logger.warn
		(prog, "Internal error(forget modiAbort). cid=" + cid);

	rr = reserved.get(rkey);
	if (rr == null) {
	    Logger.info(prog, "This request is already Passed EndTime.");
	    return true;
	}
	if (rr != request) 
	    Logger.error
		(prog, "Internal Error: ResourceRequest is not match." +
		 "\n\t ARGS:" + request.toString() +
		 "\n\t HASH:" + rr.toString());
		
	ResourceSpec rspec = request.getReservedRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	switch (rs) {
	    case RESERVED:
	    case TERMINATING:
	    case TERMINATED:
		break;
		
	    default:
		Logger.error(prog, "Status is not RESERVED. status=" + rs);
	}		    

	synchronized (prog) {
	    PathScheduler scheduler = PathScheduler.getScheduler(rspec);
	    scheduler.releaseCommit(rspec);
	}
	
	// requests.remove(rkey); 
	return true;
    }

    public String getTableSize() 
    {
	String s = prog + ": reqs=" + requests.size() +
	    ", prep=" + prepared.size() + ", modi=" + modified.size() +
	    ", resv=" + reserved.size();
	s += "\n\t" + PathScheduler.getTableSize();
	s += "\n\t" + Paths.getTableSize();
	s += "\n\t" + LinkManager.managerss.size();
	Enumeration e = LinkManager.managerss.elements();
	while (e.hasMoreElements()) {
	    LinkManager lm = (LinkManager) e.nextElement();
	    s += "\n\t" + lm.getTableSize();
	}
	return s;
    }
}
