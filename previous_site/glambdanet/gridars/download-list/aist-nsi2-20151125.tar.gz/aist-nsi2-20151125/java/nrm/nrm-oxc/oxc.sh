#! /usr/bin/expect -f
#
set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally

if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set host	[lindex $argv 0]
set cmd		[lindex $argv 1]
set ifname1	[lindex $argv 2]
set ifname2	[lindex $argv 3]
set bw		[lindex $argv 4]
set vlan	[lindex $argv 5]
set userid	"nrm"
set passwd	"nrm"
set prompt	"\\$"
set timeout	10
set addr	"" 
set command	"csw" 
set command	"echo csw" 

if {($argc < 4) || (($cmd != "teardown") && ($cmd != "setup"))} {
	puts "NTT-AT OXC $argv\r"
	puts "useage: oxcname setup|teardown ifname ifname\r"
	puts "\tswname:\tip address of NTT-AT OXC\r"
	puts "\tsetupl:\tconnect ports\r"
	puts "\tteardown:\tdis-connect ports\r"
	puts "\tifname:\tport number, example P1,P2,,,P6,null\r"
	exit -1
}

if {($host == "OXC1")} { 
#	set addr "192.168.2.241" 
	set addr "glif1" 
}

if {($addr == "")} {
	puts "The $host is unknown host.\r"
	exit -1
}

if {($ifname1 == "P0")} {
	set ifname1 "0"
} elseif {($ifname1 == "P1")} {
	set ifname1 "1"
} elseif {($ifname1 == "P2")} {
	set ifname1 "2"
} elseif {($ifname1 == "P3")} { 
	set ifname1 "3" 
} elseif {($ifname1 == "P4")} { 
	set ifname1 "4" 
} elseif {($ifname1 == "P5")} { 
	set ifname1 "5"
} elseif {($ifname1 == "P6")} { 
	set ifname1 "6" 
} elseif {($ifname1 == "P7")} { 
	set ifname1 "7" 
} elseif {($ifname1 == "P8")} { 
	set ifname1 "8" 
} else {
	puts "The ifname1($ifname1) is not correct name(P1-P8)."
	exit -1
} 

if {($ifname2 == "P0")} { 
	set ifname2 "0" 
} elseif {($ifname2 == "P1")} { 
	set ifname2 "1" 
} elseif {($ifname2 == "P2")} { 
	set ifname2 "2" 
} elseif {($ifname2 == "P3")} { 
	set ifname2 "3" 
} elseif {($ifname2 == "P4")} { 
	set ifname2 "4"
} elseif {($ifname2 == "P5")} { 
	set ifname2 "5"
} elseif {($ifname2 == "P6")} { 
	set ifname2 "6" 
} elseif {($ifname2 == "P7")} { 
	set ifname2 "7" 
} elseif {($ifname2 == "P8")} { 
	set ifname2 "8" 
} else {
	puts "The ifname2($ifname2)is not correct name(P1-P8)."
	exit -1
} 

# exit
##############################################################################
# login
puts "ssh -l $userid $addr echo csw -s 0 -i $ifname1 -o $ifname2"
spawn ssh -l $userid $addr 
expect {
    "\\$" {
    }
    "Enter passphrase" {
	send -- "$passwd\r"
	exp_continue
    }

    "Permission denied" {
	puts "set passphrase or key\r"
	exit -1
    }

    exit -1
}

if {$cmd == "setup"} { 
	send -- "$command -s 0 -i $ifname1 -o $ifname2\r"
	expect -- "${prompt}"
}

if {$cmd == "teardown"} {
	send -- "$command -s 0 -i $ifname1 -o 0\r"
	expect -- "${prompt}"
	send -- "$command -s 0 -i $ifname2 -o 0\r"
	expect -- "${prompt}"
}

send -- "exit\r"
expect -- "\r\\$"
exit 0
