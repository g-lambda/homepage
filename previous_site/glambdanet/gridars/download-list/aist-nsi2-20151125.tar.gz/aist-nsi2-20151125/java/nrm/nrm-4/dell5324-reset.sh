#! /bin/bash
#
vlans="1780 1781 1782 1783"
prog=./dell5324.sh
#echo="echo"
echo=

for vlan in $vlans 
  do
  $echo $prog SW1 teardown P1 P2 100 $vlan
  $echo $prog SW1 teardown P3 P4 100 $vlan
  $echo $prog SW1 teardown P5 P6 100 $vlan
done
