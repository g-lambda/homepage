/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;
import java.util.Enumeration;

public class L2swManager extends LinkManager
{
    private static final String prog = "L2swManager";
    private static final long resource0 = 0;

    private static Hashtable<String, L2swManager> pathManagers =
	new Hashtable<String, L2swManager>();
    private static Hashtable<Integer, VlanManager> vlanManagers =
	new Hashtable<Integer, VlanManager>();

    private final String pname;
    private final String ename;
    private final Equipment equipment;
    private final Link link;
    ArrayList<Integer> vlans = new ArrayList<Integer>();

    public static L2swManager getL2swInstance (Link link) 
	throws ServiceException
    {
	String pname = link.getName();
	String ename = link.getEquipmentName();

	L2swManager manager = pathManagers.get(pname);
	if (manager == null) {
	    manager = new L2swManager(link);
	    pathManagers.put(pname, manager);
	}
	return manager;
    }

    private L2swManager(Link link)
	throws ServiceException
    {
	super(link.getName());

	this.pname = link.getName();
	this.ename = link.getEquipmentName();
	equipment = Topology.getEquipment(ename);
	this.link = link;

	initTimeTable(resource0);

	Endpoint a = link.getEndpointA();
	Endpoint z = link.getEndpointZ();
	
	String allowVlanA = a.getAllowVlan();
	List<Integer> vlanA = VlanManager.getVlan(allowVlanA);
	String allowVlanZ = a.getAllowVlan();
	List<Integer> vlanZ = VlanManager.getVlan(allowVlanZ);

	for (Integer vA: vlanA) {
	    for (Integer vZ: vlanZ) {
		if (vA.intValue() == vZ.intValue()) vlans.add(vA);
	    }
	}
	
	for (Integer v: vlans) {
	    VlanManager vm = vlanManagers.get(v);
	    if (vm != null) continue;

	    vm = VlanManager.getVlanInstance(ename, v);
	    vlanManagers.put(v, vm);
	}
    }

    public synchronized boolean reserve 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== S-Scheduler:reserve:" + 
		    TypesToString.resourceSpec(rspec));

	Integer vlan = rspec.getVlan();
	if (vlan == null || vlan.intValue() == 0)
	    Logger.error(prog, "This vlan is 0.");

	VlanManager vm = vlanManagers.get(vlan);
	if (vm == null)
	    Logger.error(prog, "This VLAN id is not allowed. vlan=" + vlan);

	boolean rvlan = vm.reserve(false, rspec);
	Logger.info(prog, "+++++ reserved vlan=" + vlan);

	if (! rvlan)
	    Logger.error(prog, "There are not enough resources. vlan=" + vlan);
	
	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(false, resource0, rspec);
	    if (! r) 
		Logger.error(prog, "There are not enough resources.");
	}
	
	if (! isReserve) return true;
	
	rvlan = vm.reserve(true, rspec);
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(true, resource0, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in real reserve().");
	}
	
	return true;
    }

    public synchronized boolean release
	(boolean isRelease, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== S-Scheduler:release:" + 
		    TypesToString.resourceSpec(rspec));

	Integer vlan = rspec.getVlan();
	if (vlan == null || vlan.intValue() == 0)
	    Logger.error(prog, "This vlan is 0.");
	VlanManager vm = vlanManagers.get(vlan);
	if (vm == null)
	    Logger.error(prog, "This VLAN is not allocated. vlan=" + vlan);

	boolean rvlan = vm.release(false, rspec);
	if (! rvlan)
	    Logger.error(prog, "This VLAN can not release. vlan=" + vlan);
	
	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);

	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.release(false, resource0, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in test release().");
	}

	if (! isRelease) return true;

	rvlan = vm.release(true, rspec);
	boolean r = false;
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    r = t.release(true, resource0, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in real release().");
	}

	return true;
    }

    public synchronized static void garbage(Long time) 
    {
	Enumeration e = pathManagers.elements();
	while (e.hasMoreElements()) {
	    L2swManager lm = (L2swManager) e.nextElement();
	    lm.garbageTimeTable(time);
	}
    }

    public synchronized void garbageTimeTable (Long time)
    {
	while (true) {
	    TimeTable t = timeTables.get(0);
	    Long endTime = t.getEndTime();

	    if (endTime < time) {
		timeTables.remove(0);
		timeHash.remove(t.getStartTime());
		t.clear();
	    } else {
		return;
	    }
	}
    }

    public boolean reserveCommit (ResourceSpec rspec)
	throws ServiceException
    {
	return true;
    }

    public boolean reserveAbort (ResourceSpec rspec)
	throws ServiceException
    {
	release(true, rspec);
	return true;
    }

    public boolean setup ()
    {
	Logger.debug(prog, "Setup now. link=" + link);
	return true;
    }

    public boolean teardown ()
    {
	Logger.debug(prog, "Teardown now. link=" + link);
	return true;
    }

    public Equipment getEquipment()
    {
	return equipment;
    }

    public static String getTableSizes()
    {
	String s = prog +": paths=" + pathManagers.size() +
	    ":, vlans=" + vlanManagers.size();
	return s;
    }
}