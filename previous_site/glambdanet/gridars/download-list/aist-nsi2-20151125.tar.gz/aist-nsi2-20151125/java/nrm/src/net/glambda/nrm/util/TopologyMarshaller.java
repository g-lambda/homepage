/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoints;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.EndpointType;
import net.glambda.nrm.types.Equipments;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;
import net.glambda.nrm.types.InterfaceType;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;

public class TopologyMarshaller 
{
    public static Equipments equipments = new Equipments();
    public static Endpoints endpoints = new Endpoints();
    public static Links links = new Links();

    public TopologyMarshaller() {}

    public static void output()
    {
        try {
	    JAXBContext context =
		JAXBContext.newInstance("net.glambda.nrm.types");
	    
	    createObjects();
	    
	    // FileOutputStream output = new FileOutputStream("out.xml");
	    FileWriter output = new FileWriter("out.xml");
	    
	    Marshaller marshaller = context.createMarshaller();
	    marshaller.setProperty("jaxb.encoding", 
                                   Charset.defaultCharset().name());
	    marshaller.setProperty("jaxb.formatted.output", true);
	    // marshaller.marshal(endpoints, System.out);
	    marshaller.marshal(equipments, output);
	    marshaller.marshal(endpoints, output);
	    marshaller.marshal(links, output);
	    
	} catch (JAXBException ex) {
	    ex.printStackTrace();
	} catch (Exception ex) {
	    ex.printStackTrace();
	}
    }

    private static void createObjects() 
    {
	Endpoint stp1 = null;
	{
	    Endpoint endpoint = stp1 = new Endpoint();
	    endpoint.setName("STP1");
	    endpoint.setNetworkId("net.glambda.aist");
	    endpoint.setLocalId("N1");
	    // endpoint.setControlId("P15");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.STP);
	    // endpoint.setEquipmentName();
	    // endpoint.setEquipment();
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint stp2 = null;
	{
	    Endpoint endpoint = stp2 = new Endpoint();
	    endpoint.setName("STP2");
	    endpoint.setNetworkId("net.glambda.aist");
	    endpoint.setLocalId("C1");
	    // endpoint.setControlId("P16");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.STP);
	    // endpoint.setEquipmentName();
	    // endpoint.setEquipment();
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint stp3 = null;
	{
	    Endpoint endpoint = stp3 = new Endpoint();
	    endpoint.setName("STP3");
	    endpoint.setNetworkId("net.glambda.aist");
	    endpoint.setLocalId("C2");
	    // endpoint.setControlId("P17");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.STP);
	    // endpoint.setEquipmentName();
	    // endpoint.setEquipment();
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint stp4 = null;
	{
	    Endpoint endpoint = stp4 = new Endpoint();
	    endpoint.setName("STP4");
	    endpoint.setNetworkId("net.glambda.aist");
	    endpoint.setLocalId("PS");
	    // endpoint.setControlId("P18");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.STP);
	    // endpoint.setEquipmentName();
	    // endpoint.setEquipment();
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Equipment equipment = new Equipment();
	equipment.setName("SW1");
	equipment.setController("/usr/local/bin/dell5324.sh");
	// equipment.setClass()
	equipment.setEquipmentType(EquipmentType.L_2_SW);
	equipments.getEquipments().add(equipment);

	Endpoint portx = null;
	{
	    Endpoint endpoint = portx = new Endpoint();
	    endpoint.setName("SW1");
	    // endpoint.setNetworkId("net.glambda.aist");
	    // endpoint.setLocalId("SW1");
	    endpoint.setControlId("null");
	    // endpoint.setAllowVlan("1780-1784");
	    // endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.L_2_SW_CORE);
	    endpoint.setEquipmentName("SW1");
	    endpoint.setEquipment(equipment);
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint port15 = null;
	{
	    Endpoint endpoint = port15 = new Endpoint();
	    endpoint.setName("SW1.P15");
	    // endpoint.setNetworkId("net.glambda.aist");
	    // endpoint.setLocalId("SW1.P15");
	    endpoint.setControlId("P15");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.L_2_SW_PORT);
	    endpoint.setEquipmentName("SW1");
	    endpoint.setEquipment(equipment);
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint port16 = null;
	{
	    Endpoint endpoint = port16 = new Endpoint();
	    endpoint.setName("SW1.P16");
	    // endpoint.setNetworkId("net.glambda.aist");
	    // endpoint.setLocalId("SW1.P16");
	    endpoint.setControlId("P16");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.L_2_SW_PORT);
	    endpoint.setEquipmentName("SW1");
	    endpoint.setEquipment(equipment);
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint port17 = null;
	{
	    Endpoint endpoint = port17 = new Endpoint();
	    endpoint.setName("SW1.P17");
	    // endpoint.setNetworkId("net.glambda.aist");
	    // endpoint.setLocalId("SW1.P17");
	    endpoint.setControlId("P17");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.L_2_SW_PORT);
	    endpoint.setEquipmentName("SW1");
	    endpoint.setEquipment(equipment);
	    endpoints.getEndpoints().add(endpoint);
	}
	
	Endpoint port18 = null;
	{
	    Endpoint endpoint = port18 = new Endpoint();
	    endpoint.setName("SW1.P18");
	    // endpoint.setNetworkId("net.glambda.aist");
	    // endpoint.setLocalId("SW1.P18");
	    endpoint.setControlId("P18");
	    endpoint.setAllowVlan("1780-1784");
	    endpoint.getIftype().add(InterfaceType.T_1000_BASE_T);
	    endpoint.setEndpointType(EndpointType.L_2_SW_PORT);
	    endpoint.setEquipmentName("SW1");
	    endpoint.setEquipment(equipment);
	    endpoints.getEndpoints().add(endpoint);
	}
	
	{
	    Link link = new Link();
	    link.setName("CABLE.1");
	    link.setEndpointNameA("STP1");
	    link.setEndpointA(stp1);
	    link.setEndpointNameZ("SW1.P15");
	    link.setEndpointZ(port15);
	    links.getLinks().add(link);
	}	    

	{
	    Link link = new Link();
	    link.setName("CABLE.2");
	    link.setEndpointNameA("STP2");
	    link.setEndpointA(stp2);
	    link.setEndpointNameZ("SW1.P16");
	    link.setEndpointZ(port16);
	    links.getLinks().add(link);
	}	    

	{
	    Link link = new Link();
	    link.setName("CABLE.3");
	    link.setEndpointNameA("STP3");
	    link.setEndpointA(stp3);
	    link.setEndpointNameZ("SW1.P17");
	    link.setEndpointZ(port17);
	    links.getLinks().add(link);
	}	    

	{
	    Link link = new Link();
	    link.setName("CABLE.4");
	    link.setEndpointNameA("STP4");
	    link.setEndpointA(stp4);
	    link.setEndpointNameZ("SW1.P18");
	    link.setEndpointZ(port18);
	    links.getLinks().add(link);
	}	    

        return;
    }

    public static void main(String[] args) {
        new TopologyMarshaller();
	output();
    }
}
