#! /bin/bash
#! /bin/sh
LIBS=./
LIBS=$LIBS:../build/jar/nrm.jar
LIBS=$LIBS:../libs/commons-logging-1.1.1.jar
LIBS=$LIBS:../libs/log4j-1.2.13.jar

java -cp $LIBS test.TestNrm
