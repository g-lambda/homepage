/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.DataPlaneStatus;

// import net.glambda.rms.types.ServiceException;

import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;

public class TimeTable 
{
    public static String prog = "TimeTable";
    // private static long BIG = 0x7fffffffffffffff;
    private static long BIG = 100000000; /* for debug, 3 years*/
    private Hashtable<String, ResourceSpec> rspecs =
	new Hashtable<String, ResourceSpec>();

    private Long startTime;
    private Long endTime;
    private final long resource;
    private long free = 0;
    private long alloc = 0;
    
    public TimeTable(Long startTime, Long endTime, long resource) 
    {
	if (resource == 0) resource = BIG;

	this.startTime = startTime;
	this.endTime = endTime;
	this.resource = resource;
	this.free = resource;
	this.alloc = 0;

	if (endTime <= startTime) 
	    Logger.fatal(prog, "This endTime is smaller than startTime.");
	
	// Logger.info(prog, "endTime=" + TypesToString.ytime(endTime));
    }
    
    private TimeTable(TimeTable t)
    {
	this.startTime = t.getStartTime();
	this.endTime = t.getEndTime();
	this.resource = t.getResource();
	this.free = t.getFreeResource();
	this.alloc = t.getAllocatedResource();
	
	Enumeration e = t.getKeys();
	while(e.hasMoreElements()) {
	    String key = (String) e.nextElement() ;
	    ResourceSpec rspec = t.getResourceSpec(key);
	    this.rspecs.put(key, rspec);
	}
    }

    public synchronized TimeTable copy() 
    {
	TimeTable t = new TimeTable(this);
	return t;
    }

    public String getKey(ResourceSpec rspec)
    {
	String key = "";
	if (rspec == null) return key;

	key = "" + rspec.getSerialId() + "/" + rspec.getVersion();
	return key;
    }

    public synchronized boolean reserve
	(boolean isReserve, long request, ResourceSpec rspec)
    {
	// Logger.info(prog, "reserve spec=" + TypesToString.resourceSpec(rspec));

	if (free < request) return false;
	if (! isReserve) return true;

	free -= request;
	alloc += request;
	Logger.debug(prog, "reserve put=" + TypesToString.resourceSpec(rspec));
	rspecs.put(getKey(rspec), rspec);
	
	/* check */
	if (free + alloc != resource)
	    Logger.fatal(prog, "Internal Error in reserve(). resrouce" + 
			 resource + " != alloc=" + alloc  + ", free=" + free);
	return true;
    }

    public synchronized boolean release
	(boolean isRelease, long request, ResourceSpec rspec)
    {
	// Logger.info(prog, "release spec=" + TypesToString.resourceSpec(rspec));
	
	// Logger.debug(prog, "isRelease=" + isRelease);
	ResourceSpec r = rspecs.get(getKey(rspec));
	if (r == null) return true;
	if (r != rspec) {
	    Logger.info(prog, "ARGS spec=" + TypesToString.resourceSpec(rspec));
	    Logger.debug(prog, "HASH spec=" + TypesToString.resourceSpec(r));
	    Logger.warn(prog, "Internal Error(rspec in args != hash) in release()");
	    return false;
	}

	if (alloc < request) {
	    Logger.fatal(prog, "Internal Error alloc < free. resrouce=" 
			 + resource + ", alloc=" + alloc  + ", free=" + free); 
	    return false;
	}

	if (! isRelease) return true;
	
	free += request;
	alloc -= request;
	Logger.debug(prog, "release remove=" + TypesToString.resourceSpec(rspec));
	rspecs.remove(getKey(rspec));

	/* check */
	if (free + alloc != resource) 
	    Logger.fatal(prog, "Internal Error in release(). resrouce" + 
			 resource + " != alloc=" + alloc  + ", free=" + free);
	return true;
    }

    public Long getStartTime() {
	return startTime;
    }

    public Long setStartTime(Long time) {
	startTime = time;
	return startTime;
    }

    public Long getEndTime() {
	return endTime;
    }

    public Long setEndTime(Long time) {
	endTime = time;
	return endTime;
    }

    public long getResource() {
	return resource;
    }

    public long getAllocatedResource() {
	return alloc;
    }

    private synchronized long addAllocatedResource(long a) {
	alloc += a;
	free -= a;

	/* check */
	if (free + alloc != resource) 
	    Logger.warn(prog, "Internal Error in release(). resrouce" + 
			resource + " != alloc=" + alloc  + ", free=" + free);

	return alloc;
    }

    public long getFreeResource() {
	return free;
    }

    private synchronized long addFreeResource(long a) {
	alloc -= a;
	free += a;

	/* check */
	if (free + alloc != resource) 
	    Logger.warn(prog, "Internal Error in release(). resrouce" + 
			resource + " != alloc=" + alloc  + ", free=" + free);

	return free;
    }

    public synchronized boolean hasSerial(Long n) {
	Enumeration e = rspecs.elements();
	while (e.hasMoreElements()) {
	    ResourceSpec rs = (ResourceSpec) e.nextElement();
	    if (rs.getSerialId() == n) return true;
	}
	return false;
    }

    public synchronized boolean isSetup(Long n) {
	Enumeration e = rspecs.elements();
	boolean notsetup = false;
	while (e.hasMoreElements()) {
	    ResourceSpec rs = (ResourceSpec) e.nextElement();
	    if (rs.getSerialId() != n) {
		ReservationStatus st = rs.getReservationStatus();
		DataPlaneStatus ds = rs.getDataPlaneStatus();
		switch (st) {
		    case RESERVED:
			switch (ds) {
			    case ACTIVE: 
				notsetup = true;
			}
		}
	    }
	}

	return (! notsetup);
    }

    public synchronized boolean isTeardown(Long n) {
	Enumeration e = rspecs.elements();
	boolean notdown = false;
	while (e.hasMoreElements()) {
	    ResourceSpec rs = (ResourceSpec) e.nextElement();
	    if (rs.getSerialId() != n) {
		ReservationStatus st = rs.getReservationStatus();
		DataPlaneStatus ds = rs.getDataPlaneStatus();
		switch (st) {
		    case RESERVED:
			switch (ds) {
			    case ACTIVE: 
				notdown = true;
			}
		}
	    }
	}

	return (! notdown);
    }

    private Enumeration getKeys() {
	return rspecs.keys();
    }

    public ResourceSpec getResourceSpec(String key) {
	return rspecs.get(key);
    }

    public synchronized String toString() 
    {
	String s = "";
	s = "r=A" + alloc + "/R" + resource + ":";
	s += "START:" + TypesToString.time(startTime);
	s += "->END:" + TypesToString.time(endTime);

	Enumeration e = rspecs.keys();
	while (e.hasMoreElements()) {
	    String key = (String) e.nextElement();
	    ResourceSpec rs = rspecs.get(key);
	    s += ", SERIAL:" + rs.getConnectionId();
	    s += "/" + rs.getVersion();
	}
	return s;
    }

    public synchronized String toHtml() 
    {
	String s = "";
	s += "<TD>" + alloc + "</TD>";
	s += "<TD>" + resource + "</TD>";
	s += "<TD>" + TypesToString.time(startTime) + "</TD>";
	s += "<TD>" + TypesToString.time(endTime) + "</TD>";
	
	String s1 = null;
	Enumeration e = rspecs.keys();
	while (e.hasMoreElements()) {
	    String key = (String) e.nextElement();
	    ResourceSpec rs = rspecs.get(key);
	    if (s1 == null) s1 = "";
	    s1 += rs.getConnectionId() + "/" + rs.getVersion() + " ";
	}
	if (s1 == null) {
	    if (alloc != 0) Logger.warn(prog, "INTERNAL Error. rspec is null, but some resource is allocated.");
	    return "";
	}
	s += "<TD>" + s1 + "</TD>";
	return s;
    }

    public synchronized String dump()
    {
	String s = toString();
	int i = 1;

	Enumeration e = getKeys();
	while(e.hasMoreElements()) {
	    String key = (String) e.nextElement();
	    ResourceSpec rspec = rspecs.get(key);
	    s += "\n\t\t" + i + "::" + rspec.toString();
	    i++;
	}
	return s;
    }

    public void clear()
    {
	// Logger.debug(prog, "clear rspecs.");
	rspecs.clear();
    }
}
