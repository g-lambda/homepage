/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoints;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.EndpointType;
import net.glambda.nrm.types.Equipments;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;
import net.glambda.nrm.types.InterfaceType;
import net.glambda.nrm.types.ResourceSpec;

import java.util.Hashtable;
import java.util.List;
import java.util.Date;

public class TypesToString
{
    public static String prog = "TypesToString";

    public static String comma = ", ";
    public static String period = ".\n";
    private static  String delPattern1 = Parameter.getDelete1();
    private static  String delPattern2 = Parameter.getDelete2();
    private static Hashtable<String, String> months = 
	new Hashtable<String, String>();
    static 
    {
	months.put("Jan", "01");
	months.put("Feb", "02");
	months.put("Mar", "03");
	months.put("Apr", "04");
	months.put("May", "05");
	months.put("Jun", "06");
	months.put("Jul", "07");
	months.put("Aug", "08");
	months.put("Sep", "09");
	months.put("Oct", "10");
	months.put("Nov", "11");
	months.put("Dec", "12");
    }

    public static String links(Links obj)
    {
	String s = "Links: ";
	if (obj == null) return s + "null" + period; 

	List<Link> o = obj.getLinks();
	s += "size=" +  o.size() + period; 
	for (Link l: o) {
	    s += link(l);
	}
	return s;
    }

    public static String link(Link obj)
    {
	String s = "Link: ";
	if (obj == null) return s + "null" + period; 

	s += obj.getName() + comma;
	s += obj.getEndpointNameA() + comma;
	// s += obj.getEndpointA() + comma;
	s += obj.getEndpointNameZ() + comma;
	// s += obj.getEndpointZ() + comma;
	s += obj.getBandwidth() + comma;
	s += obj.getEquipmentName() + period;
	return s;
    }

    public static String endpoints(Endpoints obj)
    {
	String s = "Endpoints: ";
	if (obj == null) return s + "null" + period; 

	List<Endpoint> o = obj.getEndpoints();
	s += "size=" +  o.size() + period; 
	for (Endpoint e: o) {
	    s += endpoint(e);
	}
	return s;
    }

    public static String endpoint(Endpoint obj)
    {
	String s = "Endpoint: ";
	if (obj == null) return s + "null" + period; 

	s += obj.getName() + comma;
	s += obj.getNetworkId() + comma;
	s += obj.getLocalId() + comma;
	s += obj.getControlId() + comma;
	s += obj.getAllowVlan() + comma;

	List<InterfaceType> o = obj.getIftype();
	for (InterfaceType t: o) {
	    s += t;
	    if (! o.isEmpty()) s += ":";
	}

	s += comma;
	s += obj.getEndpointType() + comma;
	s += obj.getEquipmentName() + period;
	// s += obj.getEquipment() + period;
	return s;
    }

    public static String equipments(Equipments obj)
    {
	String s = "Equipments: ";
	if (obj == null) return s + "null" + period; 

	List<Equipment> o = obj.getEquipments();
	s += "size=" +  o.size() + period; 
	for (Equipment e: o) {
	    s += equipment(e);
	}
	return s;
    }

    public static String equipment(Equipment obj)
    {
	String s = "Equipment: ";
	if (obj == null) return s + "null" + period; 

	s += obj.getName() + comma;
	s += obj.getController() + comma;
	s += obj.getClazz() + comma;
	s += obj.getEquipmentType() + period;
	return s;
    }

    public static String time(long t)
    {
	Date d = new Date();
	d.setTime(t);
	// Calendar c = new Calendar();
	// c.setTime(d);
	String s = d.toString();
	try {
	    String[] args = s.split(" ");
	    String n = "" + months.get(args[1]) + "/" + args[2] + " " + 
		args[3];
	    // args[3] + " " + args[4];
	    return n;
	} catch (Exception ex) {
	    Logger.warn(prog, "miss long to date.");
	}
	return s;
    }

    public static String ytime(long t)
    {
	Date d = new Date();
	d.setTime(t);
	// Calendar c = new Calendar();
	// c.setTime(d);
	String s = d.toString();
	return s;
    }

    public static String resourceSpecUpdate(ResourceSpec rspec)
    {
	String s = "" + rspec.getConnectionId();
	s += ":" + rspec.getSerialId() + "/" + rspec.getVersion();

	String id = rspec.getSrcLocalId();
	if (id != null) {
	    id = id.replaceAll(delPattern1, "");
	    id = id.replaceAll(delPattern2, "");
	}
	s += ":S=" + id;

	id = rspec.getDstLocalId();
	if (id != null) {
	    id = id.replaceAll(delPattern1, "");
	    id = id.replaceAll(delPattern2, "");
	}
	s += ":D=" + id + "\n\t";

	s += ":start=" + time(rspec.getStartTimeOrg());
	s += ":end=" + time(rspec.getEndTimeOrg());
	// s += ":start=" + time(rspec.getStartTime());
	// s += ":end=" + time(rspec.getEndTime());
	s += ":vlan=" + rspec.getVlan();
	s += ":bw=" + rspec.getBandwidth();
	s += ":md=" + rspec.isModified() + "\n\t";
	s += ":status=" + rspec.getReservationStatus();
	s += "/" + rspec.getDataPlaneStatus();
	s += "/" + rspec.getLifecycleStatus();

	return s;
    }

    public static String resourceSpec(ResourceSpec rspec)
    {
	if (rspec == null) return "null";

	String s = "" + rspec.getConnectionId();
	s += ":" + rspec.getVersion();
	s += ":" + rspec.getSerialId();

	String id = rspec.getSrcLocalId();
	if (id != null) {
	    id = id.replaceAll(delPattern1, "");
	    id = id.replaceAll(delPattern2, "");
	}
	s += ":S=" + id;

	id = rspec.getDstLocalId();
	if (id != null) {
	    id = id.replaceAll(delPattern1, "");
	    id = id.replaceAll(delPattern2, "");
	}
	s += ":D=" + id;

	s += ":start=" + time(rspec.getStartTimeOrg());
	s += ":end=" + time(rspec.getEndTimeOrg());
	s += ":vlan=" + rspec.getVlan();
	s += ":bw=" + rspec.getBandwidth();
	s += ":md=" + rspec.isModified();
	s += ":status=" + rspec.getReservationStatus();
	s += "/" + rspec.getDataPlaneStatus();
	s += "/" + rspec.getLifecycleStatus();

	return s;
    }
}