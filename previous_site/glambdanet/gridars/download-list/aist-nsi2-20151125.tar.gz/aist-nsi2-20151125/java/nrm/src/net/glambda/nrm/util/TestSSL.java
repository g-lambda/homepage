/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.nsi2.Nrm;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.Logger;

import net.glambda.nsi2.impl.ResourceManagerBase;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;

import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsExchange;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URL;
import java.security.SecureRandom;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.ws.rs.core.UriBuilder;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.xml.ws.Endpoint;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBusFactory;

@WebService
    public class TestSSL
 {
     @WebMethod
     public String test() {
	 return "Hello, SSL world!";
     }  

     public TestSSL() {}
     static TestSSL impl = new TestSSL();

     public static void main(String[] args) throws Exception 
     {
	 // https(args);
	 // http(args);
	 test(args);
     }

     public static void https(String[] args) throws Exception 
     {
	 Endpoint endpoint = Endpoint.create(impl);
	 // SSLContext ssl =  SSLContext.getInstance("SSLv3");
	 SSLContext ssl =  SSLContext.getInstance("TLS");
         
	 KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	 System.err.println("KeyStore AG=" + KeyManagerFactory.getDefaultAlgorithm());
	 KeyStore store = KeyStore.getInstance(KeyStore.getDefaultType());
	 System.err.println("KeyStore Type=" + KeyStore.getDefaultType());
	 
	 //Load the JKS file (located, in this case, at D:\keystore.jks, with password 'test'
	 String file = Parameter.getKeystoreFile();
	 String pass = Parameter.getKeystorePassphrase();
	 System.err.println("KeyStore file=" + file + "/" + pass);
	 store.load(new FileInputStream(file), pass.toCharArray()); 
	 
	 //init the key store, along with the password 'test'
	 kmf.init(store, pass.toCharArray());
	 KeyManager[] keyManagers = new KeyManager[1];
	 keyManagers = kmf.getKeyManagers();
	 System.err.println("KeyManager=" + keyManagers[0]);
         
	 //Init the trust manager factory
	 TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
	 
	 //It will reference the same key store as the key managers
	 tmf.init(store);
         
	 TrustManager[] trustManagers = tmf.getTrustManagers();
	 System.err.println("trustManagers=" + trustManagers[0]);
         
	 ssl.init(keyManagers, trustManagers, new SecureRandom());
	 
	 //Init a configuration with our SSL context
	 HttpsConfigurator configurator = new HttpsConfigurator(ssl);
	 
	 //Create a server on localhost, port (https port)
	 HttpsServer httpsServer = HttpsServer.create
	     (new InetSocketAddress("0.0.0.0", 22311), 5);
	      
	 httpsServer.setHttpsConfigurator(configurator);
         
	 //Create a context so our service will be available under this context
	 HttpContext context = httpsServer.createContext("/test");
	 
	 //Finally, use the created context to publish the service
	 endpoint.setExecutor(Executors.newFixedThreadPool(5));
	 endpoint.publish(context);
	 httpsServer.start();
     }

     public static void http(String[] args) throws Exception 
     {
	 HttpServer httpServer = HttpServer.create
	     (new InetSocketAddress("0.0.0.0", 22311), 5);
	 HttpContext context = httpServer.createContext("/test");
	 httpServer.start();

	 /*
	 HttpHandler handler = new HttpHandler() {
		 @Override
	         public void handle(HttpExchange arg0) throws IOException {
		     String str = "Welcome!";
		     arg0.sendResponseHeaders(200, str.length());
		     OutputStream os = arg0.getResponseBody();
		     os.write(str.getBytes());
		     os.flush();
		     os.close();
		 }
	     };
	 context.setHandler(handler);
	 */

	 Endpoint endpoint = Endpoint.create(impl);
	 endpoint.setExecutor(Executors.newFixedThreadPool(5));
	 endpoint.publish(context);
	 // httpServer.start();
	 // endpoint.publish("http://localhost:22311/test");

	 System.err.println("publish?" + endpoint.isPublished());
	 System.err.println("path=" + context.getPath());
	 System.err.println("server=" + context.getServer().getAddress());
	 System.err.println("execu=" + context.getServer().getExecutor());
	 System.err.println("execu=" + endpoint.getExecutor());
	 System.err.println("handle=" + context.getHandler());
     }

     public static void test(String[] args) throws Exception
     {
	 SpringBusFactory bf = new SpringBusFactory();
	 URL busFile = TestSSL.class.getResource("TestSSL.xml");
	 Bus bus = bf.createBus(busFile.toString());
	 bf.setDefaultBus(bus);

	 Object implementor = new TestSSL();
	 Endpoint.publish("https://0.0.0.0:22311/test", implementor);
	 Endpoint.publish("http://0.0.0.0:22211/test", implementor);

	 System.out.println("Server ready...");
     }

}
