#! /bin/bash
xjc schema/*.xsd -d src
