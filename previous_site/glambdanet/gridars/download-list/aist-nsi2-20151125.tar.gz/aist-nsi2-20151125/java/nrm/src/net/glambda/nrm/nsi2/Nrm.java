/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.nsi2;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.SimpleHttpMonitor;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.scheduler.ResourceManager;
import net.glambda.nrm.scheduler.DataPlaneManager;
import net.glambda.nrm.scheduler.Topology;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.LifecycleStatus;
import net.glambda.nrm.types.ResourceSpec;


import net.glambda.rms.Notifier;
import net.glambda.rms.NSI2ResourceManagerBase;
import net.glambda.rms.EthernetResourceManager;
import net.glambda.rms.LambdaResourceManager;
import net.glambda.rms.ODUResourceManager;
import net.glambda.rms.TransferResourceManager;
import net.glambda.rms.types.CommonHeaderType;
import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.ServiceException;

import java.util.Comparator;;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Set;
import java.util.Arrays;

public class Nrm implements NSI2ResourceManagerBase, EthernetResourceManager
{
    public static final String prog = "Nrm";

    private Hashtable<String, ResourceRequest> reservations =
	new Hashtable<String, ResourceRequest>();

    public Notifier notifier = null;
    public ResourceManager manager = null;
    public SimpleHttpMonitor monitor = null;

    public DataPlaneManager dsManager = null;
    public boolean color = true;
    public final long heldTimeout;

    public Nrm () 
    {
	super();
	monitor = new SimpleHttpMonitor(this);
	monitor.start();
	heldTimeout = Parameter.getHeldTimeout();
    }

    public Notifier getNotifier() 
    {
	if (notifier == null) 
	    Logger.warn(prog, "The notifier is not set(null) yet.");
	return notifier;
    }

    public void setNotifier (Notifier notifier) 
    {
	if (notifier == null) 
	    Logger.fatal(prog, "This notifier is null.");
	if (this.notifier != null) 
	    Logger.fatal(prog, "The notifier is set already.");

	Logger.info(prog, "The notifier is set now.");
	this.notifier = notifier;
	this.manager = ResourceManager.getInstance();
	this.dsManager = new DataPlaneManager(this, manager);
	Topology.getInstance();
	startKeeper();
    }

    public void checkStatus(String connectionId) 
	throws ServiceException 
    {
	if (notifier == null)
	    Logger.error(prog, "The notifier is not set yet.");
	if (manager == null) 
	    Logger.error(prog, "The ResourceSceduler is not set yet.");
    }

    public void reserve
	(CommonHeaderType header, String connectionId, 
	 String globalReservationId, String description, 
	 EthernetCriteria criteria) 
	throws ServiceException 
    {
	Logger.info(prog, ">>>>> reserve <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r != null) 
	    Logger.error(prog, "This connectionId already exists at reserve()." +
			 " id=" +connectionId);
	r = ResourceRequest.create(connectionId, criteria);
	if (! r.isReserve()) 
	    Logger.error(prog, "You can not reserve this connectionId." +
			 " id=" +connectionId);

	reservations.put(connectionId, r);
	try {
	    manager.reserve(r);
	} catch (ServiceException ex) {
	    r.reserveFail();
	    throw ex;
	}

	r.reserveSuccess();
    }

    public void modify
	(CommonHeaderType header, String connectionId, 
	 String globalReservationId, String description, 
	 EthernetCriteria criteria) 
	throws ServiceException
    {
	Logger.info(prog, ">>>>> modify <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at modify()." +
			 " id=" + connectionId);
	if (! r.isModify()) 
	    Logger.error(prog, "You can not modify this connectionId." +
			 " id=" +connectionId);

	r = ResourceRequest.modify(connectionId, criteria);
	try {
	    manager.modify(r);
	} catch (ServiceException ex) {
	    r.modifyFail();
	    throw ex;
	}

	r.modifySuccess();
    }
	 
    public void commit
	(CommonHeaderType header, String connectionId) 
	throws ServiceException
    {
	Logger.info(prog, ">>>>> commit <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at commit()." + 
			 " id=" + connectionId);
	if (! r.isCommit()) 
	    Logger.error(prog, "You can not commit this connectionId." +
			 " id=" + connectionId);

	ResourceSpec rspec = r.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	try {
	    switch (rs) {
		case RESERVE_PREPARED:
		    manager.reserveCommit(r);
		    break;

		case MODIFY_PREPARED:
		    manager.modifyCommit(r);
		    break;

		default:
		    Logger.error(prog, "This status is unexpected at commit()." +
				 " id=" + connectionId + " status=" + rs);
	    }
	} catch (ServiceException ex) {
	    throw ex;
	} finally {
	    r.commitDone();
	}
    }

    public void abort
	(CommonHeaderType header, String connectionId)
	throws ServiceException
    {
	Logger.info(prog, ">>>>> abort <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at abort()." +
			 " id=" + connectionId);
	if (! r.isAbort()) 
	    Logger.error(prog, "You can not abort this connectionId." +
			 " id=" + connectionId);

	ResourceSpec rspec = r.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	try {
	    switch (rs) {
		case RESERVE_PREPARED:
		case RESERVE_TIMEOUT:
		    manager.reserveAbort(r);
		    break;
		    
		case MODIFY_PREPARED:
		case MODIFY_TIMEOUT:
		    manager.modifyAbort(r);
		    break;
		    
		case RESERVE_FAILED:
		case MODIFY_FAILED:
		    break;
		    
		default:
		    Logger.error(prog, "This status is unexpected at abort()." +
				 " id=" + connectionId + " status=" + rs);
	    }
	} catch (ServiceException ex) {
	    throw ex;
	} finally {
	    r.abortDone();
	}
    }

    public void timeout
	(CommonHeaderType header, String connectionId)
	throws ServiceException
    {
	Logger.info(prog, ">>>>> timeout <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at timeout()." +
			 " id=" + connectionId);
	boolean f = r.isAbort();
	if (f) Logger.info(prog, "This connectionId needs abort at timeout()." +
			     " id=" + connectionId);

	ResourceSpec rspec = r.getOperationRspec();
	ReservationStatus rs = rspec.getReservationStatus();

	Logger.info(prog, "Notify(Reserve Timeout) is sent now.");
	notifier.reserveTimeout(connectionId, (int) heldTimeout);

	switch (rs) {
	    case RESERVE_PREPARED:
	    case RESERVE_TIMEOUT:
		if (f) manager.reserveAbort(r);
		r.timeoutDone();
		break;
		
	    case MODIFY_PREPARED:
	    case MODIFY_TIMEOUT:
		if (f) manager.modifyAbort(r);
		r.timeoutDone();
		break;
		
	    default:
		Logger.error(prog, "This status is unexpected at timeout()." +
			     " id=" + connectionId + " status=" + rs);
	} 
    }

    public void terminate
	(CommonHeaderType header, String connectionId)
	throws ServiceException
    {
	Logger.info(prog, ">>>>> terminate <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) {
	    Logger.info(prog, "This connectionId does not exist at terminate." +
			" id=" + connectionId);
	    return;
	}

	boolean f = r.isAbort();
	if (f) {
	    Logger.info(prog, "This connectionId needs abort() at terminate()." +
			" id=" + connectionId);
	    abort(header, connectionId);
	}

	ResourceSpec rspec = r.getReservedRspec();
	ReservationStatus rs = rspec.getReservationStatus();
	switch (rs) {
	    case RESERVED:
	    case INIT:
		manager.terminate(r);
		r.terminateDone();
		break;

	    case TERMINATING:
	    case TERMINATED:
		Logger.info(prog, "This connectionId is already terminated.");
		break;

	    default:
		Logger.error(prog, "This status is unexpected at terminate()." +
			     " id=" + connectionId + " status=" + rs);
	}
    }

    public void provision
	(CommonHeaderType header, String connectionId)
	throws ServiceException
    {
	Logger.info(prog, ">>>>> provision <<<<<, id=" + connectionId);
	checkStatus(connectionId);

	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at provison()." +
			 " id=" + connectionId);
	r.provision(true);
    }

    public void release
	(CommonHeaderType header, String connectionId)
	throws ServiceException
    {
	Logger.info(prog, ">>>>> release <<<<<, id=" + connectionId);
	checkStatus(connectionId);
	ResourceRequest r = reservations.get(connectionId);
	if (r == null) 
	    Logger.error(prog, "This connectionId does not exist at release()." +
			 " id=" + connectionId);
	r.provision(false);
    }

    public String httpDumpReservation()
    {
	int size = reservations.size();

	String s = 
	    "<table width=\"96%\" align=\"center\" border=\"1\" cellpadding=\"5\"><caption><div align=\"right\">";
	s += TypesToString.time(Time.getCurrentTime());
	s += "</div></caption>";
	s += "<tr bgcolor=\"#C0C0C0\"><th>Reservation ID</th><th>Termination Point</th><th>Terminal Point</th><th>Start Time</th><th>End Time</th><th>BW (Mbps)</th><th>VLAN ID</th><th>Reservation Status</th><th>Data Plane</th><th>Life cycle</th></tr>\n";
	
	Set<String> keySet = reservations.keySet();
	Object[] keyArray = keySet.toArray();
	String[] keys = new String[keyArray.length];
	for (int i = 0; i < keyArray.length; i++) {
	    keys[i] = (String) (keyArray[i]);
	}
	Arrays.sort(keys);
	    
	color = false;
	for (int i = 0; i < keys.length; i++) {
	    String key = keys[i];

	    ResourceRequest rr = reservations.get(key);
	    if (rr == null) {
		Logger.warn(prog, "Hashtable(reservations) has null ResourceRequest." +
			    " key=" + key);
		continue;
	    }

	    ResourceSpec r = rr.getReservedRspec();
	    if (r == null && false) 
		Logger.debug(prog, "ResourceRequest has null reserved rspec." +
			     " ResourceRequest=" + rr);
	    if (r != null) s += requestToHtml(r);

	    r = rr.getOperationRspec();
	    if (r == null && false) 
		Logger.debug(prog, "ResourceRequest has null operated rspec." +
			     " ResourceRequest=" + rr);
	    if (r != null) s += requestToHtml(r);
	}

	s += "</TABLE>\n";
	return s;
    }

    public String requestToHtml(ResourceSpec r)
    {
	String s = "";

	if (color) {
	    s += "<TR bgcolor=\"#00FFFF\" align=\"center\">";
	    color = false;
	} else {
	    s += "<TR bgcolor=\"#FFFFFF\" align=\"center\">";
	    color = true;
	}
	    
	s += "<TD>" + r.getConnectionId() + "/" + r.getVersion() + "</TD>";
	s += "<TD>" + r.getSrcLocalId() + "</TD>";
	s += "<TD>" + r.getDstLocalId() + "</TD>";
	s += "<TD>" + TypesToString.time(r.getStartTimeOrg()) + "</TD>";
	s += "<TD>" + TypesToString.time(r.getEndTimeOrg()) + "</TD>";
	s += "<TD>" + (r.getBandwidth()) + "</TD>";
	s += "<TD>" + (r.getVlan()) + "</TD>";
	
	ReservationStatus rs = r.getReservationStatus();
	switch (rs) {
	    case INIT:
		s += "<TD bgcolor=\"#FFFFFF\"><blink>" + "START" + "</blink></TD>";
		break;
		
	    case RESERVE_PREPARED:
		s += "<TD bgcolor=\"#00FF00\">" + "RESERVE HELD" + "</TD>";
		break;
		
	    case RESERVE_FAILED:
		s += "<TD bgcolor=\"#00FF00\">" + "RESERVE FAILED" + "</TD>";
		break;
		
	    case RESERVED:
		s += "<TD bgcolor=\"#00FF00\">" + "RESERVED START" + "</TD>";
		break;
		
	    case MODIFY_PREPARED:
		s += "<TD bgcolor=\"#00FF00\">" + "MODIFY HELD" + "</TD>";
		break;
		
	    case MODIFY_FAILED:
		s += "<TD bgcolor=\"#00FF00\">" + "MODIFY FAULED" + "</TD>";
		break;
		
	    case TERMINATING:
		s += "<TD bgcolor=\"#FFFFFF\">" + "TERMINATING" + "</TD>";
		break;
		
	    case TERMINATED:
		s += "<TD bgcolor=\"#FFFFFF\">" + "TERMINATED" + "</TD>";
		break;

	    case RESERVE_TIMEOUT:
		s += "<TD bgcolor=\"#00FF00\">" + "RESERVE TIMEOUT" + "</TD>";
		break;

	    case MODIFY_TIMEOUT:
		s += "<TD bgcolor=\"#00FF00\">" + "MODIFY TIMEOUT" + "</TD>";
		break;

	    default:
		s += "<TD bgcolor=\"#00FF00\">" + "Unknown " + rs + "</TD>";
	}
	
	DataPlaneStatus ds = r.getDataPlaneStatus();
	switch (ds) {
	    case WAIT_START_TIME:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Wait StartTime";
		if (r.isProvision()) s += ", Provisioned";
		s += "</TD>";
		break;
		    
	    case OPERATING_SETUP:
		s += "<TD bgcolor=\"#00FF00\"><blink>" + "setup";
		if (r.isProvision()) s += ", Provisioned";
		s += "</blink></TD>";
		break;

	    case OPERATING_TEARDOWN:
		s += "<TD bgcolor=\"#00FF00\"><blink>" + "teardown";
		if (r.isProvision()) s += ", Provisioned";
		s += "</blink></TD>";
		break;
		
	    case ACTIVE:
		s += "<TD bgcolor=\"#c0ffc0\"><blink>" + "ACTIVATE";
		if (r.isProvision()) s += ", Provisioned";
		s += "</blink></TD>";
		break;
		
	    case INACTIVE:
		s += "<TD bgcolor=\"#00FF00\"><blink>" + "INACTIVATE";
		if (r.isProvision()) s += ", Provisioned";
		s += "</blink></TD>";
		break;
		
	    case PASSED_END_TIME:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Passed EndTime" + "</TD>";
		break;

	    case TERMINATED:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Passed EndTime" + "</TD>";
		break;

	    default:
		s += "<TD bgcolor=\"#00FF00\">" + "Unknown" + "</TD>";
	}

	LifecycleStatus ls = r.getLifecycleStatus();
	switch (ls) {
	    case CREATED:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Created" + "</TD>";
		break;

	    case FAILED:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Failed" + "</TD>";
		break;

	    case PASSED_END_TIME:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Passed EndTime" + "</TD>";
		break;

	    case TERMINATING:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Terminating" + "</TD>";
		break;

	    case TERMINATED:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Terminate" + "</TD>";
		break;

	    default:
		s += "<TD bgcolor=\"#FFFFFF\">" + "Unknown" + "</TD>";
	}

	s += "</TR>\n";
	return s;
    }

    private void startKeeper () 
    {
        Thread timeKeeper = new Thread(new Runnable() {
                public void run() {
		    int interval = Parameter.getTimeKeeperInterval();
                    while (true) {
                        try {
                            Thread.sleep(interval);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
			try {
			    update();
			} catch (Exception ex) {
                            ex.printStackTrace();
			}
                    }
                }
            });
        timeKeeper.start();
    }

    public void update() 
    {
	Long current = Time.getCurrentTime();
	int wait = Parameter.getTimeKeeperDeleteWait();

	Enumeration e = reservations.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    String cid = rr.getConnectionId();
	    ResourceSpec ors = rr.getOperationRspec();
	    ResourceSpec rrs = rr.getReservedRspec();

	    if (ors == null) continue;
	    ReservationStatus s = ors.getReservationStatus();
	    switch (s) {
		case RESERVE_PREPARED:
		case MODIFY_PREPARED:
		    break;

		case RESERVE_TIMEOUT:
		case RESERVE_FAILED:
		case INIT:
		    // case MODIFY_TIMEOUT: // if timeout, org resv terminated too
		    // case MODIFY_FAILED:  // if timeout, org resv terminated too
		    {
			Long heldTime = ors.getHeldTime();
			if (heldTime != 0  &&
			    heldTime + heldTimeout < current)  {
			    try {
				Logger.info(prog, "This timeout request is terminated now." +
					    " id=" + cid);
				terminate(null, cid);
			    } catch (ServiceException ex) {
				Logger.warn(prog, "Terminated operation throw exception." +
					    " id=" + cid + " ex=" + ex);
			    }
			}
		    }
		    continue;
		    
		default:
		    continue;
	    }

	    Long endTime_org = null;
	    if (rrs != null) endTime_org = rrs.getEndTime();

	    Long endTime = ors.getEndTime();
	    Long heldTime = ors.getHeldTime();
	    if ((endTime_org != null && endTime_org < current) ||
		endTime < current || 
		(heldTime != 0 && heldTime + heldTimeout < current))  {
		try {
		    Logger.info(prog, "This held-request is timeouted now." +
				" id=" + cid);
		    timeout(null, cid);
		} catch (ServiceException ex) {
		    Logger.warn(prog, "Timeout operation throw exception." +
				" id=" + cid + " ex=" + ex);
		}
	    }
	}

	e = reservations.elements();
	while (e.hasMoreElements()) {
	    ResourceRequest rr = (ResourceRequest) e.nextElement();
	    String cid = rr.getConnectionId();
	    ResourceSpec rs = rr.getReservedRspec();
	    if (rs == null) continue;

	    ReservationStatus s = rs.getReservationStatus();
	    DataPlaneStatus ds = rs.getDataPlaneStatus();

	    switch (s) {
		case TERMINATING:
		    if (ds == DataPlaneStatus.PASSED_END_TIME) {
			try {
			    rr.terminateDone();
			} catch (ServiceException ex) {
			    Logger.warn(prog, "Previous error is not real error.");
			} 
		    }
		    break;
	    }

	    Long endTime = rs.getEndTime();
	    if (endTime < current) {
		switch (s) {
		    case RESERVED:
		    case INIT:
			rs.setLifecycleStatus(LifecycleStatus.PASSED_END_TIME);
			
			if (endTime + heldTimeout < current) {
			    Logger.info(prog, "This reservation is terminated by nrm. cid=" + cid);
			    try {
				terminate(null, cid);
			    } catch (ServiceException ex) {
				Logger.warn(prog, "Terminated operation throw exception." +
					    " id=" + cid + " ex=" + ex);
			    }
			}
			break;

		    case RESERVE_PREPARED:
		    case MODIFY_PREPARED:
			Logger.warn(prog, "Internal Error:never here at update()");
			break;

		    case TERMINATING:
			if (ds == DataPlaneStatus.PASSED_END_TIME) {
			    try {
				rr.terminateDone();
			    } catch (ServiceException ex) {
				Logger.warn(prog, "Previous error is not real error.");
			    } 
			}
			break;

		    default:
			;
		}
	    }

	    Long terminateTime = rs.getTerminateTime();
	    if (terminateTime != null && terminateTime != 0 && 
		terminateTime + wait < current) {
		reservations.remove(cid);
	    }
	}
    }

    public String getTableSize()
    {
	String s = "\n\t" +prog + ": rr=" + reservations.size();
	s += "\n\t" + ResourceRequest.getTableSize();
	s += "\n\t" + manager.getTableSize();
	return s;
    }
}
