/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;
import java.util.Enumeration;

public class VlanManager extends LinkManager
{
    public static final String prog = "VlanManager";
    private static Hashtable<String, VlanManager> managers =
    new Hashtable<String, VlanManager>();
    private static Hashtable<String, Link> links =
	new Hashtable<String, Link>();

    private final String pname;
    private final Integer pvlan;
    private final int resource;

    public static VlanManager getVlanInstance (String name, Integer vlan) 
	throws ServiceException
    {
	String key = name + "-x-" + vlan;
	VlanManager manager = (VlanManager) managers.get(key);
	if (manager == null) {
	    manager = new VlanManager(name, vlan);
	    managers.put(key, manager);
	}
	return manager;
    }

    private VlanManager(String name, Integer vlan)
	throws ServiceException
    {
	super(name);
	this.pname = name;
	this.pvlan = vlan;
	resource = vlan.intValue();

	initTimeTable(resource);
    }
    
    public synchronized boolean reserve 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== V-Scheduler:reserve:" + 
		    TypesToString.resourceSpec(rspec));

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);

	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(false, resource, rspec);
	    if (! r) {
		if (t.hasSerial(rspec.getSerialId())) {
		    /* vlan is already reserved by original rspec in modify. */
		    rspec.setModified(true);
		} else 
		    Logger.error(prog, "This vlan has not enough resources. vlan=" +
				 pvlan);
	    }
	}
	
	if (! isReserve) return true;
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(true, resource, rspec);
	    if (! r) {
		if (t.hasSerial(rspec.getSerialId())) {
		    /* vlan is already reserved by original rspec in modify. */
		    if (! rspec.isModified())
			Logger.fatal(prog, "Internal error(rspec.modified)." +
				     " vlan=" + pvlan);
		} else 
		    Logger.error(prog, "This vlan can not be reserved. vlan=" +
				 pvlan);
	    }
	}

	Logger.debug(prog, "" + dumpTimeTable());
	return true;
    }

    public synchronized boolean release
	(boolean isRelease, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== V-Scheduler:release:" + 
		    TypesToString.resourceSpec(rspec));

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);

	for (int i = indexStart; i < indexEnd; i++) {
	    if (rspec.isModified()) continue;
	    TimeTable t = timeTables.get(i);

	    boolean r = t.release(false, resource, rspec);
	    if (! r) 
		Logger.error(prog, "This VLAN can not be released. vlan=" +
			     pvlan);
	}

	if (! isRelease) return true;

	boolean r = false;
	for (int i = indexStart; i < indexEnd; i++) {
	    if (rspec.isModified()) continue;
	    TimeTable t = timeTables.get(i);

	    r = t.release(true, resource, rspec);
	    if (! r) 
		Logger.error(prog, "This VLAN can not br released. vlan=" +
			     pvlan);
	}

	Logger.debug(prog, "" + dumpTimeTable());
	return true;
    }

    public synchronized static void garbage(Long time) 
    {
	Enumeration e = managers.elements();
	while (e.hasMoreElements()) {
	    VlanManager vm = (VlanManager) e.nextElement();
	    vm.garbageTimeTable(time);
	}
    }

    public synchronized void garbageTimeTable (Long time)
    {
	while (true) {
	    TimeTable t = timeTables.get(0);
	    Long startTime = t.getStartTime();
	    Long endTime = t.getEndTime();

	    if (endTime < time) {
		timeTables.remove(0);
		timeHash.remove(startTime);
		t.clear();
	    } else {
		return;
	    }
	}
    }

    public synchronized boolean setup ()
    {
	return false;
    }

    public synchronized boolean teardown ()
    {
	return false;
    }

    public static ArrayList<Integer> getVlan(String allowVlan)
	throws ServiceException
    {
	ArrayList<Integer> list = new ArrayList<Integer>();
	if (allowVlan == null) {
	    list.add(new Integer(0));
	    return list;
	}

	String[] s = allowVlan.split(", ");
	if (s.length == 0) {
	    list.add(new Integer(0));
	    return list;
	}

	for (int i = 0; i < s.length; i++) {
	    String[] ss = s[i].split("-");
	    switch (ss.length) {
		case 1:
		    try {
			int vlan = Integer.parseInt(ss[0]);
			list.add(new Integer(vlan));
		    } catch (Exception ex) {
			Logger.error(prog, "Internal Erroe(parse integer for vlan).");
		    }
		    break;

		case 2:
		    try {
			int vlan0 = Integer.parseInt(ss[0]);
			int vlan1 = Integer.parseInt(ss[1]);
			if (vlan0 > vlan1) {
			    int tmp = vlan0;
			    vlan0 = vlan1;
			    vlan1 = tmp;
			}
			for (int j = vlan0; j <= vlan1; j++) {
			    list.add(new Integer(j));
			}
		    } catch (Exception ex) {
			Logger.error(prog, "Internal Erroe(parse integer for vlan).");
		    }
		    break;
	    }
	}
	return list;
    }

    public synchronized static String httpDumpResource()
    {
	String s = "";
	Enumeration e = managers.elements();
	while (e.hasMoreElements()) {
	    VlanManager lm = (VlanManager) e.nextElement();

	    s += lm.httpTimeTable();
	}
	return s;
    }

    protected synchronized String httpTimeTable()
    {
	String s = "";
	for (TimeTable t: timeTables) {
	    String ss = t.toHtml();
	    if (ss != null && (! ss.equals("")))
		s += "<TR><TD>" + name + "-vlan-" + pvlan + "</TD>" + ss + "</TR>\n";
	}
	return s;
    }

    public synchronized static String getTableSizes() 
    {
	String s = prog + ": managers=" + managers.size() +
	    ", links=" + links.size();
	return s;
    }
}