/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.TopologyUnmarshaller;

import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoints;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.EndpointType;
import net.glambda.nrm.types.Equipments;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;
import net.glambda.nrm.types.InterfaceType;

import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;
import java.util.Enumeration;

public class Topology
{
    private static String prog = "Topology";
    private static Hashtable<String, Equipment> equipmentMgr =
	new Hashtable<String, Equipment>();
    private static Hashtable<String, Endpoint> endpointMgr =
	new Hashtable<String, Endpoint>();
    private static Hashtable<String, Endpoint> id2endpoint =
	new Hashtable<String, Endpoint>();
    private static Hashtable<String, Endpoint> stpMgr =
	new Hashtable<String, Endpoint>();
    private static Hashtable<String, Link> linkMgr =
	new Hashtable<String, Link>();

    private static Topology instance = null;
    private Equipments allequipments = null;
    private Endpoints allendpoints = null;
    private Links alllinks = null;

    public static Topology getInstance()
    {
	if (instance == null) instance = new Topology();
	return instance;
    }

    private Topology ()
    {
	readTopology();
	findPaths();
    }

    private void readTopology()
    {
	TopologyUnmarshaller unmarshaller = new TopologyUnmarshaller();

	allequipments = unmarshaller.getEquipments();
	allendpoints = unmarshaller.getEndpoints();
	alllinks = unmarshaller.getLinks();

	if (allequipments == null) 
	    Logger.fatal(prog, "Equipments is null.");
	for (Equipment o: allequipments.getEquipments()) {
	    String key = o.getName();
	    if (key == null) Logger.fatal(prog, "Equipment name is null.");

	    equipmentMgr.put(key, o);
	}
	
	if (allendpoints == null) 
	    Logger.fatal(prog, "Endpoints is null.");
	for (Endpoint o: allendpoints.getEndpoints()) {
	    String key = o.getName();
	    if (key == null) Logger.fatal(prog, "Endpoint name is null.");
	    endpointMgr.put(key, o);
	    String localId = o.getLocalId();
	    if (localId != null) id2endpoint.put(localId, o);
	    if (isSTP(o)) stpMgr.put(key, o);

	    String name = o.getEquipmentName();
	    if (name == null) continue;
	    Equipment eq = equipmentMgr.get(name);
	    if (eq == null) 
		Logger.fatal(prog, "Equipment name(" + name +
			     ") does not exist.");
	    o.setEquipment(eq);
	}

	if (alllinks == null) 
	    Logger.fatal(prog, "Links is null.");
	for (Link o: alllinks.getLinks()) {
	    String key = o.getName();
	    if (key == null) Logger.fatal(prog, "Link name is null.");

	    String name_a = o.getEndpointNameA();
	    Endpoint ep_a  = endpointMgr.get(name_a);
	    if (ep_a == null) 
		Logger.fatal(prog, "EndpointA name(" + name_a +
			     ") does not exist.");
	    o.setEndpointA(ep_a);

	    String name_z = o.getEndpointNameZ();
	    Endpoint ep_z  = endpointMgr.get(name_z);
	    if (ep_z == null) 
		Logger.fatal(prog, "EndpointZ name(" + name_z +
			     ") does not exist.");
	    o.setEndpointZ(ep_z);

	    int bandwidth = o.getBandwidth();
	    if (bandwidth == 0) {
		bandwidth = getBandwidth(ep_a, ep_z);
		o.setBandwidth(bandwidth);
	    }

	    key = getLinkKey(ep_a, ep_z);
	    linkMgr.put(key, o);
	    key = getLinkKey(ep_z, ep_a);
	    linkMgr.put(key, o);
	}

	Hashtable<String, Endpoint> done = new Hashtable<String, Endpoint>();
	for (Endpoint a: allendpoints.getEndpoints()) {
	    done.put(a.getName(), a);
	    for (Endpoint z: allendpoints.getEndpoints()) {
		if (done.get(z.getName()) != null) continue;
		if (a == z) continue;
		if (a.getEquipment() == null) continue;
		if (z.getEquipment() == null) continue;
		if (a.getEquipment() != z.getEquipment()) continue;

		Link newlink = null;
		String key1 = getLinkKey(a, z);
		newlink = linkMgr.get(key1);
		if (newlink != null) continue;
		String key2 = getLinkKey(z, a);
		newlink = linkMgr.get(key2);
		if (newlink != null) continue;
		
		newlink = new Link();
		newlink.setName(key1);
		newlink.setEndpointNameA(a.getName());
		newlink.setEndpointA(a);
		newlink.setEndpointNameZ(z.getName());
		newlink.setEndpointZ(z);
		newlink.setEquipmentName(a.getEquipmentName());

		alllinks.getLinks().add(newlink);
		linkMgr.put(key1, newlink);
		linkMgr.put(key2, newlink);
	    }
	}

	if (true) {
	    unmarshaller.printEquipments();
	    unmarshaller.printEndpoints();
	    unmarshaller.printLinks();
	}
    }

    private void findPaths()
    {
	Links oldlinks = new Links();
	Hashtable<String, Endpoint> done = new Hashtable<String, Endpoint>();

	for (String s: stpMgr.keySet()) {
	    Endpoint o = stpMgr.get(s);
	    findPathsBody(done, o, oldlinks);
	    done.put(o.getName(), o);
	}

	if (true) {
	    Logger.info(prog, " display paths" + Paths.dump());
	}
    }

    synchronized private void findPathsBody
	(Hashtable<String, Endpoint> done, Endpoint endpoint, Links oldlinks)
    {
	Link prevlink = null;;
	for (Link l: oldlinks.getLinks()) {
	    prevlink = l;
	}
	Links nextlinks = findLink(endpoint);
	
	for (Link nextlink: nextlinks.getLinks()) {
	    if (isDone(done, endpoint, nextlink)) continue;
	    if (isIncludeLink(oldlinks, nextlink)) continue;
	    if (false) {
		boolean f = isProperLinkType(endpoint, prevlink, nextlink);
		Logger.info(prog, endpoint.getName() + "/" + 
			    nextlink.getName() + "/" + f);
	    }
	    if (! isProperLinkType(endpoint, prevlink, nextlink)) continue;
	    
	    Links newlinks = cloneLinks(oldlinks);
	    newlinks.getLinks().add(nextlink);
	    
	    Endpoint peer = nextlink.getEndpointA();
	    if (peer == endpoint) peer = nextlink.getEndpointZ();
	    
	    if (isSTP(peer)) {
		Link link = oldlinks.getLinks().get(0);
		Endpoint start = link.getEndpointA();
		if (! isSTP(start)) start = link.getEndpointZ();
		if (! isSTP(start)) Logger.fatal(prog, "findPathsBody()");

		Paths paths = Paths.findPaths(start, peer);
		paths.getPaths().add(new Path(start, peer, newlinks));
		continue;
	    }
	    findPathsBody(done, peer, newlinks);
	}
    }    

    private Links findLink(Endpoint endpoint)
    {
	Links links = new Links();
	if (endpoint == null) return links;

	for (Link o: alllinks.getLinks()) {
	    if (endpoint == o.getEndpointA() || 
		endpoint == o.getEndpointZ()) {
		links.getLinks().add(o);
	    }
	}
	return links;
    }

    private boolean isDone
	(Hashtable<String, Endpoint> done, Endpoint endpoint,
	 Link nextlink) 
    {
	Endpoint a = nextlink.getEndpointA();
	if (a == endpoint) a = nextlink.getEndpointZ();
	if (done.get(a.getName()) != null) return true;
	return false;
    }

    private boolean isIncludeLink(Links links, Link o)
    {
	if (links == null) return false;
	for (Link t: links.getLinks()) {
	    if (t == o) return true;
	}
	return false;
    }

    private boolean isProperLinkType
	(Endpoint endpoint, Link prevlink, Link nextlink)
    {
	if (endpoint == null) return false;

	switch (endpoint.getEndpointType()) {
	    case STP:
		if (nextlink.getEquipmentName() == null) return true;
		return false;

	    case L_2_SW_CORE:
		if (nextlink.getEquipmentName() != null) return true;
		return false;
		
	    case L_2_SW_PORT:
	    case OXC_PORT:
		if (prevlink.getEquipmentName() == null) {
		    if (nextlink.getEquipmentName() != null) return true;
		    return false;
		} else {
		    if (nextlink.getEquipmentName() == null) return true;
		    return false;
		}
	}
	return false;
    }

    private Links cloneLinks(Links oldlinks)
    {
	Links newlinks = new Links();
	if (oldlinks == null) return newlinks;

	List<Link> newlink = newlinks.getLinks();
	for(Link oldlink: oldlinks.getLinks()) {
	    newlink.add(oldlink);
	}
	return newlinks;
    }

    private boolean isSTP(Endpoint endpoint)
    {
	if (endpoint == null) return false;

	switch(endpoint.getEndpointType()) {
	    case STP:
	    case L_2_SW_CORE:
		return true;
	}
	return false;
    }

    public static String getLinkKey(Endpoint a, Endpoint z)
    {
	String key = a.getName() + "-x-" + z.getName();
	return key;
    }

    private static int getBandwidth(Endpoint a, Endpoint z)
    {
	int bandwidth = 0;
	{
	    List<InterfaceType> iftypes = a.getIftype();
	    for (InterfaceType type: iftypes) {
		int newbw = interfaceType2Bandwidth(type);
		if (newbw > bandwidth) bandwidth = newbw;
	    }
	}
	{
	    List<InterfaceType> iftypes = z.getIftype();
	    for (InterfaceType type: iftypes) {
		int newbw = interfaceType2Bandwidth(type);
		if (newbw > bandwidth) bandwidth = newbw;
	    }
	}

	return bandwidth;
    }

    private static int interfaceType2Bandwidth(InterfaceType type)
    {
	switch (type) {
	    case T_10_BASE_T:
		return 10;
	    case T_100_BASE_T:
		return 100;
	    case T_1000_BASE_T: 
	    case T_1000_BASE_SX:
	    case T_1000_BASE_LX:
	    case T_1000_BASE_ZX:
		return 1000;
	    case T_10_GBASE_T:
	    case T_10_GBASE_SR:
	    case T_10_GBASE_LR:
	    case T_10_GBASE_ZR:
	    case T_10_GBASE_SW:
	    case T_10_GBASE_LW:
	    case T_10_GBASE_ZW:
		return 10000;
	    default:
		Logger.warn(prog, "This(" + type + ") type issUnknown.");
	}
	return 0;
    }

    public static Endpoint getEndpoint(String localId)
    {
	Endpoint endpoint = id2endpoint.get(localId);
	return endpoint;
    }

    public static Equipment getEquipment(String name)
    {
	Equipment equipment = equipmentMgr.get(name);
	return equipment;
    }

    public static Enumeration getAllLink()
    {
	Enumeration e = linkMgr.elements();
	return e;
    }

    public static void main(String[] argv)
    {
	// Topology topology = new Topology();
	Topology topology = Topology.getInstance();
    }
}
