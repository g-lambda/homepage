#!/usr/bin/expect -f
#
set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally
if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set cmdname "sw-vconfig"

set host	[lindex $argv 0]
set cmd		[lindex $argv 1]
set ifname1	[lindex $argv 2]
set ifname2	[lindex $argv 3]
set bw		[lindex $argv 4]
set vlan	[lindex $argv 5]
set timeout	10
set addr	"" 
set minvlan	1780
set maxvlan	1783

if {($argc != 1)} {
	puts "Brocade FXC624 reset shell.\r"
	puts "useage: swname\r"
	exit -1
}

if {($host == "SW3")} { 
#	set addr "203.253.235.10" 
	set addr "192.168.1.153" 
	set port "23" 
	set userid	""
	set passwd	"kistiapan13"
	set prompt "telnet@FCX624 Switch"
}

if {($addr == "")} {
	puts "The $host is unknown host.\r"
	exit -1
}

##############################################################################
# login
spawn telnet $addr $port
expect {
	"User Name:" {
		send -- "$userid\r"
		exp_continue
	} 
	"Password:" {
		send -- "$passwd\r"
		exp_continue
	}

	"$prompt>" {
		send -- "en\r"
		exp_continue
	}

	"$prompt#" { 
		#puts "OK LOGIN\r"
	}

	put "\r$cmdname: invalid $addr $userid $passwd"
	exit -1
}

##############################################################################
# config

send -- "config terminal\r"
expect "\\(config\\)#"
send -- "no spanning-tree\r"
expect "\\(config\\)#"

proc addvlan {} {
    global vlan ifname

    send -- "vlan $vlan\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "tagged ethernet $ifname\r"
    expect "\\(config-vlan-$vlan\\)#"
}

proc delvlan {} {
    global vlan

    send -- "vlan $vlan\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/1\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/2\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/3\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/4\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/5\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet 1/1/6\r"
    expect "\\(config-vlan-$vlan\\)#"
}

##############################################################################
# set vlan
set vlan	"11"
set ifname	"1/1/1"
addvlan

set vlan	"12"
set ifname	"1/1/2"
addvlan

set vlan	"13"
set ifname	"1/1/3"
addvlan

set vlan	"14"
set ifname	"1/1/4"
addvlan

set vlan	"15"
set ifname	"1/1/5"
addvlan

set vlan	"16"
set ifname	"1/1/6"
addvlan

set vlan	"1780"
set ifname	"1/1/7"
addvlan
set ifname	"1/1/8"
addvlan
delvlan

set vlan	"1781"
set ifname	"1/1/7"
addvlan
set ifname	"1/1/8"
addvlan
delvlan

set vlan	"1782"
set ifname	"1/1/7"
addvlan
set ifname	"1/1/8"
addvlan
delvlan

set vlan	"1783"
set ifname	"1/1/7"
addvlan
set ifname	"1/1/8"
addvlan
delvlan

##############################################################################
# close
send -- "exit\r"
expect {
    "\\(config\\)#" {
	send -- "exit\r"
	exp_continue
    }

    "$prompt#" { 
    }
}

send -- "show vlans\r"
expect {
    "Control-c" {
	send -- " "
	exp_continue
    }
    "$prompt#" { 
    }
}

send -- "exit\r"
expect "$prompt>"
send -- "exit\r"
expect "Connection closed by foreign host."
expect eof
exit 0

