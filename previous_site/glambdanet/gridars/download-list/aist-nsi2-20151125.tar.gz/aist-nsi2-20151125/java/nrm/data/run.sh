#! /bin/sh
#java -cp ../build/jar/nrm.jar net.glambda.nrm.util.TopologyMarshaller
#java -cp ./:../build/jar/nrm.jar net.glambda.nrm.util.TopologyUnmarshaller
#java -cp ./:../build/jar/nrm.jar:../libs/commons-logging-1.1.1.jar net.glambda.nrm.util.TopologyUnmarshaller
java -cp ./:../build/jar/nrm.jar:../libs/commons-logging-1.1.1.jar net.glambda.nrm.scheduler.Topology
