#!/usr/bin/expect -f
#
set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally
if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set cmdname "sw-vconfig"

set host	[lindex $argv 0]
set cmd		[lindex $argv 1]
set ifname1	[lindex $argv 2]
set ifname2	[lindex $argv 3]
set bw		[lindex $argv 4]
set vlan	[lindex $argv 5]
set timeout	10
set addr	"" 
#set minvlan	1780
#set maxvlan	1783
set minvlan	1779
set maxvlan	1784

if {($argc != 6) || (($cmd != "teardown") && ($cmd != "setup"))} {
	puts "Brocade FCX624 $argv\r"
	puts "useage: swname setup|teardown ifname ifname bw vlan\r"
	puts "\tswname:\tip address of Brocade FCX624 L2 switch\r"
	puts "\tsetupl:\tadd tagged vlan\r"
	puts "\tteardown:\tdelete tagged valn\r"
	puts "\tifname:\tinterface number, example P1,P2,,,P6,null\r"
	puts "\tbw:\tallowed bandwidth(Mbps), not supported now\r"
	puts "\tvlan:\tvlan id number\r"
	exit -1
}

if {($host == "SW1")} { 
	set addr "203.253.235.10" 
#	set addr "192.168.1.151" 
	set port "23" 
	set userid	""
	set passwd	"kistiapan13"
	set prompt "telnet@FCX624 Switch"
}

if {($addr == "")} {
	puts "The $host is unknown host.\r"
	exit -1
}

if {($ifname1 == "P1")} {
	set ifname1 "1/1/1"
} elseif {($ifname1 == "P2")} {
	set ifname1 "1/1/2"
} elseif {($ifname1 == "P3")} { 
	set ifname1 "1/1/3" 
} elseif {($ifname1 == "P4")} { 
	set ifname1 "1/1/4" 
} elseif {($ifname1 == "P5")} { 
	set ifname1 "1/1/5"
} elseif {($ifname1 == "P6")} { 
	set ifname1 "1/1/6" 
} elseif {($ifname1 == "null")} { 
} else {
	puts "The ifname1($ifname1) is not correct name(P1-P6,null)."
	exit -1
} 

if {($ifname2 == "P1")} { 
	set ifname2 "1/1/1" 
} elseif {($ifname2 == "P2")} { 
	set ifname2 "1/1/2" 
} elseif {($ifname2 == "P3")} { 
	set ifname2 "1/1/3" 
} elseif {($ifname2 == "P4")} { 
	set ifname2 "1/1/4" 
} elseif {($ifname2 == "P5")} { 
	set ifname2 "1/1/5"
} elseif {($ifname2 == "P6")} { 
	set ifname2 "1/1/6" 
} elseif {($ifname2 == "null")} { 
} else {
	puts "The ifname2($ifname2)is not correct name(P1-P6,null)."
	exit -1
} 

if { ($vlan < $minvlan) || ($vlan > $maxvlan) } {
   puts "The vlan ID $vlan is out of range($minvlan - $maxvlan).\r"
   exit -1
}
	
#exit
##############################################################################
# login
spawn telnet $addr $port
spawn telnet $addr $port
expect {
	"User Name:" {
		send -- "$userid\r"
		exp_continue
	} 
	"Password:" {
		send -- "$passwd\r"
		exp_continue
	}

	"$prompt>" {
		send -- "en\r"
		exp_continue
	}

	"$prompt#" { 
		#puts "OK LOGIN\r"
	}

	put "\r$cmdname: invalid $addr $userid $passwd"
	exit -1
}

##############################################################################
# config

send -- "config terminal\r"
expect "\\(config\\)#"

proc addvlan {} {
    global vlan ifname

    send -- "vlan $vlan\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "tagged ethernet $ifname\r"
    expect "\\(config-vlan-$vlan\\)#"
}

proc delvlan {} {
    global vlan ifname

    send -- "vlan $vlan\r"
    expect "\\(config-vlan-$vlan\\)#"
    send -- "no tagged ethernet $ifname\r"
    expect "\\(config-vlan-$vlan\\)#"
}

##############################################################################
# set vlan

set ifname $ifname1
if {$ifname1 != "null" && $ifname1 != "nop"} {
	if {$cmd == "setup"} {
		addvlan
	} else {
		delvlan
	}
}

set ifname $ifname2
if {$ifname2 != "null" && $ifname2 != "nop"} {
	if {$cmd == "setup"} {
		addvlan
	} else {
		delvlan
	}
}

##############################################################################
# close

send -- "exit\r"
expect {
    "\\(config\\)#" {
	send -- "exit\r"
	exp_continue
    }

    "$prompt#" { 
    }
}

send -- "show vlan $vlan\r"
expect "$prompt#"
send -- "exit\r"
expect "$prompt>"
send -- "exit\r"
expect eof
exit 0
