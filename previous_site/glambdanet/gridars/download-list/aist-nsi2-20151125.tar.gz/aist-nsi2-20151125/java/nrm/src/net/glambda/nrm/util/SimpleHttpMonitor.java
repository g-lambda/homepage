/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.nsi2.Nrm;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.scheduler.PathScheduler;
import net.glambda.nrm.scheduler.LinkManager;

import java.net.Socket;
import java.net.ServerSocket;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.IOException;

public class SimpleHttpMonitor extends Thread
{
    public static final String prog = "SimpleHttpMonitor";

    private final int refresh = Parameter.getHttpRefresh();
    private final int port = Parameter.getHttpPort();
    private String networkId = Parameter.getNetworkId();

    private ServerSocket server = null;
    private Socket socket = null;

    private Nrm nrm = null;

    private String head1 = null;
    private String head2 = null;
    private String logo1 = null;
    private String logo2 = null;
    private String tail = null;

    protected String delPattern1;
    protected String delPattern2;

    public SimpleHttpMonitor(Nrm nrm)
    {
	super();
	this.nrm = nrm;

	try {
	    server = new ServerSocket(port);
	} catch (IOException ex) {
	    Logger.fatal(prog, "", ex);
	    // Logger.warn(prog, "" + ex);
	}
    }

    public SimpleHttpMonitor(Socket socket, Nrm nrm)
    {
	super();
	
	if (socket == null) return;
	this.socket = socket;
	this.nrm = nrm;

	this.start();
    }

    public void run() 
    {
	delPattern1 = Parameter.getDelete1();
	delPattern2 = Parameter.getDelete2();
	
	head1  = "HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8;\n\n";
	head1 += "<!doctype html><html><head>\n<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">\n<title>G-lambda AIST NSI2-NRM Monitor</title>\n";
	head1 += "<script type=\"text/javascript\" language=\"javascript\">\n";
	head1 += "<!--\nsetTimeout(\"location.reload()\",";
	head2 = ");\n-->\n</script></head><body>\n";
	logo1 = "<table width=\"96%\" align=center><TR><TD><img alt=\"G-lambda logo\" src=\"http://www.g-lambda.net/wordpress/wp-content/uploads/2006/10/the_g-lambda_logo_s.jpg\" height=70></TD><TD><H3>AIST NSI2-NRM Status Monitor (" + networkId + ")</H3></TD></TABLE>\n";
	logo2 = "<table width=\"96%\" align=center><TR><TD><img alt=\"G-lambda logo\" src=\"http://www.g-lambda.net/wordpress/wp-content/uploads/2006/10/the_g-lambda_logo_s.jpg\" height=70></TD><TD><H3>AIST NSI2-NRM Resource Monitor (" + networkId + ")</H3></TD></TABLE>\n";

	tail = "</body></html>\n";

	if (server != null && socket == null) {
	    try {
		while (true) {
		    Socket s = server.accept();
		    // System.err.println("**** accept(), socket=" + s);
		    SimpleHttpMonitor m = new SimpleHttpMonitor(s, nrm);
		}
	    } catch (Exception ex) {
		Logger.fatal(prog, "", ex);
	    }
	} else if (server == null && socket != null) {
	    service();
	} else {
	    Logger.fatal(prog, "Internal Error: never here");
	}
    }
    
    private void service() 
    {
	try {
	    InputStream is = socket.getInputStream();
	    InputStreamReader ir = new InputStreamReader(is);
	    BufferedReader in = new BufferedReader(ir);
	    
	    OutputStream os = socket.getOutputStream();
	    PrintWriter out = new PrintWriter(os, true);

	    String line = null;
	    while ((line = in.readLine()) != null) {
		// Logger.debug(prog, "Monitor:input="+ line;

		if (line.startsWith("GET /getStatus")) {
		    outStatus(out);
		    break;
		} else if (line.startsWith("GET /getResource")) {
		    outResource(out);
		    break;
		} else if (line.startsWith("GET /cancel?id=")) {
		    String cid = line.replace("GET /cancel?id=", "");
		    int index = cid.indexOf(" ");
		    if (index == -1) continue;

		    cid = cid.substring(0, index);
		    // Logger.debug(prog, "Monitor:cancel="+ cid);
		    if (cid != null) {
			doCancel(cid, out);
		    }
		    break;
		} else if (line == "") return;
	    }
	} catch (Exception ex) {
	    ex.printStackTrace();
	    Logger.warn(prog, "Exception in http service. ex=" + ex);
	} finally {
	    try {
		socket.close();
	    } catch (IOException ex) {}
	}
    }

    private void outStatus(PrintWriter out)
	throws Exception
    {
	out.println(head1 + (refresh * 1000) + head2);
	out.println(logo1);

	String s1 = nrm.httpDumpReservation();
	String s2 = s1.replaceAll(delPattern1, "");
	String s3 = s2.replaceAll(delPattern2, "");

	out.println(s3);
	out.println(tail);
    }

    private void outResource(PrintWriter out)
	throws Exception
    {
	out.println(head1 + (refresh * 1000) + head2);
	out.println(logo2);

	String s1 = LinkManager.httpDumpResource();

	out.println(s1);
	out.println(tail);
    }

    private void doCancel(String cid, PrintWriter out)
    {
	String s = "HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8;\n\n";
	s += "<!doctype html><html><head>\n<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">\n<title>G-lambda AIST NSI2-NRM Monitor</title>\n</head>";
	try {
	    nrm.terminate(null, cid);
	    s +="<BODY>Terminate reservation is Done." +
		" ConnectionId=" + cid +
		"</BODY></html>";
	    out.println(s);
	} catch (Exception ex) {
	    Logger.info(prog, "Exception in terminate operation. ex=" + ex);
	}
    }
}