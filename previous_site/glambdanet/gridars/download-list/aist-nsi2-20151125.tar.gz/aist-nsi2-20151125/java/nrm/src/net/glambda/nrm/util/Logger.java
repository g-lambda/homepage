/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.rms.types.ServiceException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Logger {
    public static final Log logger =  LogFactory.getLog(Logger.class);
    public static String h = "**** ";
    public static String h2 = 
	"###################################################################";
    public static boolean useLogger = true;
    
    private Logger () {}

    static {
	useLogger = Parameter.isUseLogger();
    }

    public static void fatal (String p, String m)
    {
	fatal(p, m, null);
    }

    public static void fatal (String p, String m, Exception ex)
    {
	String s = (p + ": " + m);
	if (ex != null) {
	    s += " ex=" + ex;
	    ex.printStackTrace();
	}

	if (useLogger) logger.fatal(h + s);
	else System.err.println(h + s);

	System.exit(-1);
    }

    public static void error(String p, String m)
	throws ServiceException
    {
	error(p, m, null);
    }

    public static void error(String p, String m, Exception ex)
	throws ServiceException
    {
	String s = (p + ": " + m);
	if (ex != null) {
	    s += " ex=" + ex;
	    ex.printStackTrace();
	}

	if (useLogger) logger.error(h + s);
	else System.err.println(h + s);

	throw new ServiceException(s);
    }

    public static void warn(String p, String m)
    {
	String s = (p + ": " + m);
	if (useLogger) logger.warn(h + s);
	else System.err.println(h + s);
    }

    public static void info(String p, String m)
    {
	String s = (p + ": " + m);
	if (useLogger) logger.info(h + s);
	else System.err.println(h + s);
    }

    public static void einfo(String p, String m)
    {
	String s = (p + ": " + m);
	if (useLogger) logger.info("\n" + h2 + "\n" + s + "\n" +h2);
	else System.err.println("\n" + h2 + "\n" + s + "\n" +h2);
    }

    public static void debug(String p, String m)
    {
	String s = (p + ": " + m);
	if (useLogger) logger.debug(h + s);
	else System.err.println(h + s);
    }
}
