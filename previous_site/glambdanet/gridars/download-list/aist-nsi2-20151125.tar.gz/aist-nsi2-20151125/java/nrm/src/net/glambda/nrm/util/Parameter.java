/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.util.Logger;

import java.util.Properties;
import java.util.TimeZone;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;

public class Parameter {
    private static String prog = "Parameter";
    private static final String path = "nrmConfig";
    private static String dir;
    private static String file = "nrm.config";
    private static String config;

    private static String timezone;
    private static String networkId;
    private static String delete1;
    private static String delete2;

    private static int httpPort;
    private static int httpRefresh;

    private static int servicePortSSL;
    private static int servicePort;
    private static String serviceURL;
    private static String serviceHost;

    private static int timeKeeperInterval;	/* msec */
    private static int timeKeeperDeleteWait;	/* msec */
    private static long finalTime = 10L * 365 * 24 * 3600 * 1000;

    private static long guardTimePre;
    private static long guardTimePost;
    private static long heldTimeout;

    private static String keystoreFile;
    private static String keystorePassphrase;
    private static boolean useLogger = true;

    private static int dumpInterval = 1;
    private static Boolean dumpReduce = new Boolean(false);

    static
    {
	File currentDirectory = new File(".");
	Logger.info(prog, "Current Directory =" + currentDirectory.getAbsolutePath());

	dir = "";
	config = dir + file;

	Properties p = new Properties();

        try {
	    File f = new File(config);
	    if (! f.exists()) {
		dir = path + "/";
		config = dir + file;
		f = new File(config);
	    }

            InputStream is = new FileInputStream(f);
            p.load(is);
        } catch (Exception ex) {
            Logger.fatal(prog, "The config is missing. file=" + config, ex);
        }

	try {
	    networkId = p.getProperty("nrm.networId");
	    delete1 = p.getProperty("nrm.delete.1");
	    delete2 = p.getProperty("nrm.delete.2");
	    
	    httpPort = Integer.parseInt
		(p.getProperty("nrm.http.port"));
	    httpRefresh = Integer.parseInt
		(p.getProperty("nrm.http.refresh"));

	    servicePort = Integer.parseInt
		(p.getProperty("nrm.service.port"));
	    servicePortSSL = Integer.parseInt
		(p.getProperty("nrm.service.portssl"));
	    serviceURL = p.getProperty("nrm.service.url");
	    serviceHost = p.getProperty("nrm.service.host");
	    
	    timeKeeperInterval = 1000 * Integer.parseInt
		(p.getProperty("nrm.timekeeper.interval"));
	    timeKeeperDeleteWait = 1000 * Integer.parseInt
		(p.getProperty("nrm.timekeeper.deletewait"));

	    guardTimePre = 1000 * Integer.parseInt
		(p.getProperty("nrm.guardtime.pre"));
	    guardTimePost = 1000 * Integer.parseInt
		(p.getProperty("nrm.guardtime.post"));

	    heldTimeout = 1000 * Long.parseLong
		(p.getProperty("nrm.held.timeout"));

	    timezone = p.getProperty("nrm.timezone");
	    TimeZone.setDefault(TimeZone.getTimeZone(timezone));

	    keystoreFile = p.getProperty("nrm.keystore.file");
	    keystorePassphrase = p.getProperty("nrm.keystore.passphrase");

	    useLogger = Boolean.valueOf(p.getProperty("nrm.use.logger"));

	    if (false) dumpInterval = Integer.parseInt
			   (p.getProperty("nrm.dump.interval"));

	    try {
		dumpReduce = new Boolean
		    (p.getProperty("nrm.dump.reduce"));
	    } catch (Exception e) {
		Logger.warn(prog, "There is no \'nrm.dump.reduce\' parameger. ex=" + e);
	    }

	} catch (Exception ex) {
            Logger.fatal(prog, "There is a bad parameger. ex=", ex);
	}
    }	

    public static String getNetworkId()
    {
	return networkId;
    }

    public static String getDelete2()
    {
	return delete2;
    }

    public static String getDelete1()
    {
	return delete1;
    }

    public static int getHttpPort()
    {
	return httpPort;
    }

    public static int getHttpRefresh()
    {
	return httpRefresh;
    }

    public static int getServicePort()
    {
	return servicePort;
    }

    public static int getServicePortSSL()
    {
	return servicePortSSL;
    }

    public static String getServiceURL()
    {
	return serviceURL;
    }
    
    public static String getServiceHost()
    {
	return serviceHost;
    }
    
    public static int getTimeKeeperInterval()
    {
	return timeKeeperInterval;
    }

    public static int getTimeKeeperDeleteWait()
    {
	return timeKeeperDeleteWait;
    }

    public static long getFinalTime()
    {
	return finalTime;
    }

    public static long getGuardTimePre()
    {
	return guardTimePre;
    }

    public static long getGuardTimePost()
    {
	return guardTimePost;
    }

    public static long getHeldTimeout()
    {
	return heldTimeout;
    }

    public static String getKeystoreFile()
    {
	return keystoreFile;
    }

    public static String getKeystorePassphrase()
    {
	return keystorePassphrase;
    }

    public static String getConfigPath()
    {
	return dir;
    }

    public static boolean isUseLogger()
    {
	return useLogger;
    }

    public static int getDumpInterval()
    {
	return dumpInterval;
    }
    
    public static Boolean isDumpReduce()
    {
	return dumpReduce;
    }
    

}
