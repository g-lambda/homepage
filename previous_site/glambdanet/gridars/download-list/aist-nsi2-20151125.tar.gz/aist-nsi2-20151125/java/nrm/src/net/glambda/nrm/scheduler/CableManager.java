/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Enumeration;

public class CableManager extends LinkManager
{
    private static final String prog = "CableManager";
    private static Hashtable<String, CableManager> cableManagers =
	new Hashtable<String, CableManager>();

    private final Link link;
    private final String pname;
    private final int bandwidth;
    
    public static CableManager getCableInstance (Link link) 
	throws ServiceException
    {
	String name = link.getName();

	CableManager manager = cableManagers.get(name);
	if (manager == null) {
	    manager = new CableManager(link);
	    cableManagers.put(name, manager);
	}
	return manager;
    }

    private CableManager(Link link)
	throws ServiceException
    {
	super(link.getName());
	this.link = link;
	this.pname = link.getName();
	this.bandwidth = link.getBandwidth();

	initTimeTable(this.bandwidth);
    }

    public synchronized boolean reserve 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== C-Scheduler:reserve:" +
		    TypesToString.resourceSpec(rspec));

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(false, rspec.getBandwidth(), rspec);
	    if (! r) 
		Logger.error(prog, "There are not enough resources." +
			     " cable=" + pname +
			     " resource=A" + t.getAllocatedResource() + 
			     "/R" + t.getResource() + 
			     ", request =" + rspec.getBandwidth());
	}
	
	if (! isReserve) return true;
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(true, rspec.getBandwidth(), rspec);
	    if (! r) 
		Logger.error(prog, "Internal error: resource allocation failed.");
	}

	Logger.debug(prog, "" + dumpTimeTable());
	return true;
    }

    public synchronized boolean release
	(boolean isRelease, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== C-Scheduler:release:" + 
		    TypesToString.resourceSpec(rspec));

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);
	
	// Logger.info(prog, "release from " + indexStart + " to " + indexEnd);
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.release(false, rspec.getBandwidth(), rspec);
	    if (! r) 
		Logger.error(prog, "Internal Error: resource relese error." +
			     " cable=" + pname +
			     " resource=A" + t.getAllocatedResource() + 
			     "/R" + t.getResource() + 
			     ", request =" + rspec.getBandwidth());
	}
	
	if (! isRelease) return true;
	
	boolean r = false;
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    r = t.release(true, rspec.getBandwidth(), rspec);
	    if (! r) 
		Logger.error(prog, "Internal error: resource release failed.");
	    
	}
    
	Logger.debug(prog, "" + dumpTimeTable());
	return true;
    }

    public synchronized static void garbage(Long time) 
    {
	Enumeration e = cableManagers.elements();
	while (e.hasMoreElements()) {
	    CableManager cm = (CableManager) e.nextElement();
	    cm.garbageTimeTable(time);
	}
    }

    public synchronized void garbageTimeTable (Long time)
    {
	while (true) {
	    TimeTable t = timeTables.get(0);
	    Long startTime = t.getStartTime();
	    Long endTime = t.getEndTime();

	    if (endTime < time) {
		timeTables.remove(0);
		timeHash.remove(startTime);
		 // Logger.info(prog, "Hash.remove key=" + startTime + ", " + TypesToString.time(startTime));
		t.clear();
	    } else {
		return;
	    }
	}
    }

    public boolean setup ()
    {
	return true;
    }

    public boolean teardown ()
    {
	return true;
    }

    public static String getTableSizes()
    {
	String s = prog + ": cables=" + cableManagers.size();
	return s;
    }
}