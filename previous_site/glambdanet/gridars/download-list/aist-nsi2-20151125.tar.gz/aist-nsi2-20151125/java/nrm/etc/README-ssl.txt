1) create Self-signed certificate
$ keytool -genkey -alias aist -keypass changeit -validity 3650 -storetype JKS -keystore aist.keystore -storepass changeit

*** "What is your first and last name?", Enter CA name(your hostname)

2) get the self-cert file
$ keytool -exportcert -alias aist -file aist.ca

3) import the self-cert file
$ keytool -importcert -file aist.ca -alias aist -keystore /home/okazaki/opt/java/jre/lib/security/cacerts 

