/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.Endpoints;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.EndpointType;
import net.glambda.nrm.types.Equipments;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;
import net.glambda.nrm.types.InterfaceType;

import java.io.File;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;

public class TopologyUnmarshaller
{
    static public final String prog = "TopologyUnmarshaller";
    public Equipments equipments = null;
    public Endpoints endpoints = null;
    public Links links = null;
    static public final String path;

    static {
	path = Parameter.getConfigPath();
    }
    
    public TopologyUnmarshaller()
    {
	input();
    }

    public void input()
    {
        try {
	    String jarPath = System.getProperty("java.class.path");
	    String dirPath = jarPath.substring
		(0, jarPath.lastIndexOf(File.separator)+1);
	    // System.err.println("jar path=" + jarPath);

	    JAXBContext context =
		JAXBContext.newInstance("net.glambda.nrm.types");

            Unmarshaller unmarshaller = context.createUnmarshaller();

	    {
		File file = new File("equipments.xml");
		if (! file.exists()) file = new File(path + "equipments.xml");
		Object obj = unmarshaller.unmarshal(file);
		equipments = (Equipments)obj;
		printEquipments();
	    }
	    {
		File file = new File("endpoints.xml");
		if (! file.exists()) file = new File(path + "endpoints.xml");
		Object obj = unmarshaller.unmarshal(file);
		endpoints = (Endpoints)obj;
		printEndpoints();
	    }
	    {
		File file = new File("links.xml");
		if (! file.exists()) file = new File(path + "links.xml");
		Object obj = unmarshaller.unmarshal(file);
		links = (Links)obj;
		printLinks();
	    }

	} catch (JAXBException ex) {
	    Logger.fatal(prog, "input()", ex);
	}
    }

    public Equipments getEquipments()
    {
	return equipments;
    }

    public Endpoints getEndpoints()
    {
	return endpoints;
    }

    public Links getLinks()
    {
	return links;
    }

    public void printEquipments()
    {
	Logger.info(prog, TypesToString.equipments(equipments));
    }

    public void printEndpoints()
    {
	Logger.info(prog, TypesToString.endpoints(endpoints));
    }

    public void printLinks()
    {
	Logger.info(prog, TypesToString.links(links));
    }

    public static void main(String[] args) 
    {
        new TopologyUnmarshaller();
    }
}
