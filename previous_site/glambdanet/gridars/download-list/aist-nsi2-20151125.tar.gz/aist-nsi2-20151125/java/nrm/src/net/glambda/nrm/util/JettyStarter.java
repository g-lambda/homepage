/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.util;

import net.glambda.nrm.nsi2.Nrm;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.Logger;

import net.glambda.nsi2.impl.ResourceManagerBase;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;

import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsExchange;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;

import java.io.FileInputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.security.SecureRandom;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.xml.ws.Endpoint;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBusFactory;

public class JettyStarter extends ResourceManagerBase 
{
    public static final String prog = "JettyStarter";
    private static final String url = 
	"http://" + Parameter.getServiceHost() + 
	":" + Parameter.getServicePort() + 
	"/" + Parameter.getServiceURL();
    private static final String urlssl = 
	"https://" + Parameter.getServiceHost() + 
	":" + Parameter.getServicePortSSL() + 
	"/" + Parameter.getServiceURL();

    public JettyStarter() {
        super(new Nrm());
    }

    private static void publish() 
	throws Exception 
    {
	Logger.info(prog, "HTTPServer publush");
	ConnectionProviderPort impl = 
	    (ConnectionProviderPort) new JettyStarter();

	if (false) {
	    SpringBusFactory bf = new SpringBusFactory();
	    URL busFile = Starter.class.getResource("Starter.xml");
	    Bus bus = bf.createBus(busFile.toString());
	    bf.setDefaultBus(bus);
	}

	{
	    int port = Parameter.getServicePortSSL();
	    if (port > 0) {
		Logger.info(prog, "HTTPS Server url=" + urlssl);
		Endpoint.publish(urlssl, impl);
	    }
	}

	{
	    int port = Parameter.getServicePort();
	    if (port > 0) {
		Logger.info(prog, "HTTPServer url=" + url);
		Endpoint.publish(url, impl);
	    }
	}
    }

    public static void main (String[] args)
    {
	String dir = "";

	if (false && args != null && args.length > 0) {
	    dir = args[0];
	    String cur = System.getProperty("user.dir");
	    System.setProperty("user.dir", cur + "/" + dir);
	    cur = System.getProperty("user.dir");
	}

	try {
	    publish();

	    while (true) {
		Thread.sleep(24 * 3600 * 1000);
	    }
	} catch (Exception ex) {
	    Logger.fatal(prog, "Service stop. ex=", ex);
	}
    }
}