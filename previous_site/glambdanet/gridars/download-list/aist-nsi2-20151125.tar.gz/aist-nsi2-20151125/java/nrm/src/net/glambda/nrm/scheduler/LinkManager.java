/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Enumeration;

public abstract class LinkManager
{
    public static final String prog = "LinkManager";

    protected LinkedList<TimeTable> timeTables = 
	new LinkedList<TimeTable> ();
    protected Hashtable<Long, TimeTable> timeHash = 
	new Hashtable<Long, TimeTable> ();

    public static Hashtable<String, LinkManager> managerss = 
	new Hashtable<String, LinkManager> ();

    protected final String name;

    public static LinkManager getInstance (Link link)
       throws ServiceException 
    {
	String equipmentName = link.getEquipmentName();
	String name = link.getName();

	LinkManager lm = null;
	// LinkManager lm = managerss.get(name);
	// if (lm != null) return lm;

	if (equipmentName == null) {
	    lm = CableManager.getCableInstance(link);
	    managerss.put(name, lm);
	    return lm;
	}

	Equipment equipment = Topology.getEquipment(equipmentName);
	if (equipment == null) 
	    Logger.error(prog, "This " +  equipment + 
			 " dose not exist in equipments.");
	    
	EquipmentType equipmentType = equipment.getEquipmentType();
	switch (equipmentType) {
	    case L_2_SW:
		lm = L2swManager.getL2swInstance(link);
		managerss.put(name, lm);
		return lm;
		
	    case OXC:
		lm = OxcManager.getOxcInstance(link);
		managerss.put(name, lm);
		return lm;

	    default:
		Logger.error(prog, "" + equipmentType + 
			     " is not known EquipmentType.");
	}

	Logger.error(prog, "LingManager can not be fouund. name=" + 
		     name + ", ename=" + equipmentName);
	return null;
    }

    protected LinkManager (String name)
    {
	this.name = name;
    }

    public abstract boolean reserve 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException;

    public abstract boolean release 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException;

    public abstract boolean setup ();

    public abstract boolean teardown ();

    protected String dumpTimeTable()
    {
	String s = "LinkManager TimeTable dump: link=" + name + "\n";
	for (TimeTable t: timeTables) {
	    s += "\t" + t.toString() + "\n";
	}
	return s;
    }

    protected synchronized String httpTimeTable()
    {
	String s = "";
	for (TimeTable t: timeTables) {
	    String ss = t.toHtml();
	    if (ss != null && (! ss.equals("")))
		s += "<TR><TD>" + name + "</TD>" + ss + "</TR>\n";
	}
	return s;
    }

    public static String httpDumpResource()
    {
	String s = "<table width=\"96%\" align=\"center\" border=\"1\" cellpadding=\"5\"><caption><div align=\"right\">";
	s += TypesToString.time(Time.getCurrentTime());
	s += "</div></caption>";
        s += "<tr bgcolor=\"#C0C0C0\"><th>name</th><th>alloc</th><th>resource</th><th>Start Time</th><th>End Time</th><th>Reservations</th></tr>\n";
	
	Enumeration e = managerss.elements();
	while (e.hasMoreElements()) {
	    LinkManager lm = (LinkManager) e.nextElement();

	    s += lm.httpTimeTable();
	}

	s += VlanManager.httpDumpResource();
	s += PortManager.httpDumpResource();
	s += "</table>\n";
	return s;
    }

    protected synchronized void initTimeTable (long resource) 
	throws ServiceException
    {
	Long current = Time.getCurrentTime();
	Long future  = current + Parameter.getFinalTime();
	TimeTable t = new TimeTable(current, future, resource);
	timeTables.add(t);
	timeHash.put(current, t);
	timeHash.put(future, t);
    }

    /*
    protected synchronized void garbageTimeTable (Long time) 
    {
	while (true) {
	    TimeTable t = timeTables.get(0);
	    Long endTime = t.getEndTime();

	    if (endTime < time) {
		timeTables.remove(0);
		timeHash.remove(t.getStartTime());
		t.clear();
	    } else {
		return;
	    }
	}
    }
    */

    protected synchronized int dispartTimeTable (Long time, int index) 
	throws ServiceException
    {
	if (false) Logger.debug(prog, "dispartTimeTable key=" + time + "," + 
				TypesToString.time(time));
	TimeTable t = timeHash.get(time);

	if (t != null) { 
	    /* already disparted */

	    int i = timeTables.indexOf(t); 
	    // Logger.info(prog, "found timeTable. index=" + i);
	    if (i != -1) 
		return i;
	    else 
		Logger.error(prog, "Internal error in dispartTimeTable.");
	}

	if (index < 0) 
	    Logger.error(prog, "index < 0 in dispartTimeTable.");
	if (index >= timeTables.size())
	    Logger.error(prog, "index >= size in dispartTimeTable.");

	for (int i = index; i < timeTables.size(); i++) {
	    t = timeTables.get(i);
	    Long startTime = t.getStartTime();
	    Long endTime = t.getEndTime();
	    
	    if (startTime >= time) return i;

	    if (startTime < time && endTime > time) {
		TimeTable newone = t.copy();
		newone.setEndTime(time);
		t.setStartTime(time);
		timeTables.add(i, newone);
		timeHash.put(startTime, newone);
		timeHash.put(time, t);
		return i+1;
	    }
	}
	
	Logger.info(prog, "add TimeTable at tail.");
	int pos = timeTables.size() -1;
	t = timeTables.get(pos);
	{
	    Long startTime = t.getStartTime();
	    Long endTime = t.getEndTime();

	    TimeTable newone = t.copy();
	    newone.setEndTime(time);
	    t.setStartTime(time);
	    timeTables.add(pos, newone);
	    timeHash.put(startTime, newone);
	    timeHash.put(time, t);
	}
	return pos +1;
    }

    public String getTableSize()
    {
	String s = prog + ": name=" + name + 
	    ", table=" + timeTables.size() +
	    ", hash=" + timeHash.size();
	return s;
    }
}