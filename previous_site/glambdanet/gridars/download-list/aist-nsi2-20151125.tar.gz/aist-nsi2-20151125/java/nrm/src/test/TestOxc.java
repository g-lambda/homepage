/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package test;

import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.scheduler.ResourceManager;
import net.glambda.nrm.scheduler.Topology;
import net.glambda.nrm.nsi2.Nrm;

import net.glambda.rms.Notifier;
import net.glambda.rms.NSI2ResourceManagerBase;

import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.StpType;
import net.glambda.rms.types.DirectionalityType;
import net.glambda.rms.types.TypeValuePairListType;
import net.glambda.rms.types.TypeValuePairType;

import java.util.Calendar;
import java.util.List;

public class TestOxc 
{
    public static int serial = 1;
    public static String networkId = Parameter.getNetworkId();

    public Topology topology = null;
    public Nrm nrm = null;

    public static String namebase = "urn:ogf:network:";
    public static String site = "aruba";
    public static String nameend = ".example:2013:port";
	
    public String nameA = namebase + site + nameend + "1";
    public String nameZ = namebase + site + nameend + "4";
    public String name1 = namebase + site + nameend + "1";
    public String name2 = namebase + site + nameend + "2";
    public String name3 = namebase + site + nameend + "3";
    public String name4 = namebase + site + nameend + "4";
    public String name5 = namebase + site + nameend + "5";
    public String name6 = namebase + site + nameend + "6";
    public String name7 = namebase + site + nameend + "7";
    public String name8 = namebase + site + nameend + "8";

    public long bandwidth = 200;
    public int stime = 10;
    public int dtime = 10;
    
    public TestOxc() 
    {
	topology = Topology.getInstance();
	nrm = new Nrm();
	nrm.setNotifier(new test.Notifier());
    }

    public static synchronized String getConnectionId()
    {
	if (false && serial == 0) {
	    Exception ex = new Exception("stop");
	    ex.printStackTrace();
	}

	String s = "CID-" + serial;
	serial ++;
	return s;
    }

    public void reserveCommit_A(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),commit(),terminate(),EndTime");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommit_B(int vlan)
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= reserve(),provision(),StartTime,commit(),EndTime,terminate()");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, stime, dtime, bandwidth, nameA, nameZ, vlan);

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitDup_A()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC------S--E--T-------");
	System.err.println("= --------RPC----S----E--T---");
	System.err.println("===============================================");

	String cid1 = getConnectionId();
	EthernetCriteria criteria1 = createCriteria
	    (cid1, stime+10, dtime, bandwidth, nameA, nameZ, 1780);

	String cid2 = getConnectionId();
	EthernetCriteria criteria2 = createCriteria
	    (cid2, stime+15, dtime+10, bandwidth, nameA, nameZ, 1781);

	Thread.sleep(2000);
	nrm.reserve(null, cid1, null, null, criteria1);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid1);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid1);
	System.err.println("====== commit() is OK");

	Thread.sleep(5000);
	nrm.reserve(null, cid2, null, null, criteria2);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid2);
	System.err.println("====== provision() is OK");

	Thread.sleep(2000);
	nrm.commit(null, cid2);
	System.err.println("====== commit() is OK");

	Thread.sleep(20000);
	nrm.terminate(null, cid1);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(10000);
	nrm.terminate(null, cid2);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitDup_B()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC------S--E--T-------");
	System.err.println("= --------RPC----S----E--T---");
	System.err.println("===============================================");

	String cid1 = getConnectionId();
	EthernetCriteria criteria1 = createCriteria
	    (cid1, stime+10, dtime, bandwidth, nameA, nameZ, 1780);

	String cid2 = getConnectionId();
	EthernetCriteria criteria2 = createCriteria
	    (cid2, stime+15, dtime+10, bandwidth, name3, name2, 1781);

	Thread.sleep(2000);
	nrm.reserve(null, cid1, null, null, criteria1);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid1);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.commit(null, cid1);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.reserve(null, cid2, null, null, criteria2);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid2);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.commit(null, cid2);
	System.err.println("====== commit() is OK");

	Thread.sleep(10000);
	nrm.terminate(null, cid1);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(10000);
	nrm.terminate(null, cid2);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitDup_C()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC------S----------T--E------");
	System.err.println("= --------RPC----S-ERR-AT----E------");
	System.err.println("===============================================");

	String cid1 = getConnectionId();
	EthernetCriteria criteria1 = createCriteria
	    (cid1, stime+10, dtime, bandwidth, nameA, nameZ, 1780);

	String cid2 = getConnectionId();
	EthernetCriteria criteria2 = createCriteria
	    (cid2, stime+15, dtime+10, bandwidth, name2, nameZ, 1781);

	Thread.sleep(2000);
	nrm.reserve(null, cid1, null, null, criteria1);
	System.err.println("====== reserve() is OK");

	Thread.sleep(2000);
	nrm.provision(null, cid1);
	System.err.println("====== provision() is OK");

	Thread.sleep(10000);
	nrm.commit(null, cid1);
	System.err.println("====== commit() is OK");

	try {
	    Thread.sleep(2000);
	    nrm.reserve(null, cid2, null, null, criteria2);
	    System.err.println("====== reserve() is OK");
	} catch (Exception ex) {
	    System.err.println("====== reserve() is FAIL, not ERROR.");
	}

	Thread.sleep(2000);
	nrm.abort(null, cid2);
	System.err.println("====== abort() is OK");

	Thread.sleep(2000);
	nrm.terminate(null, cid2);
	System.err.println("====== terminate() is OK");

	Thread.sleep(10000);
	nrm.terminate(null, cid1);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitQuad_A()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC------S---E--------");
	System.err.println("= ----RPC--------S---E------");
	System.err.println("= ----RPC----------S---E------");
	System.err.println("= ----RPC------------S---E------");
	System.err.println("===============================================");

	String cid1 = getConnectionId();
	EthernetCriteria criteria1 = createCriteria
	    (cid1, 30, 20, bandwidth, nameA, nameZ, 1780);

	String cid2 = getConnectionId();
	EthernetCriteria criteria2 = createCriteria
	    (cid2, 35, 20, bandwidth, nameA, nameZ, 1781);

	String cid3 = getConnectionId();
	EthernetCriteria criteria3 = createCriteria
	    (cid3, 40, 20, bandwidth, nameA, nameZ, 1782);

	String cid4 = getConnectionId();
	EthernetCriteria criteria4 = createCriteria
	    (cid4, 45, 20, bandwidth, nameA, nameZ, 1783);

	Thread.sleep(2000);
	nrm.reserve(null, cid1, null, null, criteria1);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid1);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid1);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.reserve(null, cid2, null, null, criteria2);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid2);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid2);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.reserve(null, cid3, null, null, criteria3);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid3);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid3);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.reserve(null, cid4, null, null, criteria4);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid4);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid4);
	System.err.println("====== commit() is OK");

	Thread.sleep(30000);
	nrm.terminate(null, cid1);
	System.err.println("====== terminate() is OK");
	Thread.sleep(5000);
	nrm.terminate(null, cid2);
	System.err.println("====== terminate() is OK");
	Thread.sleep(5000);
	nrm.terminate(null, cid3);
	System.err.println("====== terminate() is OK");
	Thread.sleep(5000);
	nrm.terminate(null, cid4);
	System.err.println("====== terminate() is OK");
	
	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_A()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC----S------E---------");
	System.err.println("= --------M--S---C----E---T---");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 20, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 40, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(4000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(15000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(40000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_B()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC----S---------E-------T-");
	System.err.println("= --------M----S---------E------, not abort");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 20, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 40, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(5000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(15000);
	Thread.sleep(40000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_C()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC----S---------E-------T-");
	System.err.println("= --------M----S---A-----E------, abort");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 20, 30, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 40, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(5000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");

	Thread.sleep(15000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(40000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_D()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC--------S---------E-----T---");
	System.err.println("= --------M-S-C------------E------, commit");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 30, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 20, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(15000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(30000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_E()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC--------S---------E-----T---");
	System.err.println("= --------M-S-A------------E------, abort");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 30, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 20, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(15000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(30000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_F()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC--------S---------E-----T---");
	System.err.println("= --------M-S-------C------E---------, commit");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 30, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 30, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(25000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(30000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public void reserveCommitModifyCommit_G()
	throws Exception
    {
	System.err.println("===============================================");
	System.err.println("= ----RPC--------S---------E-----T---");
	System.err.println("= --------M-S-------A------E---------, abort");
	System.err.println("===============================================");

	String cid = getConnectionId();
	EthernetCriteria criteria = createCriteria
	    (cid, 30, 20, bandwidth, nameA, nameZ, 1870);
	EthernetCriteria mcriteria = modifyCriteria
	    (cid, 20, 30, bandwidth+100); 

	Thread.sleep(2000);
	nrm.reserve(null, cid, null, null, criteria);
	System.err.println("====== reserve() is OK");
	Thread.sleep(2000);
	nrm.provision(null, cid);
	System.err.println("====== provision() is OK");
	Thread.sleep(2000);
	nrm.commit(null, cid);
	System.err.println("====== commit() is OK");

	Thread.sleep(2000);
	nrm.modify(null, cid, null, null, mcriteria);
	System.err.println("====== modify() is OK");
	Thread.sleep(25000);
	nrm.abort(null, cid);
	System.err.println("====== abort() is OK");

	Thread.sleep(30000);
	nrm.terminate(null, cid);
	System.err.println("====== terminate() is OK");

	Thread.sleep(5000);
    }

    public static EthernetCriteria modifyCriteria
	(String cid, int start, int duration, long bandwidth)
    {
	EthernetCriteria criteria = new EthernetCriteria();
	criteria.setVersion(new Integer(serial++));

        Calendar startTime = Calendar.getInstance();
	startTime.add(Calendar.SECOND, start);
	criteria.setStartTime(startTime);
	Calendar endTime = (Calendar) startTime.clone();
	endTime.add(Calendar.SECOND, duration);
	criteria.setEndTime(endTime);

	criteria.setCapacity(new Long(bandwidth));
	return criteria;
    }

    public static EthernetCriteria createCriteria
	(String cid, int start, int duration, long bandwidth,
	 String srcLocal, String dstLocal, int vlan)
    {
	EthernetCriteria criteria = new EthernetCriteria();
	criteria.setVersion(new Integer(serial++));

        Calendar startTime = Calendar.getInstance();
	startTime.add(Calendar.SECOND, start);
	criteria.setStartTime(startTime);
	Calendar endTime = (Calendar) startTime.clone();
	endTime.add(Calendar.SECOND, duration);
	criteria.setEndTime(endTime);

	criteria.setCapacity(new Long(bandwidth));
	
	DirectionalityType direction = DirectionalityType.BIDIRECTIONAL;
	criteria.setDirectionality(direction);
	criteria.setSymmetricPath(true);

	StpType src = new StpType();
	criteria.setSourceSTP(src);
	src.setNetworkId(networkId);
	src.setLocalId(srcLocal);

	StpType dst = new StpType();
	criteria.setDestSTP(dst);
	dst.setNetworkId(networkId);
	dst.setLocalId(dstLocal);

	criteria.setSourceVLAN(vlan);
	criteria.setDestVLAN(vlan);

	/*
	TypeValuePairListType values =  new TypeValuePairListType();
	List<TypeValuePairType> list = values.getAttribute();
	TypeValuePairType pair = new TypeValuePairType();
	list.add(pair);
	pair.setType("vlan");
	List <String> value = pair.getValue();
	value.add("" + vlan);

	src.setLabels(values);
	dst.setLabels(values);
	*/
	return criteria;
    }

    public static TestOxc test = null;
    public static int ivlan = 0;

    public static void main (String[] argv)
    {
	try {
	    test = new TestOxc();

	    // test.reserveCommit_A(1780);
	    // test.reserveCommit_B(1780);
	    // test.reserveCommitDup_A();
	    // test.reserveCommitDup_B();
	    // test.reserveCommitDup_C();
	    // test.reserveCommitModifyCommit_A();
	    // test.reserveCommitModifyCommit_B();
	    // test.reserveCommitModifyCommit_C();
	    // test.reserveCommitModifyCommit_D();
	    // test.reserveCommitModifyCommit_E();
	    // test.reserveCommitModifyCommit_F();
	    // test.reserveCommitModifyCommit_G();
	    while (true)
		test.reserveCommitQuad_A();
	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(-1);
	}
	// System.exit(0);
    }
}
