/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nrm.scheduler;

import net.glambda.nrm.nsi2.ResourceRequest;
import net.glambda.nrm.util.Logger;
import net.glambda.nrm.util.Parameter;
import net.glambda.nrm.util.TypesToString;
import net.glambda.nrm.util.Time;
import net.glambda.nrm.types.ResourceSpec;
import net.glambda.nrm.types.ReservationStatus;
import net.glambda.nrm.types.Links;
import net.glambda.nrm.types.Link;
import net.glambda.nrm.types.DataPlaneStatus;
import net.glambda.nrm.types.Endpoint;
import net.glambda.nrm.types.Equipment;
import net.glambda.nrm.types.EquipmentType;

import net.glambda.rms.types.ServiceException;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;
import java.util.Enumeration;

public class OxcManager extends LinkManager
{
    private static final String prog = "OxcManager";
    private static final long resourceInit = 1000000000;
    private static final long resource = 1;

    private static Hashtable<String, OxcManager> pathManagers =
	new Hashtable<String, OxcManager>();
    private static Hashtable<String, PortManager> portManagers =
	new Hashtable<String, PortManager>();

    private final String pname;
    private final String ename;
    private final Equipment equipment;
    private final Link link;
    private final String aid;
    private final String zid;
    private PortManager apm;
    private PortManager zpm;

    public static OxcManager getOxcInstance (Link link) 
	throws ServiceException
    {
	String pname = link.getName();
	String ename = link.getEquipmentName();

	OxcManager manager = pathManagers.get(pname);
	if (manager == null) {
	    manager = new OxcManager(link);
	    pathManagers.put(pname, manager);
	}
	return manager;
    }

    private OxcManager(Link link)
	throws ServiceException
    {
	super(link.getName());

	this.pname = link.getName();
	this.ename = link.getEquipmentName();
	equipment = Topology.getEquipment(ename);
	this.link = link;

	initTimeTable(resourceInit);

	Endpoint a = link.getEndpointA();
	Endpoint z = link.getEndpointZ();
	
	aid = a.getName();
	if (aid == null)
	    Logger.error(prog, "This endpoint name is null. name=" + 
			 TypesToString.endpoint(a));
	apm = portManagers.get(aid);
	if (apm == null) {
	    apm = PortManager.getPortInstance(aid);
	    portManagers.put(aid, apm);
	}

	zid = z.getName();
	if (zid == null)
	    Logger.error(prog, "This endpoint name is null. name=" + 
			 TypesToString.endpoint(z));
	zpm = portManagers.get(zid);
	if (zpm == null) {
	    zpm = PortManager.getPortInstance(zid);
	    portManagers.put(zid, zpm);
	}
    }

    private boolean isUsePort (ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== O-Scheduler:isUsedPort:" + 
		    TypesToString.resourceSpec(rspec));

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    Long alloc = t.getAllocatedResource();
	    if (alloc != 0) {
		/* this link is already reserved, 
		   so we can reserve this link */
		continue;
	    }
	    
	    Long stime = t.getStartTime();
	    Long etime = t.getEndTime();
	    boolean f = apm.isUsePort(stime, etime, rspec);
	    if (! f)
		Logger.error(prog, "This oxc port is already used. port=" + 
			     aid);
	    f = zpm.isUsePort(stime, etime, rspec);
	    if (! f)
		Logger.error(prog, "This oxc port is already used. port=" + 
			     zid);
	}
	return true;
    }

    public synchronized boolean reserve 
	(boolean isReserve, ResourceSpec rspec)
	throws ServiceException
    {
	boolean f = isUsePort(rspec);
	if (! f) Logger.fatal(prog, "Internal Error");

	Logger.info(prog, "== O-Scheduler:reserve:" + 
		    TypesToString.resourceSpec(rspec));

	boolean aport = apm.reserve(false, rspec);
	Logger.info(prog, "+++++ reserved oxc port, id=" + aid);
	if (! aport)
	    Logger.error(prog, "This oxc port can not reserve. id=" + aid);

	boolean zport = zpm.reserve(false, rspec);
	Logger.info(prog, "+++++ reserved oxc port, id=" + zid);
	if (! zport)
	    Logger.error(prog, "This oxc port can not reserve. id=" + zid);

	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);
	
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(false, resource, rspec);
	    if (! r) 
		Logger.error(prog, "There are not enough resources.");
	}
	
	if (! isReserve) return true;
	
	aport = apm.reserve(true, rspec);
	zport = zpm.reserve(true, rspec);
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.reserve(true, resource, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in real reserve().");
	}
	return true;
    }

    public synchronized boolean release
	(boolean isRelease, ResourceSpec rspec)
	throws ServiceException
    {
	Logger.info(prog, "== O-Scheduler:release:" + 
		    TypesToString.resourceSpec(rspec));

	boolean aport = apm.release(false, rspec);
	if (! aport)
	    Logger.error(prog, "This oxc port can not release. id=" + aid);
	boolean zport = zpm.release(false, rspec);
	if (! zport)
	    Logger.error(prog, "This oxc port can not release. id=" + zid);
	
	Long startTime = rspec.getStartTime();
	int indexStart = dispartTimeTable(startTime, 0);
	Long endTime = rspec.getEndTime();
	int indexEnd = dispartTimeTable(endTime, indexStart);

	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    boolean r = t.release(false, resource, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in test release().");
	}

	if (! isRelease) return true;

	aport = apm.release(true, rspec);
	zport = zpm.release(true, rspec);
	boolean r = false;
	for (int i = indexStart; i < indexEnd; i++) {
	    TimeTable t = timeTables.get(i);
	    r = t.release(true, resource, rspec);
	    if (! r) 
		Logger.error(prog, "Internal error in real release().");
	}
	
	return true;
    }

    public synchronized boolean isSetup
	(long current, ResourceSpec rspec)
    {
	int i = 0;
	TimeTable t = null;
	while (true) {
	    t = timeTables.get(i);
	    long stime = t.getStartTime();
	    long etime = t.getEndTime();
	    if (stime <= current && etime > current) break;
	    i ++;
	    if (i == timeTables.size()) {
		Logger.info(prog, "Internal error in isSetup().");
		t = timeTables.get(0);
		break;
	    }
	}

	if (t.isSetup(rspec.getSerialId())) return true;

	// long alloc = t.getAllocatedResource();
	// Logger.info(prog, 
	//             "setup:alloc=" + alloc + ", resource=" + resource);
	// if (alloc == resource) return true;

	return false;
    }

    public synchronized boolean isTeardown
	(long current, ResourceSpec rspec)
    {
	int i = 0;
	TimeTable t = null;
	while (true) {
	    t = timeTables.get(i);
	    long stime = t.getStartTime();
	    long etime = t.getEndTime();
	    if (stime <= current && etime > current) break;
	    i ++;
	    if (i == timeTables.size()) {
		Logger.info(prog, "Internal error in isTeardown().");
		t = timeTables.get(0);
		break;
	    }
	}

	if (t.isTeardown(rspec.getSerialId())) return true;

	// long alloc = t.getAllocatedResource();
	// Logger.info(prog, 
	//             "teardown:alloc=" + alloc + ", resource=" + resource);
	// if (alloc <= resource) return true;

	return false;
    }

    public synchronized static void garbage(Long time) 
    {
	Enumeration e = pathManagers.elements();
	while (e.hasMoreElements()) {
	    OxcManager om = (OxcManager) e.nextElement();
	    om.garbageTimeTable(time);
	}
    }

    public synchronized void garbageTimeTable (Long time)
    {
	while (true) {
	    TimeTable t = timeTables.get(0);
	    Long endTime = t.getEndTime();

	    if (endTime < time) {
		timeTables.remove(0);
		timeHash.remove(t.getStartTime());
		t.clear();
	    } else {
		return;
	    }
	}
    }

    public boolean reserveCommit (ResourceSpec rspec)
	throws ServiceException
    {
	return true;
    }

    public boolean reserveAbort (ResourceSpec rspec)
	throws ServiceException
    {
	release(true, rspec);
	return true;
    }

    public boolean setup ()
    {
	Logger.debug(prog, "Setup now. link=" + link);
	return true;
    }

    public boolean teardown ()
    {
	Logger.debug(prog, "Teardown now. link=" + link);
	return true;
    }

    public Equipment getEquipment()
    {
	return equipment;
    }

    public static String getTableSizes()
    {
	String s = prog +": paths=" + pathManagers.size();
	return s;
    }
}