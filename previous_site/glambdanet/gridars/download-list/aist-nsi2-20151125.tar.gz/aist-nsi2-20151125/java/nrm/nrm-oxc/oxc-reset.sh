#! /bin/bash
#
vlans="1780 1781 1782 1783"
prog=./oxc.sh
#echo="echo"
echo=

  $echo $prog OXC1 teardown P1 P2
  $echo $prog OXC1 teardown P3 P4
  $echo $prog OXC1 teardown P5 P6
  $echo $prog OXC1 teardown P7 P8
