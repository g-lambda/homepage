#!/usr/bin/expect -f
#
set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally
if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set cmdname "sw-vconfig"

set host	[lindex $argv 0]
set cmd		[lindex $argv 1]
set ifname1	[lindex $argv 2]
set ifname2	[lindex $argv 3]
set bw		[lindex $argv 4]
set vlan	[lindex $argv 5]
set userid	"admin"
set passwd	"admin"
set prompt	""
set timeout	10
set addr	"" 
#set minvlan	1780
#set maxvlan	1783
set minvlan	1779
set maxvlan	1784

if {($argc != 6) || (($cmd != "teardown") && ($cmd != "setup"))} {
	puts "dell5324 $argv\r"
	puts "useage: swname setup|teardown ifname ifname bw vlan\r"
	puts "\tswname:\tip address of DELL5324 L2 switch\r"
	puts "\tsetupl:\tadd tagged vlan\r"
	puts "\tteardown:\tdelete tagged valn\r"
	puts "\tifname:\tinterface number, example P1,P2,,,P6,null\r"
	puts "\tbw:\tallowed bandwidth(Mbps), not supported now\r"
	puts "\tvlan:\tvlan id number\r"
	exit -1
}

if {($host == "SW1")} { 
#	set addr "192.168.2.241" 
	set addr "localhost" 
	set port "5023" 
	set prompt "VLSR#1-dell5324"
}

if {($addr == "")} {
	puts "The $host is unknown host.\r"
	exit -1
}

if {($ifname1 == "P1")} {
	set ifname1 "g14"
} elseif {($ifname1 == "P2")} {
	set ifname1 "g15"
} elseif {($ifname1 == "P3")} { 
	set ifname1 "g16" 
} elseif {($ifname1 == "P4")} { 
	set ifname1 "g17" 
} elseif {($ifname1 == "P5")} { 
	set ifname1 "g18"
} elseif {($ifname1 == "P6")} { 
	set ifname1 "g19" 
} elseif {($ifname1 == "null")} { 
} else {
	puts "The ifname1($ifname1) is not correct name(P1-P6,null)."
	exit -1
} 

if {($ifname2 == "P1")} { 
	set ifname2 "g14" 
} elseif {($ifname2 == "P2")} { 
	set ifname2 "g15" 
} elseif {($ifname2 == "P3")} { 
	set ifname2 "g16" 
} elseif {($ifname2 == "P4")} { 
	set ifname2 "g17" 
} elseif {($ifname2 == "P5")} { 
	set ifname2 "g18"
} elseif {($ifname2 == "P6")} { 
	set ifname2 "g19" 
} elseif {($ifname2 == "null")} { 
} else {
	puts "The ifname2($ifname2)is not correct name(P1-P6,null)."
	exit -1
} 

if { ($vlan < $minvlan) || ($vlan > $maxvlan) } {
   puts "The vlan ID $vlan is out of range($minvlan - $maxvlan).\r"
   exit -1
}
	
#exit
##############################################################################

# login
spawn telnet $addr $port
expect {
    "User Name:" {
	send -- "$userid\r"
	exp_continue
    } 
    "\rPassword:" {
	send -- "$passwd\r"
	exp_continue
    }
    "${prompt}#" { 
	#puts "OK LOGIN\r"
    }

    put "\r$cmdname: invalid $addr $userid $passwd"
    exit -1
}

send -- "config\r"
expect "${prompt}\\(config\\)#"

# config mode create vlan
if {$ifname1 != "null" && $ifname1 != "nop"} {
	send -- "interface ethernet $ifname1\r"
	expect {
	    "% Invalid parameter value/range" {
		puts "\r$cmdname: invalid ifname ($ifname)"
		exit -1
	    }
	    "${prompt}\\(config-if\\)#" { 
		#puts "OK INTERFACE $ifname\r"
	    }
	}

	if {$cmd == "setup"} {
		send -- "switchport trunk allowed vlan add $vlan\r"
	} else {
		send -- "switchport trunk allowed vlan remove $vlan\r"
	}
	expect {
	    "% Invalid input detected" { 
		puts "\r$cmdname: vlan id ($vlanid)"
		exit -1
	    }
	    "is not exist" { 
		#puts "OK SWITCHEDPORT NO VLAN"
	    }
	    "${prompt}\\(config-if\\)#" { 
		#puts "OK SWITCHEDPORT"
	    }
	}

	send -- "exit\r"
	expect "${prompt}\\(config\\)#"
}

if {$ifname2 != "null" && $ifname2 != "nop"} {
	send -- "interface ethernet $ifname2\r"
	expect {
	    "% Invalid parameter value/range" {
		puts "\r$cmdname: invalid ifname ($ifname)"
		exit -1
	    }
	    "${prompt}\\(config-if\\)#" { 
		#puts "OK INTERFACE $ifname\r"
	    }
	}

	if {$cmd == "setup"} {
		send -- "switchport trunk allowed vlan add $vlan\r"
	} else {
		send -- "switchport trunk allowed vlan remove $vlan\r"
	}
	expect {
	    "% Invalid input detected" { 
		puts "\r$cmdname: vlan id ($vlanid)"
		exit -1
	    }
	    "is not exist" { 
		#puts "OK SWITCHEDPORT NO VLAN"
	    }
	    "${prompt}\\(config-if\\)#" { 
		#puts "OK SWITCHEDPORT"
	    }
	}

	send -- "exit\r"
	expect "${prompt}\\(config\\)#"
}

send -- "exit\r"
expect "${prompt}#"

send -- "show vlan name $vlan\r"
expect "${prompt}#"
send -- "exit\r"
expect eof
exit 0
