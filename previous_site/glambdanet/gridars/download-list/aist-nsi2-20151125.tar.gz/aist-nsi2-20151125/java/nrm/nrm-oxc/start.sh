#! /bin/bash
#! /bin/sh
LIBS=./
LIBS=$LIBS:../build/jar/nrm.jar
LIBS=$LIBS:../libs/commons-logging-1.1.1.jar
LIBS=$LIBS:../libs/log4j-1.2.13.jar

for f in ${CXF_HOME}/lib/*.jar
do 
  LIBS=$LIBS:$f
done

LOGFILE=/tmp/nrm-oxc.log
mv $LOGFILE $LOGFILE.old 
echo java -cp $LIBS net.glambda.nrm.util.Starter
java -cp $LIBS net.glambda.nrm.util.Starter 2>&1 | tee $LOGFILE 
