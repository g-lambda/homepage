/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.impl.StateMachineManager;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSITextDump;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveConfirmedType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

public class SampleProviderHandler implements ProviderHandler {

    protected static final Log logger = AbstractLog.getLog(SampleProviderHandler.class);

    private StateMachineManager smMgr;

    @Override
    public void setStatusMachineManager(StateMachineManager smMgr) {
        this.smMgr = smMgr;
    }

    @Override
    public StateMachineManager getStatusMachineManager() {
        return smMgr;
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void reserve(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
    }

    @Override
    public void modify(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
    }

    protected ReservationConfirmCriteriaType makeReservationConfirmCriteria(
            ReservationRequestCriteriaType criteria, String connectionId, int version) {
        ReservationConfirmCriteriaType conf = new ReservationConfirmCriteriaType();
        conf.setSchedule(criteria.getSchedule());
        conf.setServiceType(criteria.getServiceType());
        conf.getAny().addAll(criteria.getAny());
        conf.setVersion(version);
        conf.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return conf;
    }

    @Override
    public ReservationConfirmCriteriaType sendReserveConfirmed(ProviderArgument arg,
            String connectionId, String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, int version) {
        ReserveConfirmedType rsvConf = new ReserveConfirmedType();
        rsvConf.setGlobalReservationId(globalReservationId);
        rsvConf.setDescription(description);
        rsvConf.setConnectionId(connectionId);
        ReservationConfirmCriteriaType confCrit =
                makeReservationConfirmCriteria(criteria, connectionId, version);
        rsvConf.setCriteria(confCrit);

        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), rsvConf),
                "ReservationConfirm", false));
        try {
            arg.requester().reserveConfirmed(connectionId, globalReservationId, description,
                    rsvConf.getCriteria());
        } catch (Exception e) {
            logger.error("sendReserveConfirmed failed, connId=" + connectionId, e);
        }
        return rsvConf.getCriteria();
    }

    protected ServiceExceptionType makeReserveFailedExecption(String connectionId, Exception e) {
        return NSIExceptionUtil.makeServiceExceptionType(connectionId, e);
    }

    @Override
    public void sendReserveFailed(ProviderArgument arg, String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, Exception e) {
        ServiceExceptionType serviceException = makeReserveFailedExecption(connectionId, e);
        ConnectionStatesType connectionStates = arg.connectionStates();
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), globalReservationId,
                connectionId, connectionStates, serviceException), "ReservationFailed", false));
        try {
            arg.requester().reserveFailed(connectionId, connectionStates, serviceException);
        } catch (Exception ex) {
            logger.error("sendReserveFailed failed, connId=" + connectionId, ex);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void reserveCommit(ProviderArgument arg, String connectionId) throws ServiceException {
    }

    @Override
    public void sendReserveCommitConfirmed(ProviderArgument arg, String connectionId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ReserveConfirmed", false));
        try {
            arg.requester().reserveCommitConfirmed(connectionId);
        } catch (Exception e) {
            logger.error("sendReserveCommitConfirmed failed, connId=" + connectionId, e);
        }
    }

    @Override
    public void sendReserveCommitFailed(ProviderArgument arg, String connectionId,
            ConnectionStatesType connectionStates, Exception e) {
        ServiceExceptionType serviceException =
                NSIExceptionUtil.makeServiceExceptionType(connectionId, e);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                connectionStates, serviceException), "ReserveFailed", false));
        try {
            arg.requester().reserveCommitFailed(connectionId, connectionStates, serviceException);
        } catch (Exception ex) {
            logger.error("sendReserveCommitFailed failed, connId=" + connectionId, ex);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void reserveAbort(ProviderArgument arg, String connectionId) throws ServiceException {
    }

    @Override
    public void sendReserveAbortConfirmed(ProviderArgument arg, String connectionId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ReserveAbortConfirmed", false));
        try {
            arg.requester().reserveAbortConfirmed(connectionId);
        } catch (Exception e) {
            logger.error("sendReserveAbortConfirmed failed, connId=" + connectionId, e);
        }
    }

    @Override
    public void sendReserveTimeout(ProviderArgument arg, String connectionId, long notificationId,
            Calendar timeStamp, int timeoutValue, String originatingConnectionId,
            String originatingNSA) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                notificationId, timeStamp, timeoutValue, originatingConnectionId, originatingNSA),
                "ReserveTimeout", false));
        try {
            arg.requester().reserveTimeout(connectionId, notificationId, timeStamp, timeoutValue,
                    originatingConnectionId, originatingNSA);
        } catch (Exception e) {
            logger.error("sendReserveTimeout failed, connId=" + connectionId, e);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void provision(ProviderArgument arg, String connectionId) throws ServiceException {
    }

    @Override
    public void sendProvisionConfirmed(ProviderArgument arg, String connectionId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ProvisionConfirmed", false));
        try {
            arg.requester().provisionConfirmed(connectionId);
        } catch (Exception e) {
            logger.error("sendProvisionConfirmed failed, connId=" + connectionId, e);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void release(ProviderArgument arg, String connectionId) throws ServiceException {
    }

    @Override
    public void sendReleaseConfirmed(ProviderArgument arg, String connectionId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ReleaseConfirmed", false));
        try {
            arg.requester().releaseConfirmed(connectionId);
        } catch (Exception e) {
            logger.error("sendReleaseConfirmed failed, connId=" + connectionId, e);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void terminate(ProviderArgument arg, String connectionId) throws ServiceException {
    }

    @Override
    public void sendTerminateConfirmed(ProviderArgument arg, String connectionId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "TerminateConfirmed", false));
        try {
            arg.requester().terminateConfirmed(connectionId);
        } catch (Exception e) {
            logger.error("sendTerminateConfirmed failed, connId=" + connectionId, e);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public QuerySummaryResultType querySummary(ProviderArgument arg, StateMachineManager smMgr,
            String connectionId) throws ServiceException {
        StateMachine sm = smMgr.getStateMachine(connectionId);
        return sm.getSummayResult();
    }

    private ChildRecursiveType sumamry2recursive(QuerySummaryResultType summary,
            QuerySummaryResultCriteriaType criteria, ChildSummaryType child) {
        if (child == null) {
            return null;
        }
        ChildRecursiveType result = new ChildRecursiveType();
        result.setConnectionId(child.getConnectionId());
        result.setProviderNSA(child.getProviderNSA());
        result.setConnectionStates(summary.getConnectionStates());
        QueryRecursiveResultCriteriaType recCrit = new QueryRecursiveResultCriteriaType();
        result.getCriteria().add(recCrit);
        recCrit.setSchedule(criteria.getSchedule());
        recCrit.setServiceType(criteria.getServiceType());
        recCrit.getAny().addAll(child.getAny());
        recCrit.setVersion(criteria.getVersion());
        recCrit.getOtherAttributes().putAll(child.getOtherAttributes());
        result.setOrder(child.getOrder());
        return result;
    }

    private ChildRecursiveListType summary2recursive(QuerySummaryResultType summary,
            QuerySummaryResultCriteriaType criteria, ChildSummaryListType children) {
        if (children == null) {
            return null;
        }
        ChildRecursiveListType result = new ChildRecursiveListType();
        for (ChildSummaryType child : children.getChild()) {
            result.getChild().add(sumamry2recursive(summary, criteria, child));
        }
        return result;
    }

    private QueryRecursiveResultCriteriaType summary2recursive(
            QuerySummaryResultCriteriaType criteria, QuerySummaryResultType summary) {
        QueryRecursiveResultCriteriaType result = new QueryRecursiveResultCriteriaType();
        result.setSchedule(criteria.getSchedule());
        result.setServiceType(criteria.getServiceType());
        result.setChildren(summary2recursive(summary, criteria, criteria.getChildren()));
        result.getAny().addAll(criteria.getAny());
        result.setVersion(criteria.getVersion());
        result.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return result;
    }

    @Override
    public QueryRecursiveResultType queryRecursive(ProviderArgument arg, StateMachineManager smMgr,
            String connectionId) throws ServiceException {
        // simply convert QuerySummaryResultType to QueryRecursiveResultType
        StateMachine sm = smMgr.getStateMachine(connectionId);
        QuerySummaryResultType summary = sm.getSummayResult();
        QueryRecursiveResultType result = new QueryRecursiveResultType();
        result.setConnectionId(summary.getConnectionId());
        result.setGlobalReservationId(summary.getGlobalReservationId());
        result.setDescription(summary.getDescription());
        for (QuerySummaryResultCriteriaType criteria : summary.getCriteria()) {
            result.getCriteria().add(summary2recursive(criteria, summary));
        }
        result.setRequesterNSA(summary.getRequesterNSA());
        result.setConnectionStates(summary.getConnectionStates());
        result.setNotificationId(summary.getNotificationId()); // TODO
        return result;
    }

    @Override
    public void sendQuerySummaryConfirmed(ProviderArgument arg,
            List<QuerySummaryResultType> reservation) {
        logger.info(NSITextDump.addTab(
                NSITextDump.toStringQuerySummayList(arg.header(), reservation),
                "QuerySummaryConfirmed", false));
        try {
            arg.requester().querySummaryConfirmed(reservation);
        } catch (Exception e) {
            logger.error("sendQuerySummaryConfirmed failed, corId="
                    + arg.header().getCorrelationId(), e);
        }
    }

    @Override
    public void sendQuerySummaryFailed(ProviderArgument arg, Exception e) {
        ServiceExceptionType serviceException =
                NSIExceptionUtil.makeServiceExceptionType(arg.getConnectionId(), e);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), serviceException),
                "QuerySummaryFailed", false));
        try {
            arg.requester().error(serviceException);
        } catch (Exception ex) {
            logger.error("sendQuerySummaryFailed failed, corId=" + arg.header().getCorrelationId(),
                    ex);
        }
    }

    @Override
    public void sendQueryRecursiveConfirmed(ProviderArgument arg,
            List<QueryRecursiveResultType> reservation) {
        logger.info(NSITextDump.addTab(
                NSITextDump.toStringQueryRecursiveList(arg.header(), reservation),
                "QueryRecursiveConfirmed", false));
        try {
            arg.requester().queryRecursiveConfirmed(reservation);
        } catch (Exception ex) {
            logger.error("sendQueryRecursiveConfirmed failed, corId="
                    + arg.header().getCorrelationId(), ex);
        }
    }

    @Override
    public void sendQueryRecursiveFailed(ProviderArgument arg, Exception e) {
        ServiceExceptionType serviceException =
                NSIExceptionUtil.makeServiceExceptionType(arg.getConnectionId(), e);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), serviceException),
                "QueryRecursiveFailed", false));
        try {
            arg.requester().error(serviceException);
        } catch (Exception ex) {
            logger.error("sendQueryRecursiveFailed failed, corId="
                    + arg.header().getCorrelationId(), ex);
        }
    }

    @Override
    public GenericAcknowledgmentType sendQueryNotificationConfirmed(ProviderArgument arg,
            QueryNotificationConfirmedType queryNotificationConfirmed) {
        logger.info(NSITextDump.addTab(
                NSITextDump.toString(arg.header(), queryNotificationConfirmed),
                "QueryNotificationConfirmed", false));
        try {
            arg.requester().queryNotificationConfirmed(queryNotificationConfirmed);
        } catch (Exception ex) {
            logger.error("sendQueryNotificationConfirmed failed, corId="
                    + arg.header().getCorrelationId(), ex);
        }
        return new GenericAcknowledgmentType();
    }

    @Override
    public void sendQueryNotificationFailed(ProviderArgument arg,
            ServiceExceptionType serviceException) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), serviceException),
                "QueryNotificationFailed", false));
        try {
            arg.requester().error(serviceException);
        } catch (Exception e) {
            logger.error("sendQueryNotificationFailed failed, corId="
                    + arg.header().getCorrelationId(), e);
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    @Override
    public void sendMessageDeliveryTimeout(ProviderArgument arg, String connectionId,
            int notificationId, Calendar timeStamp, String correlationId) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                notificationId, timeStamp, correlationId), "MessageDeliveryTimeout", false));
        try {
            arg.requester().messageDeliveryTimeout(connectionId, notificationId, timeStamp,
                    correlationId);
        } catch (Exception e) {
            logger.error("sendMessageDeliveryTimeout failed", e);
        }
    }

    @Override
    public void sendDataPlaneStateChange(ProviderArgument arg, String connectionId,
            int notificationId, Calendar timeStamp, DataPlaneStatusType dataPlaneStatus) {
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                notificationId, timeStamp, dataPlaneStatus), "DataPlaneStateChange", false));
        try {
            arg.requester().dataPlaneStateChange(connectionId, notificationId, timeStamp,
                    dataPlaneStatus);
        } catch (Exception e) {
            logger.error("sendDataPlaneStateChange failed", e);
        }
    }

    @Override
    public void sendErrorEvent(ProviderArgument arg, String connectionId, long notificationId,
            Calendar timeStamp, EventEnumType event, String originatingConnectionId,
            String originatingNSA, TypeValuePairListType additionalInfo, Exception e) {
        ServiceExceptionType serviceException =
                NSIExceptionUtil.makeServiceExceptionType(connectionId, e);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                notificationId, timeStamp, event, additionalInfo, serviceException), "ErrorEvent",
                false));
        try {
            arg.requester().errorEvent(connectionId, notificationId, timeStamp, event,
                    originatingConnectionId, originatingNSA, additionalInfo, serviceException);
        } catch (Exception ex) {
            logger.error("sendErrorEvent failed", ex);
        }
    }

}
