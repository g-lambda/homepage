/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.util.NSIPortManager;
import net.glambda.nsi2.util.NSIUtil;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

public class RequesterPortWithHeader implements ConnectionRequesterPort {

    private static final NSIPortManager portMgr = NSIPortManager.getInstance();

    private final CommonHeaderType header;
    private final ConnectionRequesterPort requester;

    public RequesterPortWithHeader(CommonHeaderType header) {
        this.requester = portMgr.getRequesterPort(header.getReplyTo());
        this.header = header;
        this.header.setProtocolVersion(NSIUtil.getRequesterProtocolVersion());
    }

    @Override
    public void reserveConfirmed(String connectionId, String globalReservationId,
            String description, ReservationConfirmCriteriaType criteria) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveConfirmed(connectionId, globalReservationId, description, criteria);
        }
    }

    @Override
    public void reserveFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveFailed(connectionId, connectionStates, serviceException);
        }
    }

    @Override
    public void reserveCommitConfirmed(String connectionId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveCommitConfirmed(connectionId);
        }
    }

    @Override
    public void reserveCommitFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveCommitFailed(connectionId, connectionStates, serviceException);
        }
    }

    @Override
    public void reserveAbortConfirmed(String connectionId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveAbortConfirmed(connectionId);
        }
    }

    @Override
    public void provisionConfirmed(String connectionId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.provisionConfirmed(connectionId);
        }
    }

    @Override
    public void releaseConfirmed(String connectionId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.releaseConfirmed(connectionId);
        }
    }

    @Override
    public void terminateConfirmed(String connectionId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.terminateConfirmed(connectionId);
        }
    }

    @Override
    public void querySummaryConfirmed(List<QuerySummaryResultType> reservation)
            throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.querySummaryConfirmed(reservation);
        }
    }

    @Override
    public void queryRecursiveConfirmed(List<QueryRecursiveResultType> reservation)
            throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.queryRecursiveConfirmed(reservation);
        }
    }

    @Override
    public GenericAcknowledgmentType queryNotificationConfirmed(
            QueryNotificationConfirmedType queryNotificationConfirmed) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            return requester.queryNotificationConfirmed(queryNotificationConfirmed);
        }
    }

    @Override
    public void error(ServiceExceptionType serviceException) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.error(serviceException);
        }
    }

    @Override
    public void errorEvent(String connectionId, long notificationId, Calendar timeStamp,
            EventEnumType event, String originatingConnectionId, String originatingNSA,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException)
            throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.errorEvent(connectionId, notificationId, timeStamp, event,
                    originatingConnectionId, originatingNSA, additionalInfo, serviceException);
        }
    }

    @Override
    public void queryResultConfirmed(List<QueryResultResponseType> result) throws ServiceException {
        // TODO Auto-generated method stub

    }

    @Override
    public void messageDeliveryTimeout(String connectionId, long notificationId,
            Calendar timeStamp, String correlationId) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester
                    .messageDeliveryTimeout(connectionId, notificationId, timeStamp, correlationId);
        }
    }

    @Override
    public void dataPlaneStateChange(String connectionId, long notificationId, Calendar timeStamp,
            DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester
                    .dataPlaneStateChange(connectionId, notificationId, timeStamp, dataPlaneStatus);
        }
    }

    @Override
    public void reserveTimeout(String connectionId, long notificationId, Calendar timeStamp,
            int timeoutValue, String originatingConnectionId, String originatingNSA)
            throws ServiceException {
        synchronized (requester) {
            portMgr.setCommonHeader(requester, header);
            requester.reserveTimeout(connectionId, notificationId, timeStamp, timeoutValue,
                    originatingConnectionId, originatingNSA);
        }
    }

}
