/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.Serializer;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.rms.DataPlaneState;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.LifecycleStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.NotificationBaseType;
import org.ogf.schemas.nsi._2013._12.connection.types.ProvisionStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;

public class StateMachine {

    protected static final Log logger = AbstractLog.getLog(StateMachine.class);

    // /////////////////////////////////////////////////////////////////////////

    private final ProviderHandler provHandler;
    private final String connectionId;
    private ProviderArgument reserveArg;

    private QuerySummaryResultType query; // current reservation status
    private QuerySummaryResultType prevQuery; // cloned status for modifyCancel

    private final ArrayList<NotificationBaseType> notificationList;

    public StateMachine(ProviderHandler provHandler, String connId) {
        this.provHandler = provHandler;
        this.connectionId = connId;
        this.reserveArg = null;
        this.query = makeNewQuery();
        this.prevQuery = query;
        this.notificationList = new ArrayList<NotificationBaseType>();
    }

    private QuerySummaryResultType makeNewQuery() {
        QuerySummaryResultType q = new QuerySummaryResultType();
        q.setConnectionId("");
        q.setRequesterNSA("");
        QuerySummaryResultCriteriaType crit = new QuerySummaryResultCriteriaType();
        crit.setSchedule(new ScheduleType());
        crit.setVersion(NSIConstants.INVALID_VERSION);
        q.getCriteria().add(crit); // to avoid empty list
        q.setConnectionStates(TypesBuilder.makeConnectionStatesType(
                ReservationStateEnumType.RESERVE_START, ProvisionStateEnumType.RELEASED,
                LifecycleStateEnumType.CREATED, false, NSIConstants.INVALID_VERSION, true));
        q.setConnectionId(connectionId);
        return q;
    }

    public String getConnectionId() {
        return connectionId;
    }

    public synchronized ScheduleType getSchedule() {
        ScheduleType sched = query.getCriteria().get(0).getSchedule();
        if (sched != null) {
            return sched;
        } else {
            return prevQuery.getCriteria().get(0).getSchedule();
        }
    }

    public synchronized Calendar getStartTime() {
        return getSchedule().getStartTime();
    }

    public synchronized Calendar getEndTime() {
        return getSchedule().getEndTime();
    }

    public synchronized void setEndTimeNow() {
        getSchedule().setEndTime(Calendar.getInstance());
    }

    public synchronized ConnectionStatesType getConnectionStates() {
        return query.getConnectionStates();
    }

    public synchronized String getDescription() {
        return query.getDescription();
    }

    public synchronized int getCurrentVersion() {
        return getConnectionStates().getDataPlaneStatus().getVersion();
    }

    public synchronized long addNotification(NotificationBaseType notification) {
        long id = notificationList.size();
        notification.setNotificationId(id);
        notificationList.add(notification);
        query.setNotificationId(id);
        return id;
    }

    public synchronized List<NotificationBaseType> getNotifications(String connectionId,
            Long startNotificationId, Long endNotificationId) throws ServiceException {
        long start, end;
        if (startNotificationId != null) {
            start = startNotificationId;
            if (start < 0 || notificationList.size() <= start) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                        connectionId, "invalid startNotificationId: " + startNotificationId
                                + ", must be 0 <= id < " + notificationList.size());
            }
        } else {
            start = 0;
        }
        if (endNotificationId != null) {
            end = endNotificationId + 1;
            if (endNotificationId < 0 || notificationList.size() <= endNotificationId) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                        connectionId, "invalid endNotificationId: " + endNotificationId
                                + ", must be 0 <= id < " + notificationList.size());
            }
            if (end <= start) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                        connectionId, "invalid endNotificationId(" + endNotificationId
                                + ") < startNotificationId(" + startNotificationId + ")");
            }
        } else {
            end = notificationList.size();
        }
        if (start < Integer.MAX_VALUE && end < Integer.MAX_VALUE) {
            return notificationList.subList((int) start, (int) end);
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "start=" + start + ", end=" + end + " are too large");
        }
    }

    private int dataPlaneNotificationId = 0;

    public synchronized int getNewDataPlaneNotificationId() {
        return dataPlaneNotificationId++;
    }

    private void setReservationState(ReservationStateEnumType state) {
        logger.info("ReservationState " + getConnectionStates().getReservationState() + " -> "
                + state + ", connId=" + getConnectionId());
        getConnectionStates().setReservationState(state);
    }

    private void setProvisionState(ProvisionStateEnumType state) {
        logger.info("ProvisionState " + getConnectionStates().getProvisionState() + " -> " + state
                + ", connId=" + getConnectionId());
        getConnectionStates().setProvisionState(state);
    }

    private void setLifecycleState(LifecycleStateEnumType state) {
        LifecycleStateEnumType curState = getConnectionStates().getLifecycleState();
        if (curState == state) {
            return;
        }
        switch (curState) {
        case PASSED_END_TIME:
            logger.info("LifecycleState " + curState + " should not change to " + state
                    + ", connId=" + getConnectionId());
            break;
        default:
            logger.info("LifecycleState " + curState + " -> " + state + ", connId="
                    + getConnectionId());
            getConnectionStates().setLifecycleState(state);
            break;
        }
    }

    public void dataPlaneStatusChange(DataPlaneState state) {
        if (state == null) {
            return;
        }
        switch (state) {
        case ACTIVE:
        case INACTIVE:
            boolean isActive = (state == DataPlaneState.ACTIVE);
            logger.info("DataPlaneStatus.active "
                    + getConnectionStates().getDataPlaneStatus().isActive() + " -> " + isActive
                    + ", connId=" + getConnectionId());
            getConnectionStates().getDataPlaneStatus().setActive(isActive);
            break;
        case PASSED_END_TIME:
            if (getConnectionStates().getDataPlaneStatus().isActive()) {
                dataPlaneStatusChange(DataPlaneState.INACTIVE);
            }
            if (getConnectionStates().getProvisionState() == ProvisionStateEnumType.PROVISIONED) {
                setProvisionState(ProvisionStateEnumType.RELEASED);
            }
            setLifecycleState(LifecycleStateEnumType.PASSED_END_TIME);
            break;
        default:
            break;
        }
    }

    public void setStatusByEvent(EventEnumType event) {
        if (event == null) {
            return;
        }
        switch (event) {
        case ACTIVATE_FAILED:
            // TODO
            break;
        case DEACTIVATE_FAILED:
            // TODO
            break;
        case DATAPLANE_ERROR:
            // TODO
            break;
        case FORCED_END:
            switch (getConnectionStates().getLifecycleState()) {
            case CREATED:
                setLifecycleState(LifecycleStateEnumType.FAILED);
                break;
            default:
                break;
            }
            break;
        }
    }

    public void setStatusByReserveTimeout() {
        switch (getConnectionStates().getReservationState()) {
        case RESERVE_HELD:
            setReservationState(ReservationStateEnumType.RESERVE_TIMEOUT);
            break;
        default:
            break;
        }
    }

    private QuerySummaryResultCriteriaType rsvconf2qrysummary(
            ReservationConfirmCriteriaType criteria) {
        // NOTE: some NSI provider miss parameters...
        if (criteria == null) {
            logger.warn("ReservationConfirmCriteriaType is null");
            return null;
        }
        if (criteria.getSchedule() == null) {
            logger.warn("ReservationConfirmCriteriaType.getSchedule() is null");
            return null;
        }
        if (criteria.getSchedule().getStartTime() == null) {
            logger.warn("ReservationConfirmCriteriaType.getSchedule().getStartTime() is null");
            return null;
        }
        // NOTE: NSI allows endTime is null (means forever reservation)
        if (criteria.getAny().isEmpty()) {
            logger.warn("ReservationConfirmCriteriaType.getAny() is empty");
            return null;
        }
        QuerySummaryResultCriteriaType summary = new QuerySummaryResultCriteriaType();
        summary.setSchedule(criteria.getSchedule());
        summary.setServiceType(criteria.getServiceType());
        summary.getAny().addAll(criteria.getAny());
        summary.setVersion(criteria.getVersion());
        summary.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return summary;
    }

    private QuerySummaryResultCriteriaType rsvcrit2qrysummary(
            ReservationRequestCriteriaType criteria) {
        QuerySummaryResultCriteriaType summary = new QuerySummaryResultCriteriaType();
        summary.setSchedule(criteria.getSchedule());
        summary.setServiceType(criteria.getServiceType());
        summary.getAny().addAll(criteria.getAny());
        summary.setVersion(criteria.getVersion());
        summary.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return summary;
    }

    private String getStatesText() {
        ConnectionStatesType states = getConnectionStates();
        return String
                .format("Reservation=%s, Provision=%s, Life=%s, Data.active=%s, version=%d, versionConsistent=%s",
                        states.getReservationState(), states.getProvisionState(), states
                                .getLifecycleState(), states.getDataPlaneStatus().isActive(),
                        states.getDataPlaneStatus().getVersion(), states.getDataPlaneStatus()
                                .isVersionConsistent());
    }

    private ServiceException makeInvalidTrasitionEx(String connectionId) {
        return NSIExceptionUtil.makeServiceException(ErrorID.INVALID_TRANSITION, connectionId,
                getStatesText());
    }

    public void checkPassedEndtime(String connectionId) throws ServiceException {
        if (getConnectionStates().getLifecycleState() == LifecycleStateEnumType.PASSED_END_TIME) {
            throw makeInvalidTrasitionEx(connectionId);
        }
        Calendar end = getEndTime();
        if (end == null) {
            return;
        }
        // NOTE: check for aggregator etc.
        Calendar now = Calendar.getInstance();
        if (end.getTimeInMillis() <= now.getTimeInMillis()) {
            setLifecycleState(LifecycleStateEnumType.PASSED_END_TIME);
            throw makeInvalidTrasitionEx(connectionId);
        }
    }

    public void checkResevationOK(ProviderArgument arg, String connectionId)
            throws ServiceException {
        checkPassedEndtime(connectionId);
        if (getConnectionStates().getReservationState() != ReservationStateEnumType.RESERVE_START) {
            throw makeInvalidTrasitionEx(connectionId);
        }
    }

    private static final org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory P2P_FACTORY =
            new org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory();

    private void mergeCriteria(ReservationRequestCriteriaType criteria) {
        // reset schedule if not modified
        if (criteria.getSchedule() == null) {
            criteria.setSchedule(prevQuery.getCriteria().get(0).getSchedule());
        } else {
            if (criteria.getSchedule().getStartTime() == null) {
                criteria.getSchedule().setStartTime(
                        prevQuery.getCriteria().get(0).getSchedule().getStartTime());
            }
            if (criteria.getSchedule().getEndTime() == null) {
                criteria.getSchedule().setEndTime(
                        prevQuery.getCriteria().get(0).getSchedule().getEndTime());
            }
        }

        // clone previous criteria, update capacity
        P2PServiceBaseType oldEvts;
        try {
            oldEvts = TypesBuilder.getP2PServiceBaseType(prevQuery.getCriteria().get(0));
        } catch (ServiceException e) {
            logger.warn("PROGRAM ERROR", e);
            return;
        }
        P2PServiceBaseType newP2p = Serializer.cloneP2PServiceBaseType(oldEvts);
        for (Object o : criteria.getAny()) {
            Object ele = TypesBuilder.getJAXBValue(o);
            if (ele == null) {
                continue;
            }
            if (ele instanceof Long) {
                Long capacity = (Long) ele;
                if (capacity > 0) {
                    newP2p.setCapacity(capacity);
                }
            }
        }
        criteria.getAny().clear();
        criteria.getAny().add(P2P_FACTORY.createP2Ps(newP2p));
    }

    public boolean reservation(ProviderArgument arg, String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, boolean bNew) {
        if (!bNew) {
            if (globalReservationId == null) {
                globalReservationId = query.getGlobalReservationId();
            }
            if (description == null) {
                description = query.getDescription();
            }
        }
        prevQuery = query;
        try {
            checkResevationOK(arg, connectionId);
            reserveArg = arg;
            query = makeNewQuery();
            query.setGlobalReservationId(globalReservationId);
            query.setDescription(description);
            query.getCriteria().set(0, rsvcrit2qrysummary(criteria));
            query.setRequesterNSA(arg.header().getRequesterNSA());
            query.setConnectionStates(prevQuery.getConnectionStates());
            query.setNotificationId(prevQuery.getNotificationId());
            query.setResultId(prevQuery.getResultId());
            setReservationState(ReservationStateEnumType.RESERVE_CHECKING);
            if (bNew) {
                provHandler.reserve(arg, connectionId, globalReservationId, description, criteria);
            } else {
                provHandler.modify(arg, connectionId, globalReservationId, description, criteria);
                mergeCriteria(criteria);
            }
            setReservationState(ReservationStateEnumType.RESERVE_HELD);
            //
            ReservationConfirmCriteriaType confCriteria =
                    provHandler.sendReserveConfirmed(arg, connectionId, globalReservationId,
                            description, criteria, criteria.getVersion());
            getConnectionStates().getDataPlaneStatus().setVersion(criteria.getVersion());
            QuerySummaryResultCriteriaType summary = rsvconf2qrysummary(confCriteria);
            if (summary != null) {
                query.getCriteria().set(0, summary);
            }
            if (bNew) {
                prevQuery.getCriteria().set(0, query.getCriteria().get(0));
            }
            return true;
        } catch (Exception e) {
            logger.warn(e);
            if (bNew) {
                prevQuery.getCriteria().set(0, query.getCriteria().get(0));
            }
            setReservationState(ReservationStateEnumType.RESERVE_FAILED);
            provHandler.sendReserveFailed(arg, connectionId, globalReservationId, description,
                    criteria, e);
            return false;
        }
    }

    public void checkReseveCommitAbortOK(String connectionId, boolean bCommit)
            throws ServiceException {
        checkPassedEndtime(connectionId);
        switch (getConnectionStates().getReservationState()) {
        case RESERVE_HELD:
            return;
        case RESERVE_FAILED:
            if (!bCommit) {
                return;
            }
            break;
        case RESERVE_TIMEOUT:
            if (!bCommit) {
                return;
            }
            break;
        default:
            break;
        }
        throw makeInvalidTrasitionEx(connectionId);
    }

    public void reserveCommit(ProviderArgument arg, String connectionId) {
        try {
            checkReseveCommitAbortOK(connectionId, true);
            setReservationState(ReservationStateEnumType.RESERVE_COMMITTING);
            provHandler.reserveCommit(arg, connectionId);
            setReservationState(ReservationStateEnumType.RESERVE_START);
            provHandler.sendReserveCommitConfirmed(arg, connectionId);
        } catch (Exception e) {
            logger.warn(e);
            setReservationState(ReservationStateEnumType.RESERVE_START);
            provHandler.sendReserveCommitFailed(arg, connectionId, getConnectionStates(), e);
        }
    }

    public void reserveAbort(ProviderArgument arg, String connectionId) {
        try {
            checkReseveCommitAbortOK(connectionId, false);
            query = prevQuery;
            setReservationState(ReservationStateEnumType.RESERVE_ABORTING);
            provHandler.reserveAbort(arg, connectionId);
            setReservationState(ReservationStateEnumType.RESERVE_START);
            provHandler.sendReserveAbortConfirmed(arg, connectionId);
        } catch (Exception e) {
            logger.warn(e);
            setReservationState(ReservationStateEnumType.RESERVE_START);
            provHandler.sendReserveAbortConfirmed(arg, connectionId);
        }
    }

    public void checkProvisionOK(ProviderArgument arg, String connectionId) throws ServiceException {
        checkPassedEndtime(connectionId);
        // provision/release can be accepted even if ReservationState !=
        // RESERVE_START
        if (getConnectionStates().getProvisionState() != ProvisionStateEnumType.RELEASED) {
            throw makeInvalidTrasitionEx(connectionId);
        }
    }

    public void provision(ProviderArgument arg, String connectionId) throws ServiceException {
        checkProvisionOK(arg, connectionId);
        setProvisionState(ProvisionStateEnumType.PROVISIONING);
        try {
            provHandler.provision(arg, connectionId);
        } catch (Exception e) {
            logger.warn(e);
        }
        setProvisionState(ProvisionStateEnumType.PROVISIONED);
        provHandler.sendProvisionConfirmed(arg, connectionId);
    }

    public void checkReleaseOK(ProviderArgument arg, String connectionId) throws ServiceException {
        checkPassedEndtime(connectionId);
        if (getConnectionStates().getProvisionState() != ProvisionStateEnumType.PROVISIONED) {
            throw makeInvalidTrasitionEx(connectionId);
        }
    }

    public void release(ProviderArgument arg, String connectionId) throws ServiceException {
        checkReleaseOK(arg, connectionId);
        setProvisionState(ProvisionStateEnumType.RELEASING);
        try {
            provHandler.release(arg, connectionId);
        } catch (Exception e) {
            logger.warn(e);
        }
        setProvisionState(ProvisionStateEnumType.RELEASED);
        provHandler.sendReleaseConfirmed(arg, connectionId);
    }

    public void checkTerminateOK(ProviderArgument arg, String connectionId) throws ServiceException {
        switch (getConnectionStates().getLifecycleState()) {
        case CREATED:
        case FAILED:
        case PASSED_END_TIME:
            return;
        default:
            throw makeInvalidTrasitionEx(connectionId);
        }
    }

    public void terminate(ProviderArgument arg, String connectionId) throws ServiceException {
        checkTerminateOK(arg, connectionId);
        setLifecycleState(LifecycleStateEnumType.TERMINATING);
        try {
            provHandler.terminate(arg, connectionId);
        } catch (Exception e) {
            logger.warn(e);
        }
        setLifecycleState(LifecycleStateEnumType.TERMINATED);
        provHandler.sendTerminateConfirmed(arg, connectionId);
    }

    public String getRequesterNSA() {
        return query.getRequesterNSA();
    }

    public String getGlobalReservationId() {
        return query.getGlobalReservationId();
    }

    public ProviderArgument getReserveArg() {
        return reserveArg;
    }

    // /////////////////////////////////////////////////////////////////////////

    public QuerySummaryResultType getSummayResult() {
        Calendar end = getEndTime();
        Calendar now = Calendar.getInstance();
        if (end != null
                && end.getTimeInMillis() <= now.getTimeInMillis()
                && getConnectionStates().getLifecycleState() != LifecycleStateEnumType.PASSED_END_TIME) {
            logger.info("PASSED_END_TIME not received it's already passed endTime. change here");
            setLifecycleState(LifecycleStateEnumType.PASSED_END_TIME);
        }
        return query;
    }

}
