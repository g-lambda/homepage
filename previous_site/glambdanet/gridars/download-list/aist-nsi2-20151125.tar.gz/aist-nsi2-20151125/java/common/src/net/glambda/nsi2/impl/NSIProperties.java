/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class NSIProperties {

    // NOTE: DO NOT USE AbstractLog here, because it refers NSIProperties
    protected static final Log logger = LogFactory.getLog(NSIProperties.class);

    private static NSIProperties instance = null;
    private static final Properties prop = new Properties();
    private static final String PROP_FILE = "etc/nsi2.properties";

    public static final String PROP_CHECK_SESS_SECURITY = "nsi.checkSessionSecurity";
    public static final String PROP_USERS_ALLOW = "nsi.users.allow";
    public static final String PROP_GLOBAL_USER_NAME = "nsi.globalUserName";
    public static final String PROP_HTTP_USER = "nsi.http.username";
    public static final String PROP_HTTP_PASS = "nsi.http.password";
    public static final String PROP_REPLY_TIMEOUT = "nsi.reply.timeout";
    public static final String PROP_ABSTRACT_EX = "nsi.abstractex";
    public static final String PROP_QUERYALL_NSA = "nsi.queryall.requester";
    public static final String PROP_MY_PROVIDER_NSA = "nsi.my.provider.nsa";
    public static final String PROP_MY_REQUESTER_NSA = "nsi.my.requester.nsa";
    //
    public static final String PROP_SSL_KEY_FILE = "ssl.keyStore";
    public static final String PROP_SSL_KEY_STORE_PASS = "ssl.keyStorePassword";
    public static final String PROP_SSL_KEY_PASS = "ssl.keyPassword";
    public static final String PROP_SSL_TRUST_FILE = "ssl.trustStore";
    public static final String PROP_SSL_TRUST_STORE_PASS = "ssl.trustStorePassword";

    private static String QUERYALL_NSA;
    private static int reserveTimeoutSec = 120;
    private static int replyTimeoutSec = 120;

    private NSIProperties() {
        InputStream is = null;
        try {
            is = this.getClass().getResourceAsStream("/" + PROP_FILE);
            if (is == null) {
                is = new FileInputStream(PROP_FILE);
            }
            prop.load(is);
            logger.debug(prop.toString());
        } catch (IOException e) {
            logger.warn("cannot read " + PROP_FILE, e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    logger.warn("cannot close " + PROP_FILE, e);
                }
            }
        }
    }

    public synchronized static final NSIProperties getInstance() {
        if (instance == null) {
            instance = new NSIProperties();
            QUERYALL_NSA = instance.getProperty(NSIProperties.PROP_QUERYALL_NSA, "");
            reserveTimeoutSec =
                    Integer.parseInt(instance.getProperty("nsi2.reserve.timeout", "120"));
            replyTimeoutSec = Integer.parseInt(instance.getProperty(PROP_REPLY_TIMEOUT, "120"));
            String sslTrust = instance.getProperty(PROP_SSL_TRUST_FILE);
            String sslPass = instance.getProperty(PROP_SSL_TRUST_STORE_PASS);
            if (sslTrust != null && sslPass != null) {
                System.setProperty("javax.net.ssl.trustStore", sslTrust);
                System.setProperty("javax.net.ssl.trustStorePassword", sslPass);
            }
        }
        return instance;
    }

    public String getProperty(String key) {
        return prop.getProperty(key);
    }

    public String getProperty(String key, String defaultValue) {
        return prop.getProperty(key, defaultValue);
    }

    public String getHTTPUsername() {
        return getProperty(PROP_HTTP_USER);
    }

    public String getHTTPPassword() {
        return getProperty(PROP_HTTP_PASS);
    }

    public static boolean isQuerierNSA(String nsa) {
        return QUERYALL_NSA.equals(nsa);
    }

    public int reserveTimeoutSec() {
        return reserveTimeoutSec;
    }

    public int replyTimeoutSec() {
        return replyTimeoutSec;
    }

    private static final String DEFAULT_NSA = "urn:ogf:network:aist.go.jp:2013:nsa";

    private String getNSA(String key) {
        String v = getProperty(PROP_MY_PROVIDER_NSA);
        if (v != null) {
            return v;
        }
        v = DEFAULT_NSA;
        logger.info("missing config value of " + key + ". Use default NSA = " + v + ". Set it in "
                + PROP_FILE + " if you want to change it!");
        prop.setProperty(key, v);
        return v;
    }

    public String getMyProviderNSA() {
        return getNSA(PROP_MY_PROVIDER_NSA);
    }

    public String getMyRequesterNSA() {
        return getNSA(PROP_MY_REQUESTER_NSA);
    }

    public String getAggregatorRequesterURL() {
        return getProperty("nsi.aist.aggr.requester",
                "http://127.0.0.1:28090/nsi2/services/ConnectionServiceRequester");
    }

    public String getTopologyXml() {
        return getProperty("nsi.topology.xml", "etc/master.xml");
    }

    public String getDiscoveryTopologyXml() {
        return getProperty("nsi.discovery.topology.xml", "etc/master-discovery.xml");
    }

    public String getMasterDDSXml() {
        return getProperty("nsi.dds.xml", "etc/master-dds.xml");
    }

    public String getQueryAllNSA() {
        return QUERYALL_NSA;
    }
}
