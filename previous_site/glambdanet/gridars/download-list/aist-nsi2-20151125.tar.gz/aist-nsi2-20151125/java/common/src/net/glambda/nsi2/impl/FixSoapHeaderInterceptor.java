/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.binding.soap.interceptor.SoapPreProtocolOutInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

public class FixSoapHeaderInterceptor extends AbstractPhaseInterceptor<Message> {

    protected static final Log logger = LogFactory.getLog(FixSoapHeaderInterceptor.class);

    // http://www.mastertheboss.com/javaee/jboss-web-services/apache-cxf-interceptors
    // http://stackoverflow.com/questions/6915428/how-to-modify-the-raw-xml-message-of-an-outbound-cxf-request
    // https://access.redhat.com/discussions/1344833

    private class CachedStream extends CachedOutputStream {
        public CachedStream() {
            super();
        }

        protected void doFlush() throws IOException {
            currentStream.flush();
        }

        protected void doClose() throws IOException {
        }

        protected void onWrite() throws IOException {
        }
    }

    public FixSoapHeaderInterceptor() {
        super(Phase.PRE_STREAM);
        addAfter(SoapPreProtocolOutInterceptor.class.getName());
    }

    private static final String START_SOAPBODY = "<soap:Body>";
    private static final String END_NSIHEADER = "nsiHeader>";

    private String changeOutboundMessage(String mes) {
        int idx = mes.indexOf(START_SOAPBODY);
        if (idx < 0) {
            logger.warn("cannot find " + START_SOAPBODY);
            return mes;
        }
        String header = mes.substring(0, idx);
        int idx1 = header.indexOf(END_NSIHEADER);
        int idx2 = header.lastIndexOf(END_NSIHEADER);
        if (idx1 == idx2) {
            return mes;
        } else {
            String body = mes.substring(idx);
            logger.info("HEAD1\t" + header);
            header = header.substring(0, idx1) + header.substring(idx2);
            logger.info("HEAD2\t" + header);
            return header + body;
        }
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        boolean isOutbound =
                message == message.getExchange().getOutMessage()
                        || message == message.getExchange().getOutFaultMessage();
        if (!isOutbound) {
            return;
        }

        OutputStream os = message.getContent(OutputStream.class);

        CachedStream cs = new CachedStream();
        message.setContent(OutputStream.class, cs);
        message.getInterceptorChain().doIntercept(message);

        try {
            cs.flush();
            IOUtils.closeQuietly(cs);
            CachedOutputStream csnew = (CachedOutputStream) message.getContent(OutputStream.class);

            String currentEnvelopeMessage = IOUtils.toString(csnew.getInputStream(), "UTF-8");
            csnew.flush();
            IOUtils.closeQuietly(csnew);

            String res = changeOutboundMessage(currentEnvelopeMessage);

            InputStream replaceInStream = IOUtils.toInputStream(res, "UTF-8");

            IOUtils.copy(replaceInStream, os);
            replaceInStream.close();
            IOUtils.closeQuietly(replaceInStream);

            os.flush();
            message.setContent(OutputStream.class, os);
            IOUtils.closeQuietly(os);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
