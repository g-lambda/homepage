/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

public enum ErrorID {

    // section 16.1 & 19.3 of https://www.ogf.org/documents/GFD.212.pdf
    // https://code.google.com/p/ogf-nsi-project/wiki/NSIErrorCodes

    PAYLOAD_ERROR(100),
    //
    MISSING_PARAMETER(101, "Invalid or missing parameter",
            "Include the parameter name that is missing."),
    //
    UNSUPPORTED_PARAMETER(102,
            "A provided request parameter that MUST be processed contains an unsupported value.",
            "Include the parameter name that is unsupported."),
    //
    NOT_IMPLEMENTED(103, "", "Include the capability that is not implemented."),
    //
    VERSION_NOT_SUPPORTED(104, "The service version requested in NSI header is not supported.",
            "Return type protocolVersion and value the version requested"),
    //
    CONNECTION_ERROR(200),
    //
    INVALID_TRANSITION(201, "Connection state machine is in invalid state for received message.",
            "Include the current state of the state machine."),
    //
    CONNECTION_EXISTS(202, "Schedule already exists for connectionId"),
    //
    CONNECTION_NONEXISTENT(203, "Schedule does not exist for connectionId."),
    //
    CONNECTION_GONE(204),
    //
    CONNECTION_CREATE_ERROR(205,
            "Failed to create connection (payload was ok, something went wrong)"),
    //
    SECURITY_ERROR(300),
    //
    AUTHENTICATION_FAILURE(301),
    //
    UNAUTHORIZED(302),
    //
    TOPOLOGY_ERROR(400),
    //
    NO_PATH_FOUND(403, "Path computation failed to resolve route for reservation."),
    //
    INTERNAL_ERROR(500, "An internal error has caused a message processing failure."),
    //
    INTERNAL_NRM_ERROR(501, "An internal NRM error has caused a message processing failure.",
            "Include information describing the specific NRM error."),
    //
    RESOURCE_UNAVAILABLE(600),
    //
    SERVICE_ERROR(700, "Parent error classification for a service-specific error."),
    //
    UNKNOWN_STP(701, "Could not find STP in topology database.", "<Unknown STP name>"),
    //
    STP_RESOLUTION_ERROR(702, "Could not resolve STP to a managing NSA."),
    //
    VLANID_INTERCANGE_NOT_SUPPORTED(703, "VLAN interchange not supported for requested path."),
    //
    STP_UNAVALABLE(704, "Specified STP already in use."),
    //
    CAPACITY_UNAVAILABLE(705, "Insufficient bandwidth available for reservation.");

    private final String errorId;
    private final String text;
    private final boolean hasVar;

    ErrorID(int errorId) {
        this(errorId, null);
    }

    ErrorID(int errorId, String text) {
        this(errorId, text, null);
    }

    ErrorID(int errorId, String text, String varDesc) {
        this.errorId = Integer.toString(errorId);
        this.text = text;
        this.hasVar = (varDesc != null && !varDesc.isEmpty());
    }

    public String errorId() {
        return errorId;
    }

    public String text() {
        return text;
    }

    public boolean hasVariable() {
        return hasVar;
    }

}
