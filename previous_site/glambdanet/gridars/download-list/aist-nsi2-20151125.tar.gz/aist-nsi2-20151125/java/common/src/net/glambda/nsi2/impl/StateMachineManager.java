/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.NotificationBaseType;

public class StateMachineManager {

    protected static final Log logger = AbstractLog.getLog(StateMachineManager.class);
    private static final String QUERYALL_REQUESTER = NSIProperties.getInstance().getProperty(
            "nsi.queryall.requester");

    static final int PURGE_AFTER_MSEC = 3600 * 1000; // [msec]
    static final int GC_PERIOD_MSEC = 3600 * 1000; // [msec]

    private class GCTask extends TimerTask {

        @Override
        public void run() {
            try {
                gc();
            } catch (Exception e) {
                logger.warn(e);
            }
        }

    }

    private static final Timer timer = new Timer();
    private final ProviderHandler provHandler;

    private final HashMap<String, StateMachine> connIdMap =
            new LinkedHashMap<String, StateMachine>();

    public StateMachineManager(ProviderHandler provHandler) {
        this.provHandler = provHandler;
        this.provHandler.setStatusMachineManager(this);
        timer.schedule(new GCTask(), GC_PERIOD_MSEC, GC_PERIOD_MSEC);
    }

    public synchronized StateMachine makeNewStateMachine(String connId) throws ServiceException {
        if (!connIdMap.containsKey(connId)) {
            StateMachine sm = new StateMachine(provHandler, connId);
            connIdMap.put(connId, sm);
            return sm;
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.CONNECTION_EXISTS, connId);
        }
    }

    public synchronized StateMachine getStateMachine(String connId) throws ServiceException {
        StateMachine sm = connIdMap.get(connId);
        if (sm != null) {
            return sm;
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.CONNECTION_NONEXISTENT, connId);
        }
    }

    public synchronized void deleteStateMachine(String connId) {
        connIdMap.remove(connId);
        logger.info("delete StateMachine of connId=" + connId);
    }

    public synchronized List<StateMachine> getStateMachines(List<String> connIds,
            List<String> globalIds, String reqNSA) {
        boolean isQuerier = NSIProperties.isQuerierNSA(reqNSA);
        LinkedList<StateMachine> matched = new LinkedList<StateMachine>();
        if (connIds.isEmpty() && globalIds.isEmpty() && reqNSA != null) {
            for (StateMachine sm : connIdMap.values()) {
                if (reqNSA.equals(sm.getRequesterNSA()) || reqNSA.equals(QUERYALL_REQUESTER)) {
                    matched.add(sm);
                }
            }
            return matched;
        }
        //
        for (String connId : connIds) {
            StateMachine sm = connIdMap.get(connId);
            if (sm != null) {
                matched.add(sm);
            } else if (!isQuerier) {
                logger.warn("cannot find connId=" + connId);
            }
        }
        for (String globalId : globalIds) {
            // NOTE: globalID is NOT unique identifier of the each reservation.
            int nFound = 0;
            for (StateMachine sm : connIdMap.values()) {
                if (globalId.equals(sm.getGlobalReservationId())) {
                    matched.add(sm);
                    nFound++;
                }
            }
            if (nFound == 0 && !isQuerier) {
                logger.warn("cannot find globalId=" + globalId);
            }
        }
        return matched;
    }

    public synchronized List<NotificationBaseType> queryNotifications(String connectionId,
            Long startNotificationId, Long endNotificationId) throws ServiceException {
        StateMachine sm = getStateMachine(connectionId);
        return sm.getNotifications(connectionId, startNotificationId, endNotificationId);
    }

    private synchronized void gc() {
        LinkedList<String> idList = new LinkedList<String>();
        Calendar limit = Calendar.getInstance();
        limit.add(Calendar.MILLISECOND, -PURGE_AFTER_MSEC);
        for (StateMachine sm : connIdMap.values()) {
            Calendar end = sm.getEndTime();
            if (end != null && end.before(limit)) {
                idList.add(sm.getConnectionId());
            }
        }
        if (!idList.isEmpty()) {
            logger.info("Delete old StateMachines....");
            for (String connId : idList) {
                deleteStateMachine(connId);
            }
        }
    }

}
