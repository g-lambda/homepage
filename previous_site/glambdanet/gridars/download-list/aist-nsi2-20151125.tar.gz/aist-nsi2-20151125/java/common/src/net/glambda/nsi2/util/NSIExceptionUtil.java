/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import net.glambda.nsi2.impl.NSIProperties;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType;
import org.ogf.schemas.nsi._2013._12.framework.types.VariablesType;

public class NSIExceptionUtil {

    private static final NSIProperties prop = NSIProperties.getInstance();
    private static final String MY_PROVIDER_NSA = prop.getMyProviderNSA();

    public static ServiceExceptionType makeServiceExceptionType(ErrorID err, String connectionId) {
        return makeServiceExceptionType(err, connectionId, null);
    }

    public static ServiceExceptionType makeServiceExceptionType(ErrorID err, String connectionId,
            String variable) {
        ServiceExceptionType nsiEx = new ServiceExceptionType();
        nsiEx.setNsaId(MY_PROVIDER_NSA);
        nsiEx.setConnectionId(connectionId);
        nsiEx.setErrorId(err.errorId());
        nsiEx.setText(err.text());
        if (variable != null) {
            TypeValuePairType pair = new TypeValuePairType();
            pair.setType("text");
            pair.getValue().add(variable);
            VariablesType v = new VariablesType();
            v.getVariable().add(pair);
            nsiEx.setVariables(v);
        }
        return nsiEx;
    }

    public static ServiceException makeServiceException(ErrorID err, String connectionId) {
        return makeServiceException(err, connectionId, null);
    }

    public static ServiceException makeServiceException(ErrorID err, String connectionId,
            String variable) {
        ServiceExceptionType nsiEx = makeServiceExceptionType(err, connectionId, variable);
        String text = (err.text() != null ? err.name() + " : " + err.text() : err.name());
        return new ServiceException(text, nsiEx);
    }

    public static ServiceExceptionType makeServiceExceptionType(String connectionId, Exception e) {
        if (e instanceof ServiceException) {
            return ((ServiceException) e).getFaultInfo();
        }
        if (e != null) {
            return makeServiceExceptionType(ErrorID.INTERNAL_ERROR, connectionId, e.getMessage());
        } else {
            return makeServiceExceptionType(ErrorID.INTERNAL_ERROR, connectionId, null);
        }
    }

    public static ServiceException type2ex(ServiceExceptionType type) {
        if (type != null) {
            return new ServiceException(type.getText(), type);
        } else {
            return new ServiceException(ErrorID.INTERNAL_ERROR.text());
        }
    }

    public static ServiceException makeServiceException(String connectionId, Exception e) {
        return type2ex(makeServiceExceptionType(connectionId, e));
    }

    public static ServiceException makeServiceException(Exception e) {
        return type2ex(makeServiceExceptionType(null, e));
    }

    public static ServiceException makeServiceException(String message) {
        return makeServiceException(ErrorID.INTERNAL_ERROR, null, message);
    }
}
