/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;

public class Serializer {

    protected static final Log logger = LogFactory.getLog(Serializer.class);

    private static final HashMap<Package, Marshaller> marshMap = new HashMap<Package, Marshaller>();
    private static final HashMap<Package, Unmarshaller> unmarshMap =
            new HashMap<Package, Unmarshaller>();

    private static synchronized Marshaller getMarshaller(Class<?> cls) {
        Package pkg = cls.getPackage();
        Marshaller m = marshMap.get(pkg);
        if (m != null) {
            return m;
        }
        try {
            JAXBContext context = JAXBContext.newInstance(pkg.getName());
            m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshMap.put(pkg, m);
        } catch (JAXBException e) {
            logger.fatal("cannot initialize JAXB marshaller\t" + e.getMessage());
        }
        return m;
    }

    private static synchronized Unmarshaller getUnmarshaller(Class<?> cls) {
        Package pkg = cls.getPackage();
        Unmarshaller m = unmarshMap.get(pkg);
        if (m != null) {
            return m;
        }
        try {
            JAXBContext context = JAXBContext.newInstance(pkg.getName());
            m = context.createUnmarshaller();
            unmarshMap.put(pkg, m);
        } catch (JAXBException e) {
            logger.fatal("cannot initialize JAXB unmarshaller\t" + e.getMessage());
        }
        return m;
    }

    private static String obj2xml(JAXBElement<?> jaxbElem) {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            Marshaller marshaller = getMarshaller(jaxbElem.getDeclaredType());
            synchronized (marshaller) {
                marshaller.marshal(jaxbElem, os);
                return os.toString();
            }
        } catch (JAXBException e) {
            logger.warn("failed marshalling!", e);
        }
        return "";
    }

    public static String obj2xml(QName qname, Object obj) {
        if (obj == null) {
            return "";
        }

        @SuppressWarnings({ "rawtypes", "unchecked" })
        JAXBElement elem = new JAXBElement(qname, obj.getClass(), obj);
        return obj2xml(elem);
    }

    @SuppressWarnings("unchecked")
    public static <T> T xml2obj(String xml, Class<T> cls) {
        if (xml == null || xml.isEmpty() || cls == null) {
            return null;
        }

        ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes());
        try {
            Unmarshaller unmarshaller = getUnmarshaller(cls);
            Object o;
            JAXBElement<?> jaxbEle = null;
            synchronized (unmarshaller) {
                o = unmarshaller.unmarshal(is);
            }
            if (o instanceof JAXBElement) {
                jaxbEle = (JAXBElement<?>) o;
                o = jaxbEle.getValue();
            }
            if (o != null && o.getClass().getName().equals(cls.getName())) {
                return (T) o;
            } else {
                return null;
            }
        } catch (JAXBException e) {
            logger.warn("failed unmarshalling!", e);
        }
        return null;
    }

    private static final org.ogf.schemas.nsi._2013._12.connection.types.ObjectFactory CONN_TYPES_FACTORY =
            new org.ogf.schemas.nsi._2013._12.connection.types.ObjectFactory();

    public static QuerySummaryResultType cloneQuerySummaryResultType(QuerySummaryResultType summary) {
        QuerySummaryConfirmedType conf = new QuerySummaryConfirmedType();
        conf.getReservation().add(summary);
        JAXBElement<QuerySummaryConfirmedType> jaxbElem =
                CONN_TYPES_FACTORY.createQuerySummaryConfirmed(conf);
        try {
            String xml = obj2xml(jaxbElem);
            // NOTE: JAXB cannot unmarshal QuerySummaryResultType object
            // directly. So make QuerySummaryConfirmedType temporary.
            QuerySummaryConfirmedType clone = xml2obj(xml, QuerySummaryConfirmedType.class);
            if (clone != null) {
                return clone.getReservation().get(0);
            } else {
                logger.warn("cannot clone QuerySummaryResultType object");
                return null;
            }
        } catch (Exception e) {
            logger.warn(e);
            return null;
        }
    }

    private static final org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory P2P_FACTORY =
            new org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory();

    public static P2PServiceBaseType cloneP2PServiceBaseType(P2PServiceBaseType p2p) {
        JAXBElement<P2PServiceBaseType> jaxbElem = P2P_FACTORY.createP2Ps(p2p);
        try {
            String xml = obj2xml(jaxbElem);
            P2PServiceBaseType clone = xml2obj(xml, P2PServiceBaseType.class);
            if (clone != null) {
                return clone;
            } else {
                logger.warn("cannot clone P2PServiceBaseType object");
                return null;
            }
        } catch (Exception e) {
            logger.warn(e);
            return null;
        }
    }

}
