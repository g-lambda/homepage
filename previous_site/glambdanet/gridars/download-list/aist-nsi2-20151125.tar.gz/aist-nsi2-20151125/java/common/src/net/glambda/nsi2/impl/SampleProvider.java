/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.xml.ws.Holder;
import javax.xml.ws.WebServiceContext;

import net.glambda.nsi2.impl.ProviderArgument;
import net.glambda.nsi2.impl.StateMachine;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.nsi2.util.SecurityUtil;
import net.glambda.nsi2.impl.SampleProviderHandler;
import net.glambda.nsi2.impl.ProviderHandler;
import net.glambda.nsi2.impl.SampleProvider;
import net.glambda.nsi2.impl.StateMachineManager;
import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.NotificationBaseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

// @org.apache.cxf.interceptor.OutInterceptors (interceptors = {"net.glambda.nsi2.impl.FixSoapHeaderInterceptor" })
@javax.jws.WebService(portName = "ConnectionServiceProviderPort", serviceName = "ConnectionServiceProvider", targetNamespace = "http://schemas.ogf.org/nsi/2013/12/connection/provider", endpointInterface = "org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort")
public class SampleProvider implements ConnectionProviderPort {

    protected static final Log logger = AbstractLog.getLog(SampleProvider.class);

    // NOTE: see the bottom of http://cxf.apache.org/docs/servlet-transport.html
    @Resource
    private WebServiceContext context;

    private final ProviderHandler provHandler;
    private final StateMachineManager smMgr;

    public SampleProvider() {
        this(new SampleProviderHandler());
    }

    public SampleProvider(ProviderHandler provHandler) {
        this.provHandler = provHandler;
        this.smMgr = new StateMachineManager(provHandler);
    }

    private void checkSchedule(ScheduleType schedule, String connectionId) throws ServiceException {
        Calendar start = schedule.getStartTime();
        if (start == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, connectionId,
                    "startTime");
        }
        Calendar end = schedule.getEndTime();
        if (end != null) {
            if (!start.before(end)) {
                throw NSIExceptionUtil
                        .makeServiceException(
                                ErrorID.UNSUPPORTED_PARAMETER,
                                connectionId,
                                String.format(
                                        Locale.US,
                                        "invalid schedule, must be startTime < endTime: start=%tc, end=%tc",
                                        start, end));
            }
            Calendar now = Calendar.getInstance();
            if (end.before(now)) {
                throw NSIExceptionUtil.makeServiceException(ErrorID.UNSUPPORTED_PARAMETER,
                        connectionId, String.format(Locale.US,
                                "invalid schedule, must be now <= endTime: now=%tc, end=%tc", now,
                                end));
            }
        }
    }

    protected void checkReservationCriteria(ReservationRequestCriteriaType criteria,
            String connectionId) throws ServiceException {
        if (criteria.getSchedule() != null) {
            checkSchedule(criteria.getSchedule(), connectionId);
        }
    }

    private void reserve(final ProviderArgument arg, final Holder<String> connectionIdHolder,
            final String globalReservationId, final String description,
            final ReservationRequestCriteriaType criteria) throws ServiceException {
        // check required fields
        if (criteria.getSchedule() == null) {
            throw NSIExceptionUtil
                    .makeServiceException(ErrorID.MISSING_PARAMETER, null, "schedule");
        }
        //
        final String connectionId = NSIUtil.getNewConnectionID();
        logger.info("assign connectionId=" + connectionId + " for correlationId="
                + arg.header().getCorrelationId());
        if (criteria.getVersion() == null) {
            criteria.setVersion(NSIConstants.INITIAL_VERSION);
            logger.info("set initial version=" + criteria.getVersion() + " for connectionId="
                    + connectionId);
        }
        if (criteria.getSchedule().getStartTime() == null) {
            criteria.getSchedule().setStartTime(Calendar.getInstance());
            logger.info("set start time="
                    + String.format(Locale.US, "%tc", criteria.getSchedule().getStartTime())
                    + " for connectionId=" + connectionId);
        }
        checkReservationCriteria(criteria, connectionId);
        final StateMachine sm = smMgr.makeNewStateMachine(connectionId);
        sm.checkResevationOK(arg, connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.reservation(arg, connectionId, globalReservationId, description, criteria,
                            true);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
        // must be set after success
        connectionIdHolder.value = connectionId;
    }

    private void modify(final ProviderArgument arg, Holder<String> connectionIdHolder,
            final String globalReservationId, final String description,
            final ReservationRequestCriteriaType criteria) throws ServiceException {
        final String connectionId = connectionIdHolder.value;
        if (criteria.getVersion() == null) {
            criteria.setVersion(NSIConstants.INITIAL_VERSION);
        }
        checkReservationCriteria(criteria, connectionId);
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        if (sm.getCurrentVersion() >= criteria.getVersion()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNSUPPORTED_PARAMETER,
                    connectionId,
                    "cannot accept the request because current version=" + sm.getCurrentVersion()
                            + " >= criteria version=" + criteria.getVersion() + ", connId="
                            + connectionId);
        }
        sm.checkResevationOK(arg, connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.reservation(arg, connectionId, globalReservationId, description, criteria,
                            false);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    @Override
    public synchronized void reserve(Holder<String> connectionIdHolder,
            final String globalReservationId, final String description,
            final ReservationRequestCriteriaType criteria) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), globalReservationId,
                description, connectionIdHolder, criteria), "ReserveRequest", true));
        if (connectionIdHolder.value == null) {
            logger.info("try creating new reservation");
            reserve(arg, connectionIdHolder, globalReservationId, description, criteria);
        } else {
            logger.info("try reservation modification");
            modify(arg, connectionIdHolder, globalReservationId, description, criteria);
        }
    }

    @Override
    public void reserveCommit(final String connectionId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ReserveCommit", true));
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.reserveCommit(arg, connectionId);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    @Override
    public void reserveAbort(final String connectionId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "ReserveAbort", true));
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.reserveAbort(arg, connectionId);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    @Override
    public void provision(final String connectionId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "Provision", true));
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        sm.checkProvisionOK(arg, connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.provision(arg, connectionId);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    @Override
    public void release(final String connectionId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId), "Release",
                true));
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        sm.checkReleaseOK(arg, connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.release(arg, connectionId);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    @Override
    public void terminate(final String connectionId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId),
                "Terminate", true));
        final StateMachine sm = smMgr.getStateMachine(connectionId);
        sm.checkTerminateOK(arg, connectionId);
        arg.setStateMachine(sm);
        new Thread() {
            public void run() {
                try {
                    sm.terminate(arg, connectionId);
                    smMgr.deleteStateMachine(connectionId);
                } catch (Exception e) {
                    logger.warn(e);
                }
            }
        }.start();
    }

    private ChildRecursiveType sumary2recursive(QuerySummaryResultType summary,
            QuerySummaryResultCriteriaType criteria, ChildSummaryType child) {
        if (child == null) {
            return null;
        }
        ChildRecursiveType result = new ChildRecursiveType();
        result.setConnectionId(child.getConnectionId());
        result.setProviderNSA(child.getProviderNSA());
        result.setConnectionStates(summary.getConnectionStates());
        QueryRecursiveResultCriteriaType recCrit = new QueryRecursiveResultCriteriaType();
        result.getCriteria().add(recCrit);
        recCrit.setSchedule(criteria.getSchedule());
        recCrit.setServiceType(criteria.getServiceType());
        recCrit.getAny().addAll(child.getAny());
        recCrit.setVersion(criteria.getVersion());
        recCrit.getOtherAttributes().putAll(child.getOtherAttributes());
        result.setOrder(child.getOrder());
        return result;
    }

    protected ChildRecursiveListType makeChildRecursiveListType(QuerySummaryResultType summary,
            QuerySummaryResultCriteriaType criteria, ChildSummaryListType children) {
        if (children == null) {
            return null;
        }
        ChildRecursiveListType result = new ChildRecursiveListType();
        for (ChildSummaryType child : children.getChild()) {
            result.getChild().add(sumary2recursive(summary, criteria, child));
        }
        return result;
    }

    protected QueryRecursiveResultCriteriaType makeQueryRecursiveResultCriteriaType(
            QuerySummaryResultType summary, QuerySummaryResultCriteriaType criteria) {
        QueryRecursiveResultCriteriaType result = new QueryRecursiveResultCriteriaType();
        result.setSchedule(criteria.getSchedule());
        result.setServiceType(criteria.getServiceType());
        result.setChildren(makeChildRecursiveListType(summary, criteria, criteria.getChildren()));
        result.getAny().addAll(criteria.getAny());
        result.setVersion(criteria.getVersion());
        result.getOtherAttributes().putAll(criteria.getOtherAttributes());
        return result;
    }

    protected QueryRecursiveResultType makeQueryRecursiveResultType(QuerySummaryResultType summary) {
        QueryRecursiveResultType recursive = new QueryRecursiveResultType();
        recursive.setConnectionId(summary.getConnectionId());
        recursive.setGlobalReservationId(summary.getGlobalReservationId());
        recursive.setDescription(summary.getDescription());
        for (QuerySummaryResultCriteriaType criteria : summary.getCriteria()) {
            recursive.getCriteria().add(makeQueryRecursiveResultCriteriaType(summary, criteria));
        }
        recursive.setRequesterNSA(summary.getRequesterNSA());
        recursive.setConnectionStates(summary.getConnectionStates());
        recursive.setNotificationId(summary.getNotificationId());
        return recursive;
    }

    protected List<QueryRecursiveResultType> makeQueryRecursiveResultList(
            QuerySummaryConfirmedType confirmed) {
        List<QueryRecursiveResultType> result = new ArrayList<QueryRecursiveResultType>();
        for (QuerySummaryResultType summary : confirmed.getReservation()) {
            result.add(makeQueryRecursiveResultType(summary));
        }
        return result;
    }

    @Override
    public GenericAcknowledgmentType queryRecursive(final QueryType queryRecursive)
            throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), queryRecursive),
                "QueryRecursive", true));
        new Thread() {
            public void run() {
                try {
                    QuerySummaryConfirmedType confirmed = querySummarySync(arg, queryRecursive);
                    List<QueryRecursiveResultType> reservation =
                            makeQueryRecursiveResultList(confirmed);
                    provHandler.sendQueryRecursiveConfirmed(arg, reservation);
                } catch (Exception e) {
                    logger.warn(e);
                    provHandler.sendQueryRecursiveFailed(arg, e);
                }
            }
        }.start();
        return new GenericAcknowledgmentType();
    }

    private QuerySummaryConfirmedType querySummarySync(ProviderArgument arg, QueryType queryType)
            throws ServiceException {
        List<StateMachine> smList =
                smMgr.getStateMachines(queryType.getConnectionId(),
                        queryType.getGlobalReservationId(), arg.header().getRequesterNSA());
        QuerySummaryConfirmedType confirm = new QuerySummaryConfirmedType();
        for (StateMachine sm : smList) {
            try {
                QuerySummaryResultType summary =
                        provHandler.querySummary(arg, smMgr, sm.getConnectionId());
                confirm.getReservation().add(summary);
            } catch (Exception e) {
                logger.warn(e);
            }
        }
        return confirm;
    }

    @Override
    public GenericAcknowledgmentType querySummary(final QueryType queryType)
            throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), queryType),
                "QuerySummary", true));
        new Thread() {
            public void run() {
                try {
                    QuerySummaryConfirmedType confirmed = querySummarySync(arg, queryType);
                    provHandler.sendQuerySummaryConfirmed(arg, confirmed.getReservation());
                } catch (Exception e) {
                    logger.warn(e);
                    provHandler.sendQuerySummaryFailed(arg, e);
                }
            }
        }.start();
        return new GenericAcknowledgmentType();
    }

    @Override
    public QuerySummaryConfirmedType querySummarySync(QueryType querySummarySync) throws Error {
        // TODO Auto-generated method stub
        final ProviderArgument arg = new ProviderArgument(context);
        try {
            return querySummarySync(arg, querySummarySync);
        } catch (Exception e) {
            logger.warn(e);
            throw new Error(e.getMessage(), e);
        }
    }

    private QueryNotificationConfirmedType makeQueryNotificationConfirmed(String connectionId,
            Long startNotificationId, Long endNotificationId) throws ServiceException {
        List<NotificationBaseType> list;
        list = smMgr.queryNotifications(connectionId, startNotificationId, endNotificationId);
        QueryNotificationConfirmedType conf = new QueryNotificationConfirmedType();
        conf.getErrorEventOrReserveTimeoutOrDataPlaneStateChange().addAll(list);
        return conf;
    }

    @Override
    public QueryNotificationConfirmedType queryNotificationSync(
            QueryNotificationType queryNotificationSync) throws Error {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(),
                queryNotificationSync.getConnectionId(),
                queryNotificationSync.getStartNotificationId(),
                queryNotificationSync.getEndNotificationId()), "QueryNotificationSync", true));
        try {
            return makeQueryNotificationConfirmed(queryNotificationSync.getConnectionId(),
                    queryNotificationSync.getStartNotificationId(),
                    queryNotificationSync.getEndNotificationId());
        } catch (ServiceException e) {
            logger.warn(e);
            throw new Error(e.getMessage());
        }
    }

    @Override
    public void queryNotification(final String connectionId, final Long startNotificationId,
            final Long endNotificationId) throws ServiceException {
        final ProviderArgument arg = new ProviderArgument(context);
        logger.info(NSITextDump.addTab(NSITextDump.toString(arg.header(), connectionId,
                startNotificationId, endNotificationId), "QueryNotification", true));
        new Thread() {
            public void run() {
                try {
                    QueryNotificationConfirmedType confirmed =
                            makeQueryNotificationConfirmed(connectionId, startNotificationId,
                                    endNotificationId);
                    provHandler.sendQueryNotificationConfirmed(arg, confirmed);
                } catch (Exception e) {
                    logger.warn(e);
                    if (e instanceof ServiceException) {
                        provHandler.sendQueryNotificationFailed(arg,
                                ((ServiceException) e).getFaultInfo());
                    } else {
                        ServiceExceptionType ex =
                                NSIExceptionUtil.makeServiceExceptionType(ErrorID.INTERNAL_ERROR,
                                        connectionId, e.getMessage());
                        provHandler.sendQueryNotificationFailed(arg, ex);
                    }
                }
            }
        }.start();
    }

    @Override
    public List<QueryResultResponseType> queryResultSync(String connectionId, Long startResultId,
            Long endResultId) throws Error {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void queryResult(String connectionId, Long startResultId, Long endResultId)
            throws ServiceException {
        // TODO Auto-generated method stub

    }

    private static void publish(String[] args) throws Exception {
        String url =
                (args.length > 0 ? args[0]
                        : "http://127.0.0.1:28080/provider/services/ConnectionProvider");
        ConnectionProviderPort implementor = new SampleProvider();
        SecurityUtil.publish(url, implementor);
        System.out.println("Starting Server at " + url);
    }

    public static void main(String args[]) throws Exception {
        publish(args);
        Thread.sleep(10 * 3600 * 1000L); // 10 hours
        System.out.println("Server exiting");
    }

}
