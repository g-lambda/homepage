// アプリ用変数
var App = {
	portToNsa: {},			// portからnsaを引き当てる
	nsaToPosition: {},		// nsaからpositionを引き当てる
	reservationColor: {},	// 予約に対応したカラーを管理する
	object: {},					// トポロジ、デバイス、ラベル、リレーションのオブジェクト
	path: {						// 予約をマップビュー上に表示させる情報
		/*
		aist.go.jp:2013:bi-ps-aist.go.jp:2013:term:server: [
		    {
		    	id: "C=urn:uuid:2ad965b4-1b3c-41d3-a525-e7278a50aebe, G=, D=, V=1780",
		    	status: "ACTIVATED"
		    }
		]
		*/
	},
	jqplot: null,
	viewed: {},
	polling: null
};

$(function(){

	// Viewerエリアを非表示にする
	$('#viewer').css('display', 'none');

	// ログインモーダルを表示する
	$('#modal-login').modal({backdrop: false}).modal('show');

	// 設定ファイルを取得する
	$.when(
		$.getJSON('setting/color.json'),
		$.getJSON('setting/general.json'),
		$.getJSON('setting/layout.json'),
		$.getJSON('setting/topology.json')
	)
	.then(
		function(color, general, layout, topology) {
			// 設定ファイルを格納する
			App = $.extend(App, color[0], general[0], layout[0], topology[0]);
			// Viewer名を反映させる
			$('title').html(App.layout.title);
			$('.navbar-brand').html(App.layout.title);
		},
		function(){
			// アラートモーダル表示
			$('#alert-name').empty().html('error! json parse failed.');
			$('#myAlert').modal('show');
		}
	);

	// ログインボタン押下時
	$('#submit-login').on('click', function(){
		if($('#form-login')[0].checkValidity()) {
			var btn = $(this);
			btn.prop('disabled', true);

			$.ajax({
				type: 'POST',
				url: App.general.endPoint.login,
				data: {
					'user': $('#user').val(),
					'password': $('#password').val()
				},
				cache: false,
				dataType: 'json'
			})
			.done(function(res){
				if(res){
					// ログイン画面非表示
					$('#login').css('display', 'none');
					$('#modal-login').modal('hide');
					$('#login-error-message').css('display', 'none');
					// メイン画面表示
					$('#viewer').css('display', '');
					// ログインユーザー名表示、ログアウトボタン表示
					$( '#navbar-right' )
						.append(
							$( '<li />' )
								.append(
									$( '<a />' )
										.css('color', '#ffffff')
										.html( ' ' + res.user.name )
										.prepend(
											$( '<i />' ).addClass('glyphicon glyphicon-user')
										)
								)
						)
						.append(
							$( '<form />' )
								.addClass('navbar-form navbar-left')
								.append(
									 $( '<button />' )
									 	.addClass('btn btn-default')
									 	.attr('id', 'btn-logout')
									 	.html(' Logout ')
									 	.prepend(
									 		$( '<i />' ).addClass('glyphicon glyphicon-log-out')
									 	)
								)
						);

					getReservation().then(
						function() {
							// マップビューを初期化する
							initMapView();
							// トポロジ、デバイスを作成する
							initTopology();
							// portからnsaを引き当てる配列を作成する
							initPortToNsaArray();
							// nsaから座標を引き当てる配列を作成する
							initNsaToPositionArray();
							// リレーションを作成する, pathへポート名ペアをキーに配列を格納する
							initRelation();
							// アニメーションを開始する
							startAnimation();
							// ポーリングを開始する
							polling();

							// 最小化された際にはポーリングをストップ、再表示された場合に再開
							document.addEventListener("visibilitychange", function() {
								console.log(document.hidden, document.visibilityState);
								if( document.hidden ){
									clearTimeout( App.polling );
									App.polling = null;
									console.log("*** stop polling");
								}else{
									polling();
									console.log("*** restart polling ");
								}
							}, false);

							// ウィンドウリサイズイベントに処理を追加
							window.addEventListener('resize', function() {

								// マップビューのサイズ調整
								var width = $('#mapview').width();
								var height = $('#mapview').height();
								App.mapview.renderer.setSize(width, height);

								// layoutの座標からX軸、Y軸の最大値を取得する
								var xMax = 0;
								var yMax = 0;
								$.each(App.layout.mapview.topology, function(key, value) {
									if( value.position.x > xMax){
										xMax = value.position.x;
									}
									if( value.position.y > yMax){
										yMax = value.position.y;
									}
								});
								var distance = App.layout.mapview.nodeDistance;
								var cameraWidth = (xMax * distance) / 2;
								var aspect = height / width;
								var cameraHeight = aspect * cameraWidth;

								App.mapview.camera.left = -cameraWidth;
								App.mapview.camera.right = cameraWidth;
								App.mapview.camera.top = cameraHeight;
								App.mapview.camera.bottom = -cameraHeight;

								App.mapview.camera.updateProjectionMatrix();
								// タイムラインのサイズ調整
								App.jqplot.replot();
							}, false );
						},
						function(){
							console.log('warning! getReservation faild!');
						}
					);

				}else{
					$('#login-error-message').css('display', '');
				}

			}).fail(function(){
				$('#login-error-message').css('display', '');
			}).always(function () {
				btn.prop('disabled', false);
			});

		}else{
			$('#login-error-message').css('display', '');
		}
	});

	// ログアウトボタン
	$( document ).on('click', '#btn-logout', function(){
		var btn = $(this);
		btn.prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: App.general.endPoint.logout,
			cache: false
		})
		.done(function(){
			// ポーリング停止
			clearTimeout(App.polling);
			App.polling = null;
			// ログイン情報をクリア
			App.reservationColor = null;
			App.reservationColor = {};
			$.each( App.path, function(key, value) {
				App.path[key] = null;
				App.path[key] = [];
			});
			removeViewed( App.viewed );
			$( '#navbar-right' ).empty();
			$( '#mapview' ).empty();
			$( '#list-table' ).empty();
			$( '#plot' ).empty();
			// ログイン画面表示
			$('#login').css('display', '');
			$('#modal-login').modal('show');
			// ユーザー、パスワードクリア
			$('#user').val('');
			$('#password').val('');
			// メイン画面非表示
			$('#viewer').css('display', 'none');
		}).fail(function(res){
			// アラートモーダル表示
			var status = res.statusText;
			var response = res.responseText;
			$('#alert-name').empty().html(status + '<br>' + response);
			$('#myAlert').modal('show');
		}).always(function () {
			btn.prop('disabled', false);
		});
	});

	// 一覧表のセルにマウスオーバー時
	$( document ).on('mouseover', '.reservation-tr', function(){

		// ハイライト色を一覧表へ適用する
		var targetId = $(this).attr('id');
		var selectedColor = App.reservationColor[ targetId ]['selected'];
		$(this).css('background', selectedColor);

		// ハイライト色をタイムラインへ適用する
		var series = [];
		$.each( App.reservationIDMap, function( key, reservationIDMap ) {
			$.each( reservationIDMap.resourceSet, function( key, resourceSet ) {

				var resourceSetId = resourceSet.id;
				if( resourceSetId === null ) return true;

				$.each( resourceSet.networkResource, function( key, networkResource ) {
					$.each( networkResource.path, function( key, path ) {

						if( path.startTime === null || path.endTime === null ) return true;

						var timelineColor = App.color.error;
						if( isset( App.reservationColor[ resourceSetId ][ path.reservationStatus.toLowerCase() ] ) ){
							timelineColor = App.reservationColor[ resourceSetId ][ path.reservationStatus.toLowerCase() ];
						}

						// マウスオーバーした予約IDと一致する場合には選択色を取得する
						if( targetId === resourceSetId ) {
							timelineColor = selectedColor;
						}

						series.push(timelineColor);
					});
				});
			});
		});

		$.each( series.reverse(), function( key, value ) {
			App.jqplot.series[key].renderer.shapeRenderer.strokeStyle = value;
			App.jqplot.series[key].markerRenderer.shapeRenderer.strokeStyle = value;
			App.jqplot.series[key].markerRenderer.shapeRenderer.fillStyle = value;
		});
		App.jqplot.replot();

		// ハイライト色をマップビューの予約線に適用する
		if( isset(App.viewed[ targetId ]) ){
			$.each( App.viewed[ targetId ], function( key, value ) {
				App.viewed[ targetId ][key].material.color = new THREE.Color( selectedColor );
			});
		}
	});

	$( document ).on('mouseout', '.reservation-tr', function(){

		// アクティブ色を一覧表へ適用する（一覧表は常にアクティブ色）
		var targetId = $(this).attr('id');
		$(this).css('background', App.reservationColor[ targetId ]['active']);

		// ステータスに適した色をタイムラインへ適用する
		var series = [];
		$.each( App.reservationIDMap, function( key, reservationIDMap ) {
			$.each( reservationIDMap.resourceSet, function( key, resourceSet ) {

				var resourceSetId = resourceSet.id;
				if( resourceSetId === null ) return true;

				$.each( resourceSet.networkResource, function( key, networkResource ) {
					$.each( networkResource.path, function( key, path ) {

						if( path.startTime === null || path.endTime === null ) return true;

						var timelineColor = App.color.error;
						if( isset( App.reservationColor[ resourceSetId ][ path.reservationStatus.toLowerCase() ] ) ){
							timelineColor = App.reservationColor[ resourceSetId ][ path.reservationStatus.toLowerCase() ];
						}

						series.push(timelineColor);
					});
				});
			});
		});

		$.each( series.reverse(), function( key, value ) {
			App.jqplot.series[key].renderer.shapeRenderer.strokeStyle = value;
			App.jqplot.series[key].markerRenderer.shapeRenderer.strokeStyle = value;
			App.jqplot.series[key].markerRenderer.shapeRenderer.fillStyle = value;
		});
		App.jqplot.replot();

		// アクティブ色をマップビューの予約線に適用する（active, inactiveはアクティブ色）
		if( isset(App.viewed[ targetId ]) ){
			$.each( App.viewed[ targetId ], function( key, value ) {
				App.viewed[ targetId ][key].material.color = new THREE.Color( App.reservationColor[ targetId ]['active'] );
			});
		}
	});

	// アラートモーダルOKボタン
	$('#btn-alert-ok').on('click', function(){
		console.log('#btn-alert-ok');
		$('#myAlert').modal('hide');
	});

	window.onunload = function () {
		// 処理不要
		// イベントのみ存在するだけでキャッシュメモリを無効化
	}

});



// 予約を表示する
function showPath(){
	console.log('showPath');

	$.each( App.path, function( key, path ) {
		$.each( path, function( key, value ) {

			var nsaA = portToNsa(value.APoint);
			var nsaZ = portToNsa(value.ZPoint);

			var positionA = nsaToPosition(nsaA).clone();
			var positionZ = nsaToPosition(nsaZ).clone();
			positionA.z = -10;
			positionZ.z = -10;

			//頂点座標の追加
			var lineGeo = new THREE.Geometry();
			lineGeo.vertices.push( positionA );
			lineGeo.vertices.push( positionZ );

			// 複数登録してある場合にはずらす
			if( key > 9 ){
				console.log('warning! path limit.');
				return true;
			}
			if( key > 0 ){
				var mod = key % 2;
				if ( lineGeo.vertices[0].x === lineGeo.vertices[1].x ){
					if( mod !== 0 ){
						lineGeo.vertices[0].x = lineGeo.vertices[0].x + 10 * Math.round(key / 2);
						lineGeo.vertices[1].x = lineGeo.vertices[1].x + 10 * Math.round(key / 2);
					}else{
						lineGeo.vertices[0].x = lineGeo.vertices[0].x - 10 * (key / 2);
						lineGeo.vertices[1].x = lineGeo.vertices[1].x - 10 * (key / 2);
					}
				}else{
					if( mod !== 0 ){
						lineGeo.vertices[0].y = lineGeo.vertices[0].y + 10 * Math.round(key / 2);
						lineGeo.vertices[1].y = lineGeo.vertices[1].y + 10 * Math.round(key / 2);
					}else{
						lineGeo.vertices[0].y = lineGeo.vertices[0].y - 10 * (key / 2);
						lineGeo.vertices[1].y = lineGeo.vertices[1].y - 10 * (key / 2);
					}
				}
			}

			// ステータスを見て、実線、破線、輝度を選択する
			var param = {};
			var color = App.reservationColor[value.id][value.status.toLowerCase()];
			param.color = new THREE.Color( color );

			if( App.layout.mapview.renderMode === 'webgl' ){
				param.dashSize = 2;
				param.gapSize = 2;
			}else{
				param.linewidth = App.layout.mapview.reservationLineWidth;
				param.dashSize = 1;
				param.gapSize = 5;
			}

			var line = null;
			switch( value.status ){
				case 'INACTIVE' :
					lineGeo.computeLineDistances();
					line = new THREE.Line( lineGeo, new THREE.LineDashedMaterial( param ) );
					break;
				case 'ACTIVE' :
					line = new THREE.Line( lineGeo, new THREE.LineBasicMaterial( param ) );
					break;
				default:
					break;
			}

			// inactive, active以外はマップビューにパスを引かない
			if( line === null ) return true;

			// 格納する
			if( !isset(App.viewed[value.id]) ) App.viewed[value.id] = {};
			var pathName = value.APoint + '-' + value.ZPoint;
			App.viewed[value.id][pathName] = line;

			// 表示する
			App.mapview.scene.add( App.viewed[value.id][pathName] );
		});
	});
}

//メニューを表示する
function showMenu(){
	console.log('showMenu');

	var plot = {
		data: [],
		series: []
	};

	// リストをクリアする
	$('#list-table').empty();

	var cntTimeLine = 0;

	if( !isset(App.reservationIDMap) || App.reservationIDMap == null ) return;
	$.each( App.reservationIDMap, function( key, reservationIDMap ) {

		var cntResourceSet = reservationIDMap.resourceSet.length;

		$.each( reservationIDMap.resourceSet, function( key, resourceSet ) {

			var id = resourceSet.id;

			// 予約カラーをセットする
			var num = cntResourceSet - (key + 1);
			var color = App.color.list[num];
			App.reservationColor[id] = {
				reserved: ctrlBrightness(color, -100),
				inactive: color,
				active: color,
				released: ctrlBrightness(color, -100),
				selected: ctrlBrightness(color, 100)
			};

			// タイムライン用のデータ、レイアウトを作成する
			var statusError = true;
			$.each( resourceSet.networkResource, function( key, networkResource ) {
				$.each( networkResource.path, function( key, path ) {


					//
					// マップビューに予約のパスを引くための情報をApp.pathに格納する
					//

					// リレーション作成時に設定したpathのリストに該当するポイント名ペアがあるか
					var AZpoint = null;
					if( isset( App.path[path.APoint + '-' + path.ZPoint] ) ){
						AZpoint = path.APoint + '-' + path.ZPoint;
					}else if( isset( App.path[path.ZPoint + '-' + path.APoint]  ) ){
						AZpoint = path.ZPoint + '-' + path.APoint;
					}else{
						console.log('worning! AZpoint not found.');
						console.log(path.APoint);
						console.log(path.ZPoint);
						//return true;
					}
					// APoint, ZPointのパスが存在する
					if( AZpoint !== null ){
						// Active, InActiveのみ線を表示する
						if( path.reservationStatus === 'INACTIVE' || path.reservationStatus === 'ACTIVE' ){
							App.path[AZpoint].push(
								{
									id: id,
									status: path.reservationStatus,
									APoint: path.APoint,
									ZPoint: path.ZPoint
								}
							);
						}
					}
					//
					// マップビューに予約のパスを引くための情報をApp.pathに格納する ここまで
					//

					if( path.startTime === null || path.endTime === null ){
						console.log('warning! time not found.');
						return true;
					}

					// タイムゾーン（'+09:00'）を追加した
					// chromeは必要、firefox、ieは必要なかったがつけても正常。
					var start = new Date(path.startTime + '+09:00').format('{yyyy}/{MM}/{dd} {24hr}:{mm}').toString();
					var end = new Date(path.endTime).format('{yyyy}/{MM}/{dd} {24hr}:{mm}').toString();

					// Vlanを表示するか否か
					var label;
					cntTimeLine++;	// ラベル末尾にカウントを追加してユニーク名を作成する
					if( App.layout.timeline.showVlanLabel ){
						label = path.srcLocal + ' - ' + path.dstLocal + ', ' + path.srcVlan + ' - ' + path.dstVlan + ', ' + path.capacity + 'Mbps, ' + cntTimeLine;
					}else{
						label = path.srcLocal + ' - ' + path.dstLocal + ', ' + path.capacity + 'Mbps, ' + cntTimeLine;
					}

					// タイムラインのデータをセットする
					plot['data'].push([[start, label], [end, label]]);

					// タイムラインのレイアウトをセットする
					var timelineColor;
					if( isset( App.reservationColor[id][ path.reservationStatus.toLowerCase() ] ) ){
						timelineColor = App.reservationColor[id][ path.reservationStatus.toLowerCase() ];
						// 1件でもステータスerrorがなければ一覧表はerror色にしない
						statusError = false;
					}else{
						// errorの場合
						timelineColor = App.color.error;
					}

					var style = {
							showMarker: true,
							lineWidth: 12,
							color: timelineColor,
						};
					plot['series'].push(style);

				});
			});

			// pathのステータスが全てerrorだった場合にはerror色を表示する
			var backgroundColor;
			if( statusError ){
				backgroundColor = App.color.error;
				App.reservationColor[id] = {
					active: App.color.error,
					selected: ctrlBrightness(App.color.error, 50)
				};
			}else{
				backgroundColor = App.reservationColor[id].active;
			}

			// 一覧表に行を追加する
			$('#list-table')
			.append(
				$('<tr />')
				.addClass('reservation-tr')
				.attr('id', id)
				.css('background', backgroundColor )
				.css('font-size', '10px')
				.append(
					$('<td style="white-space: nowrap; padding-top: 2px; padding-bottom: 2px;" />')
					.html( id )
				)
			);

		});
	});


	// タイムラインを表示する
	// 縦ドットライン用の現在時刻
	var verticalLinePosition = new $.jsDate( Date.create().format('{yyyy}/{MM}/{dd} {24hr}:{mm}') ).getTime();
	// 取得時刻スタート
	var minTime = Date.create().addMinutes( App.layout.timeline.startMin ).format('{yyyy}/{MM}/{dd} {24hr}:{mm}').toString();
	// 取得時刻エンド
	var maxTime = Date.create().addMinutes( App.layout.timeline.endMin ).format('{yyyy}/{MM}/{dd} {24hr}:{mm}').toString();

	// 表示用オプションデータを作成する
	var options = {
		seriesDefaults: {
			showMarker: true,
			xaxis: 'x2axis',
		},
		axes : {
			x2axis : {
				renderer : $.jqplot.DateAxisRenderer,
				tickOptions : {
					formatString : '%H:%M'
				},
				min: minTime,
				max: maxTime,
				tickInterval: App.layout.timeline.tickInterval
			},
			yaxis : {
				renderer: $.jqplot.CategoryAxisRenderer
			}
		},
		canvasOverlay: {
			show: true,
			objects: [
				{
					dashedVerticalLine: {
						xaxis: 'x2axis',
						x: verticalLinePosition,
						lineWidth: 2,
						color: 'red',
						shadow: false,
						dashPattern: [ 2, 4 ]
					}
				}
			]
		}
	};

	// 表示用データ数にあわせて高さを調整し、表を表示する
	if( plot.data.length === 0 ) return true;
	var height = 35 + plot.data.length * 20;
	$('#plot').css('height', height);

	options.series = plot.series.reverse();

	// タイムラインをクリアする
	if( isset(App.jqplot) && App.jqplot !== null ) {
		//$('#plot').empty();
		App.jqplot.destroy();
		App.jqplot = null;
		console.log('plot destroy');
	}

	App.jqplot = $.jqplot('plot', plot.data.reverse(),  options);	// 逆順にして一覧表順とあわせる

}

// 予約情報を取得する
function getReservation(){
	console.log('getReservation');

	var dfd = $.Deferred();

	$.ajax({
		type: 'GET',
		url: App.general.endPoint.reservation,
		dataType: 'json',
	})
	.done(function(res){
		console.log('success getReservation');
		console.log('res : ', res);

		App = $.extend(App, {reservationIDMap: res.reservationIDMap});

		dfd.resolve();
	})
	.fail(function(){
		console.log('faild getReservation');
		dfd.reject();
	})

	return dfd.promise();
}

// トポロジを作成する
function initTopology(){
	console.log('initTopology');

	var distance = App.layout.mapview.nodeDistance;
	$.each( App.topology, function(key, value) {

		// トポロジを作成する
		// 座標を取得する

		if( !isset(App.layout.mapview.topology[value.nsa]) ){
			// トポロジ名に該当する座標が無い場合にはスキップ
			console.log('warning! position not found. name : ' + value.nsa);
			return true;
		}

		var x = App.layout.mapview.topology[value.nsa].position.x * distance;
		var y = App.layout.mapview.topology[value.nsa].position.y * distance;

		var imgPath = App.general.endPoint.webroot + 'img/circle.png';
		var circle =  new THREE.Mesh(
			new THREE.PlaneGeometry(80, 80),
			new THREE.MeshBasicMaterial(
				{
					map: THREE.ImageUtils.loadTexture( imgPath ),
					transparent: true
				}
			)
		);
		circle.position = new THREE.Vector3( x, y, 0);
		var topologyName = value.nsa;
		App.object[topologyName] = circle;
		App.mapview.scene.add(App.object[topologyName]);

		// トポロジのラベルを作成する
		var canvas1 = document.createElement('canvas');
		var context1 = canvas1.getContext('2d');

		var labelText = value.name;
		var labelColor = '#000000';
		var labelFontSize = 32;
		var labelPositionX = 25;
		var labelPositionY = -30;

		// layout.jsonに設定がある場合には優先する
		if( isset( App.layout.mapview.topology[ value.nsa ] ) ){

			// text
			if( isset( App.layout.mapview.topology[ value.nsa ].label.text ) ){
				if( App.layout.mapview.topology[ value.nsa ].label.text !== null ){
					if( App.layout.mapview.topology[ value.nsa ].label.text !== "" ){
						labelText = App.layout.mapview.topology[ value.nsa ].label.text;
					}
				}
			}

			// color
			if( isset( App.layout.mapview.topology[ value.nsa ].label.color ) ){
				if( App.layout.mapview.topology[ value.nsa ].label.color !== null ){
					if( App.layout.mapview.topology[ value.nsa ].label.color !== "" ){
						labelColor = App.layout.mapview.topology[ value.nsa ].label.color;
					}
				}
			}

			// fontSize
			if( isset( App.layout.mapview.topology[ value.nsa ].label.fontSize ) ){
				if( App.layout.mapview.topology[ value.nsa ].label.fontSize !== null ){
					if( App.layout.mapview.topology[ value.nsa ].label.fontSize !== "" ){
						labelFontSize = App.layout.mapview.topology[ value.nsa ].label.fontSize;
					}
				}
			}

			// x
			if( isset( App.layout.mapview.topology[ value.nsa ].label.position.x ) ){
				if( App.layout.mapview.topology[ value.nsa ].label.position.x !== null ){
					if( App.layout.mapview.topology[ value.nsa ].label.position.x !== "" ){
						labelPositionX = App.layout.mapview.topology[ value.nsa ].label.position.x;
					}
				}
			}

			// y
			if( isset( App.layout.mapview.topology[ value.nsa ].label.position.y ) ){
				if( App.layout.mapview.topology[ value.nsa ].label.position.y !== null ){
					if( App.layout.mapview.topology[ value.nsa ].label.position.y !== "" ){
						labelPositionY = App.layout.mapview.topology[ value.nsa ].label.position.y;
					}
				}
			}
		}

		// 文字列とフォントによる幅を取得する
		context1.font = "Bold " + labelFontSize + "px Arial";
		var metrics = context1.measureText( labelText );
		var textHeight = labelFontSize * 1.5;

		// キャンバスの幅を変更する（設定がクリアされる）
		canvas1.width = metrics.width;
		canvas1.height = textHeight;

		// 再設定
		context1.font = "Bold " + labelFontSize + "px Arial";
		context1.fillStyle = labelColor;
		context1.fillText(labelText, 0, labelFontSize);

		var texture1 = new THREE.Texture(canvas1)
		texture1.needsUpdate = true;
		var material1 = new THREE.MeshBasicMaterial( {map: texture1} );
		material1.transparent = true;

		var mesh1 = new THREE.Mesh(
			new THREE.PlaneGeometry(canvas1.width, canvas1.height),
			material1
		);

		var labelX = x + (canvas1.width / 2) + labelPositionX;
		var labelY = y - (canvas1.height / 2) + labelPositionY;

		mesh1.position = new THREE.Vector3( labelX, labelY, 0);
		var labelName = value.nsa + '-label'
		App.object[labelName] = mesh1;
		App.mapview.scene.add(App.object[labelName]);

		// ターミナルを作成する
		if( value.terminal.length > 0 ){
			$.each( value.terminal, function(key, value) {
				// ターミナル情報の有無を調べる
				if( !isset(App.layout.mapview.terminal[value]) ){
					// ターミナルに該当する座標が無い場合にはスキップ
					console.log('warning! position not found. name : ' + value);
					return true;
				}
				// ターミナル画像オブジェクトを作成する
				var imgPath = App.general.endPoint.webroot + App.layout.mapview.terminal[value].img;
				var panel =  new THREE.Mesh(
					new THREE.PlaneGeometry(80, 80),
					new THREE.MeshBasicMaterial(
						{
							map: THREE.ImageUtils.loadTexture( imgPath ),
							transparent: true
						}
					)
				);
				// ターミナルに座標を設定する
				var x = App.layout.mapview.terminal[value].position.x * distance;
				var y = App.layout.mapview.terminal[value].position.y * distance;
				panel.position = new THREE.Vector3( x, y, 0);
				// 格納する
				App.object[value] = panel;
				App.mapview.scene.add(App.object[value]);
			});
		}
	});
}

// portからnsaを引き当てる配列を初期化する
// terminalはportとnsaを同一とする
function initPortToNsaArray(){
	$.each( App.topology, function(topologyKey, topologyValue) {
		$.each( topologyValue.port, function(portKey, portValue) {
			App.portToNsa[portValue] = topologyValue.nsa;
		});
		$.each( topologyValue.terminal, function(terminalKey, terminalValue) {
			App.portToNsa[terminalValue] = terminalValue;
		});
	});
}
function portToNsa(port){
	var result = null;
	if( isset(App.portToNsa[port]) ){
		result = App.portToNsa[port];
	}
	return result;
}

// nsa,terminalから座標を引き当てる配列を初期化する
function initNsaToPositionArray(){
	$.each( App.object, function(key, object) {
		App.nsaToPosition[key] = object.position;
	});
}
function nsaToPosition(nsa){
	var result = null;
	if( isset(App.nsaToPosition[nsa]) ){
		result = App.nsaToPosition[nsa];
	}
	return result;
}


// リレーションを作成する
function initRelation(){
	console.log('initRelation');

	$.each( App.relation, function(key, relation) {

		if( !isset(relation[0]) || !isset(relation[1]) ){
			console.log('warning! relation not found. key : ', key);
			return true;
		}

		var nsaSrc = portToNsa(relation[0]);
		var nsaDst = portToNsa(relation[1]);
		if( nsaSrc === null || nsaDst === null ){
			console.log('warning! portToNsa not found.');
			console.log(relation[0]);
			console.log(relation[1]);
			return true;
		}

		var positionSrc = nsaToPosition(nsaSrc).clone();
		var positionDst = nsaToPosition(nsaDst).clone();
		if( positionSrc === null || positionDst === null ){
			console.log('warning! nsaToPosition not found.');
			console.log(nsaSrc);
			console.log(nsaDst);
			return true;
		}
		// 高さを下げてノードと接触しないようにする
		positionSrc.z = -20;
		positionDst.z = -20;

		/*
		 *
		 * pathにポート名をつないだキーを配置する
		 *
		 */
		var pathName = relation[0] + '-' + relation[1];
		App.path[pathName] = [];

		//頂点座標の追加
		var lineGeo = new THREE.Geometry();
		lineGeo.vertices.push( positionSrc );
		lineGeo.vertices.push( positionDst );

		//線オブジェクトの生成
		var line = new THREE.Line( lineGeo, new THREE.LineBasicMaterial( { linewidth: 2, color: 0xeeeeee} ) );
		var lineName = relation[0] + '-' + relation[1];
		// 格納する
		App.object[lineName] = line;
		// 表示する
		App.mapview.scene.add(App.object[lineName]);
	});

}


// マップビューを初期化
function initMapView(){
	console.log('initMapView');

	// renderer
	var domid = 'mapview';
	var renderer;
	if( App.layout.mapview.renderMode === 'canvas' ){
		renderer = new THREE.CanvasRenderer();
	}else{
		renderer = new THREE.WebGLRenderer({antialias: true});
	}
	var width = document.getElementById(domid).clientWidth;
	var height = document.getElementById(domid).clientHeight;
	renderer.setSize(width, height);
	document.getElementById(domid).appendChild( renderer.domElement );
	renderer.setClearColor(0xffffff, 1.0);
	renderer.shadowMapEnabled = true;
	renderer.domElement.addEventListener( 'mousewheel', mousewheel, false );
	renderer.domElement.addEventListener( 'DOMMouseScroll', mousewheel, false ); // firefox

	// camera

	// レイアウトが画面に納まるように調整
	// layoutの座標からX軸、Y軸の最大値を取得する
	var xMax = 0;
	var yMax = 0;
	$.each(App.layout.mapview.topology, function(key, value) {
		if( value.position.x > xMax){
			xMax = value.position.x;
		}
		if( value.position.y > yMax){
			yMax = value.position.y;
		}
	});
	var distance = App.layout.mapview.nodeDistance;
	var cameraWidth = (xMax * distance) / 2;
	var aspect = height / width;
	var cameraHeight = aspect * cameraWidth;

	var cameraScale = App.layout.mapview.cameraPosition.z;

	var camera = new THREE.OrthographicCamera( -cameraWidth * cameraScale, cameraWidth * cameraScale, cameraHeight * cameraScale, -cameraHeight * cameraScale, 0.01, 10000 );
	camera.position.x = App.layout.mapview.cameraPosition.x * distance;
	camera.position.y = App.layout.mapview.cameraPosition.y * distance;
	camera.position.z = 1;

	// controls
	var controls = new THREE.OrbitControls( camera, renderer.domElement );
	controls.target.set(
		App.layout.mapview.cameraPosition.x * distance,
		App.layout.mapview.cameraPosition.y * distance,
		1
	);
	controls.noRotate = true;		// 回転無し

	// scene
	var scene = new THREE.Scene();

	// light
	var light = new THREE.DirectionalLight( 0xffffff, 1.5 );	// 白、強さ1
	light.position.set(50,100,50).normalize();	// (0,1,0)方向の無限遠から光が指す
	light.castShadow = true;
	scene.add( light );	// ＝ どの面に対しても(0,-1,0)方向の光が当たる

	// xyz軸 (補助線)
	//var axes = new THREE.AxisHelper(1000);
	//scene.add( axes );

	App.mapview = {camera: camera, controls: controls, scene: scene, renderer: renderer};
}

// アニメーションを開始する
function startAnimation() {
	window.requestAnimationFrame(startAnimation);
	App.mapview.controls.update();
	App.mapview.renderer.render( App.mapview.scene, App.mapview.camera);
}

var zoom = 0.02;
function mousewheel( event ) {
    event.preventDefault();
    event.stopPropagation();

    var delta = 0;

    if ( event.wheelDelta ) { // WebKit / Opera / Explorer 9
        delta = event.wheelDelta / 40;
    } else if ( event.detail ) { // Firefox
        delta = - event.detail / 3;
    }

    var width = App.mapview.camera.right / zoom;
    var height = App.mapview.camera.top / zoom;

	var temp = zoom - delta * 0.001;
	if( temp < 0) return;
	zoom = temp;

	App.mapview.camera.left = -zoom*width;
	App.mapview.camera.right = zoom*width;
	App.mapview.camera.top = zoom*height;
	App.mapview.camera.bottom = -zoom*height;

    App.mapview.camera.updateProjectionMatrix();
    App.mapview.renderer.render( App.mapview.scene, App.mapview.camera );

    //console.log('camera : ', App.mapview.camera);
    //console.log('controls : ', App.mapview.controls);
    // console.log('left : ' , App.mapview.camera.left);
    // console.log('right : ' , App.mapview.camera.right);
    //console.log('top : ' , App.mapview.camera.top);
    //console.log('bottom : ' , App.mapview.camera.bottom);
}

// ポーリング
function polling() {
	console.log('polling');

	getReservation()
	.done(function(){
		// App.reservationColorをクリアする
		App.reservationColor = null;
		App.reservationColor = {};
		// App.pathをクリアする
		$.each( App.path, function(key, value) {
			App.path[key] = null;
			App.path[key] = [];
		});
		// App.viewedをクリアする
		removeViewed( App.viewed );
		// メニューを表示する
		showMenu();
		// マップビューに予約パスを表示する
		showPath();

		console.log(App);
	})
	.fail(function(){
		console.log('warning! getReservation failed.');
	})
	.always(function(){

		App.polling = setTimeout(
			function() {
				polling();
			},
		App.general.pollingSec * 1000);

	});
}

function removeViewed( viewed ){
	console.log('removeViewed');

	if( viewed.length < 0 ) return;

	for(var id in viewed){
		for(var pathName in viewed[id]){
			viewed[id][pathName].geometry.dispose();
			viewed[id][pathName].material.dispose();
			App.mapview.scene.remove( viewed[id][pathName] );
			viewed[id][pathName] = null;
			delete viewed[id][pathName];
		}
		viewed[id] = null;
		delete viewed[id];
	}
	viewed = null;
	delete viewed;
}
