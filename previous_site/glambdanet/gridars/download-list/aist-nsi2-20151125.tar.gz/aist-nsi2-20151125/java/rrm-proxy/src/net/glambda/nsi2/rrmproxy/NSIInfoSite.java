/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.LifecycleStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;

import net.glambda.nsi2.util.NSIPortManager;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.nsi2.util.TypesBuilder;
import nsirrmproxy.NetworkResourceType;
import nsirrmproxy.ReservationIDMapType;
import nsirrmproxy.ReservationStatusType;
import nsirrmproxy.ResourceSetType;

public class NSIInfoSite implements InfoSite {

    protected static final Log logger = LogFactory.getLog(NSIInfoSite.class);

    private final String name;
    private final String providerUrl;
    private final ConnectionProviderPort provider;
    private final boolean shortStpName;

    private static final NSIPortManager portMgr = NSIPortManager.getInstance();

    private final CommonHeaderType provHeader;

    public NSIInfoSite(String propKey, RRMProxyProperties prop) throws Exception {
        this.name = prop.name(propKey);
        this.providerUrl = prop.providerUrl(propKey);
        this.provider = NSIUtil.getProviderPort(providerUrl);
        String reqNsa = prop.requesterNsa(propKey);
        if (reqNsa == null) {
            reqNsa = "";
        }
        this.provHeader =
                TypesBuilder.makeCommonHeaderType(reqNsa, prop.providerNsa(propKey), null);
        this.shortStpName = prop.shortStpName(propKey);
    }

    @Override
    public String name() {
        return name;
    }

    private static final Pattern STPNAME = Pattern.compile("urn:ogf:network:(.+)");

    static String shortStpName(String name) {
        Matcher m = STPNAME.matcher(name);
        if (m.find()) {
            return m.group(1);
        } else {
            return name;
        }
    }

    private String stp2simplename(String stp) {
        if (shortStpName) {
            return shortStpName(stp);
        } else {
            return stp;
        }
    }

    private static final String UNKNOWN_PROVIDER = "";

    private List<String> makeStpList(P2PServiceBaseType ether,
            QuerySummaryResultCriteriaType criteria) {
        List<String> list = new LinkedList<String>();
        ChildSummaryListType children = criteria.getChildren();
        if (children == null || children.getChild().isEmpty()) {
            list.add(ether.getSourceSTP());
            list.add(ether.getDestSTP());
            list.add(UNKNOWN_PROVIDER);
        } else {
            for (ChildSummaryType child : children.getChild()) {
                P2PServiceBaseType childEther;
                try {
                    childEther = TypesBuilder.getP2PServiceBaseType(child.getAny());
                    list.add(childEther.getSourceSTP());
                    list.add(childEther.getDestSTP());
                    list.add(child.getProviderNSA());
                } catch (ServiceException e) {
                    logger.warn(e);
                    list.clear();
                    list.add(ether.getSourceSTP());
                    list.add(ether.getDestSTP());
                    list.add(UNKNOWN_PROVIDER);
                    return list;
                }
            }
        }
        return list;
    }

    private String txt2txt(String txt) {
        return (txt != null ? txt : "");
    }

    private String summary2id(QuerySummaryResultType summary, P2PServiceBaseType ether) {
        return "C=" + txt2txt(summary.getConnectionId()) + ", G="
                + txt2txt(summary.getGlobalReservationId()) + ", D="
                + txt2txt(summary.getDescription()) + ", V="
                + TypesBuilder.getVlan(ether.getSourceSTP());
    }

    private nsirrmproxy.PathType makeRRMPath(String src, String dst, String net,
            QuerySummaryResultCriteriaType criteria, nsirrmproxy.ReservationStatusType status) {
        nsirrmproxy.PathType rrmPath = new nsirrmproxy.PathType();
        rrmPath.setStartTime(criteria.getSchedule().getStartTime());
        rrmPath.setEndTime(criteria.getSchedule().getEndTime());
        rrmPath.setReservationStatus(status);
        rrmPath.setSrcNet(net);
        rrmPath.setDstNet(net);
        rrmPath.setSrcLocal(src);
        rrmPath.setDstLocal(dst);
        P2PServiceBaseType ether;
        try {
            ether = TypesBuilder.getP2PServiceBaseType(criteria);
            rrmPath.setCapacity(ether.getCapacity());
            rrmPath.setSrcVlan(TypesBuilder.getVlan(src));
            rrmPath.setDstVlan(TypesBuilder.getVlan(dst));
            rrmPath.setAPoint(stp2simplename(src));
            rrmPath.setZPoint(stp2simplename(dst));
            // rrmPath.setAPoint(stp2simplename(src) + "@" +
            // rrmPath.getSrcVlan());
            // rrmPath.setZPoint(stp2simplename(dst) + "@" +
            // rrmPath.getDstVlan());
        } catch (ServiceException e) {
            logger.warn(e);
        }
        return rrmPath;
    }

    private nsirrmproxy.ReservationStatusType makeStatus(ConnectionStatesType connectionStates,
            ScheduleType schedule) {
        if (connectionStates.getReservationState() == ReservationStateEnumType.RESERVE_TIMEOUT) {
            return ReservationStatusType.ERROR;
        }
        if (connectionStates.getLifecycleState() == LifecycleStateEnumType.FAILED) {
            return ReservationStatusType.ERROR;
        }
        Calendar now = Calendar.getInstance();
        if (now.after(schedule.getEndTime())) {
            return ReservationStatusType.RELEASED;
        }
        if (now.before(schedule.getStartTime())) {
            return ReservationStatusType.RESERVED;
        }
        if (connectionStates.getDataPlaneStatus().isActive()) {
            return ReservationStatusType.ACTIVE;
        } else {
            return ReservationStatusType.INACTIVE;
        }
    }

    private ResourceSetType summary2rscset(QuerySummaryResultType summary, Calendar start,
            Calendar end) {
        if (summary.getCriteria().isEmpty()) {
            return null;
        }
        QuerySummaryResultCriteriaType criteria = summary.getCriteria().get(0);
        if (start != null && criteria.getSchedule().getEndTime().before(start)) {
            return null;
        }
        if (end != null && end.before(criteria.getSchedule().getStartTime())) {
            return null;
        }
        if (summary.getConnectionStates().getReservationState() == org.ogf.schemas.nsi._2013._12.connection.types.ReservationStateEnumType.RESERVE_FAILED) {
            return null;
        }
        if (summary.getConnectionStates().getLifecycleState() == LifecycleStateEnumType.TERMINATED) {
            return null;
        }
        P2PServiceBaseType ether;
        try {
            ether = TypesBuilder.getP2PServiceBaseType(criteria);
        } catch (ServiceException e) {
            logger.warn(e);
            return null;
        }
        //
        nsirrmproxy.ReservationStatusType status =
                makeStatus(summary.getConnectionStates(), criteria.getSchedule());
        NetworkResourceType netrsc = new NetworkResourceType();
        netrsc.setAPoint(stp2simplename(ether.getSourceSTP()));
        netrsc.setZPoint(stp2simplename(ether.getDestSTP()));
        netrsc.setGlobalReservationId(summary.getGlobalReservationId());
        netrsc.setDescription(summary.getDescription());
        netrsc.setConnectionId(summary.getConnectionId());
        netrsc.setSummaryPath(makeRRMPath(ether.getSourceSTP(), ether.getDestSTP(), null, criteria,
                status));
        netrsc.setRequesterNSA(summary.getRequesterNSA());
        netrsc.setReservationState(summary.getConnectionStates().getReservationState().name());
        netrsc.setProvisionState(summary.getConnectionStates().getProvisionState().name());
        netrsc.setLifecycleState(summary.getConnectionStates().getLifecycleState().name());
        DataPlaneStatusType ds = summary.getConnectionStates().getDataPlaneStatus();
        netrsc.setDataPlaneState(String.format("isAct=%s, ver=%d, isConsistent=%s",
                Boolean.toString(ds.isActive()), ds.getVersion(),
                Boolean.toString(ds.isVersionConsistent())));
        //
        List<String> stpList = makeStpList(ether, criteria);
        for (int i = 0; i < stpList.size(); i += 3) {
            netrsc.getPath().add(
                    makeRRMPath(stpList.get(i), stpList.get(i + 1), stpList.get(i + 2), criteria,
                            status));
        }
        netrsc.getSummaryPath().setSrcNet(netrsc.getPath().get(0).getSrcNet());
        netrsc.getSummaryPath().setDstNet(
                netrsc.getPath().get(netrsc.getPath().size() - 1).getDstNet());
        //
        ResourceSetType rscset = new ResourceSetType();
        rscset.getNetworkResource().add(netrsc);
        rscset.setId(summary2id(summary, ether));
        rscset.setDistinguishedName("");
        return rscset;
    }

    private static class ResourceSetTypeComp implements Comparator<ResourceSetType> {

        private Calendar startTime(ResourceSetType o) {
            return o.getNetworkResource().get(0).getSummaryPath().getStartTime();
        }

        private Calendar endTime(ResourceSetType o) {
            return o.getNetworkResource().get(0).getSummaryPath().getEndTime();
        }

        @Override
        public int compare(ResourceSetType o1, ResourceSetType o2) {
            // NOTE: reverse sort by start&endTime
            int r = startTime(o2).compareTo(startTime(o1));
            if (r != 0) {
                return r;
            }
            return endTime(o2).compareTo(endTime(o1));
        }

    }

    private ReservationIDMapType query2idmap(QuerySummaryConfirmedType conf, Calendar start,
            Calendar end) {
        ReservationIDMapType map = new ReservationIDMapType();
        map.setSched(name);
        map.setUrl(providerUrl);
        for (QuerySummaryResultType summary : conf.getReservation()) {
            try {
                ResourceSetType rscset = summary2rscset(summary, start, end);
                if (rscset != null) {
                    map.getResourceSet().add(rscset);
                }
            } catch (Exception e) {
                logger.warn(e);
            }
        }
        if (!map.getResourceSet().isEmpty()) {
            Collections.sort(map.getResourceSet(), new ResourceSetTypeComp());
        }
        return map;
    }

    private synchronized QuerySummaryConfirmedType query() {
        try {
            portMgr.setCommonHeader(provider, provHeader);
            return provider.querySummarySync(new QueryType());
        } catch (Exception e) {
            logger.warn(e);
            return null;
        }
    }

    @Override
    public ReservationIDMapType getReservationIdMap(Calendar start, Calendar end) throws Exception {
        QuerySummaryConfirmedType conf = query();
        if (conf != null) {
            logger.debug(NSITextDump.addTab(NSITextDump.toString(conf), conf, true));
            return query2idmap(conf, start, end);
        } else {
            ReservationIDMapType map = new ReservationIDMapType();
            map.setSched(name);
            map.setUrl(providerUrl);
            return map;
        }
    }

}
