/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nsirrmproxy;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import net.arnx.jsonic.JSONHint;


/**
 * <p>Java class for ReservationIDMaps_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReservationIDMaps_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="updateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="infoStartTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="infoEndTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element ref="{http://glambda/schema/2013/01/rrm}reservationIDMap" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReservationIDMaps_Type", propOrder = {
    "updateTime",
    "infoStartTime",
    "infoEndTime",
    "reservationIDMap"
})
public class ReservationIDMapsType {

    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar updateTime;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar infoStartTime;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar infoEndTime;
    protected List<ReservationIDMapType> reservationIDMap;

    /**
     * Gets the value of the updateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=0)
    public Calendar getUpdateTime() {
        return updateTime;
    }

    /**
     * Sets the value of the updateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateTime(Calendar value) {
        this.updateTime = value;
    }

    /**
     * Gets the value of the infoStartTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=1)
    public Calendar getInfoStartTime() {
        return infoStartTime;
    }

    /**
     * Sets the value of the infoStartTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInfoStartTime(Calendar value) {
        this.infoStartTime = value;
    }

    /**
     * Gets the value of the infoEndTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=2)
    public Calendar getInfoEndTime() {
        return infoEndTime;
    }

    /**
     * Sets the value of the infoEndTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInfoEndTime(Calendar value) {
        this.infoEndTime = value;
    }

    /**
     * Gets the value of the reservationIDMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reservationIDMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReservationIDMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReservationIDMapType }
     * 
     * 
     */
    @JSONHint(ordinal=3)
    public List<ReservationIDMapType> getReservationIDMap() {
        if (reservationIDMap == null) {
            reservationIDMap = new ArrayList<ReservationIDMapType>();
        }
        return this.reservationIDMap;
    }

    public void setReservationIDMap(List<ReservationIDMapType> reservationIDMap) {
        this.reservationIDMap = reservationIDMap;
    }

}
