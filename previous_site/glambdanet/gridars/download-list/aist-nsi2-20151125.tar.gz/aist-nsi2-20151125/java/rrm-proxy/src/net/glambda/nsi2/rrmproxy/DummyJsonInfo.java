/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.arnx.jsonic.JSON;
import nsirrmproxy.*;

public class DummyJsonInfo {

    private static final File DUMMY_DIR = new File("web", "dummy");
    private static final File DUMMY_INFO = new File(DUMMY_DIR, "info.json");

    protected static final Log logger = LogFactory.getLog(DummyJsonInfo.class);

    private ReservationIDMapsType getInfo() throws Exception {
        if (!DUMMY_INFO.exists()) {
            logger.warn("missing " + DUMMY_INFO.getAbsolutePath());
            return null;
        }
        FileInputStream in = null;
        try {
            in = new FileInputStream(DUMMY_INFO);
            // NOTE: 参照するフィールドには、get/set関数が必要。
            // xjc の生成ソースは、リスト型の set 関数がないので手作業で追加すること。
            // Eclipse の Source -> Generate Getters and Setters ... を使えばよい。
            // コンストラクタはなくてもよい。
            return JSON.decode(in, ReservationIDMapsType.class);
        } catch (Exception e) {
            logger.warn("cannot read " + DUMMY_INFO.getAbsolutePath(), e);
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    logger.warn(e.getMessage());
                }
            }
        }
    }

    private void dummycal(Calendar now, Calendar cal) {
        if (cal != null) {
            cal.set(Calendar.YEAR, now.get(Calendar.YEAR));
            cal.set(Calendar.MONTH, now.get(Calendar.MONTH));
            cal.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, now.get(Calendar.HOUR_OF_DAY));
        }
    }

    private void setDummyCal(PathType path, Calendar now) {
        if (path != null) {
            dummycal(now, path.getStartTime());
            dummycal(now, path.getEndTime());
        }
    }

    private void setDummyCal(ReservationIDMapsType maps) {
        if (maps == null) {
            return;
        }
        Calendar now = Calendar.getInstance();
        maps.setUpdateTime(now);
        Calendar start = (Calendar) now.clone();
        start.add(Calendar.MINUTE, -30);
        Calendar end = (Calendar) now.clone();
        end.add(Calendar.MINUTE, 60);
        maps.setInfoStartTime(start);
        maps.setInfoEndTime(end);
        //
        for (ReservationIDMapType map : maps.getReservationIDMap()) {
            for (ResourceSetType r : map.getResourceSet()) {
                for (NetworkResourceType n : r.getNetworkResource()) {
                    setDummyCal(n.getSummaryPath(), now);
                    for (PathType p : n.getPath()) {
                        setDummyCal(p, now);
                    }
                }
            }
        }
    }

    public String getJson() {
        ReservationIDMapsType maps;
        try {
            maps = getInfo();
        } catch (Exception e) {
            logger.warn(e);
            return "";
        }
        setDummyCal(maps);
        return JSONHandler.toJson(maps);
    }
}
