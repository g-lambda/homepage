/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nsirrmproxy;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the nsirrmproxy package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ReservationStatus_QNAME = new QName("http://glambda/schema/2013/01/rrm", "reservationStatus");
    private final static QName _ReservationIDMaps_QNAME = new QName("http://glambda/schema/2013/01/rrm", "reservationIDMaps");
    private final static QName _NetworkResource_QNAME = new QName("http://glambda/schema/2013/01/rrm", "networkResource");
    private final static QName _Path_QNAME = new QName("http://glambda/schema/2013/01/rrm", "path");
    private final static QName _ReservationIDMap_QNAME = new QName("http://glambda/schema/2013/01/rrm", "reservationIDMap");
    private final static QName _SummaryPath_QNAME = new QName("http://glambda/schema/2013/01/rrm", "summaryPath");
    private final static QName _ResourceSet_QNAME = new QName("http://glambda/schema/2013/01/rrm", "resourceSet");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: nsirrmproxy
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ResourceSetType }
     * 
     */
    public ResourceSetType createResourceSetType() {
        return new ResourceSetType();
    }

    /**
     * Create an instance of {@link ReservationIDMapType }
     * 
     */
    public ReservationIDMapType createReservationIDMapType() {
        return new ReservationIDMapType();
    }

    /**
     * Create an instance of {@link PathType }
     * 
     */
    public PathType createPathType() {
        return new PathType();
    }

    /**
     * Create an instance of {@link NetworkResourceType }
     * 
     */
    public NetworkResourceType createNetworkResourceType() {
        return new NetworkResourceType();
    }

    /**
     * Create an instance of {@link ReservationIDMapsType }
     * 
     */
    public ReservationIDMapsType createReservationIDMapsType() {
        return new ReservationIDMapsType();
    }

    /**
     * Create an instance of {@link ResourcesType }
     * 
     */
    public ResourcesType createResourcesType() {
        return new ResourcesType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReservationStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "reservationStatus")
    public JAXBElement<ReservationStatusType> createReservationStatus(ReservationStatusType value) {
        return new JAXBElement<ReservationStatusType>(_ReservationStatus_QNAME, ReservationStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReservationIDMapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "reservationIDMaps")
    public JAXBElement<ReservationIDMapsType> createReservationIDMaps(ReservationIDMapsType value) {
        return new JAXBElement<ReservationIDMapsType>(_ReservationIDMaps_QNAME, ReservationIDMapsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NetworkResourceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "networkResource")
    public JAXBElement<NetworkResourceType> createNetworkResource(NetworkResourceType value) {
        return new JAXBElement<NetworkResourceType>(_NetworkResource_QNAME, NetworkResourceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PathType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "path")
    public JAXBElement<PathType> createPath(PathType value) {
        return new JAXBElement<PathType>(_Path_QNAME, PathType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReservationIDMapType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "reservationIDMap")
    public JAXBElement<ReservationIDMapType> createReservationIDMap(ReservationIDMapType value) {
        return new JAXBElement<ReservationIDMapType>(_ReservationIDMap_QNAME, ReservationIDMapType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PathType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "summaryPath")
    public JAXBElement<PathType> createSummaryPath(PathType value) {
        return new JAXBElement<PathType>(_SummaryPath_QNAME, PathType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResourceSetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://glambda/schema/2013/01/rrm", name = "resourceSet")
    public JAXBElement<ResourceSetType> createResourceSet(ResourceSetType value) {
        return new JAXBElement<ResourceSetType>(_ResourceSet_QNAME, ResourceSetType.class, null, value);
    }

}
