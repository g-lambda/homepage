nsi2/java/rrm-proxy/web/setting/topology.json の生成

cd nsi2/java/topology/

# nsi2/java/topology/etc/master-dds.xml 更新（適宜最新版を取得する）
bin/getmasterdds.sh

# topology.json 生成
bin/dds2json.sh > ../rrm-proxy/web/setting/topology.json

- - - - - - - - - -

Webでネット接続画面が表示されればよし、表示されない場合は
新規端点・NSAの追加に対応して web/setting/layout.json を更新する。
Firefoxのデバッグコンソールで不正な名前がコンソールに出るので、それを
layout.json に追加する。
