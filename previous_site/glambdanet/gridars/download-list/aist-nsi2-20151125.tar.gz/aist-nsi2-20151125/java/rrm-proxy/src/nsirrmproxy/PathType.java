/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nsirrmproxy;

import java.util.Calendar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import net.arnx.jsonic.JSONHint;


/**
 * <p>Java class for Path_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Path_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="startTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="endTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element ref="{http://glambda/schema/2013/01/rrm}reservationStatus"/>
 *         &lt;element name="APoint" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ZPoint" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="capacity" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="srcNet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dstNet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcLocal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dstLocal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcVlan" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="dstVlan" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="domains" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Path_Type", propOrder = {
    "startTime",
    "endTime",
    "reservationStatus",
    "APoint",
    "ZPoint",
    "capacity",
    "srcNet",
    "dstNet",
    "srcLocal",
    "dstLocal",
    "srcVlan",
    "dstVlan",
    "domains"
})
public class PathType {

    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar startTime;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar endTime;
    @XmlElement(required = true)
    protected ReservationStatusType reservationStatus;
    @XmlElement(name = "APoint", required = true)
    protected String APoint;
    @XmlElement(name = "ZPoint", required = true)
    protected String ZPoint;
    protected long capacity;
    protected String srcNet;
    protected String dstNet;
    protected String srcLocal;
    protected String dstLocal;
    protected Integer srcVlan;
    protected Integer dstVlan;
    protected String domains;

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=0)
    public Calendar getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartTime(Calendar value) {
        this.startTime = value;
    }

    /**
     * Gets the value of the endTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=1)
    public Calendar getEndTime() {
        return endTime;
    }

    /**
     * Sets the value of the endTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndTime(Calendar value) {
        this.endTime = value;
    }

    /**
     * Gets the value of the reservationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ReservationStatusType }
     *     
     */
    @JSONHint(ordinal=2)
    public ReservationStatusType getReservationStatus() {
        return reservationStatus;
    }

    /**
     * Sets the value of the reservationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReservationStatusType }
     *     
     */
    public void setReservationStatus(ReservationStatusType value) {
        this.reservationStatus = value;
    }

    /**
     * Gets the value of the APoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=3)
    public String getAPoint() {
        return APoint;
    }

    /**
     * Sets the value of the APoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPoint(String value) {
        this.APoint = value;
    }

    /**
     * Gets the value of the ZPoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=4)
    public String getZPoint() {
        return ZPoint;
    }

    /**
     * Sets the value of the ZPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZPoint(String value) {
        this.ZPoint = value;
    }

    /**
     * Gets the value of the capacity property.
     * 
     */
    @JSONHint(ordinal=5)
    public long getCapacity() {
        return capacity;
    }

    /**
     * Sets the value of the capacity property.
     * 
     */
    public void setCapacity(long value) {
        this.capacity = value;
    }

    /**
     * Gets the value of the srcNet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=6)
    public String getSrcNet() {
        return srcNet;
    }

    /**
     * Sets the value of the srcNet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcNet(String value) {
        this.srcNet = value;
    }

    /**
     * Gets the value of the dstNet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=7)
    public String getDstNet() {
        return dstNet;
    }

    /**
     * Sets the value of the dstNet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstNet(String value) {
        this.dstNet = value;
    }

    /**
     * Gets the value of the srcLocal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=8)
    public String getSrcLocal() {
        return srcLocal;
    }

    /**
     * Sets the value of the srcLocal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcLocal(String value) {
        this.srcLocal = value;
    }

    /**
     * Gets the value of the dstLocal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=9)
    public String getDstLocal() {
        return dstLocal;
    }

    /**
     * Sets the value of the dstLocal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstLocal(String value) {
        this.dstLocal = value;
    }

    /**
     * Gets the value of the srcVlan property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JSONHint(ordinal=10)
    public Integer getSrcVlan() {
        return srcVlan;
    }

    /**
     * Sets the value of the srcVlan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSrcVlan(Integer value) {
        this.srcVlan = value;
    }

    /**
     * Gets the value of the dstVlan property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JSONHint(ordinal=11)
    public Integer getDstVlan() {
        return dstVlan;
    }

    /**
     * Sets the value of the dstVlan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDstVlan(Integer value) {
        this.dstVlan = value;
    }

    /**
     * Gets the value of the domains property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=12)
    public String getDomains() {
        return domains;
    }

    /**
     * Sets the value of the domains property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDomains(String value) {
        this.domains = value;
    }

}
