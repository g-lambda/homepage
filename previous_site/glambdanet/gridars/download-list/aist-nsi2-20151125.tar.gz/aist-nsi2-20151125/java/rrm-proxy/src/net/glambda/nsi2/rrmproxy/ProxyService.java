/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.TopologyLoader;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.nsi2.util.TypesBuilder;
import net.sf.ooweb.http.RequestState;
import net.sf.ooweb.http.ResponseState;
import net.sf.ooweb.objectmapping.Controller;
import nsirrmproxy.NetworkResourceType;
import nsirrmproxy.PathType;
import nsirrmproxy.ReservationIDMapType;
import nsirrmproxy.ReservationIDMapsType;
import nsirrmproxy.ResourceSetType;

@Controller("/")
public class ProxyService {

    private class PeriodicallyUpdater extends TimerTask {

        private boolean updated = false;

        public void run() {
            if (isAccessedRecently()) {
                logger.info("try to update XML");
                updateRsvIDMaps();
                logger.info("XML was updated");
                updated = true;
            } else {
                if (updated) {
                    logger.info("stop update Properties because Proxy isn't accessed recently");
                    updated = false;
                }
            }
        }

    }

    private final JAXBHandler jaxbHandler;
    private final List<InfoSite> siteList;
    private final XalanTransformer xalan;
    private final HashMap<String, String> stpid2topoMap = new HashMap<String, String>();

    private String mergedXml = "";
    private String mergedHtml = "";
    private String mergedJson = "";
    private final int showBeforeMin; // [min]
    private final int showAfterMin; // [min]

    protected static final Log logger = LogFactory.getLog(ProxyService.class);

    private static long lastAccess = Calendar.getInstance().getTimeInMillis();
    private static long SLEEP_TIMER = 60 * 1000L; // [msec]
    private static final int DEFAULT_UPDATE_PERIOD = 10; // [sec]

    private int getInt(Properties prop, String key, int defaultValue) {
        String v = prop.getProperty(key);
        if (v != null) {
            return Integer.parseInt(v);
        } else {
            return defaultValue;
        }
    }

    public ProxyService() throws Exception {
        this(null);
    }

    public ProxyService(RRMProxyProperties prop) throws Exception {
        if (prop == null) {
            File config = new File(RestProxyServer.RRM_DIR, "etc/proxy.properties");
            prop = new RRMProxyProperties();
            prop.load(new FileInputStream(config));
        }
        this.jaxbHandler = new JAXBHandler();
        this.xalan =
                new XalanTransformer(
                        new File(RestProxyServer.RRM_DIR, "web/nsirrmproxy.xsl").getAbsolutePath());
        this.showBeforeMin = getInt(prop, "showPeriodBeforeMin", 10);
        this.showAfterMin = getInt(prop, "showPeriodAfterMin", 60);

        this.siteList = new LinkedList<InfoSite>();
        for (int i = 1; i <= 10; i++) {
            String prefix = "site" + i + ".";
            String name = prop.getProperty(prefix + "name");
            if (name == null) {
                continue;
            }
            String type = prop.getProperty(prefix + "type");
            InfoSite site;
            if (type.equals("nsi")) {
                site = new NSIInfoSite(prefix, prop);
            } else {
                logger.warn("invalid site type: " + type);
                continue;
            }
            siteList.add(site);
        }

        for (NSA nsa : TopologyLoader.loadAll()) {
            // use nsa.ets(), not nsa.name()
            String topo = nsa.ets();
            for (STP stp : nsa.biStps()) {
                stpid2topoMap.put(NSIUtil.dropPrefix(stp.stpid()), topo);
            }
        }

        updateRsvIDMaps();

        Timer timer = new Timer("xml updater");
        long updatePeriod = 1000L * getInt(prop, "pollingPeriod", DEFAULT_UPDATE_PERIOD); // [msec]
        timer.schedule(new PeriodicallyUpdater(), 0, updatePeriod);
        SLEEP_TIMER = 1000L * getInt(prop, "autoPollingStopPeriod", 60); // [msec]
    }

    private static void accessed() {
        lastAccess = System.currentTimeMillis();
        logger.info("HTTP accessed at " + String.format(Locale.US, "%tc", lastAccess));
    }

    static boolean isAccessedRecently() {
        long now = System.currentTimeMillis();
        return ((now - lastAccess) < SLEEP_TIMER);
    }

    public String index() {
        return "This is NSI RRM-Proxy";
    }

    public ResponseState rnds(RequestState state) {
        accessed();
        ResponseState res = new ResponseState();
        res.setMimeType("text/xml");
        res.setBody(mergedXml);
        return res;
    }

    public ResponseState rndsHtml(RequestState state) {
        accessed();
        ResponseState res = new ResponseState();
        res.setMimeType("text/html");
        res.setBody(mergedHtml);
        return res;
    }

    void setMergedXML(String xml) {
        if (xml != null && !xml.isEmpty()) {
            xml =
                    xml.replace("<reservationIDMaps ",
                            "<?xml-stylesheet type=\"text/xsl\" href=\"nsirrmproxy.xsl\"?>\n<reservationIDMaps ");
            logger.debug(xml);
            mergedXml = xml;
            mergedHtml = xalan.transform(xml);
        } else {
            logger.debug("ignore empty xml:" + xml);
        }
    }

    void setMergedJSON(String json) {
        if (json != null && !json.isEmpty()) {
            logger.debug(json);
            mergedJson = json;
        }
    }

    private PathType makeBridgePath(String stp, PathType pathA) {
        stp = TypesBuilder.makeStpWithVlan(stp, pathA.getSrcVlan());
        PathType pathAB = new PathType();
        pathAB.setStartTime(null);
        pathAB.setEndTime(null);
        pathAB.setReservationStatus(pathA.getReservationStatus());
        pathAB.setAPoint(NSIInfoSite.shortStpName(stp));
        pathAB.setZPoint(pathA.getAPoint());
        pathAB.setCapacity(pathA.getCapacity());
        pathAB.setSrcNet(pathA.getDstNet());
        pathAB.setDstNet(pathA.getSrcNet());
        pathAB.setSrcLocal(stp);
        pathAB.setDstLocal(pathA.getSrcLocal());
        pathAB.setSrcVlan(pathA.getDstVlan());
        pathAB.setDstVlan(pathA.getSrcVlan());
        pathAB.setDomains(pathA.getDomains());
        return pathAB;
    }

    private PathType makeBridgePath(PathType pathA, PathType pathB) {
        PathType pathAB = new PathType();
        pathAB.setStartTime(null);
        pathAB.setEndTime(null);
        pathAB.setReservationStatus(pathA.getReservationStatus());// TODO
        pathAB.setAPoint(pathA.getZPoint());
        pathAB.setZPoint(pathB.getAPoint());
        pathAB.setCapacity(pathA.getCapacity());
        pathAB.setSrcNet(pathA.getDstNet());
        pathAB.setDstNet(pathB.getSrcNet());
        pathAB.setSrcLocal(pathA.getDstLocal());
        pathAB.setDstLocal(pathB.getSrcLocal());
        pathAB.setSrcVlan(pathA.getDstVlan());
        pathAB.setDstVlan(pathB.getSrcVlan());
        pathAB.setDomains(pathA.getDomains());
        return pathAB;
    }

    private String stpid2topo(String stpid) {
        return stpid2topoMap.get(stpid);
    }

    private void dropPrefix(PathType path) {
        path.setAPoint(NSIUtil.dropPrefixStpExt(path.getAPoint()));
        path.setZPoint(NSIUtil.dropPrefixStpExt(path.getZPoint()));
        path.setSrcNet(stpid2topo(path.getAPoint()));
        path.setDstNet(stpid2topo(path.getZPoint()));
        path.setSrcLocal(NSIUtil.dropPrefix(path.getSrcLocal()));
        path.setDstLocal(NSIUtil.dropPrefix(path.getDstLocal()));
    }

    private static final HashMap<String, String> bi2termMap = new HashMap<String, String>();

    static {
        bi2termMap.put("urn:ogf:network:aist.go.jp:2013:topology:bi-ps",
                "urn:ogf:network:aist.go.jp:2013:topology:term:server");
        bi2termMap.put("urn:ogf:network:aist.go.jp:2013:topology:bi-video",
                "urn:ogf:network:aist.go.jp:2013:topology:term:video");
    }

    private void pathFill(NetworkResourceType net) {
        List<PathType> pathList = net.getPath();
        if (pathList.isEmpty()) {
            return;
        }
        net.setAPoint(NSIUtil.appendPrefix(net.getAPoint()));
        net.setZPoint(NSIUtil.appendPrefix(net.getZPoint()));
        net.getSummaryPath().setAPoint(NSIUtil.dropPrefix(net.getSummaryPath().getAPoint()));
        net.getSummaryPath().setZPoint(NSIUtil.dropPrefix(net.getSummaryPath().getZPoint()));
        //
        LinkedList<PathType> list = new LinkedList<PathType>();
        for (int i = 0; i < pathList.size() - 1; i++) {
            PathType pathA = pathList.get(i);
            list.add(pathA);
            PathType pathB = pathList.get(i + 1);
            PathType pathAB = makeBridgePath(pathA, pathB);
            list.add(pathAB);
        }
        list.add(pathList.get(pathList.size() - 1));
        net.setPath(list);
        // TODO temporary
        String term = bi2termMap.get(NSIUtil.dropStpExt(list.get(0).getSrcLocal()));
        if (term != null) {
            PathType path = makeBridgePath(term, list.get(0));
            list.addFirst(path);
            // net.setAPoint(path.getAPoint());// NOTE: keep original
            net.getSummaryPath().setAPoint(path.getAPoint());
            net.getSummaryPath().setSrcNet(path.getSrcNet());
            net.getSummaryPath().setSrcLocal(path.getSrcLocal());
        }
        dropPrefix(net.getSummaryPath());
        for (PathType path : list) {
            dropPrefix(path);
        }
    }

    private static class ResourceSetComparator implements Comparator<ResourceSetType> {

        private long time(ResourceSetType r, boolean bStart) {
            if (r != null && !r.getNetworkResource().isEmpty()
                    && r.getNetworkResource().get(0).getSummaryPath() != null) {
                if (bStart) {
                    if (r.getNetworkResource().get(0).getSummaryPath().getStartTime() != null) {
                        return r.getNetworkResource().get(0).getSummaryPath().getStartTime()
                                .getTimeInMillis();
                    } else {
                        return 0;
                    }
                } else {
                    if (r.getNetworkResource().get(0).getSummaryPath().getEndTime() != null) {
                        return r.getNetworkResource().get(0).getSummaryPath().getEndTime()
                                .getTimeInMillis();
                    } else {
                        return Long.MAX_VALUE;
                    }
                }
            }
            return 0;
        }

        @Override
        public int compare(ResourceSetType o1, ResourceSetType o2) {
            long v = time(o2, true) - time(o1, true);
            if (v == 0) {
                v = time(o2, false) - time(o1, false);
            }
            if (v > 0) {
                return 1;
            } else if (v < 0) {
                return -1;
            } else {
                return 0;
            }
        }

    }

    private static ResourceSetComparator RS_COMP = new ResourceSetComparator();

    private void pathFillSort(ReservationIDMapsType maps) {
        LinkedList<ResourceSetType> list = new LinkedList<ResourceSetType>();
        for (ReservationIDMapType map : maps.getReservationIDMap()) {
            String sched = map.getSched();
            for (ResourceSetType r : map.getResourceSet()) {
                r.setId(sched + " " + r.getId());
                for (NetworkResourceType n : r.getNetworkResource()) {
                    pathFill(n);
                }
                list.add(r);
            }
        }
        //
        Collections.sort(list, RS_COMP);
        ReservationIDMapType map = new ReservationIDMapType();
        map.setResourceSet(list);
        maps.getReservationIDMap().clear();
        maps.getReservationIDMap().add(map);
    }

    void updateRsvIDMaps() {
        ReservationIDMapsType maps = new ReservationIDMapsType();
        Calendar now = Calendar.getInstance();
        now.set(Calendar.MILLISECOND, 0);
        maps.setUpdateTime(now);
        Calendar start;
        Calendar end;
        if (showBeforeMin > 0) {
            start = (Calendar) now.clone();
            start.add(Calendar.MINUTE, -showBeforeMin);
        } else {
            start = null;
        }
        if (showAfterMin > 0) {
            end = (Calendar) now.clone();
            end.add(Calendar.MINUTE, showAfterMin);
        } else {
            end = null;
        }
        maps.setInfoStartTime(start);
        maps.setInfoEndTime(end);

        for (InfoSite site : siteList) {
            try {
                ReservationIDMapType map = site.getReservationIdMap(start, end);
                if (map != null) {
                    maps.getReservationIDMap().add(map);
                }
            } catch (Exception e) {
                logger.warn("cannot get information from " + site.name(), e);
            }
        }

        setMergedXML(jaxbHandler.toXML(maps));
        //
        pathFillSort(maps);
        setMergedJSON(JSONHandler.toJson(maps));
    }

    String getJson() {
        accessed();
        return mergedJson;
    }

    String getXml() {
        accessed();
        return mergedXml;
    }

    String getHtml() {
        accessed();
        return mergedHtml;
    }
}
