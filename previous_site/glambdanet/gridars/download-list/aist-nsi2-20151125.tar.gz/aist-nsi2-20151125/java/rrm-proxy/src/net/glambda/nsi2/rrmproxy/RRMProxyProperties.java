/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.util.Properties;

public class RRMProxyProperties extends Properties {

    private static final long serialVersionUID = 7423110929461437264L;

    public String name(String key) {
        return getProperty(key + "name");
    }

    public String providerNsa(String key) {
        return getProperty(key + "providerNSA");
    }

    public String providerUrl(String key) {
        return getProperty(key + "providerURL");
    }

    public String requesterNsa(String key) {
        return getProperty(key + "requesterNSA");
    }

    public String requesterUrl(String key) {
        return getProperty(key + "requesterURL");
    }

    public boolean shortStpName(String key) {
        return "true".equalsIgnoreCase(getProperty(key + "shortSTPname"));
    }
    
}
