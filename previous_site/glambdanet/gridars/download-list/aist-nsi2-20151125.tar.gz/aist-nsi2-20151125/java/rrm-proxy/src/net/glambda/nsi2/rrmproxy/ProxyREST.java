/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.message.Message;

@Path("/")
public class ProxyREST {

    protected static final Log logger = LogFactory.getLog(ProxyREST.class);
    private static final ProxyService proxy;
    private static final DummyJsonInfo dummyInfo;

    public static final boolean DUMMY_MODE = "true".equals(System.getProperty("nsi.dummy"));
    private final static String COOKIE_NAME = "rrm-name";

    static {
        if (DUMMY_MODE) {
            proxy = null;
            dummyInfo = new DummyJsonInfo();
        } else {
            ProxyService p;
            try {
                p = new ProxyService();
            } catch (Exception e) {
                e.printStackTrace();
                logger.fatal(e);
                System.exit(1);
                p = null;
            }
            proxy = p;
            dummyInfo = null;
        }
    }

    public static AuthorizationPolicy getAuthPolicy(HttpHeaders headers) {
        try {
            // http://grepcode.com/file/repo1.maven.org/maven2/com.fluxcorp.plugins/webservice-trigger/1.0.4/fluximpl/WebServiceTriggerImpl.java?av=f#289
            // http://stackoverflow.com/questions/1196192/how-do-i-read-a-private-field-in-java
            Field f = headers.getClass().getDeclaredField("message");
            f.setAccessible(true);
            Object o = f.get(headers);
            if (o instanceof Message) {
                Message m = (Message) o;
                return (AuthorizationPolicy) m.get(AuthorizationPolicy.class);
            }
        } catch (Exception e) {
            logger.error("PROGRAM ERROR", e);
        }
        return null;
    }

    public static String username(HttpHeaders headers) {
        for (Cookie cookie : headers.getCookies().values()) {
            if (cookie.getName().equals(COOKIE_NAME)) {
                logger.info("cookie: " + cookie.toString());
                return cookie.getValue();
            }
        }
        logger.warn("missing " + COOKIE_NAME + " cookie in HTTP headers");
        return null;
    }

    // Common
    private final static Pattern USER_PASS = Pattern.compile("user=(.+?)&password=(.+)");

    private static final HashMap<String, String> userpassMap = new HashMap<String, String>();

    static {
        userpassMap.put("nsi", "pass");
        userpassMap.put("aist", "pass");
    }

    private boolean isValidUser(String username, String pass) {
        String v = userpassMap.get(username);
        if (v == null) {
            logger.warn("unknown user: " + username);
            return false;
        }
        if (!v.equals(pass)) {
            logger.warn("invalid password for user: " + username);
            return false;
        }
        return true;
    }

    private String loginResponse(String user) {
        return "{\"user\":{\"name\":\"" + user + "\"}}";
    }

    private NewCookie makeCookie(String user) {
        return new NewCookie(COOKIE_NAME, user);
    }

    @POST
    @Path("/login")
    @Produces("application/json")
    public Response login(@Context HttpHeaders headers, String body) throws Exception {
        logger.info("start login: " + body);
        Matcher m = USER_PASS.matcher(body);
        if (!m.find()) {
            throw new Exception("invalid body: " + body);
        }
        String username = m.group(1);
        String pass = m.group(2);
        boolean isValid = isValidUser(username, pass);
        logger.info("end login: " + body);
        if (isValid) {
            return Response.ok(loginResponse(username)).header("Set-Cookie", makeCookie(username))
                    .build();
        } else {
            return Response.status(Status.UNAUTHORIZED).build();
        }
    }

    @POST
    @Path("/logout")
    @Produces("application/json")
    public Response logout(@Context HttpHeaders headers) {
        ResponseBuilder rb = Response.ok();
        String username = username(headers);
        logger.info("start logout: " + username);
        NewCookie c = new NewCookie(makeCookie(username), null, 0, false);
        rb.header("Set-Cookie", c);
        logger.info("end logout: " + username);
        return rb.build();
    }

    @GET
    @Path("/rrm/info.json")
    @Produces("application/json")
    public String info(@Context HttpHeaders headers) {
        if (DUMMY_MODE) {
            return dummyInfo.getJson();
        } else {
            return proxy.getJson();
        }
    }

    @GET
    @Path("/rnds")
    @Produces("text/xml")
    public String xml(@Context HttpHeaders headers) {
        if (DUMMY_MODE) {
            return "";
        } else {
            return proxy.getXml();
        }
    }

    @GET
    @Path("/rnds.html")
    @Produces("text/html")
    public String html(@Context HttpHeaders headers) {
        if (DUMMY_MODE) {
            return "";
        } else {
            return proxy.getHtml();
        }
    }

}
