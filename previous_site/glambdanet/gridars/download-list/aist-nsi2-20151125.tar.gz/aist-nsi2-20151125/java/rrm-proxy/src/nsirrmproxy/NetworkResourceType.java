/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nsirrmproxy;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import net.arnx.jsonic.JSONHint;


/**
 * <p>Java class for NetworkResource_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkResource_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="globalReservationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="connectionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requesterNSA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reservationState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="provisionState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lifecycleState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataPlaneState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://glambda/schema/2013/01/rrm}summaryPath"/>
 *         &lt;element ref="{http://glambda/schema/2013/01/rrm}path" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="APoint" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ZPoint" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkResource_Type", propOrder = {
    "globalReservationId",
    "description",
    "connectionId",
    "requesterNSA",
    "reservationState",
    "provisionState",
    "lifecycleState",
    "dataPlaneState",
    "summaryPath",
    "path"
})
public class NetworkResourceType {

    protected String globalReservationId;
    protected String description;
    protected String connectionId;
    protected String requesterNSA;
    protected String reservationState;
    protected String provisionState;
    protected String lifecycleState;
    protected String dataPlaneState;
    @XmlElement(required = true)
    protected PathType summaryPath;
    @XmlElement(required = true)
    protected List<PathType> path;
    @XmlAttribute(name = "APoint", required = true)
    protected String APoint;
    @XmlAttribute(name = "ZPoint", required = true)
    protected String ZPoint;

    /**
     * Gets the value of the globalReservationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=0)
    public String getGlobalReservationId() {
        return globalReservationId;
    }

    /**
     * Sets the value of the globalReservationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlobalReservationId(String value) {
        this.globalReservationId = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=1)
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the connectionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=2)
    public String getConnectionId() {
        return connectionId;
    }

    /**
     * Sets the value of the connectionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnectionId(String value) {
        this.connectionId = value;
    }

    /**
     * Gets the value of the requesterNSA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=3)
    public String getRequesterNSA() {
        return requesterNSA;
    }

    /**
     * Sets the value of the requesterNSA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequesterNSA(String value) {
        this.requesterNSA = value;
    }

    /**
     * Gets the value of the reservationState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=4)
    public String getReservationState() {
        return reservationState;
    }

    /**
     * Sets the value of the reservationState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReservationState(String value) {
        this.reservationState = value;
    }

    /**
     * Gets the value of the provisionState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=5)
    public String getProvisionState() {
        return provisionState;
    }

    /**
     * Sets the value of the provisionState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvisionState(String value) {
        this.provisionState = value;
    }

    /**
     * Gets the value of the lifecycleState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=6)
    public String getLifecycleState() {
        return lifecycleState;
    }

    /**
     * Sets the value of the lifecycleState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifecycleState(String value) {
        this.lifecycleState = value;
    }

    /**
     * Gets the value of the dataPlaneState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JSONHint(ordinal=7)
    public String getDataPlaneState() {
        return dataPlaneState;
    }

    /**
     * Sets the value of the dataPlaneState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataPlaneState(String value) {
        this.dataPlaneState = value;
    }

    @JSONHint(ordinal=8)
    public String getAPoint() {
        return APoint;
    }

    public void setAPoint(String APoint) {
        this.APoint = APoint;
    }

    @JSONHint(ordinal=9)
    public String getZPoint() {
        return ZPoint;
    }

    public void setZPoint(String ZPoint) {
        this.ZPoint = ZPoint;
    }

    /**
     * Gets the value of the summaryPath property.
     * 
     * @return
     *     possible object is
     *     {@link PathType }
     *     
     */
    @JSONHint(ordinal=10)
    public PathType getSummaryPath() {
        return summaryPath;
    }

    /**
     * Sets the value of the summaryPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link PathType }
     *     
     */
    public void setSummaryPath(PathType value) {
        this.summaryPath = value;
    }


    /**
     * Gets the value of the path property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the path property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPath().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PathType }
     * 
     * 
     */
    @JSONHint(ordinal=11)
    public List<PathType> getPath() {
        if (path == null) {
            path = new ArrayList<PathType>();
        }
        return this.path;
    }

    public void setPath(List<PathType> path) {
        this.path = path;
    }

}
