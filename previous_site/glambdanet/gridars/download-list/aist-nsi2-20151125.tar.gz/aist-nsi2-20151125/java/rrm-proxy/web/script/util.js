// dataの存在有無
function isset( data ){
    return ( typeof( data ) != 'undefined' );
}

// パスからファイル名を取得
function basename(path) {
    return path.replace(/\\/g,'/').replace( /.*\//, '' );
}

// パスからディレクトリ名を取得
function dirname(path) {
    return path.replace(/\\/g,'/').replace(/\/[^\/]*$/, '');;
}
