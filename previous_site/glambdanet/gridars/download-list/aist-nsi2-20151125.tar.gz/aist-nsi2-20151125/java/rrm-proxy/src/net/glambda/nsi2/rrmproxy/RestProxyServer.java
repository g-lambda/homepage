/*
 * Copyright 2003-2015 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.rrmproxy;

import java.io.File;

import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.JAXRSServiceFactoryBean;
import org.apache.cxf.transport.Destination;
import org.apache.cxf.transport.http_jetty.JettyHTTPDestination;
import org.apache.cxf.transport.http_jetty.JettyHTTPServerEngine;
import org.apache.cxf.transport.http_jetty.ServerEngine;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;

public class RestProxyServer {

    public static File RRM_DIR = null;
    
    RestProxyServer(String[] args) throws Exception {
        // NOTE: Apache CXF 2.7.3 causes Exception at sf.create().
        // Use CXF 2.6.6 etc.
        // NOTE: sf.setAddress("http://localhost/.."); only accepts from
        // localhost. sf.setAddress("http://x.x.x.x/..."); can accept from
        // external hosts, or use "http://0.0.0.0/..." for both accesses.
        String port = (args.length > 0 ? args[0] : "8180");
        String url = "http://0.0.0.0:" + port;
        System.out.println("Starting REST RRMProxy server... at " + url);
        String basedir = (args.length > 1 ? args[1] : "web");
        RRM_DIR = new File(basedir).getParentFile();
        
        JAXRSServiceFactoryBean svcFactory = new JAXRSServiceFactoryBean();
        JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean(svcFactory);

        sf.setResourceClasses(ProxyREST.class);
        sf.setAddress(url);
        org.apache.cxf.endpoint.Server cxfServer = sf.create();

        Destination dest = cxfServer.getDestination();
        JettyHTTPDestination jettyDestination = JettyHTTPDestination.class.cast(dest);
        ServerEngine engine = jettyDestination.getEngine();
        JettyHTTPServerEngine serverEngine = JettyHTTPServerEngine.class.cast(engine);
        org.eclipse.jetty.server.Server httpServer = serverEngine.getServer();

        httpServer.stop();
        httpServer.join();

        Handler[] existingHandlers = httpServer.getHandlers();

        ResourceHandler resourceHandler = new ResourceHandler();
        resourceHandler.setDirectoriesListed(true);

        resourceHandler.setResourceBase(basedir);

        HandlerList handlers = new HandlerList();
        handlers.addHandler(resourceHandler);
        if (existingHandlers != null) {
            for (Handler h : existingHandlers) {
                handlers.addHandler(h);
            }
        }
        httpServer.setHandler(handlers);

        httpServer.start();
        httpServer.join();
    }

    public static void main(String args[]) {
        try {
            new RestProxyServer(args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
