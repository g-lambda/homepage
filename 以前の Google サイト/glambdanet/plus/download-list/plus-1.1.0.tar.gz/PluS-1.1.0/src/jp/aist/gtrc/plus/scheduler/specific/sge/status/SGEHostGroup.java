/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;
import java.util.LinkedHashSet;

import jp.aist.gtrc.plus.scheduler.specific.sge.jaxb.common.*;
import jp.aist.gtrc.plus.scheduler.status.Status;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class SGEHostGroup implements Status {

	private final JAXBSGEHostgroup hgroup;
	private final LinkedHashSet<String> hosts;

	public SGEHostGroup(JAXBSGEHostgroup hgroup) {

		assert(hgroup != null);
		this.hgroup = hgroup;
		this.hosts = new LinkedHashSet<String>();

		makeHostSet();

	}

	private void makeHostSet() {

		HGRPHostList list = hgroup.getHGRPHostList();
		if (list != null) {
			for (HRElement e : list.getHRElement()) {
				hosts.add(e.getHRName());
			}
		}

	}

	public String getName() {

		return hgroup.getHGRPName();

	}

	public Collection<String> getAllHostNames() {

		return hosts;

	}

	public boolean contains(String hostname) {

		return hosts.contains(hostname);

	}

	public String toString() {

		return TextUtil.fromList(hosts, " ");

	}

}
