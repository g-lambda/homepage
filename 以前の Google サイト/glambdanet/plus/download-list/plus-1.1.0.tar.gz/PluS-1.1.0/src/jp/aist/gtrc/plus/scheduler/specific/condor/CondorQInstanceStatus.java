/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.condor;

import jp.aist.gtrc.plus.scheduler.status.QInstanceStatusBase;

public class CondorQInstanceStatus extends QInstanceStatusBase {
	boolean used = false;
	boolean readyToUse = true;
	boolean suspended = true;
	
	CondorQInstanceStatus(CondorQueueStatus parent, String hostname, boolean suspended){
		super(parent, hostname);
		this.suspended = suspended; 
	}
	
	public int getUsedSlotNum() {
		return used? 0 : 1;
	}

	public boolean isReadyToUse() {
		return readyToUse;
	}

	public boolean isSuspended() {
		return suspended;
	}

}
