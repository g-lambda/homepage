/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import jp.aist.gtrc.plus.reserve.ReserveManager;
import jp.aist.gtrc.plus.reserve.ReserveRecorderImpl;
import jp.aist.gtrc.plus.scheduler.specific.condor.CondorQbaseMainServer;
import jp.aist.gtrc.plus.scheduler.specific.condor.CondorQbaseReserveManager;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class CondorQbaseScheduler extends DefaultQbaseScheduler {

	protected CondorQbaseScheduler(SchedulerOptions options) throws Exception {
		super(options);
	}

	@Override
	protected MainServer getMainServer() throws Exception {
		/*
		 * We must return MainServer instance for Condor.
		 */
		return new CondorQbaseMainServer(cache);
	}

	CondorQbaseReserveManager cache;
	
	@Override
	protected ReserveManager getReserveManager(SchedulerOptions options) throws SchedulerException {
		
		ReserveRecorderImpl recorder =
			new ReserveRecorderImpl(options.getReserveFilePath());
		/*
		 * We must use ReserveManager for Condor to override some operation
		 * when making new reservation, start it, finish it.
		 * See CondorQbaseReserveManager, CondorQbaseReserveInfo. 
		 * 
		 */
		cache = new CondorQbaseReserveManager(
				nodeMgr, starter, recorder,
				getRsvNodeAllocator(options), statusMgr, options);

		return cache;
	}

}
