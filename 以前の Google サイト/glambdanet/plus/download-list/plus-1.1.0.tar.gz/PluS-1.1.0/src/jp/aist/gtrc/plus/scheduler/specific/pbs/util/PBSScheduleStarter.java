/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import java.io.IOException;
import java.net.Socket;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.ScheduleOrder;
import jp.aist.gtrc.plus.scheduler.ScheduleStarter;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;


public class PBSScheduleStarter extends ScheduleStarter {

	private final PBSServerConnector connector;
	private final PBSServerAcceptor acceptor;

	public PBSScheduleStarter() throws SchedulerException {

		this(new PBSServerConfig());

	}

	public PBSScheduleStarter(PBSServerConfig config) throws SchedulerException{

		super();
		connector = new PBSServerConnector(config);

		try {
			acceptor = new PBSServerAcceptor(config, this);
		} catch (IOException e) {
			throw new PBSException(PBSErrorCode.RMSYSTEM);
		}

		start();

	}

	private void start() {

		Thread t = new Thread(acceptor, "PBSServerAcceptor");
		t.setDaemon(true);
		t.start();

	}

	protected ScheduleOrder makePeriodicalScheduleOrder() throws SchedulerException {

		Socket s = connector.getAuthorizedSocket();
		return new PBSScheduleOrder(PBSSchedulerCommandType.TIME, s);

	}

	public void runSchedule(ReserveId rsvID) throws SchedulerException {

		Socket s = connector.getAuthorizedSocket();
		super.runSchedule(new PBSScheduleOrder(rsvID, s));

	}

}
