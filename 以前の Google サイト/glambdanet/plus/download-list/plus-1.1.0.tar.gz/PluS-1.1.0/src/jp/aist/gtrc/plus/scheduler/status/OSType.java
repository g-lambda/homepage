/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

public enum OSType {

	Linux,
	Linux_22,
	Linux_24,
	Linux_26,

	Solaris,
	Solaris_8,
	Solaris_9,
	Solaris_10,

	Windows,
	Windows_2000,
	Windows_XP,

	/*
	NetBSD,
	FreeBSD,

	HPUX,
	HPUX_10,
	HPUX_11,
	*/

	Unknown;

	public static boolean isMatch(OSType reqOS, OSType myOS) {

		/*
		 * req\my	L22	L24	L26	Lnx Ukn	Sol ...
		 * L22		Y	N	N	N	N	N
		 * L24		N	Y	N	N	N	N
		 * L26		N	N	Y	N	N	N
		 * Lnx		Y	Y	Y	Y	N	N
		 * Ukn		Y	Y	Y	Y	Y	Y
		 * ...
		 */
		switch(reqOS) {
		case Linux:
		case Solaris:
		case Windows:
			return (myOS.name().startsWith(reqOS.name()));
		case Unknown:
			return true;	// always returns true
		default:
			return (reqOS == myOS);
		}

	}

	public static OSType getOS(String name) {

		for (OSType os : OSType.values()) {
			if (os.name().equalsIgnoreCase(name)) {
				return os;
			}
		}
		return null;	// return null for invalid name, not unknown

	}
}
