/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import java.net.Socket;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchOperationType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequestManage;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequestManage.ManagerCommandType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSMainServer;

public class PBSQueueManager {

	private final PBSServerConnector serverConnector;
	private PBSMainServer server;

	public PBSQueueManager(PBSServerConnector serverConnector) {

		if (serverConnector == null) {
			serverConnector = new PBSServerConnector(new PBSServerConfig());
		}
		this.serverConnector = serverConnector;
		this.server = null;

	}

	public void connect() throws PBSException {

		if (server != null) {
			disconnect();
		}

		Socket s = serverConnector.getAuthorizedSocket();
		server = new PBSMainServer(s);

	}

	public void disconnect() {

		if (server != null) {
			server.disconnect();
			server = null;
		}

	}

	public void createQueue(String queueName) throws PBSException {

		assert(server != null);

		BatchRequestManage request = new BatchRequestManage(
				ManagerCommandType.CREATE, BatchObjectType.QUEUE, queueName);
		server.serverCall(request);

	}

	public void setQueue(String queueName, String attr, String value) throws PBSException {

		/*
		 * "set queue QUEUENAME queue_type = Execution"
		 * "set queue QUEUENAME Priority = 0"
		 * "set queue QUEUENAME acl_users = userA"
		 */
		setQueuePlus(queueName, attr, null, value, BatchOperationType.SET);

	}

	public void setQueue(String queueName, String attr, String rsc, String value) throws PBSException {

		/*
		 * "set queue QUEUENAME resources_default.nodes = 1"
		 * "set queue QUEUENAME resources_default.walltime = 01:00:00"
		 */
		setQueuePlus(queueName, attr, rsc, value, BatchOperationType.SET);

	}

	public void setQueuePlus(String queueName, String attr, String value) throws PBSException {

		/*
		 * "set queue QUEUENAME acl_users += userB"
		 * 			NOTE: using "+=", not "="
		 */
		setQueuePlus(queueName, attr, null, value, BatchOperationType.INCR);

	}

	private void setQueuePlus(String queueName, String attr, String rsc, String value,
			BatchOperationType opeType) throws PBSException {

		assert(server != null);

		BatchRequestManage request = new BatchRequestManage(
				ManagerCommandType.SET, BatchObjectType.QUEUE, queueName,
				attr, rsc, value, opeType);
		server.serverCall(request);

	}

	public void deleteQueue(String queueName) throws PBSException {

		assert(server != null);

		BatchRequestManage request = new BatchRequestManage(
				ManagerCommandType.DELETE, BatchObjectType.QUEUE, queueName);
		server.serverCall(request);

	}

}
