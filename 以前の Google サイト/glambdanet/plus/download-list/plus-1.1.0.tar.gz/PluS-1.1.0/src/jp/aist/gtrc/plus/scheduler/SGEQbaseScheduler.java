/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import jp.aist.gtrc.plus.reserve.ReserveManager;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.sge.qbase.SGEQbaseMainServer;
import jp.aist.gtrc.plus.scheduler.specific.sge.qbase.SGEQbaseReserveManager;
import jp.aist.gtrc.plus.scheduler.specific.sge.qbase.SGEQbaseReserveRecorderImpl;
import jp.aist.gtrc.plus.scheduler.specific.sge.qbase.SGEQbaseStatusManager;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class SGEQbaseScheduler extends DefaultQbaseScheduler {

	protected SGEQbaseScheduler(SchedulerOptions options) throws Exception {

		super(options);

	}

	protected MainServer getMainServer() throws Exception {

		return SGEQbaseMainServer.getInstance();

	}

	protected StatusManager getStatusManager(SchedulerOptions options) throws SchedulerException {

		try {
			return SGEQbaseStatusManager.getInstance();
		} catch (RuntimeException e) {
			throw new SchedulerException(e.getMessage());
		}

	}

	protected ReserveManager getReserveManager(SchedulerOptions options) throws SchedulerException {

		NodeAllocator rsvNodeAllocator = getRsvNodeAllocator(options);
		if (rsvNodeAllocator == null) {
			throw new SchedulerException("Invalid ReserveNodeAllocator");
		}

		assert(starter != null);
		assert(statusMgr != null);
		assert(statusMgr instanceof SGEQbaseStatusManager);

		SGEQbaseReserveRecorderImpl recorder = new SGEQbaseReserveRecorderImpl(
				options.getReserveFilePath());
		SGEQbaseReserveManager rsvMgr = new SGEQbaseReserveManager(
				nodeMgr, starter, recorder, rsvNodeAllocator,
				(SGEQbaseStatusManager)statusMgr, options);
		recorder.init(rsvMgr);

		return rsvMgr;

	}

}
