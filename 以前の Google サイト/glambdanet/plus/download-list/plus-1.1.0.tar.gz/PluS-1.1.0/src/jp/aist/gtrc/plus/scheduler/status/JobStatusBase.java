/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.job.JobStateType;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeResource;

public abstract class JobStatusBase implements JobStatus {

	private QueueStatus queue;
	private int priority = 0;

	public abstract JobID getJobID();
	public abstract ReserveId getReserveId();
	public abstract JobStateType getState();

	public Calendar getExecStartTime() {
		return null;
	}

	public Collection<NodeAllocateSet> getNodeRequests() {
		NodeResource rsc = new NodeResource(1);
		LinkedList<NodeAllocateSet> list = new LinkedList<NodeAllocateSet>();
		NodeAllocateSet set = new NodeAllocateSet(1, rsc);
		list.add(set);
		return list;
	}

	public String getOwner() {
		return "";
	}

	public int getPriority() {
		return priority;
	}

	public QueueStatus getQueueStatus() {
		return queue;
	}

	public Calendar getRequestedExecStartTime() {
		return null;
	}

	public int getRequestedTime() {
		/*
		 * It's desirable to return walltime (requested running time)
		 * at [second].
		 * 	Example on PBS: qsub -l cput=3600 ....
		 * 	Example on SGE: qsub -l h_rt=1:00:00 ....
		 * These are requested 3600 seconds to run the job (task).
		 */
		return WALLTIME_NOT_SPECIFIED;
	}

	public Calendar getSubmitTime() {
		return Calendar.getInstance();
	}

	public boolean isReadyToRun() {
		return (getState() == JobStateType.Queued);
	}

	public void setPriority(int newPrio) {
		priority = newPrio;
	}

	public void setQueueStatus(QueueStatus q) {
		this.queue = q;
	}

	public String getName() {
		return getJobID().toString();
	}

}
