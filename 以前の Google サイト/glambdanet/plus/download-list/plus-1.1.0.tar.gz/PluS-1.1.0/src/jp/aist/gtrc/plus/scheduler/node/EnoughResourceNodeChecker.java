/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;


import java.util.Collection;

import jp.aist.gtrc.plus.scheduler.util.Checker;


public class EnoughResourceNodeChecker extends Checker<NodeInfo>{

	private final NodeAllocateRequest allocReq;

	public EnoughResourceNodeChecker(NodeAllocateRequest allocReq) {

		this.allocReq = allocReq;

	}

	public boolean isOK(NodeInfo node){

		for (NodeAllocateSet allocSet : allocReq.getRequestedNodeAllocateSets()) {
			if (allocSet.isAllocatedEnough()) {
				continue;
			}
			Collection<NodeResource> reqRsc = allocSet.getRequestedResources();
			NodeResource enoughRsc = node.getResource().getEnoughResource(reqRsc);
			if (enoughRsc != null) {
				allocSet.addAllocatedNode(node);
				node.setLaunceProcessNum(enoughRsc.getProcessNum());
				return true;
			}
		}

		return false;

	}

}
