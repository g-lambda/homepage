/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class HostUtil {

	private static String domainName = null;
	static {
		try {
			String hostname = getLocalHostName();
			int index = hostname.indexOf('.');
			if (index > 0) {
				// 'domainName' will be ".example.com" etc
				domainName = hostname.substring(index);
			}
		} catch (Exception e) {
			// ignore
		}

	}

	public static final  String getLocalHostName() {

		String hostname;
		try {
			hostname = InetAddress.getLocalHost().getCanonicalHostName();
			if (hostname.indexOf('.') > 0) {
				return hostname;		// hostname is FQDN.
			} else {
				// fall-through, try to get environment variable
			}
		} catch (UnknownHostException e) {
			// ignore, fall-through
		}

		hostname = System.getenv("HOSTNAME");
		if (TextUtil.isEmpty(hostname)) {
			hostname = System.getenv("HOST");
			if (TextUtil.isEmpty(hostname)) {
				hostname = "localhost.localdomain";
			}
		}
		return hostname;	// hostname is FQDN or non-FQDN.

	}

	public static final  String makeFQDN(String hostname) {

		if (hostname.indexOf('.') >= 0) {
			return hostname;
		} else if (domainName != null) {
			return hostname + domainName;
		} else {
			return hostname;
		}

	}

}
