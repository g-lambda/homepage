/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

public class TextUtil {

	public static String toNonNull(String text) {

		return (text == null) ? "" : text;

	}

	public static boolean isEmpty(String text) {

		return ((text == null) || (text.length() == 0));

	}

	public static boolean isValid(String text) {

		return ((text != null) && (text.length() > 0));

	}

	public static String fromList(Collection<String> textList, String delim) {

		if (CollectionUtil.isEmpty(textList)){
			return "";
		} else {
			final String[] emptyArray = new String[]{};
			return fromArray(textList.toArray(emptyArray), delim);
		}

	}

	public static String fromArray(String[] textArray, String delim) {

		if (CollectionUtil.isEmpty(textArray)) {
			return "";
		}
		delim = toNonNull(delim);

		StringBuffer sb = new StringBuffer();
		int i = 1;
		for (String text : textArray) {
			sb.append(text);
			if (i < textArray.length) {
				sb.append(delim);
			}
			i++;
		}
		return sb.toString();

	}

	public static String fromMap(Map<String, String> map, String delim) {

		if (CollectionUtil.isEmpty(map)) {
			return "";
		}
		delim = toNonNull(delim);

		StringBuffer sb = new StringBuffer();
		int i = 1;
		for (Entry<String, String> ent : map.entrySet()) {
			sb.append(ent.getKey());
			sb.append('=');
			sb.append(ent.getValue());
			if (i < map.size()) {
				sb.append(delim);
			}
			i++;
		}
		return sb.toString();

	}

	public static final double calcSize(String value) {

		/*
		 * value must be xxx[kKmMgGtT] such as "100M"
		 */
		String v = value.substring(0, value.length() - 1);
		char postfix = value.charAt(value.length() -1);
		double val;
		try {
			val = Double.parseDouble(v);
		} catch (NumberFormatException e) {
			throw new NumberFormatException("invalid number format: " + v);
		}

		final double K10 = 1000.0;
		final double K2 = 1024.0;
		switch (postfix) {
		case 'k':
			return K10 * val;
		case 'K':
			return K2 * val;
		case 'm':
			return K10 * K10 * val;
		case 'M':
			return K2 * K2 * val;
		case 'g':
			return K10 * K10 * K10 * val;
		case 'G':
			return K2 * K2 * K2 * val;
		case 't':
			return K10 * K10 * K10 * K10 * val;
		case 'T':
			return K2 * K2 * K2 * K2 * val;
		default:
			try {
				return Double.parseDouble(value);
			} catch (NumberFormatException e2) {
				throw new NumberFormatException("invalid number format: " + value);
			}
		}

	}

	public static final String[] cloneStringArray(String[] array) {

		if (CollectionUtil.isEmpty(array)) {
			return new String[]{};
		}

		String[] data = new String[array.length];
		int i = 0;
		for (String s : array) {
			data[i] = new String(s);
			i++;
		}
		return data;

	}
}
