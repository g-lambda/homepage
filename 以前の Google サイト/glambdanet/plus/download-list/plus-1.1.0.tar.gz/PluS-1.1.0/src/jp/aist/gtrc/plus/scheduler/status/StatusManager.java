/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;


public class StatusManager {

	private final HashMap<String, QueueStatus> queues;
	private final HashMap<String, NodeStatus> nodes;
	private final HashMap<String, JobStatus> jobs;
	private int qIndex;
	private boolean roundRobinQueue = false;

	private static StatusManager instance = null;

	protected StatusManager() {

		queues = new LinkedHashMap<String, QueueStatus>();
		nodes = new LinkedHashMap<String, NodeStatus>();
		jobs = new LinkedHashMap<String, JobStatus>();
		qIndex = 0;

	}

	public static synchronized StatusManager getInstance() {

		if (instance == null)
			instance = new StatusManager();
		return instance;

	}

	private void updateQueueIndex(Collection<QueueStatus> collection) {

		/*
		 * 		roundRobinQ			!roundRobinQ		'qIndex'
		 * 		q1	q2	q3	q4		q1	q2	q3	q4		q1	q2	q3	q4
		 * 1st:	0	1	2	3		0	1	2	3		0	1	2	3
		 * 2nd:	3	0	1	2		0	1	2	3		3	4	5	6
		 * 3rd:	2	3	0	1		0	1	2	3		6	7	8	9
		 * 4th:	1	2	3	0		0	1	2	3		9	10	11	12
		 * 	...
		 */
		for (QueueStatus q : collection) {
			q.setQueueIndex(qIndex % collection.size());
			qIndex++;
		}

		if (roundRobinQueue)
			qIndex -= 1;

	}

	protected void getAllJobs(MainServer srv) throws SchedulerException {

		for (JobStatus j : srv.getJobStatus()) {
			// TODO ???
			//j.setQueueStatus(q);	// to see queue priority/index from job
			addJob(j);
		}

	}

	protected final void addJob(JobStatus job) {

		jobs.put(job.getJobID().toString(), job);

	}

	public synchronized void updateStatus(MainServer srv) throws SchedulerException{

		nodes.clear();
		for (NodeStatus node : srv.getNodeStatus()) {
			nodes.put(node.getName(), node);
		}

		jobs.clear();	// always clear
		queues.clear();

		for (QueueStatus q : srv.getQueueStatus()) {
			queues.put(q.getName(), q);
		}
		updateQueueIndex(queues.values());

		getAllJobs(srv);

	}

	public synchronized Collection<QueueStatus> getQueues(){

		return queues.values();

	}

	public synchronized HashMap<String, QueueStatus> getQueueMap(){

		return queues;

	}

	public synchronized QueueStatus getQueue(String qname) {

		return queues.get(qname);

	}

	public synchronized Collection<NodeStatus> getNodes(){

		return nodes.values();

	}

	public synchronized HashMap<String, NodeStatus> getNodeMap(){

		return nodes;

	}

	public synchronized NodeStatus getNode(String nodeName) {

		return nodes.get(nodeName);

	}

	public synchronized Collection<JobStatus> getJobs(){

		return jobs.values();

	}

	public synchronized JobStatus getJob(String jobId) {

		/*
		 * 'jobId' must be got by JobStatus:getJobId().
		 * JobStatus:getJobName() is "STDIN" or user specified name.
		 * We use jobId for hash key, not job name.
		 */
		return jobs.get(jobId);

	}

}
