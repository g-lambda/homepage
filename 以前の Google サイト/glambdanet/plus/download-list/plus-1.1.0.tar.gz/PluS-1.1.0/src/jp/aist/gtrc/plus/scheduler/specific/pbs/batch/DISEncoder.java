/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch;

import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class DISEncoder {

	private String encodedData;

	public DISEncoder() {

		reset();

	}

	public final void reset(){

		encodedData = "";

	}

	private void addEncodedData(String data) {

		assert(TextUtil.isValid(data));
		encodedData += data;

	}

	public void putInt(int data) {

		//	data	value(DIS)	digit
		//	-------------------------
		//	-14		"2-14"		2
		//	 -9		"-9"		1
		//	 -1		"-1"		1
		//	  0		"+0"		1
		//	  1		"+1"		1
		//	  9		"+9"		1
		//	 14		"2+14"		2
		//	123		"3+123"		3

		String value;	// DIS format of data
		int digit;

		value = Integer.toString(data);
		if (data >= 0) {
			digit = value.length();
			value = "+" + value;
		} else {
			// value.charAt(0) == '-'
			digit = value.length() -1; 	// delete '-' char length
		}

		if (digit > 1) {
			value = Integer.toString(digit) + value;
		}

		addEncodedData(value);

	}

	public void putString(String data){

		//	data			DIS format				length
		//	---------------------------------------------------
		//	null			"+0"					0
		//	""				"+0"					0
		//	"Hello"			"+5Hello"				5
		//	"Hello, World"	"2+12Hello, World"		12

		if (data == null) {
			putInt(0);
		} else {
			putInt(data.length());
			addEncodedData(data);
		}

	}

	public void putAttrValue(String attr, String value){

		if (TextUtil.isValid(attr) && TextUtil.isValid(value)) {
			// attr and value is valid string
			putInt(1);	// one attr&value pair
			putInt(attr.length() + value.length() + 2);
			putString(attr);
			putInt(0);		// 0: without resource name, 1: exists
			putString(value);
		} else if (TextUtil.isEmpty(attr) && TextUtil.isEmpty(value)) {
			// attr and value is empty string
			putInt(0);	// zero pair
		} else {
			// attr or value is null
			assert(false);
		}

	}

	public void putAttrRscValue(String attr, String rsc, String value) {

		if (TextUtil.isValid(rsc)) {
			putInt(1);		// one attr&rsc&value pair
			putInt(attr.length() + rsc.length() + value.length() + 3);
			putString(attr);
			putInt(1);		// 1: resource name exists, 0: none
			putString(rsc);
			putString(value);
		} else {
			putAttrValue(attr, value);
		}
	}

	public String getEncodedData(){

		return encodedData;

	}

}
