/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.specific.sge.jaxb.common.*;
import jp.aist.gtrc.plus.scheduler.status.QInstanceStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatusBase;


public class SGEQueueStatus extends QueueStatusBase {

	private final JAXBSGEQueue queue;
	private final HashMap<String, QInstanceStatus> instances;
	private SGEACL acl;
	private Collection<SGEHostGroup> hgroups;
	private HashMap<String, SGEParallelEnv> peMap;
	private static final SGEStatusManager statusMgr = SGEStatusManager.getInstance();

	public SGEQueueStatus(JAXBSGEQueue queue) {

		assert(queue != null);
		this.queue = queue;
		this.instances = new LinkedHashMap<String, QInstanceStatus>();

		makeQInsMap();

	}

	private void makeQInsMap() {

		CQQinstances qinsList = queue.getCQQinstances();
		if (qinsList != null) {
			for (JAXBSGEQinstance jaxbQins : qinsList.getQUElement()) {
				SGEQInstance plusQins = new SGEQInstance(jaxbQins);
				instances.put(plusQins.getFullName(), plusQins);
			}
		}

	}

	public String getName() {
		return queue.getCQName();
	}

	public int getPriority() {
		return queue.getCQPriority();
	}

	public Collection<QInstanceStatus> getAllQInstances() {

		return instances.values();

	}

	public SGEQInstance getInstanceOnNode(String nodeName) {
		
		String fullName = getName() + "@" + nodeName;
		return (SGEQInstance)instances.get(fullName);
		
	}
	
	public boolean hasInstanceOnNode(SGENodeStatus node) {

		// 'fullname' maybe "all.q@host00.example.com"
		String fullName = getName() + "@" + node.getName();
		return instances.containsKey(fullName);

	}

	private Collection<USElement> getUSentries(CQAcl acl) {

		if (acl == null)
			return null;

		AUSRLISTElement list = acl.getAUSRLISTElement();
		if (list == null)
			return null;

		AUSRLISTValue value = list.getAUSRLISTValue();
		return (value == null) ? null : value.getUSElement();

	}

	private Collection<UPElement> getUPentries(CQProjects acl) {

		if (acl == null)
			return null;

		APRJLISTElement list = acl.getAPRJLISTElement();
		if (list == null)
			return null;

		APRJLISTValue value = list.getAPRJLISTValue();
		return (value == null) ? null : value.getUPElement();

	}

	private SGEACL makeAcl() {

		SGEUserACL userAcl = SGEUserACL.getInstance(
				getUSentries(queue.getCQAcl()),
				getUSentries(queue.getCQXacl()));
		SGEProjectACL projAcl = SGEProjectACL.getInstance(
				getUPentries(queue.getCQProjects()),
				getUPentries(queue.getCQXprojects()));
		return new SGEACL(userAcl, projAcl);

	}

	public SGEACL getAcl() {

		if (acl == null)
			acl = makeAcl();
		return acl;

	}

	private HashMap<String, SGEParallelEnv> makeParallelEnvs() {

		HashMap<String, SGEParallelEnv> map = new HashMap<String, SGEParallelEnv>();
		CQPeList peList = queue.getCQPeList();
		if (peList == null)
			return map;

		ASTRLISTElement strList = peList.getASTRLISTElement();
		if (strList == null)
			return map;
		ASTRLISTValue value = strList.getASTRLISTValue();
		if (value == null)
			return map;

		for (STElement e : value.getSTElement()) {
			String peName = e.getSTName();
			SGEParallelEnv pe = statusMgr.getParallelEnv(peName);
			if (pe != null) {
				map.put(peName, pe);
			} else {
				// invalid pe name, ignore.
				// may occur, sometimes normally
			}
		}

		return map;

	}

	public HashMap<String, SGEParallelEnv> getParallelEnvs() {

		if (peMap == null)
			peMap = makeParallelEnvs();
		return peMap;

	}

	public boolean hasParallelEnv(String peName) {

		return peMap.containsKey(peName);

	}

	private Collection<SGEHostGroup> makeHostGroups() {

		LinkedList<SGEHostGroup> groupList = new LinkedList<SGEHostGroup>();
		CQHostlist hostList = queue.getCQHostlist();
		if (hostList == null)
			return groupList;

		for (HRElement e : hostList.getHRElement()) {
			SGEHostGroup hgroup = statusMgr.getHostGroup(e.getHRName());
			if (hgroup != null) {
				groupList.add(hgroup);
			} else {
				// invalid hgroup name, ignore
			}
		}

		return groupList;

	}

	public Collection<SGEHostGroup> getHostGroups() {

		if (hgroups == null)
			hgroups = makeHostGroups();
		return hgroups;

	}

	public String toString() {

		StringBuffer sb = new StringBuffer(super.toString());
		sb.append("\nACL " + getAcl().toString());
		sb.append("\nPE ");
		for (SGEParallelEnv pe : getParallelEnvs().values()) {
			 sb.append(pe.getName() + " ");
		}
		sb.append("\nHostGroup ");
		for (SGEHostGroup hg : getHostGroups()) {
			 sb.append(hg.getName() + " ");
		}

		for (QInstanceStatus ins : instances.values()) {
			sb.append("\n" + ins.toString());
		}

		return sb.toString();

	}


}
