/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.util.Arrays;
import java.util.LinkedList;


public class Sorter<V> {

	private final LinkedList<SortKey<V>> sortKeys;

	public Sorter() {

		sortKeys = new LinkedList<SortKey<V>>();

	}

	public void addSortKey(SortKey<V> key){

		// primary sort key must set at first call,
		// and it is tail of sortKeys list
		sortKeys.addFirst(key);

	}

	public boolean containsKey(SortKey<V> key) {

		return sortKeys.contains(key);

	}

	public int size() {

		return sortKeys.size();

	}

	public void sort(V[] values){

		if (CollectionUtil.isEmpty(values))
			return;

		/*
		 * Primary sort key is a tail of sortKeys list,
		 * which are used at last sort() call.
		 */
		for (SortKey<V> k : sortKeys)
			Arrays.sort(values, k.getComparator());

	}

}
