/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request;

import java.util.Collection;
import java.util.Locale;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISEncoder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSJobStatus;
import jp.aist.gtrc.plus.scheduler.status.JobID;


public class BatchRequestRunJob  extends BatchRequest{

	private final JobID jobID;
	private final String destination;
	private final int resch;

	public BatchRequestRunJob(JobID jobID, String destination){

		super();
		this.jobID = jobID;
		this.destination = destination;	// exec-host name
		this.resch = 0;		// resource handle (not used)

	}

	private static String makeDestination(Collection<NodeInfo> nodes) {

		StringBuffer sb = new StringBuffer();
		for (NodeInfo n : nodes) {
			sb.append(String.format(Locale.US, "%s:ppn=%d+",
				n.getName(), n.getLaunchProcessNum()));
		}
		return sb.toString().substring(0, sb.length() -1);	// drop last "+"

	}

	public BatchRequestRunJob(PBSJobStatus job, Collection<NodeInfo> nodes) {

		this(job.getJobID(), makeDestination(nodes));

	}

	protected void encodeBody(DISEncoder encoder){

		encoder.putString(jobID.toString());
		encoder.putString(destination);
		encoder.putInt(resch);

	}

	public BatchRequestType getRequestType(){

		return BatchRequestType.RunJob;

	}

}
