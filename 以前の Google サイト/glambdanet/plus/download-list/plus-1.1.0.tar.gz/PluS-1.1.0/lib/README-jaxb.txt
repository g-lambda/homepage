==============================================================================
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================

					PluS and JAXB library

PluS uses JAXB for XML->Java object binding.
JAXB is a external library for Java 1.5.x, but it's a internal
library for Java 1.6.x.  

Add thease libraries to build path if you develop PluS on Eclipse for Java 1.5.x.
	activation.jar, jaxb1-impl.jar, jaxb-api.jar, jaxb-impl.jar, jsr173_api.jar

jaxb-xjc.jar is XSD->Java compiler, it's only used by build-for-Java15.xml,
not necessary to add to build path.

Thease JAXB libraries are not necessary if you build PluS by Java 1.6.

PluS startup script (plus_scheduler) is created by build.xml (Java 1.6) or
build-for-Java15.xml (Java 1.5). It set correct classpath for each.
