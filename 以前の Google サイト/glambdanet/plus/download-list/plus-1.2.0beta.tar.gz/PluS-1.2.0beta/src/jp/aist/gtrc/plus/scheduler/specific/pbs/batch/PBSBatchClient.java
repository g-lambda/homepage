/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch;

import java.io.IOException;
import java.net.Socket;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply.BatchReply;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequest;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request.BatchRequestType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSErrorCode;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSException;


public class PBSBatchClient extends PBSBatch {

	private Socket socket;

	public void setSocket(Socket socket){

		if (socket != null)
			logger.debug(socket.toString());
		this.socket = socket; // socket is null after pbs.disconnect()

	}

	public Socket getSocket() {

		return socket;

	}

	public BatchReply serverCall(BatchRequest request) throws PBSException {

		assert(request != null);
		if ((socket == null) || (socket.isConnected() == false)){
			throw new PBSException(PBSErrorCode.INTERNAL);
		}

		/*
		 * encode request
		 */
		encoder.reset();	// clear previous encoded data buffer
		request.encode(encoder);
		logger.debug(request.toString());

		/*
		 * send encoded request
		 */
		try {
			sendData(socket, encoder.getEncodedData());
		} catch (IOException e) {
			logger.warn("cannot send request: ", e);
			throw new PBSException(PBSErrorCode.NOSERVER);
		}
		if (request.getRequestType() == BatchRequestType.Disconnect)
			return null; // no reply

		/*
		 * receive encoded reply
		 */
		String rawReply;
		try {
			rawReply = receiveData(socket);
		} catch (IOException e) {
			logger.warn("cannot receive reply: ", e);
			throw new PBSException(PBSErrorCode.INTERNAL);
		}

		/*
		 * decode reply
		 */
		BatchReply reply = decoder.getDecodedReply(rawReply, request);
		logger.debug(reply.toString());

		return reply;

	}

}
