#!/bin/sh

# Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
# National Institute of Advanced Industrial Science and Technology.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# usage exmaple:
#  ./sge_rsvq_del.sh R123 4
#
# PHASE
#	3 : delete preQ&mainQ, resume postQ
#	4 : delete postQ, hostgroup, usergroup
#	5 : delete mainQ, hostgroup, usergroup
#	6 : same as 5, and delete postQ if exists
#	other: ignore

if [ "$#" -ne 2 ]; then
  echo 'usage: sge_rsvq_del.sh RSVID PHASE'
  exit 1
fi

RSVID=$1

SGE_QNAME="${RSVID}"
SGE_HOSTLIST="@${SGE_QNAME}_hosts"
SGE_USERLIST="${SGE_QNAME}_users"
SGE_PHASE=$2
SGE_PREQNAME="${RSVID}pre"
SGE_POSTQNAME="${RSVID}post"

delete_job() {
	# $1 must be one or more job id(s).
	# NOTE: "qdel jobid" waits to receive job termination reply from
	# sge_execd and records SGE account (usage) infomation for "qacct".
	# But "qdel -f jobid" doesn't wait it, and doesn't record it,
	# so you will not be able to see that job by "qacct".
	# "qdel -f" must be used if sge_execd will be down often (but I think
	# it doesn't occur so often).
	# See qdel(1) man page also.
	qdel $1
}

delete_jobs_on_Q() {
	qname=$1
	# delete jobs on qname which host_list is not NONE
	JOBS=`qstat -q ${qname} | grep '^ ' | awk '{print $1}'`
	if [ "$JOBS" ]; then
		delete_job "${JOBS}"
	fi

	# delete jobs on qname which host_list is NONE
	JOBS=`qstat -s p | grep '^ ' | awk '{print $1}'`
	if [ "$JOBS" ]; then
		for JOB in $JOBS; do
			HARD_QUEUE=`qstat -j ${JOB} | grep hard_queue_list | awk '{print $2}'`
			if [ "$HARD_QUEUE" = "${qname}" ]; then
				delete_job "${JOB}"
			fi
		done
	fi
}

delete_Q() {
	qname=$1
	delete_jobs_on_Q "${qname}"
	qconf -dq "${qname}"
	if [ "$?" -ne 0 ]; then
		# We could not delete this queue because some jobs still remain.
		# It sometimes takes a few time (<1 sec?) to delete *running* jobs
		# completely by "qdel jobid".
		# Retry to delete queue after 1 sec.
		sleep 1
		qconf -dq "${qname}"
		if [ "$?" -ne 0 ]; then
			# Suspend it at least if failed.
			qmod -sq "${qname}"
		fi
	fi
}

delete_preQ() {
	delete_Q "${SGE_PREQNAME}"
}

delete_mainQ() {
	delete_Q "${SGE_QNAME}"
}
	
delete_postQ() {
	delete_Q "${SGE_POSTQNAME}"
}

delete_allQ() {
	delete_Q "${SGE_PREQNAME}"
	delete_Q "${SGE_QNAME}"
	delete_Q "${SGE_POSTQNAME}"
}

delete_hostgroup_and_usergroup() {
	qconf -dhgrp "${SGE_HOSTLIST}"
	qconf -dul "${SGE_USERLIST}"
}

if [ "$SGE_PHASE" -eq "3" ]; then
	delete_preQ
	delete_mainQ
	qmod -usq "${SGE_POSTQNAME}"
elif [ "$SGE_PHASE" -eq "4" ]; then
	delete_postQ
	delete_hostgroup_and_usergroup
elif [ "$SGE_PHASE" -eq "5" ]; then
	delete_mainQ
	delete_hostgroup_and_usergroup
elif [ "$SGE_PHASE" -eq "6" ]; then
	delete_allQ
	delete_hostgroup_and_usergroup
fi
