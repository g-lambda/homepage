/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.SchedulerOptions;
import jp.aist.gtrc.plus.scheduler.node.EnoughResourceNodeChecker;
import jp.aist.gtrc.plus.scheduler.node.FreePeriodNodeChecker;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.node.RestrictNodeByQueueChecker;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.util.Filter;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;


public class ReserveNodeAllocator extends Filter<NodeInfo> implements NodeAllocator {

	protected final NodeManager nodeMgr;
	protected final StatusManager statusMgr;
	protected final String defaultQName;
	private final String adFilePath;

	public ReserveNodeAllocator(SchedulerOptions options, NodeManager nodeMgr,
			StatusManager statusMgr) {

		assert(nodeMgr != null);
		assert(statusMgr != null);

		this.nodeMgr = nodeMgr;
		this.statusMgr = statusMgr;
		this.defaultQName = options.getTargetQueueName();
		this.adFilePath = options.getReserveFilePath()
			+ "/" + ReserveClassAdChecker.DEFAULT_CLASSAD_FILE;

	}

	protected ReserveClassAdChecker makeClassAdChecker(
			Collection<NodeInfo> nodes, NodeAllocateRequest allocReq,
			String adFilePath, String evalAttr){

		return new ReserveClassAdChecker(nodeMgr, adFilePath, evalAttr, allocReq);

	}

	private RestrictNodeByQueueChecker makeQueueChecker(String qNames) {

		if (TextUtil.isValid(qNames)) {
			LinkedList<QueueStatus> qList = new LinkedList<QueueStatus>();
			for (String qName : qNames.split(",")) {
				QueueStatus queue = (QueueStatus)statusMgr.getQueue(qName);
				if (queue != null) {
					qList.add(queue);
				}
			}
			return new RestrictNodeByQueueChecker(qList);
		} else {
			return null;
		}

	}

	private RestrictNodeByQueueChecker getQueueChecker(NodeAllocateRequest allocReq) {

		String qNames = allocReq.getReserveRequest().getOptions().getTargetQueueName();
		if (TextUtil.isValid(qNames)) {
			return makeQueueChecker(qNames);
		} else {
			return makeQueueChecker(defaultQName);
		}
	}

	public Collection<NodeInfo> suitable(Collection<NodeInfo> nodes, NodeAllocateRequest allocReq){

		assert(allocReq != null);

		// Qname checker
		// restricts reserve nodes of the specified queue
		// (plus_reserve -tgtq qName ... or plus_scheduler -tgtq qName1,qName2 ...)
		RestrictNodeByQueueChecker qChecker = getQueueChecker(allocReq);
		if (qChecker != null) {
			addOneTimeChecker(qChecker);
		} else {
			// don't restrict nodes by queue
		}

		// Node is reserved while requested period checker
		addOneTimeChecker(new FreePeriodNodeChecker(
				allocReq.getStartTime(), allocReq.getEndTime()));

		// Node resources (CPU, Memory, OS etc) checker
		addOneTimeChecker(new EnoughResourceNodeChecker(
				allocReq));

		// ClassAd checker (NOTE: check at last)
		String evalAttr;
		Calendar now = Calendar.getInstance();
		evalAttr = now.before(allocReq.getStartTime())
			? ReserveClassAdChecker.DEFAULT_EVAL_ATTR_WAITING
			: ReserveClassAdChecker.DEFAULT_EVAL_ATTR_RUNNING;
		addOneTimeChecker(makeClassAdChecker(nodes, allocReq,
				adFilePath, evalAttr));

		int maxAlloc = 0;
		for (NodeAllocateSet set : allocReq.getRequestedNodeAllocateSets()) {
			maxAlloc += set.getRequestedNum();
		}
		return filter(nodes, maxAlloc);

	}

	String getAdFilePath() {
		return adFilePath;
	}

}
