/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.status;

import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QInstanceStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatusBase;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

//	attr			value
//	-----------------------------
//	batch			7
//		queue_type		Execution
//		total_jobs		0
//		...
//	workq			7
//		queue_type		Execution
//		total_jobs		1
//		state_count		Transit:0 Queued:1 Held:0 Waiting:0 Running:0 Exiting:0
//		resources_assigned	ncpus	0
//		resources_assigned	nodect	0
//		enabled			True
//		started			True
//		Priority			0				<<< THIS IS OPTIONAL VALUE, use qmgr


public class PBSQueueStatus extends QueueStatusBase implements QueueStatus, StatusMap {

	private final StatusMap map;
	private static final  StatusManager statMgr = StatusManager.getInstance();
	private Collection<QInstanceStatus> qinsList = null;
	
	/*
	 * Delimiter of acl_hosts is "+" in
	 *   http://www.clusterresources.com/wiki/doku.php?id=torque:4.1_queue_configuration#routing
	 * but is "," in
	 *   http://www.clusterresources.com/products/mwm/docs/12.1nodelocation.shtml#open 
	 */
	private static final String ACL_ENTRY_DELIM = ",";

	public PBSQueueStatus(String name){

		map = new StatusMapImpl(name);

	}

	public String getQueueType(){

		return getStatus("queue_type");

	}

	public boolean isExecution(){

		return getQueueType().equals("Execution");

	}

	public boolean isEnabled(){

		return getStatus("enabled").equals("True");

	}

	public boolean isStarted(){

		return getStatus("started").equals("True");

	}

	public boolean isReadyToUse(){

		return isExecution() && isEnabled() && isStarted();

	}

	public int getTotalJobs(){

		return Integer.parseInt(getStatus("total_jobs"));

	}

	public int getStateCount(String type){

		String s = getStatus("state_count");

		for (String t : s.split("\\s")) {
			if (t.startsWith(type)) {
				// t is "Queued:1" (if type is "Queued")
				// u is "1" (plus 1 means length of ":")
				String u = t.substring(type.length() + 1);
				return Integer.parseInt(u);
			}
		}

		return 0;	// Not found

	}

	public int getQueuedJobs(){

		return getStateCount("Queued");

	}

	public int getRunningJobs(){

		return getStateCount("Running");

	}

	public int getPriority() {

		/*
		 * If you want to use queue priority, set it by qmgr such as
		 * 		% su
		 * 		# qmgr
		 * 		Qmgr: set queue QUEUE_NAME priority = VALUE
		 * 		Qmgr: quit
		 * If not set, "Priority" doesn't appear.
		 */
		String p = getStatus("Priority");
		if (p != UNKNOWN_STATUS)
			return Integer.parseInt(p);
		else
			return 0;		// default normal priority

	}

	public boolean isSuspended() {

		return (!isEnabled() || !isStarted());

	}

	private Collection<QInstanceStatus> malkeAllQInstanceList() {
		LinkedList<QInstanceStatus> list = new LinkedList<QInstanceStatus>();
		if (isAclHostEnable() == false) {
			/*
			 * restrict nodes if "acl_hosts" is *FALSE*, not true.
			 * see http://www.clusterresources.com/products/mwm/docs/12.1nodelocation.shtml#open
			 *		queue to node mapping can be accomplished by using the qmgr
			 *		command to set the queue acl_hosts parameter to the mapping
			 *		hostlist desired. Further, the acl_host_enable parameter
			 *		should be set to False.
			 *		NOTE: Setting acl_hosts and then setting acl_host_enable
			 *		to True constrains the list of hosts from which jobs may
			 *		be submitted to the queue.
			 */
			String[] hosts = getAclHosts();
			if (hosts.length > 0) {
				// restricts to the usable nodes of this queue
				for (String host : getAclHosts()) {
					list.add(new PBSQInstanceStatus(this, statMgr.getNode(host)));
				}
				return list;
			}
		}

		// all exec-nodes
		for (NodeStatus node : statMgr.getNodes()) {
			list.add(new PBSQInstanceStatus(this, node));
		}
		return list;
	}

	public Collection<QInstanceStatus> getAllQInstances() {
		if (qinsList == null) {
			qinsList = malkeAllQInstanceList();
		}
		return qinsList;
	}

	public String getQname() {

		return getName();
	}

	public boolean isAclHostEnable() {
		String val = getStatus("acl_host_enable");
		if (TextUtil.isValid(val)) {
			return val.equalsIgnoreCase("true");
		} else {
			return false;
		}
	}
	
	public String[] getAclHosts() {
		String val = TextUtil.toNonNull(getStatus("acl_hosts"));
		return val.split(ACL_ENTRY_DELIM);
	}

	public boolean isAclUserEnable() {
		String val = getStatus("acl_user_enable");
		if (TextUtil.isValid(val)) {
			return val.equalsIgnoreCase("true");
		} else {
			return false;
		}
	}
	
	public String[] getAclUsers() {
		String val = TextUtil.toNonNull(getStatus("acl_users"));
		return val.split(ACL_ENTRY_DELIM);
	}

	public String getName() {
		return map.getName();
	}

	public String getStatus(String attr) {
		return map.getStatus(attr);
	}

	public String getStatus(String name, String attr) {
		return map.getStatus(name, attr);
	}

	public StatusMap getStatusMap(String name) {
		return map.getStatusMap(name);
	}

	public void putStatus(String attr, String value) {
		map.putStatus(attr, value);
	}

}
