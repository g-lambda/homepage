/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.dummy;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Properties;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.status.JobID;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.sys.SignalType;

public class DummyMainServer implements MainServer {

	private final Properties prop = new Properties();
	private final Collection<JobStatus> jobList = new LinkedList<JobStatus>();
	private final Collection<NodeStatus> nodeList = new LinkedList<NodeStatus>();
	private final Collection<QueueStatus> queueList = new LinkedList<QueueStatus>();
	
	public static final String CPUNUM_KEY = "cpuNum";
	public static final String NODENAMES_KEY = "nodeNames";
	
	private void loadProp(String propFileName) throws IOException {
		InputStream stream = new FileInputStream(propFileName);
		prop.load(stream);
		
		int cpuNum = Integer.parseInt(prop.getProperty(CPUNUM_KEY, "1"));
		String nodeNames[] = prop.getProperty(NODENAMES_KEY, "host00").split(",");
		
		for (String name : nodeNames) {
			DummyNodeStatus node = new DummyNodeStatus(name, cpuNum);
			nodeList.add(node);
		}
	}

	DummyMainServer(String propFileName) throws IOException {
		loadProp(propFileName);
		queueList.add(new DummyQueueStatus("queue"));
	}

	public void disconnect() {
	}

	public Collection<JobStatus> getJobStatus() throws SchedulerException {
		return jobList;
	}

	public Collection<NodeStatus> getNodeStatus() throws SchedulerException {
		return nodeList;
	}

	public Collection<QueueStatus> getQueueStatus() throws SchedulerException {
		return queueList;
	}

	public void deleteJob(JobID jobID) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void holdJob(JobID jobID) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void releaseJob(JobID jobID) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void rerunJob(JobStatus job) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void resumeJob(JobID jobID) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void runJob(JobID jobID, NodeStatus node) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void runJob(JobStatus job, Collection<NodeInfo> nodes)
			throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void signalJob(JobID jobID, SignalType signal)
			throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}

	public void suspendJob(JobID jobID) throws SchedulerException {
		throw new SchedulerException("unsupported method");
	}
}
