/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.condor;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatusBase;
import jp.aist.gtrc.plus.scheduler.status.OSType;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import condor.classad.Expr;
import condor.classad.RecordExpr;

public class CondorNodeStatus extends NodeStatusBase {
	private final boolean alive;
	private final boolean idle;
	private final OSType osType;
	private final ArchType archType;
	private final int cpuNum;
	private final double loadAverage;
	private final long physicalMemory;
	private final int runningJobNum;
	private final String name;

	public CondorNodeStatus(Expr expr) throws SchedulerException {
		RecordExpr rec = (RecordExpr) expr;

		alive = true;
		idle = (Util.stringAttr(rec, "Activity") .equals("Idle"));
		name = Util.stringAttr(rec, "Name");
		osType = osMap.get(Util.stringAttr(rec, "OpSys"));
		archType = archMap.get(Util.stringAttr(rec, "Arch"));
		cpuNum = 1;
		loadAverage = Util.doubleAttr(rec, "LoadAvg");
		physicalMemory = Util.intAttr(rec, "Memory") * 1024L * 1024L;   
		//idleTime = Util.intAttr(rec, "KeyboardIdle");
		runningJobNum = idle ? 0 : 1; 
	}

	public boolean isAlive() {
		return alive;
	}

	public boolean isIdle() {
		return idle;
	}

	public OSType getOSType() {
		return osType;
	}

	public ArchType getArchType() {
		return archType;
	}

	public int getCPUNum() {
		return cpuNum;
	}

	public double getLoadAverage() {
		return loadAverage;
	}

	public long getPhysicalMemory() {
		return physicalMemory;
	}

	public int getRunningJobNum() {
		return runningJobNum;
	}

	public Collection<JobStatus> getJobs() {
		// TODO
		return null;
	}

	public String getName() {
		return name;
	}

	public static Map<String, OSType> osMap = new HashMap<String, OSType>();
	public static Map<String, ArchType> archMap = new HashMap<String, ArchType>();
	static {
		osMap.put("LINUX", OSType.Linux);
	
		archMap.put("INTEL", ArchType.x86);
	}
	
	
}
