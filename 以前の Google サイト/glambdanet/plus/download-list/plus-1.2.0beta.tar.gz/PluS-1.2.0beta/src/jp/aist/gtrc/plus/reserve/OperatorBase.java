/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import org.apache.log4j.Logger;


class OperatorBase {

	protected final ReserveManager rsvMgr;
	protected final ReserveTable table;
	protected final ReserveRecorder recorder;

	protected static final Logger logger = Logger.getLogger(OperatorBase.class);

	protected OperatorBase(ReserveManager rsvMgr) {

		this.rsvMgr = rsvMgr;
		this.table = rsvMgr.getReserveTable();
		this.recorder = rsvMgr.getReserveRecorder();

	}

	protected final synchronized void startCurrentOperation(ReserveOperation ope) throws ReserveException {

		rsvMgr.startCurrentOperation(ope);

	}

	protected final synchronized ReserveOperation getCurrentOperation() {

		return rsvMgr.getCurrentOperation();

	}

	protected final synchronized void finishCurrentOperation() {

		rsvMgr.finishCurrentOperation();

	}

	protected final ReserveInfo getReserveInfoWithoutException(ReserveId rsvId) {

		return table.get(rsvId);

	}

	protected final ReserveInfo getReserveInfo(ReserveId rsvId) throws ReserveException {

		ReserveInfo info = getReserveInfoWithoutException(rsvId);
		if (info != null)
			return info;
		else if (rsvId != null)
			throw new ReserveException("Unknown ReserveId: " + rsvId);
		else
			throw new ReserveException("Invalid ReserveId");

	}

}
