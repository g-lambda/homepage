/************************************************************************
Copyright 2003, 2004, 2005, 2006, 2007, 2008 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.condor;

import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import condor.classad.Expr;
import condor.classad.RecordExpr;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.job.JobStateType;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.status.JobID;
import jp.aist.gtrc.plus.scheduler.status.JobStatusBase;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class CondorJobStatus extends JobStatusBase {
	private final CondorJobID jobID;
	private final String owner;
	private final JobStateType state;
	private final Calendar submitTime;
	private final Calendar execStartTime;
	private final ReserveId reserveId;
	
	public CondorJobStatus(Expr expr) throws SchedulerException {
		RecordExpr rec = (RecordExpr) expr;
		
		int cluster = Util.intAttr(rec, "ClusterId");
		int node    = Util.intAttr(rec, "ProcId");
		jobID = new CondorJobID(cluster, node);
		
		try {
			String tmp = Util.stringAttr(rec, "PluSResourceFor");
			reserveId = ReserveId.getInstance(tmp);
		} catch (SchedulerException e){
			throw e;
		}
		
		owner = Util.stringAttr(rec, "Owner");
		setPriority(Util.intAttr(rec, "JobPrio"));
		state = stateMap.get(Util.intAttr(rec, "JobStatus"));
		submitTime = new GregorianCalendar();
		submitTime.setTimeInMillis(Util.intAttr(rec, "QDate") * 100L);
		try {
			int start = Util.intAttr(rec, "JobStartDate");
			execStartTime = new GregorianCalendar();
			execStartTime.setTimeInMillis(start * 100L);
		} catch (NumberFormatException e) {
			throw new SchedulerException(e);
		} catch (SchedulerException e) {
			throw e;
		}
	}
	
	public JobID getJobID() {
		return jobID;
	}

	public String getOwner() {
		return owner;
	}

	public JobStateType getState() {
		return state;
	}

	public Calendar getSubmitTime() {
		return submitTime;
	}

	public Calendar getExecStartTime() {
		return execStartTime;
	}

	public ReserveId getReserveId() {
		return reserveId;
	}

	public Collection<NodeAllocateSet> getNodeRequests() {
		NodeAllocateSet set = new NodeAllocateSet(
				1, new NodeResource(1, 1));
		Collection<NodeAllocateSet> reqs = new LinkedList<NodeAllocateSet>();
		reqs.add(set);
		return reqs;
	}

	public static Map<Integer, JobStateType> stateMap = new HashMap<Integer, JobStateType>();
	static {
		stateMap.put(1, JobStateType.Queued);
		stateMap.put(2, JobStateType.Running);
		stateMap.put(3, JobStateType.Exiting);
		stateMap.put(4, JobStateType.Exiting);		
		stateMap.put(5, JobStateType.Held);
		stateMap.put(6, JobStateType.Exiting);
	}


}
