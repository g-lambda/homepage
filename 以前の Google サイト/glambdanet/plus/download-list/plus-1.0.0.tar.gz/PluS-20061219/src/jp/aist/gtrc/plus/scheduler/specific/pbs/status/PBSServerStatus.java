/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.status;

import jp.aist.gtrc.plus.scheduler.status.ServerStatus;


//	attr			value
//	-----------------------------
//	server_state	Scheduling
//	server_host		koume.hpcc.jp
//	scheduling		True
//	total_jobs		1
//	state_count		Transit:0 Queued:1 Held:0 Waiting:0 Running:0 Exiting:0 Begun:0
//	managers		ohkubo@*.hpcc.jp,root@koume.hpcc.jp
//	operators		ohkubo@*.hpcc.jp,root@koume.hpcc.jp
//	default_queue	workq
//	log_events		511
//	mail_from		adm
//	query_other_jobs	True
//	resources_default	ncpus	1
//	resources_default	nodect	1
//	resources_default	walltime	00:15:00
//	resources_assigned	ncpus	0
//	resources_assigned	nodect	0
//	scheduler_iteration	600
//	node_ping_rate	300
//	node_check_rate	600
//	tcp_timeout		6
//	job_stat_rate	30
//	pbs_version		torque_1.2.0p4


public class PBSServerStatus extends StatusMap implements ServerStatus {

	private static final String RES_DEFAULT = "resource_default";
	private static final String RES_ASSIGNED = "resources_assigned";

	public PBSServerStatus(String name){
		
		super(name);
		
	}

	public String getServerName(){

		return getStatus("server_host");

	}

	public boolean isScheduling(){

		return getStatus("scheduling").equals("True");

	}
	
	public String getServerState() {
		
		return getStatus("server_state");
		
	}
	
	public boolean isReadyToUse() {
		
		return isScheduling();//  && (getServerState().equals("Scheduling"));
		
	}

	public String getDefaultQueue(){

		return getStatus("default_queue");

	}

	public int getTotalJobs(){

		return Integer.parseInt(getStatus("total_jobs"));

	}

	public int getStateCount(String state){

		String s = getStatus("state_count");
		// s = "Transit:0 Queued:1 Held:0 ...."

		if (s == UNKNOWN_STATUS)
			return 0;
		
		for (String t : s.split("\\s")) {
			if (t.startsWith(state)) {
				// t is "Queued:1" (if state is "Queued")
				// u is "1" (plus 1 means length of ":")
				String u = t.substring(state.length() + 1);
				return Integer.parseInt(u);
			}
		}

		logger.debug("unknown status: " + state);
		return 0;	// Not found

	}

	public int getQueuedJobs(){

		return getStateCount("Queued");

	}

	public int getRunningJobs(){

		return getStateCount("Running");

	}

	public int getDefaultResourceCPU(){

		return Integer.parseInt(
				getStatus(RES_DEFAULT, "ncpus"));

	}
	
	public int getAssignedNode(){
		
		return Integer.parseInt(
				getStatus(RES_ASSIGNED, "nodect"));

	}

}