/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply;

import java.util.LinkedHashMap;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchOperationType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISDecoder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.StatusMap;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSErrorCode;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSException;


abstract class BatchReplyStatus<V extends StatusMap> extends BatchReply { 
	
	protected Map<String, V> map;

	protected BatchReplyStatus(BatchReplyHeader header){

		super(header);
		map = new LinkedHashMap<String, V>();

	}

	protected void decodeOneRank(DISDecoder decoder, StatusMap parent,
			int attrNum) throws PBSException {

		//	type	var			description
		//	-------------------------------
		//	int		sumLen		withResc==0: attr.length() + value.length() + 2
		//						withResc==1: attr.length() + resname.length() + value.length() + 3
		//	String	attr		"server_state", "Job_Name" etc
		//	int		withResc 	0: without resname, 1: with resname
		//	(String	resname)	<OPTIONAL (if withResc==1)> "ncpus", "nodect" etc
		//	String	value		"Scheduling", "MyJob" etc
		//	int		batchOp		<IGNORE> 0: SET etc
		//
		// Ex1: "2+242+12server_state+02+10Scheduling+0"
		//	means: server_state is Scheduling
		//
		//				DIS	format			real value
		//		-----------------------------------------
		//		sumLen	"2+24"				24 (= 12 + 10 + 2)
		//		attr	"2+12server_state"	"server_state"	(len=12)
		//		withResc"+0"				0
		//		(resname	none)
		//		value	"2+10Scheduling"	"Scheduling"	(len=10)
		//		batchOp	"+0"				0
		//
		// Ex2: "2+272+18resources_assigned+1+5ncpus+10+0"
		//	means:	resources_assigned of ncpus is 0
		//
		//				DIS	format			real value
		//		-----------------------------------------
		//		sumLen	"2+27"				27 (= 18 + 5 + 1 + 3)
		//		attr	"2+18resources_assigned"
		//									"resources_assigned"	(len=18)
		//		withResc"+1"				1 (resname exists)
		//		resname	"+5ncpus"			"ncpus"		(len=5)
		//		value	"+10"				"0"			(len=1)
		//		batchOp	"+0"				0
		
		int i, sumLen,  withResc, batchOp;
		String attr, resname, value;
		
		for (i = 0; i < attrNum; i++) {
			sumLen = decoder.getInt();
			attr = decoder.getString();
			withResc = decoder.getInt();
			if (withResc == 0) {
				resname = null;
			} else {
				resname = decoder.getString();
			}
			value = decoder.getString();
			batchOp = decoder.getInt();
			
			if ((attr.length() == 0) || (value.length() == 0) ||
					(batchOp != BatchOperationType.SET.value())) {
				logger.warn("status data is broken");
				throw new PBSException(PBSErrorCode.BADATLST); 
			}
			
			if (withResc == 0) {
				if (attr.length() + value.length() + 2 != sumLen) {
					logger.warn("status data is broken");
					throw new PBSException(PBSErrorCode.BADATLST); 
				}
				parent.putStatus(attr, value);
			} else {
				if ((resname.length() == 0) ||
						(attr.length() + resname.length() + value.length() + 3 != sumLen)) {
					logger.warn("status data is broken");
					throw new PBSException(PBSErrorCode.BADATLST); 
				}
				StatusMap child = parent.getStatusMap(attr);
				assert(child != null);	 // allocate if not exists
				child.putStatus(resname, value);
			}
		}

	}

	public void decode(DISDecoder decoder) throws PBSException{

		int num = decoder.getInt();
	
		for (int i = 0; i < num; i++) {
			int objType = decoder.getInt();
			String name = decoder.getString();
			int subNum = decoder.getInt();
			
			assert(objType == getObjectType().value());
			V child = newStatus(name);
			map.put(name, child);
			
			decodeOneRank(decoder, child, subNum);
		}

	}

	public V getStatus(String name) {
		
		return map.get(name);
		
	}

	public String toString() {
		String s = super.toString() + "\n";
		
		/*
		for (StatusMap v : map.values()) {
			s += v.toString();
		}
		*/
		
		return s;
	}

	protected abstract BatchObjectType getObjectType();
	protected abstract V newStatus(String name);

}