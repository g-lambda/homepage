/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.node;

import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEACL;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEParallelEnv;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEStatusManager;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGETaskStatus;
import jp.aist.gtrc.plus.scheduler.util.Checker;

public class SGEJobPEChecker extends Checker<SGETaskStatus> {

	private static SGEStatusManager statusMgr = SGEStatusManager.getInstance();
	
	public boolean isOK(SGETaskStatus task) {
		
		String tgtPe = task.getTargetParallelEnvName();
		if (tgtPe.length() == 0) {
			return true;
		}
		
		SGEParallelEnv pe = statusMgr.getParallelEnv(tgtPe);
		if (pe == null) {
			// invalid PE name is specified, qsub shall reject it.
			assert(false);
			return false;
		}
		
		SGEACL acl = pe.getAcl();
		return acl.isAllowedTo(task.getOwner(), tgtPe);
			
	}

}
