/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public abstract class XMLStatus {

	public abstract String getName();

	protected HashMap<String, String> map;
	private String prefix;

	protected static Logger logger = Logger.getLogger(XMLStatus.class);
	
	protected XMLStatus(Node node, String prefix) throws SchedulerException {

		map = new LinkedHashMap<String, String>();
		
		try {
			NodeList nodes = node.getChildNodes();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node sub = nodes.item(i);
				if (sub.getNodeType() != Node.ELEMENT_NODE)
					continue;
				addNode(sub);
			}
		} catch (Exception e) {
			throw new SchedulerException(e.getMessage());
		}

		this.prefix = prefix;
		
	}
	
	protected XMLStatus() {
		map = new LinkedHashMap<String, String>();
		prefix = "";
	}
	
	protected XMLStatus(XMLStatus status) {
		this.map = new LinkedHashMap<String, String>(status.map);
		this.prefix = status.prefix;
	}
	
	protected void addNode(Node sub) throws Exception {
		
		map.put(sub.getNodeName(), sub.getTextContent());

	}
	
	protected void addAttrValueNode(Node node) {
		
		NodeList elements = node.getChildNodes();
		for (int i = 0; i < elements.getLength(); i++) {
			Node elem = elements.item(i);
			if (elem.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}

			NodeList children = elem.getChildNodes();
			for (int j = 0; j < children.getLength(); j++) {
				if (elem.getNodeType() != Node.ELEMENT_NODE) {
					continue;
				}
				
				// s maybe "    cpu   0.070000"
				// t[] will be { "", "cpu", "0.070000" }
				String s = elem.getTextContent();
				String t[] = s.split("\\s+");
				if ((t.length == 3) && (t[0].length() ==0)) {
					map.put(t[1], t[2]);
					break;
				}
			}
		}
		
	}

	protected String getString(String name) {
		
		String s = map.get(prefix + name);
		// logger.debug("Key=" + prefix + name + ", Value=" + s);
		if (s != null)
			return s;
		else
			return "";

	}
	
	protected int getInt(String name) {
		
		String s = getString(name);
		if (s.length() > 0)
			return Integer.parseInt(s);
		else
			return 0;
		
	}
	
	protected double getDouble(String name) {
		
		String s = getString(name);
		if (s.length() > 0)
			return Double.parseDouble(s);
		else
			return 0.0;

	}
	
	protected int[] getIntParams(String name) {
		
		String s = getString(name);
		if (s.length() == 0)
			return new int[]{};
		
		String t[] = s.split("\\s+");
		if (t.length <= 1)
			return new int[]{};
		
		// t[] = { "", "param1", "param2", ... }, skip t[0]
		int params[] = new int[t.length-1];
		for (int i = 0; i < params.length; i++) {
			int v;
			try {
				v = Integer.parseInt(t[i+1]);
			} catch (NumberFormatException e) {
				v = 0;		// ignore error
			}
			params[i] = v;
		}
		
		return params;
		
	}

	protected String[] getStringParams(String name) {
		
		return getStringParams(name, 0);
		
	}

	protected String[] getStringParams(String name, int skip) {
		
		String s = getString(name);
		if (s.length() == 0)
			return new String[]{};
		
		String t[] = s.split("\\s+");
		if (t[0].length() == 0)
			skip++;
		if (t.length <= skip)
			return new String[]{};
		
		// maybe t[] = { "", "param1", "param2", ... }, skip t[0] normally.
		// if skip==2, return { "param2", ... }
		String params[] = new String[t.length - skip];
		for (int i = 0; i < params.length; i++) {
			params[i] = t[i + skip];
		}
		
		return params;
		
	}
	
	protected void setAttrValue(String attr, String value) {
		
		logger.debug("attr:" + prefix+attr 
				+ ", old value:" + map.get(prefix+attr)
				+ ", new value:" + value);
		map.put(prefix+attr, value);
		
	}

	public String toString() {
		
		String s = "XMLStatus: name = " + getName() + "\n";

		for (Map.Entry<String, String> e : map.entrySet()) {
			s += "\t" + e.getKey() + "\t" + e.getValue().toString() + "\n";
		}

		return s;
		
	}
	
}
