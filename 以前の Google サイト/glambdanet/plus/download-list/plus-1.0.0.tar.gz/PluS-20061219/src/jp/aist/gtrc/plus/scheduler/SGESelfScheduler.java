/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeSorter;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.node.SGEExecNodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.node.SGEReserveNodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.*;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEScheduleStarter;
import jp.aist.gtrc.plus.scheduler.status.*;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

class SGESelfScheduler extends DefaultScheduler {

	private boolean jobReruned;
	
	SGESelfScheduler(String[] args) throws Exception {

		super(args);
		
		startReserveServer();
		
	}

	protected StatusManager getStatusManager(String[] args) throws SchedulerException {
		
		return SGEStatusManager.getInstance();
		
	}

	protected ScheduleStarter getScheduleStarter(String[] args) throws SchedulerException {

		return new SGEScheduleStarter();
		
	}

	protected NodeAllocator getExecNodeAllocator(SchedulerOptions options) throws SchedulerException {
		
		return new SGEExecNodeAllocator(new NodeSorter(options));
		
	}
	
	protected NodeAllocator getRsvNodeAllocator(SchedulerOptions options) throws SchedulerException {
		
		return new SGEReserveNodeAllocator(options, nodeMgr);
		
	}
	
	protected MainServer getMainServer() throws Exception  {
		
		return (MainServer)new SGEMainServer();
		
	}
	
	protected void runSchedule(ScheduleOrder order) throws SchedulerException {
		
		super.runSchedule(order);
		afterSchedule(order.getMainServer());
		
	}
	
	protected void schedule(ScheduleOrder order) throws SchedulerException{

		MainServer srv = order.getMainServer();
		
		Collection<JobStatus> allJobs = statusMgr.getJobs();
		Collection<JobStatus> runnableJobs = jobMgr.getRunnableJobs(allJobs);
		if (runnableJobs == null)
			return;

		jobReruned = false;
		while ((runnableJobs.size() > 0) && (jobReruned == false)) { 
			JobStatus job = scheduler.selectJob(runnableJobs);
			runOneJob(srv, job);
			runnableJobs.remove(job);
		}
		
	}
	
	protected boolean handleUnreservedJobs(MainServer srv, Collection<NodeInfo> rsvdNodes) {

		Collection<JobStatus> allTasks = statusMgr.getJobs();
		HashSet<SGEJobStatus> rerunedJobs = new HashSet<SGEJobStatus>();
		
		/*
		 * 'tasksOnNodeMap' is HashMap of Task list
		 * ex.
		 * 	 key		value [ task list of running on the node ]
		 * node00		{ TaskA, TaskB }
		 * node01		{ TaskA, TaskX, taskY }
		 */
		HashMap<String, LinkedList<SGETaskStatus>> tasksOnNodeMap
			= new HashMap<String, LinkedList<SGETaskStatus>>();
		for (JobStatus t : allTasks) {
			SGETaskStatus task = (SGETaskStatus)t;
			if (task.isRunning() == false) {
				continue;
			}
			if (task.getReserveId() != null) {
				// 'task' is running with reserve. OK to run.
				continue;
			}
			for (SGEGrantedQueue gq : task.getGrantedQueues()) {
				// NOTE: 'nodename' is queue fullname actually
				String nodename = gq.getQName();
				LinkedList<SGETaskStatus> list = tasksOnNodeMap.get(nodename);
				if (list == null) {
					list = new LinkedList<SGETaskStatus>();
					tasksOnNodeMap.put(nodename, list);
				}
				list.add(task);
			}
		}
		if (tasksOnNodeMap.size() == 0)
			return false;
		
		for (NodeInfo node : rsvdNodes) {
			SGEQInstance qIns = (SGEQInstance)node.getStatus();

			// NOTE: 'nodename' is queue fullname actually
			String nodename = qIns.getName();
			Collection<SGETaskStatus> tasksOnNode = tasksOnNodeMap.get(nodename);
			if (tasksOnNode == null) {
				// no unreserved-running task on this 'node'
				continue;
			}
			for (SGETaskStatus task : tasksOnNode) {
				SGEJobStatus job = task.getSGEJobStatus();
				if (rerunedJobs.contains(job)) {
					// already reruned 'job' by previous task
					continue;
				}
				
				try {
					/*
					 * NOTE: rerunJob(SGETaskStatus) will
					 * 	 1. resubmit 'job' (not 'task'), make clone of 'job'
					 * 	 2. delete (means kill) 'job'
					 * After them, clone of 'job' remains.
					 */
					srv.rerunJob(task);
					jobReruned = true;
				} catch (SchedulerException e) {
					logger.info("cannot rerun of " + task.getName());
				}
				
				// 'job' is already reruned, not check anymore
				rerunedJobs.add(job);
			}
		}
		
		return jobReruned;
		
	}

	protected void afterSchedule(MainServer srv)  {
		
		SGEMainServer sgeSrv = (SGEMainServer)srv; 
		Collection<JobStatus> allJobs = statusMgr.getJobs();
		for (JobStatus j : allJobs) {
			SGETaskStatus task = (SGETaskStatus)j;
			if (task.isReadyToDelete()) {
				try {
					sgeSrv.expireJob(task.getJobID());
				} catch (SchedulerException e) {
					// ignore fail
					logger.info("Failed to expire job: " + task.getJobID());
				}
			}
		}
		
	}

	protected void stopScheduler() {
		
		try {
			SGEMainServer srv = new SGEMainServer();
			srv.shutdown();
		} catch (SchedulerException e) {
			// ignore
		}
		
		super.stopScheduler();

	}

}