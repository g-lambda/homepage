/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

class TwoPhaseOperator extends OperatorBase {

	protected TwoPhaseOperator(ReserveManager rsvMgr) {

		super(rsvMgr);

	}

	protected final void checkCommitAbort(ReserveId rsvId) throws ReserveException {

		ReserveOperation currentOpe = getCurrentOperation();
		if (currentOpe == null) {
			throw new ReserveException("needless commit/abort");
		}
		if (rsvId == null) {
			throw new ReserveException("missing ReserveId");
		}

		ReserveId desId = currentOpe.getReserveId();
		if (rsvId.equals(desId) == false) {
			throw new ReserveException("invalid ReserveId for commit/abort");
		}

	}

	protected final void done() {

		ReserveOperation currentOpe = getCurrentOperation();
		assert(currentOpe != null);

		ReserveInfo target = currentOpe.getTargetReserveInfo();
		try {
			if (target != null) {
				recorder.removeOperation(currentOpe);
				recorder.commit(target);
				if (currentOpe.getOperationType() != ReserveOperationType.remove) {
					rsvMgr.kickScheduler(target);
				}
			}
		} catch (ReserveException e) {
			// ignore
		}

		finishCurrentOperation();

	}

}
