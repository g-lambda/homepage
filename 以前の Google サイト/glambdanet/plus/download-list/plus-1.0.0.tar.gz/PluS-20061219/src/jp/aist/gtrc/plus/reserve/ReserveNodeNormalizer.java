/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.reserve.ReserveStatus.State;
import static jp.aist.gtrc.plus.reserve.ReserveStatus.State.*;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;

class ReserveNodeNormalizer {

	private ReserveManager rsvMgr;
	private ReserveTable table;
	private ReserveRecorder recorder;
	private NodeManager nodeMgr;
	private NodeAllocator nodeAllocator;
	
	ReserveNodeNormalizer(ReserveManager rsvMgr) {
	
		this.rsvMgr = rsvMgr;
		this.table = rsvMgr.getReserveTable();
		this.recorder = rsvMgr.getReserveRecorder();
		this.nodeMgr = rsvMgr.getNodeManager();
		this.nodeAllocator = rsvMgr.getNodeAllocator();
		
	}

	private Collection<NodeInfo> dropAllocatedNodes(Collection<NodeInfo> allNodes,
			Collection<NodeInfo> allocatedNodes) {
		
		if (allocatedNodes.size() == 0) {
			return allNodes;
		}
		
		LinkedList<NodeInfo> list = new LinkedList<NodeInfo>();
		for (NodeInfo node : allNodes) {
			if (allocatedNodes.contains(node) == false) {
				list.add(node);
			}
		}
		
		return list;
		
	}

	protected ReserveNodeSet makeReserveNodeSet(ReserveRequest rsvReq) throws ReserveException {
		
		Calendar start = rsvReq.getStartTime();
		ReserveNodeSet nodeSet = new ReserveNodeSet(nodeMgr);
		Collection<NodeInfo> candidates, usable;
		NodeAllocateRequest allocReq = new NodeAllocateRequest(rsvReq);

		/*
		 * 1st: allocate nodes from previous reserves
		 */
		for (ReserveInfo info : table.getNotAfterEndTime(start)) {
			State state = info.getReserveState();
			if ((state != Confirmed) && (state != Running)) {
				continue;	// 'state' is done/canceled/error
			}
			
			candidates = dropAllocatedNodes(info.getReservedNodeInfos(), nodeSet.getAll());
			if (candidates.size() > 0) {
				usable = nodeAllocator.suitable(candidates, allocReq);
				if (usable != null) {
					nodeSet.add(usable);
				}
			}
			if (allocReq.isAllocatedEnough()) {
				return nodeSet;	// already allocated enough
			}
			
			ReserveNodeSet set = info.getReserveNodeSet();
			assert(set != null);
			if (set.isNodeSkipped() == false) {
				break;
			}
		}
		
		/*
		 * 2nd: allocate nodes from all nodes if 1st is not enough
		 */
		candidates = dropAllocatedNodes(nodeMgr.getNodes(), nodeSet.getAll());
		usable = null;
		if (candidates.size() > 0) {
			usable = nodeAllocator.suitable(candidates, allocReq);
		}
		if (allocReq.isAllocatedEnough()) {
			nodeSet.add(usable);
		} else {
			// we cannot allocate enough nodes
			throw new ReserveException("Cannot reserve nodes");
		}

		return nodeSet;
		
	}
	
	protected void reallocateNodes(Calendar startTime, boolean equalTimeAlso) throws ReserveException {
		
		Collection<ReserveInfo> candidateInfos;
		Collection<ReserveInfo> targetInfos;
		int nSkip = 0;
		
		candidateInfos = table.getAfterStartTime(startTime, equalTimeAlso);
		if ((candidateInfos == null) || (candidateInfos.size() == 0)) {
			// no reserve info to reallocate
			return;
		}
		
		targetInfos = new LinkedList<ReserveInfo>();
		
		/*
		 * 1st: free all reserved nodes which starts after 'rsvInfo'
		 */
		for (ReserveInfo info : candidateInfos) {
			if (info.getReserveState() != Confirmed) {
				continue;
			}
			
			ReserveNodeSet curNodeSet = info.getReserveNodeSet();
			assert(curNodeSet != null);
			if (curNodeSet.isNodeSkipped() == false) {
				nSkip++;
				if (nSkip >= 2) {
					break;
				}
			}

			targetInfos.add(info);
			info.unregisterReservedNodesTemporary();
		}
		
		if (targetInfos.size() == 0) {
			return;
		}
		rsvMgr.getCurrentOperation().setReallocatedReserveInfo(targetInfos);
		
		/*
		 * 2nd: re-allocate nodes for them
		 */
		for (ReserveInfo info : targetInfos) {
			ReserveRequest rsvReq = info.getReserveRequest();
			ReserveNodeSet newNodeSet = makeReserveNodeSet(rsvReq);
			if (info.modify(newNodeSet) == true) {
				recorder.store(info);
			}
		}
	
		/*
		 * NOTE: we don't recover modification here even if failed.
		 * Caller must use abort() to recover.
		 */
	}
	
}
