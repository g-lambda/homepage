/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;
import java.util.LinkedList;


public class SGEUserACL extends SGEACLBase<SGEUserset> {

	private static SGEStatusManager statusMgr = SGEStatusManager.getInstance();
	
	protected Collection<SGEUserset> makeEmptyList() {
		
		return new LinkedList<SGEUserset>();
		
	}
	
	private static Collection<SGEUserset> makeUsersets(String rawText[]) {

		String names[] = getACLEntryNames(rawText);
		if (names == null)
			return null;
		
		LinkedList<SGEUserset> list = new LinkedList<SGEUserset>();
		for (String userset : names) {
			SGEUserset us = statusMgr.getUserset(userset);
			if (us != null) {
				list.add(us);
			} else {
				// invalid userset name, ignore
				assert(false);
			}
		}
		
		return list;
		
	}
	
	static SGEUserACL getInstance(String acl[], String xacl[]) {
		
		Collection<SGEUserset> allows = makeUsersets(acl);
		Collection<SGEUserset> denys = makeUsersets(xacl);
		
		SGEUserACL userAcl = new SGEUserACL();
		userAcl.setAllowsDenys(allows, denys);
		
		return userAcl;
		
	}

	protected boolean contains(String username, Collection<SGEUserset> collection) {
		
		assert(collection != null);
		
		for (SGEUserset uset : collection) {
			if (uset.contains(username))
				return true;
		}
		return false;
		 
	}

}
