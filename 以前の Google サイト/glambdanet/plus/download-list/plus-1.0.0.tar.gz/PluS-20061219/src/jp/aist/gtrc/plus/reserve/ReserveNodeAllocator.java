/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Collection;

import jp.aist.gtrc.plus.scheduler.SchedulerOptions;
import jp.aist.gtrc.plus.scheduler.node.EnoughResourceNodeChecker;
import jp.aist.gtrc.plus.scheduler.node.FreePeriodNodeChecker;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.util.Filter;


public class ReserveNodeAllocator extends Filter<NodeInfo> implements NodeAllocator {

	private String dbPath;
	private NodeManager nodeMgr;
	
	public ReserveNodeAllocator(SchedulerOptions options, NodeManager nodeMgr) {
	
		this.dbPath = options.getReserveFilePath();
		this.nodeMgr = nodeMgr;
			
	}
	
	public Collection<NodeInfo> suitable(Collection<NodeInfo> nodes, NodeAllocateRequest allocReq){
		
		assert(allocReq != null);

		addOneTimeChecker(new ReserveClassAdChecker(nodeMgr, dbPath, allocReq));
		
		// checker added by addOneTimeChecker() will be removed
		// automatically after doing filter()
		addOneTimeChecker(new FreePeriodNodeChecker(
				allocReq.getStartTime(), allocReq.getEndTime()));
		
		addOneTimeChecker(new EnoughResourceNodeChecker(
				allocReq));
		
		int maxAlloc = 0;
		for (NodeAllocateSet set : allocReq.getRequestedNodeAllocateSets()) {
			maxAlloc += set.getRequestedNum();
		}
		return filter(nodes, maxAlloc);

	}

}