This file is written in UTF-8 (Japanese). TAB=4chars.

Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

				sge_operatord の仕様
								2006/11/21
					
								
sge_operatord は、文字列ベースで要求を受け取り、それに対応する
SGE GDI (SUN Grid Engine Gridengine Database Interface)関数を
呼び出すサーバーである。
sge_qmaster に対する要求を簡易に扱うための中間サーバーと言える。

★構成図
＝＝＝＝

					 +---------------+
					　| Java        |
					 | スケジューラー |
					 +---------------+
		文字列による	    ↓      ↑　１行文字列/XML形式での
		要求送信　	    ↓      ↑　応答受信
					 +-----------------+
		GDI 呼出	 | sge_operatord |	CULL -> XML 変換
					 +-----------------+
		GDI を利用した  ↓      ↑	GDI の応答
		要求送信		    ↓      ↑  CULL 形式
					 +-----------------+
					 | sge_qmaster   |
					 +-----------------+

CULL (Common Usable List Library) は、SGE で内部情報を管理
しているリスト(を利用したツリー)である。					 

 

★sge_operatord のコンパイル
＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
SGE 6.0u8 のソースをダウンロードする。
sge-V60u8-plus.patch を当てる。

source/aimk.site の OPENSSL_HOME, BERKELEYDB_HOME, source/scripts/distinst.site の
OPENSSLBASE, BERKELEYDBBASE を適切なディレクトリに設定する。
なお、OpenSSL ライブラリとそのヘッダがない環境では、./aimk -no-secure でビルドすれば良い。
BerkeleyDB ライブラリは、なくても sge_operatord を作れるが、SGE 全体のビルドには
必要とされる。

通常通り SGE をビルドすると、source/LINUX86_26/sge_operatord が 出来る。
./aimk -only-core とすれば、SGE ツールコマンド類はビルドされないので
早く済む。

sge_operatord さえ出来れば、そのほかのビルドに失敗しても良い。
その場合は、公開されている SGE バイナリをセットアップしておき、
$SGE_ROOT/bin/lx26-x86/ に自分でビルドした sge_operatord だけを
コピーする。


★動作環境
＝＝＝＝＝
以下の環境での動作確認をした。


[1] lx26-x86
	SGE			grindengine 6.0u8, 6.0u9
	OS			Linux 2.6.11 (FedoraCore 4)
	CPU			Pentium 4
	gcc			4.0.0
	OpenSSL	0.9.7f
	BerkeleyDB	4.3.27

[2] lx24-x86
	SGE			grindengine 6.0u8
	OS			Linux 2.4.20 (RedHat 8)
	CPU			Pentium 3
	gcc			3.2.1
	OpenSSL	0.9.7i
	BerkeleyDB	4.4.20
	
[3] lx26-amd64
	SGE			grindengine 6.0u8
	OS			Linux 2.6.5 (SuSE Enterprise Server 9.3)
	CPU			Opteron x 2
	gcc			3.3.3
	OpenSSL	0.9.7l
	BerkeleyDB	4.2.52
	
[4] sol-amd64
	SGE			grindengine 6.0u8
	OS			Solaris 10
	CPU			Opteron x 2
	gcc			3.4.3
	OpenSSL	なし  (aimk -no-secure でビルド)
	BerkeleyDB	なし

[5] sol-sparc64
	SGE			grindengine 6.0u8
	OS			Solaris 9
	CPU			sparc (Ultra-60)
	gcc			3.4.1 (Sun C 5.9 でもOK)
	OpenSSL	なし  (aimk -no-secure でビルド)
	BerkeleyDB	なし
	
[6] sol-x86
	SGE			grindengine 6.0u8
	OS			Solaris 10  (ただし VMware 上)
	CPU			Pentium 4
	gcc			3.4.3
	OpenSSL	0.9.7i
	BerkeleyDB	なし


★sge-V60u8-plus.patch の内容
＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
●sge_operatord.c
	sge_operatord サーバー本体
●sge_operatord をビルド対象とするための Makefile 変更
	sge_operatord を Makefile に追加した。
	SGE本体についてコンパイル警告が多数出るので、-Werror を消した。
●sge_operatord のための、CULL->XML 変換ルーチン lWriteElemXMLTo2() の追加
	オリジナルの lWriteElemXMLTo() ではXMLタグに CULL リスト名が使われ、
	<リスト名>...</リスト名> という形になる。リスト名が空の時は、<element>...
	</element> となる。このリスト名は、"JOB:", "job_sublist" など、SGE 内部
	で適当に指定されている。それらの中には、XML のタグとしてふさわしくない表記
	(空白や/)が含まれたり、sge_qmaster 再起動によってリスト名が変わることもあり、
	XML 解釈に失敗することになる。
	lWriteElemXMLTo2() では、この問題の解決のため、XMLタグを常に
	<element name="リスト名">...</element> という形式で出力するようにした。
	この形式であれば、リスト名に空白や/が含まれても問題にならない。
●異なる SGE バージョン対応のための SGE_GDI_VERSION 環境変数の追加
	GDI 要求には、要求元SGEのバージョン番号が含まれ、受け付けた sge_qmaster と
	番号が異なれば処理を拒否されてしまう。それぞれのバージョン用に sge_operatord
	をビルドするのは面倒なので、GDI 要求に指定されるバージョン番号を環境変数
	SGE_GDI_VERSION で上書きできるようにした。
	バージョン番号は以下の通りである。
		名前				番号
		---------------------------
		6.0, 6.0u1		0x10000FFF
		6.0u3			0x10001000
		6.0u4 〜 6.0u8	0x10001001
		6.0u9			0x10001002
	
	自分のソースのバージョン番号は libs/gdi/sge_gdiP.h に
		#define GRM_GDI_VERSION 0x10001001
	というように定義されている。
	
	例えば、SGE6.0u8 環境でビルドした sge_operatord を SGE 6.0u1 環境で動作させるには
		% setenv SGE_GDI_VERSION 0x10000FFF
		% ./sge_operatord
	などとすればよい。
	ただし安全のためには、ターゲット環境のバージョンで sge_operatord をコンパイル
	することが望ましい。
	
	本スケジューラーと sge_operatord は SGE 6.0 系列用に開発されている。
	SGE 5.3 系列と 6.0 系列ではキューの扱いが全く異なるため、上記環境変数の指定に関わらず
	正しく処理できないと思われる（動作未確認）。

●ジョブの Resubmit での、ジョブオーナー・グループの指定追加
qresub コマンドを利用すると、既に投入されたジョブのコピーをもう一度投入できる。
ただし、コピージョブのオーナーは元のオーナーではなくて qresub 実行者となってしまう。
Java スケジューラーが qresub 相当処理を行うと、コピージョブのオーナーが全て
スケジューラーの起動者なってしまい、意図した処理にならないので、コピージョブのオーナー・
オーナーグループを指定できるようにした。

これは、daemons/qmaster/sge_job_qmaster.c の sge_gdi_copy_job() で、
要求引数に JB_owner, JB_uid, JB_group, JB_gid 属性が指定されていた場合、
それを優先するようにした。
セキュリティー上あまり望ましくないかもしれないが、Resubmit 処理実体はそのジョブの
オーナーかSGE管理者しか出来ないようになっているので、実用上問題は無いと思われる。


★sge_operatord 起動条件
＝＝＝＝＝＝＝＝＝＝＝＝＝
デフォルトでは 16000 番を開く。
起動時に "sge_operatord port" と言うように指定すれば、port を開く。
サーバー起動時にポート使用済みの場合は、エラー終了となる。

sge_operatord 起動者は誰でも良い(rootでなくても良い)。
ただし、sge_operatord 起動者は、SGE の世界での Manager グループに参加して
いること。でないと、RunJob 指令などは sge_qmaster に拒否される。

sge_operatord 起動ノードで、sge_qmaster も起動して*いる*こと。

sge_operatord 起動ノードで、sge_schedd は起動し*ない*こと。
sge_operatord も、スケジューラーとして qmaster に接続するので、
動作はするが、排他利用となるため。


★接続クライアントの条件
＝＝＝＝＝＝＝＝＝＝＝
sge_operatord は、ローカルホストからの要求しか受け付けない。

sge_qmaster との接続認証はない。

要求文字列の末尾には必ず改行を付けること。
sge_operatord が UNIX 環境で動作しており、fgets() で入力待ちしているので、
改行文字は '\n' である。

sge_operatord はシングルスレッドで動作しているので、同時に複数のクライアント
からの接続を受けることは出来ない。


★sge_operatord の機能
＝＝＝＝＝＝＝＝＝＝＝＝＝
＜情報取得処理＞
"GetStatus 情報種別名" を受信すると、その情報を XML 形式で応答する。
情報取得失敗の場合は、改行付きエラーメッセージを返す。

情報種別名としては、以下をサポートしている。
	情報種別名			SGEシンボル						意味					同義コマンド
	---------------------------------------------------------------------------------
   server				SGE_ADMINHOST_LIST			管理者ホスト 		qconf -sh
   submithost			SGE_SUBMITHOST_LIST			ジョブ投入ホスト		qconf -ss
   node				SGE_EXECHOST_LIST				実行ホスト			qhost
   queue				SGE_CQUEUE_LIST				クラスタキュー		qconf -sql
   job					SGE_JOB_LIST					ジョブ				qstat
   event				SGE_EVENT_LIST				状態変更通知イベント
   centry				SGE_CENTRY_LIST				リソース情報定義		qconf -sc
   order				SGE_ORDER_LIST				qmaster に対する処理待ち要求（？）
   master_event		SGE_MASTER_EVENT				？
   config				SGE_CONFIG_LIST				実行ノードことの設定	qconf -sconf hostname
   manager				SGE_MANAGER_LIST				SGE管理者名			qconf -sm
   operator			SGE_OPERATOR_LIST				SGEオペレーター		qconf -so
   pe					SGE_PE_LIST					並列実行環境			qconf -spl
   sched_conf			SGE_SC_LIST          		スケジューラーの設定	qconf -ssconf
   user				SGE_USER_LIST					利用者				qconf -suserl
   userset				SGE_USERSET_LIST				利用者グループ		qconf -sul
   project				SGE_PROJECT_LIST				プロジェクト			qconf -sprjl
   sharetree			SGE_SHARETREE_LIST			シェアツリー情報		qconf -sstree
   ckpt				SGE_CKPT_LIST					チェックポイント		qconf -sckptl
   calendar			SGE_CALENDAR_LIST				利用カレンダー		qconf -scall
   job_schedd_info	SGE_JOB_SCHEDD_INFO			スケジューリング情報	qstat -f -j jobid 
   zombie				SGE_ZOMBIE_LIST				ゾンビジョブ			
   user_mapping		SGE_USER_MAPPING_LIST		？
   hgroup				SGE_HGROUP_LIST				ホストグループ		qstat -shgrpl
   dummy				SGE_DUMMY_LIST				何もしない

●"RunJob jobid qInstance qVersion qSlot [qInstance qVersion qSlot...] [PEname]\n"
	jobid を qInstance 上で実行させる。並列実行の場合は複数指定し、最後に
	PEname も指定する。
	jobid は jobnum.tasknum の形式 (例 "12.1") とする。
	qInstance は "all.q@host00.example.com" といった形式である。
	qVersion は GetStatus queue で得られる QU_version の値である。キューの設定を
	変更するとインクリメントされる。この値が正しくないと、要求は拒否される。
	qSlot は qInstance に投入するプロセス数である。
	成功した場合 "OK\n" を、失敗した場合は改行付きエラーメッセージを
	応答する。

●"DeleteJob jobid\n"
	まだ終了していない jobid を削除する。現在実行中ならば強制停止の上削除する。
	qdel jobid に相当する。
	jobid は jobnum.tasknum か jobnum とする。
	tasknum が指定されればそのタスクだけ、無ければそのジョブ全体が削除される。
	成功した場合 "OK\n" を、失敗した場合は改行付きエラーメッセージを
	応答する。

●"ExpireJob jobid\n"
	既に終了した jobid を削除する。
	SGE では終了したジョブの情報は、qstat で見えなくなってもqmaster内部に残っており、
	スケジューラーが削除しなければならない。
	成功した場合 "OK\n" を、失敗した場合は改行付きエラーメッセージを
	応答する。

●"SuspendJob jobid\n"
	ジョブを一時停止する。qmod -sj jobid に相当する。
	jobid は jobnum.tasknum か jobnum とする。
	
●"ResumeJob jobid\n"
	ジョブを再開する。qmod -usj jobid に相当する。
	jobid は jobnum.tasknum か jobnum とする。
	
●"HoldJob jobid\n"
	ジョブの実行を一時禁止する。qhold jobid に相当する。
	jobid は jobnum.tasknum か jobnum とする。
	
●"ReleaseJob jobid\n"
	ジョブの実行禁止を解く。qrls jobid に相当する。
	jobid は jobnum.tasknum か jobnum とする。
	
●"ResubmitJob jobid owner uid group gid\n"
	現在実行中のジョブをキューに再投入してから元のジョブを削除する。
		sudo -u owner qresub jobid
		qdel jobid
	に相当する処理を行う。
	jobid は jobnum とし、taskid 付きは認めない。
	qresub すると、新ジョブのオーナーは元ジョブのオーナーではなく、
	qresub 実行者になってしまう。このため、元のジョブオーナーを指定し、
	その情報もコピーするようにした。SGE 本体にも修正を加えた。
	
●"Bye\n"
	現在接続中のクライアントの接続を切る。
	サーバーは次の要求待ちになる。

●"Shutdown\n"
	現在接続中のクライアントの接続を切る。
	サーバーも終了する。

	
★利用のテスト方法
＝＝＝＝＝＝＝＝
サーバー側
	sudo SGE/bin/LINUX86_26/sge_qmaster
	<sge_schedd を起動しないこと>
	<sge_execd は適宜起動する>
	
	SGE/bin/LINUX86_26/sge_operatord 16000
	
クライアント側
	sge_operatord 起動ノードで、telnet コマンドを利用する。
	
	> telnet localhost 16000
	GetStatus server
		<XML形式でサーバー情報を得る>
	GetStatus queue
		<XML形式でキュー情報を得る>
	GetStatus node
		<XML形式で実行ノード情報を得る>
	GetStatus job
		<XML形式でジョブ情報を得る>
	。。。
	Bye あるいは Shutdown


★Java GDI について
＝＝＝＝＝＝＝＝＝＝
2006/09/15 に、CVS 上の gridengine ソースに Java GDI モジュールが
追加された。まだ開発中であるが、sge_operatord と開発目的は似ている。
http://gridengine.sunsource.net/source/browse/gridengine/source/libs/jgdi/src/com/sun/grid/jgdi/
ただし、RunJob 相当インターフェースは、現時点では無い。

[EOF]