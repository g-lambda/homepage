/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.job.JobStateType;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateSet;
import jp.aist.gtrc.plus.scheduler.status.JobID;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class SGETaskStatus extends XMLStatus implements JobStatus {

	private SGEJobStatus job;
	private JobID jobId;
	private JobStateType stateType;
	private SGEUsageList usage, scaledUsage;
	private HashMap<String, SGEGrantedQueue> grantedQ;

	static final int TS_IDLE 			= 0x00000000;		//	0
	static final int TS_ENABLED			= 0x00000008;		//	8
	static final int TS_HELD				= 0x00000010;		// 16
	static final int TS_MIGRATING		= 0x00000020;		// 32
	static final int TS_QUEUED			= 0x00000040;		// 64
	static final int TS_RUNNING			= 0x00000080;		// 128
	static final int TS_SUSPENDED		= 0x00000100;		// 256
	static final int TS_TRANSFERING		= 0x00000200;		// 512
	static final int TS_DELETED			= 0x00000400;		// 1024
	static final int TS_WAITING			= 0x00000800;		// 2048
	static final int TS_EXITING			= 0x00001000;		// 4096
	static final int TS_WRITTEN			= 0x00002000;		// 8192
	static final int TS_WAITING4OSJID	= 0x00004000;		// 16384
	static final int TS_ERROR			= 0x00008000;		// 32768
	static final int TS_FINISHED		= 0x00010000;		// 65536
	static final int TS_SLAVE			= 0x00020000;		// 131072
	static final int TS_SIMULATED		= 0x00040000;		// 262144
	
	private static SGEStatusManager statusMgr = SGEStatusManager.getInstance();
	
	private static final String TASK_NUMBER_KEY = "task_number";
	private static final String TASK_STATUS_KEY = "status";
	
	
	SGETaskStatus(Node node, SGEJobStatus job) throws Exception {
		
		super(node, "JAT_");
		this.job = job;
		
	}
	
	SGETaskStatus(SGEJobStatus job, int taskId, int state) {
		/*
		 * Make Idle SGETaskStatus using template & its taskId
		 */
		super(job.getTemplateTask());
		this.job = job;
		setAttrValue(TASK_NUMBER_KEY, Integer.toString(taskId));
		setAttrValue(TASK_STATUS_KEY, Integer.toString(state));
		
	}
	
	private void addGrantedQueue(Node node) throws Exception {
		
		if (grantedQ == null)
			grantedQ = new HashMap<String, SGEGrantedQueue>();
		
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node sub = list.item(i);
			if (sub.getNodeType() != Node.ELEMENT_NODE)
				continue;

			SGEGrantedQueue q = new SGEGrantedQueue(sub);
			grantedQ.put(q.getName(), q);
		}

	}

	protected void addNode(Node node) throws Exception {
		
		String name = node.getNodeName();
		
		if (name.endsWith("usage_list")) {
			if (name.equals("JAT_usage_list")) {
				usage = new SGEUsageList(node);
			} else if (name.equals("JAT_scaled_usage_list")) {
				scaledUsage = new SGEUsageList(node);
			} else {
				assert(false);
			}
		} else if (name.equals("JAT_granted_destin_identifier_list")) {
			// NOTE: Only running task has this node, waintig/finished not.
			addGrantedQueue(node);
		} else {
			super.addNode(node);
		}
		
	}

	int getTaskNumber() {
		
		return getInt(TASK_NUMBER_KEY);
		
	}
	
	public SGEJobStatus getSGEJobStatus() {
		
		return job;
		
	}
	
	public JobID getJobID() {

		if (jobId == null)
			jobId = new SGEJobID(job.getJobNumber(), getTaskNumber());
		return jobId;
		
	}

	public String getOwner() {

		return job.getOwner();
		
	}

	public String getUid() {

		return job.getUid();
		
	}

	public int getPriority() {

		return job.getPriority();
		
	}

	public void setPriority(int newPrio) {
		
		job.setPriority(newPrio);
		
	}

	public String getName() {

		return getJobID().toString();
		
	}

	public Date getSubmitTime() {
		
		return job.getSubmitTime();
		
	}

	public ReserveId getReserveId() {
		
		return job.getReserveId();
		
	}

	public Collection<NodeAllocateSet> getNodeRequests() {
		
		return job.getNodeRequests();
		
	}

	public int getRequestedTime() {
		
		return job.getRequestedTime();
		
	}

	public String getOwnersGroup() {

		return job.getOwnersGroup();
		
	}

	public String getGid() {

		return job.getGid();
		
	}

	public String getOwnersHost() {

		return job.getOwnersHost();
		
	}

	public QueueStatus getQueueStatus() {

		return job.getQueueStatus();
		
	}

	public boolean isRunnableOn(NodeStatus node) {

		return job.isRunnableOn(node);
		
	}

	private JobStateType makeStateType() {
		
		// 'state' is bit-or of TaskStatusType value 
		int state = getInt(TASK_STATUS_KEY);

		if ((state & TS_HELD) != 0)
			return JobStateType.Held;
		if ((state & TS_SUSPENDED) != 0)
			return JobStateType.Suspended;
		if ((state & TS_FINISHED) != 0)
			return JobStateType.Exiting;
		if ((state & TS_DELETED) != 0)
			return JobStateType.Exiting;
		if ((state & TS_RUNNING) != 0)
			return JobStateType.Running;
		
		Calendar now = Calendar.getInstance();
		if (now.before(getRequestedExecStartTime()))
			return JobStateType.Held;
		
		return JobStateType.Queued;

	}
	
	public JobStateType getState() {
		
		if (stateType == null)
			stateType = makeStateType();
		return stateType;
		
	}

	public void setQueueStatus(QueueStatus q) {

		job.setQueueStatus(q);
		
	}

	public boolean isReadyToRun() {
		
		if (statusMgr.isDirtyTask((SGEJobID)getJobID()))
			return false;
		
		/*
		 *	JB_restart		JAT_job_restarted 	stauts	readyToRun
		 *	-------------------------------------------------------------
		 *	0 or 2			0						IDLE	YES
		 *	0 or 2			1					<nerver happen>
		 *
		 *	1 (yes)			0						IDLE	YES
		 *	1				1						IDLE	YES
		 */
		
		// except held/suspended/waiting even if the job is queued
		return (getInt(TASK_STATUS_KEY) == TS_IDLE);

	}
	
	public boolean isReadyToDelete() {
		
		return (getState() == JobStateType.Exiting);
		
	}

	public boolean isQueued() {
		
		return (getState() == JobStateType.Queued);
		
	}

	public boolean isRunning() {

		return (getState() == JobStateType.Running);

	}
	
	public String[] getTargetQueueNames() {
		
		return job.getTargetQueueNames();
		
	}
	
	public String getTargetProjectName() {
		
		return job.getTargetProjectName();
		
	}
	
	public	String getTargetParallelEnvName() {
		
		return job.getTargetParallelEnvName();
		
	}
	
	public SGEParallelEnv getTargetParallelEnv() {
		
		return job.getTargetParallelEnv();
		
	}
	
	public int[] getPEProcNumRange() {
		
		return job.getPEProcNumRange();
		
	}
	
	public Calendar getRequestedExecStartTime() {
		
		return job.getRequestedExecStartTime();
		
	}
	
	public Collection<SGEGrantedQueue> getGrantedQueues() {
		
		if (grantedQ != null)
			return grantedQ.values();
		else
			return null;
		
	}
	
	public String toString() {
		
		String s = super.toString();
		if (usage != null)
			s += usage.toString();
		if (scaledUsage != null)
			s += scaledUsage.toString();
		return s;
		
	}

}
