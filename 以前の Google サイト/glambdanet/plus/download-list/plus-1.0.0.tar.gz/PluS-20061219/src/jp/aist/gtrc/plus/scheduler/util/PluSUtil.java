/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class PluSUtil {

	/*
	 * hostname, domainname, make FQDN
	 */
	private static String domainName = null;
	static {
		try {
			String hostname = getLocalHostName();
			int index = hostname.indexOf('.');
			if (index > 0) {
				// 'domainName' will be ".example.com" etc
				domainName = hostname.substring(index);
			}
		} catch (Exception e) {
			// ignore
		}
		
	}

	public final static String getLocalHostName() {
		
		String hostname;
		try {
			hostname = InetAddress.getLocalHost().getCanonicalHostName();
			if (hostname.indexOf('.') > 0) {
				return hostname;		// hostname is FQDN.
			} else {
				// fall-through, try to get environment variable
			}
		} catch (UnknownHostException e) {
			// ignore, fall-through
		}

		hostname = System.getenv("HOSTNAME");
		if (hostname == null) {
			hostname = System.getenv("HOST");
			if (hostname == null) {
				hostname = "localhost.localdomain";
			}
		}
		return hostname;	// hostname is FQDN or non-FQDN.
		
	}
	
	public final static String makeFQDN(String hostname) {
		
		if (hostname.indexOf('.') >= 0) {
			return hostname;
		} else if (domainName != null) {
			return hostname + domainName;
		} else {
			return hostname;
		}
		
	}

	private static boolean logOut = false;
	private static Logger logger = null;
	
	public static final void showLog() {
		
		logOut = true;
		
	}
	
	private static void logDebug(String message) {
		
		if (logOut) {
			if (logger == null) {
				logger = Logger.getLogger(PluSUtil.class);
			}
			logger.debug(message);
		}
		
	}
	
	/*
	 * run external command
	 */
	private static Runtime runtime = Runtime.getRuntime();

	public static LinkedList<String> runCommand(String cmdArgs[]) throws ReserveException {


		assert(cmdArgs.length > 0);
		String cmd = "";
		for (String s : cmdArgs) {
			cmd += s + " ";
		}
		cmd = cmd.trim();
		logDebug("RUN " + cmd);
		
		int ret = -1;
		LinkedList<String> stdoutLines = new LinkedList<String>();
		String stdout = "";

		try {
			Process proc = runtime.exec(cmdArgs);
			
			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(proc.getInputStream(), "US-ASCII"));
				String line;
				while ((line = reader.readLine()) != null) {
					stdoutLines.add(line);
					logDebug("STDOUT " + line);
				}
				reader.close();
			} catch (Exception e) {
				//ignore
			}

			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(proc.getErrorStream(), "US-ASCII"));
				String line;
				while ((line = reader.readLine()) != null) {
					stdout += line + "\n";
					logDebug("STDERR " + line);
				}
				reader.close();
			} catch (Exception e) {
				//ignore
			}

			/*
			 * NOTE: If stdout&stderr doesn't read before waitFor(),
			 * waitFor() will be blocked especially many lines are printed. 
			 */
			ret = proc.waitFor();
		} catch (Exception e) {
			throw new ReserveException(e.getMessage());
		}
		logDebug("exit code = " + ret);
		
		if (ret != 0) {
			stdout = stdout.trim();
			throw new ReserveException("Failed to run \"" + cmd + "\"\n" + stdout);
		}
		
		return stdoutLines;
		
	}

	
	/*
	 * handle time notaion
	 */
	private static final String ISO8601_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ssZ";
	private static SimpleDateFormat iso8601Format;
	private static String localTimeZone;
	public static final double HOUR_MSEC = 3600000.0;	// 3,600,000 [msec] = 1 hour
	
	private static String getLocalTimeZone() {
		
		if (localTimeZone != null)
			return localTimeZone;
		
		// localTimeZone will be "+0900" etc.
		localTimeZone = String.format("%tz", new Date());  
		return localTimeZone;
		
	}
	
	public static Calendar makeCalendarFromISO8601(String arg) {
		
		if ((arg == null) || (arg.length() == 0))
			return null;

		/*
		 * make Calendar object from ISO8601 format date&time string.
		 * See http://www.w3.org/TR/NOTE-datetime
		 * 
		 * This function support:
		 * 		"yyyy-MM-DDTHH:mm:ss+zz:zz" or "...-zz:zz"
		 * 		"yyyy-MM-DDTHH:mm:ss+zzzz"  or "...-zzzz"
		 * 		"yyyy-MM-DDTHH:mm:ssZ"	(interpret as UTC)
		 * 		"yyyy-MM-DDTHH:mm:ss"	(interpret as local time)
		 * 1st ant 3rd are strict ISO8601 format,
		 * others are our original notation.
		 *
		 * ex:  "1994-11-05T08:15:30-05:00"
		 * digit 0123456789012345678901234
		 * Note: Java timezone format is "{+-}zzzz", without ":".
		 */

		String date;
		int i = arg.lastIndexOf(':');
		if (i == 22) {
			// arg may be "yyyy-MM-DDTHH:mm:ss+zz:zz" [strict ISO8601]
			if (arg.length() != 25)
				return null;
			// cut ':' in timezone for Java interpretation
			date = arg.substring(0, 22) + arg.substring(23);
			// date is "yyyy-MM-ddTHH:mm:ss+zzzz"
		} else if (i == 16) {
			if (arg.charAt(arg.length()-1) == 'Z') {
				// arg may be "yyyy-MM-DDTHH:mm:ssZ" [strict ISO8601 also]
				// time is expressed in UTC
				date = arg.substring(0, arg.length()-1) + "+0000";
				// date is "yyyy-MM-DDTHH:mm:ss+0000"
			} else if (arg.length() == 19) {
				date = arg + getLocalTimeZone();
				// date is "yyyy-MM-DDTHH:mm:ss+zzzz" or "..-zzzz"
			} else {
				// arg may be "yyyy-MM-DDTHH:mm:ss+zzzz"
				date = arg;
			}
		} else {
			return null;
		}
		
		try {
			Calendar c = Calendar.getInstance();
			if (iso8601Format == null)
				iso8601Format = new SimpleDateFormat(ISO8601_FORMAT_PATTERN);
			c.setTime(iso8601Format.parse(date));
			return c;
		} catch (ParseException e) {
			return null;
		}
		
	}
	
	public static Calendar makeCalendarFromHHmm(String arg) {

		if ((arg == null) || (arg.length() == 0))
			return null;
		
		/*
		 * [1] TIME format:
		 * 	[a]	hh:mm		(hh as 24-hour format always) 
		 * 	[b]	hh:mm:ss
		 * [2] DATE format
		 * 	[a]	DD
		 * 	[b]	DD/MM
		 *	[c]	DD/MM/YY	(year as 20YY, ex: 05 means 2005)
		 *	[d]	DD/MM/YYYY
		 *
		 * arg format: TIME or TIME_DATE
		 * 	[1a]	hh:mm
		 * 	[1b]	hh:mm:ss
		 * 	[1a+2a]	hh:mm_DD
		 * 	[1a+2b]	hh:mm_DD/MM
		 * 	[1a+2c]	hh:mm_DD/MM/YY
		 * 	[1a+2d]	hh:mm_DD/MM/YYYY
		 * 	[1b+2a]	hh:mm:ss_DD
		 * 	[1b+2b]	hh:mm:ss_DD/MM
		 * 	[1b+2c]	hh:mm:ss_DD/MM/YY
		 * 	[1b+2d]	hh:mm:ss_DD/MM/YYYY
		 */
		
		// set c as now
		Calendar c = Calendar.getInstance();

		/*
		 * Split time & date
		 */
		String x[] = arg.split("_");
		if ((x.length == 0) || (x.length > 2))
			return null;
		String time, date;
		time = x[0];
		date = (x.length == 2) ? x[1] : null;
		
		try {
			/*
			 * Split time to hh:mm or hh:mm:ss
			 */
			String y[] = time.split(":");
			int sec = 0;
			switch(y.length) {
			case 3:
				sec = Integer.parseInt(y[2]);
				// fall-through
			case 2:
				c.set(Calendar.MILLISECOND, 0);
				c.set(Calendar.SECOND, sec);
				int min = Integer.parseInt(y[1]);
				if ((min < 0) || (60 <= min))
					return null;
				c.set(Calendar.MINUTE, min);
				int hour = Integer.parseInt(y[0]);
				if ((hour < 0) || (24 <= hour))
					return null;
				c.set(Calendar.HOUR_OF_DAY, hour);
				break;
			default:
				return null;
			}
			c.set(Calendar.MILLISECOND, 0);
	
			/*
			 * Split date to DD/MM/YYYY
			 */
			if (date != null) {
				String z[] = date.split("/");
				switch(z.length) {
				case 3:
					int year = Integer.parseInt(z[2]);
					if (year < 0)
						return null;
					if (year < 100)
						year += 2000;
					c.set(Calendar.YEAR, year);
					// fall-through
				case 2:
					int month = Integer.parseInt(z[1]);
					if ((month < 0) || (12 < month))
						return null;
					// MONTH value must be 0...11
					c.set(Calendar.MONTH, month -1);
					// fall-through
				case 1:
					int day = Integer.parseInt(z[0]);
					if ((day < 0) || (31 < day))
						return null;
					c.set(Calendar.DAY_OF_MONTH, day);
					break;
				default:
					return null;
				}
			}
		} catch (final NumberFormatException e) {
			// parseInt() failed
			return null;
		}
		
		return c;
	
	}
	
	public static Calendar makeCalendarFromPOSIX(String arg) {

		if ((arg == null) || (arg.length() == 0))
			return null;
		
		/*
		 * [[[[CC]YY]MM]DD]hhmm[.SS]
		 * 
		 * ex: "Thu Jun  1 16:27:50 JST 2006" is equal to
		 * 		"200606011627.50"		(length = 15)
		 * 		  "0606011627.50"		(length = 13)
		 * 		    "06011627.50"		(length = 11)
		 * 		      "011627.50"		(length = 9)
		 * 		        "1627.50"		(length = 7)
		 * 
		 * ex: "Thu Jun  1 16:27:00 JST 2006" is equal to
		 * 		"200606011627.00"  "200606011627" 
		 * 		  "0606011627.00"    "0606011627"
		 * 		    "06011627.00"      "06011627"
		 * 		      "011627.00"        "011627"
		 * 		        "1627.00"          "1627"
		 */		        

		int length = arg.length();
		if ((length < 4) || (15 < length))
			return null;
		
		if (arg.charAt(length - 3) != '.') {
			arg = arg + ".00";
			length = arg.length();
		}
		
		Calendar c = Calendar.getInstance();
		
		try {
			switch (length) {
			case 15:	// "CCYYMMDDhhmm.SS"
				c.set(Calendar.YEAR, Integer.parseInt(arg.substring(0, 4)));
				break;
			case 13:  // "YYMMDDhhmm.SS"
				c.set(Calendar.YEAR, 2000 + Integer.parseInt(arg.substring(0, 2)));
				break;
			case 11:	// "MMDDhhmm.SS"
				int now_MM = c.get(Calendar.MONTH);
				int arg_MM = Integer.parseInt(arg.substring(0, 2));
				if (arg_MM < now_MM) {
					// set 'c' as next year
					c.add(Calendar.YEAR, 1);
				}
				break;
			case 9:	// "DDhhmm.SS"
				int now_DD = c.get(Calendar.DAY_OF_MONTH);
				int arg_DD = Integer.parseInt(arg.substring(0, 2));
				if (arg_DD < now_DD) {
					// set 'c' as next month
					c.add(Calendar.MONTH, 1);
				}
				break;
			case 7:	// "hhmm.SS"
				int now_hhmm = 100 * c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE);
				int arg_hhmm = Integer.parseInt(arg.substring(0, 4));
				if (arg_hhmm < now_hhmm) {
					// set 'c' as tomorrow
					c.add(Calendar.DAY_OF_MONTH, 1);
				}
				break;
			default:
				break;
			}
			
			int index = 0;
			switch (length) {
			case 15:	// "CCYYMMDDhhmm.SS"
				index += 2;
				// fall through
			case 13:  // "YYMMDDhhmm.SS"
				index += 2;
				// fall through
			case 11:	// "MMDDhhmm.SS"
				c.set(Calendar.MONTH, Integer.parseInt(arg.substring(index, index + 2)) -1);
				index += 2;
				// fall through
			case 9:	// "DDhhmm.SS"
				c.set(Calendar.DAY_OF_MONTH, Integer.parseInt(arg.substring(index, index + 2)));
				index += 2;
				// fall through
			case 7:	// "hhmm.SS"
				c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(arg.substring(index, index + 2)));
				index += 2;
				c.set(Calendar.MINUTE, Integer.parseInt(arg.substring(index, index + 2)));
				index += 3;	// skip "mm."
				c.set(Calendar.SECOND, Integer.parseInt(arg.substring(index, index + 2)));
				c.set(Calendar.MILLISECOND, 0);
				break;
			default:
				return null;
			}
		
			return c;
		} catch (NumberFormatException e) {
			return null;
		}

	}
	
	public static void truncateDate(Calendar c) {
		
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		
	}
	
	public static Calendar makeCalendarFromDate(String arg) {

		if ((arg == null) || (arg.length() == 0))
			return null;
		
		/*
		 * arg must be "[yyyy-]MM-DD"
		 */
		Calendar c = Calendar.getInstance();
		String params[] = arg.split("-");
		int index = 0;
		try {
			switch (params.length) {
			case 3:
				// check year
				if (params[index].length() != 4) {
					return null;
				}
				int year = Integer.parseInt(params[index]);
				c.set(Calendar.YEAR, year);
				index++;
				// fall-through
			case 2:
				// check month
				if (params[index].length() != 2) {
					return null;
				}
				int month = Integer.parseInt(params[index]);
				// MONTH value must be 0...11
				c.set(Calendar.MONTH, month -1);
				index++;
				// check day
				if (params[index].length() != 2) {
					return null;
				}
				int day = Integer.parseInt(params[index]);
				c.set(Calendar.DAY_OF_MONTH, day);
				break;
			default:
				return null;
			}
		} catch (NumberFormatException e) {
			return null;
		}
		
		truncateDate(c);
		
		return c;
	}
	
	public static Calendar makeCalendar(String arg) {
		
		Calendar c;
		/*
		c = makeCalendarFromHHmm(arg);
		if (c != null)
			return c;
		*/

		c = makeCalendarFromISO8601(arg);
		if (c != null)
			return c;
		
		c = makeCalendarFromPOSIX(arg);
		if (c != null)
			return c;
		
		return null;
		
	}
	
	public static int hhmmssToSec(String time) throws SchedulerException {
		
		/*
		 * Support "hh:mm:ss" or "mm:ss" or "ss"
		 */
		String s[] = time.split(":");
		try {
			int sec, min = 0, hour = 0, index = 0; 
			switch (s.length) {
			case 3:
				hour = Integer.parseInt(s[index]);
				if (hour < 0) {
					throw new SchedulerException("hour must be positive");
				}
				index++;
				// fall-through
			case 2:
				min = Integer.parseInt(s[index]);
				if (min < 0) {
					throw new SchedulerException("minute must be positive");
				}
				if ((s.length > 2) && (min >= 60)) {
					throw new SchedulerException("minute must be 00..59");
				}
				index++;
				// fall-through
			case 1:
				sec = Integer.parseInt(s[index]);
				if (sec < 0) {
					throw new SchedulerException("second must be positive");
				}
				if ((s.length > 1) && (sec >= 60)) {
					throw new SchedulerException("second must be 00..59");
				}
				break;
			default:
				throw new SchedulerException("invalid description: " + time);
			}
			return 3600 * hour + 60 * min + sec;
		} catch (NumberFormatException e) {
			throw new SchedulerException("invalid description: " + time);
		}
		
	}
	
	public static final double calcSize(String value) throws SchedulerException {

		/*
		 * value must be xxx[kKmMgGtT] such as "100M"
		 */
		String v = value.substring(0, value.length() - 1);
		char postfix = value.charAt(value.length() -1);
		double val;
		try {
			val = Double.parseDouble(v);
		} catch (NumberFormatException e) {
			throw new SchedulerException("invalid number format: " + v);
		}
		
		final double K10 = 1000.0;
		final double K2 = 1024.0;
		switch (postfix) {
		case 'k':
			return K10 * val;
		case 'K':
			return K2 * val;
		case 'm':
			return K10 * K10 * val;
		case 'M':
			return K2 * K2 * val;
		case 'g':
			return K10 * K10 * K10 * val;
		case 'G':
			return K2 * K2 * K2 * val;
		case 't':
			return K10 * K10 * K10 * K10 * val;
		case 'T':
			return K2 * K2 * K2 * K2 * val;
		default:
			try {
				return Double.parseDouble(value);
			} catch (NumberFormatException e2) {
				throw new SchedulerException("invalid number format: " + value);
			}
		}
		
	}
	
}
