/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Date;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;

import org.apache.log4j.Logger;

import condor.classad.*;

public class ClassAdEvaluator {

	private final String adFilePath;
	private final RecordExpr rec;
	private static final Logger logger = Logger.getLogger(ClassAdEvaluator.class);
	private static boolean initialized = false;

	private static synchronized void initClassAd(String filepath) {
		
		if (initialized) {
			return;
		}
		
		/*
		 * Load methods in ClassAdFuncsForPluS
		 */
		final String CLASSAD_FUNCS_CLASS
			= ClassAdFuncsForPluS.class.getCanonicalName();
	    if (ClassAd.loadJavaLibrary(CLASSAD_FUNCS_CLASS) == false) {
	    	logger.warn("Cannot load " + CLASSAD_FUNCS_CLASS + ", ignored");
	    }
	    
		/*
		 * Must call setLoggerPath() before using plus_rsvutil() from ClassAd
		 */
	    int index = filepath.lastIndexOf('/');
	    if (index != -1) {
	    	filepath = filepath.substring(0, index);
	    }
		ClassAdFuncsForPluS.setLoggerPath(filepath);
		
		initialized = true;
	    
	}
	
	public ClassAdEvaluator(String adFilePath, NodeAllocateRequest allocReq) throws ReserveException {
		
		this.adFilePath = adFilePath;
		this.rec = makeRecord(adFilePath);
		
		// add default reserve attributes
		String owner = allocReq.getRequester();
		Date start = allocReq.getStartTime().getTime();
		Date end = allocReq.getEndTime().getTime();
		rec.insertAttribute("PLUS_RSV_OWNER", Constant.getInstance(owner));
		rec.insertAttribute("PLUS_RSV_START", Constant.getInstance(start));
		rec.insertAttribute("PLUS_RSV_END", Constant.getInstance(end));

	}
	
	private RecordExpr makeRecord(String adFilePath) throws ReserveException {
		
		initClassAd(adFilePath);
		
		InputStream in;
		try {
			in = new FileInputStream(new File(adFilePath));
		} catch (FileNotFoundException e) {
			throw new ReserveException("cannot open " + adFilePath);
		}
		
		ClassAdParser parser = new ClassAdParser(in);
		Expr expr = parser.parse();
		if ((expr == null) || !(expr instanceof RecordExpr)) {
			throw new ReserveException("Syntax error in " + adFilePath);
		} else {
			return (RecordExpr)expr;
		}
		
	}
	
	public void insertAttribute(String name, Expr expr) {

		// NOTE: replace expr if name is already set
		rec.insertAttribute(name, expr);
		
	}
	
	public Expr eval(String exp) {
	
		assert(rec != null);
		
		Expr value = rec.lookup(exp);
		if (value != null) {
			Env env = new Env();
			env.push(rec);
			/*
			 * NOTE: return Constant.Undef if syntax error occured.
			 */
			Expr result = value.eval(env);
			if (result == Constant.Undef) {
				logger.warn("Syntax error in " + adFilePath);
			}
			return result;
		} else {
			logger.warn("no definition of " + exp + " in " + adFilePath);
			return Constant.Undef;
		}
		
	}
	
}
