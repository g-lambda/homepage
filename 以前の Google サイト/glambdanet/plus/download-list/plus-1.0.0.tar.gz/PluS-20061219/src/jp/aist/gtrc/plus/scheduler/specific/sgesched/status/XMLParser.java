/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Collection;
import java.util.LinkedHashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import jp.aist.gtrc.plus.scheduler.status.Status;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;


public abstract class XMLParser<V extends Status> {

	private static DocumentBuilderFactory factory = null;
	private static DocumentBuilder builder = null;
	private LinkedHashMap<String, V> map;

	protected static Logger logger = Logger.getLogger(XMLParser.class);

	protected XMLParser() throws SchedulerException {
		
		if (factory == null) {
			try {
				factory = DocumentBuilderFactory.newInstance();
				factory.setValidating(true);
				factory.setAttribute(		
					"http://java.sun.com/xml/jaxp/properties/schemaLanguage",		
					"http://www.w3.org/2001/XMLSchema");
	
				builder = factory.newDocumentBuilder(); 			 		 
				builder.setErrorHandler(new DefaultHandler());
			} catch (Exception e) {
				throw new SchedulerException(e.getMessage());
			}
		}

		map = new LinkedHashMap<String, V>();
		
	}

	private boolean checkElement(Node n, String name) {
		
		return (n.getNodeType() == Node.ELEMENT_NODE) && 
			n.getNodeName().equals(name);
			
	}
	
	protected void parse(InputStream stream, String objName) throws SchedulerException {
		
		Document document;

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(stream));
			String line;
			String last = "</" + objName + ">";
			StringBuffer bf = new StringBuffer();
			while ((line = in.readLine()) != null) {
				bf.append(line);
				// logger.debug(line);
				if (line.startsWith(last))
					break;
			}
			
			InputSource is = new InputSource(new StringReader(bf.toString())); 
			document = builder.parse(is);
		} catch (Exception e) {
			logger.debug(e, e);
			throw new SchedulerException(e.getMessage());
		}
		
		map.clear();

		NodeList roots = document.getChildNodes();
		if (roots.getLength() != 1)
			return;
		
		Node objsNode = roots.item(0);
		if (!checkElement(objsNode, objName))
			return;
		
		NodeList nodes = objsNode.getChildNodes(); 
		for (int i = 0; i < nodes.getLength(); i++) {
			Node node = nodes.item(i);
			if (!checkElement(node, "element"))
				continue;
			
			V status = newStatus(node);
			map.put(status.getName(), status);
			logger.debug(status.toString());
		}
		
	}
	
	public Collection<V> getAllStatus() {
		
		return map.values();
		
	}
	
	public LinkedHashMap<String, V> getAllStatusMap() {
		
		return map;
		
	}
	
	public V getStatus(String name) {
		
		return map.get(name);
		
	}
	
	protected V deleteStatus(String name) {
		
		return map.remove(name);
		
	}

	public abstract void parse(InputStream stream) throws SchedulerException;
	protected abstract V newStatus(Node n) throws SchedulerException;
	
}
