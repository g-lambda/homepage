/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;


import java.util.Map;

import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.specific.sge.common.SGENodeResource;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;
import jp.aist.gtrc.plus.scheduler.util.PluSUtil;

import org.w3c.dom.Node;

public class SGEQInstance extends XMLStatus implements NodeStatus {

	private Integer totalSlot;
	private int usedNumBias;
	private String fullname;
	private SGENodeStatus node = null;
	
	private final static int QI_DEFAULT		= 0x00000000;
	private final static int QI_SUSPENDED		= 0x00000100;
	/*
	private final static int QI_ALARM			= 0x00000001;
	private final static int QI_SUSPEND_ALARM	= 0x00000002;
	private final static int QI_DISABLED		= 0x00000004;
	private final static int QI_UNKNOWN		= 0x00000400;
	private final static int QI_ERROR			= 0x00004000;
	private final static int QI_SUSPENDED_ON_SUBORDINATE = 0x00008000;
	private final static int QI_CAL_DISABLED	= 0x00020000;
	private final static int QI_CAL_SUSPENDED	= 0x00040000;
	private final static int QI_AMBIGUOUS		= 0x00080000;
	private final static int QI_ORPHANED		= 0x00100000;
	private final static int QI_FULL			= 0x00200000;
	*/
	
	SGEQInstance(Node node) throws Exception {
		
		super(node, "QU_");
		usedNumBias = 0;
		

	}

	public String getName() {
		
		/*
		 *	<QU_qhostname>uml2.suri.co.jp</QU_qhostname>
        *	<QU_qname>all.q</QU_qname>
        *	<QU_full_name>all.q@uml2.suri.co.jp</QU_full_name>
		 */
		return getFullName();
		
	}
	
	public String getQName() {
		return getString("qname");
	}
	
	public String getQHostName() {
		return PluSUtil.makeFQDN(getString("qhostname"));
	}
	
	public String getFullName() {
		
		/*
		 * NOTE: getStatus("full_name") may be "all.q@host" or "all.q@host.example.com".
		 * make FQDN always
		 */
		if (fullname == null)
			fullname = getQName() + "@" + getQHostName();
		return fullname;
		
	}
	
	public int getTotalSlotNum() {
		
		if (totalSlot == null)
			totalSlot = getInt("job_slots");
		return totalSlot;
		
	}
	
	public int getState() {
		
		return getInt("state");
		
	}
	
	public boolean isReadyToUse() {
		
		return (getState() == QI_DEFAULT);
		
	}
	
	public boolean isSuspended() {
		
		return (getState() == QI_SUSPENDED);
		
	}

	public int getUsedSlotNum() {
		
		String s[] = getStringParams("resource_utilization");
		for (int i = 0; i <= s.length - 2; i++) {
			if (s[i].equals("slots")) {
				try {
					return (int)Double.parseDouble(s[i+1]) + usedNumBias;
				} catch (NumberFormatException e) {
					break;
				}
			}
		}
		
		return 0;
		
	}
	
	public void incrementUsedSlotNum(int nSlot) {
		
		usedNumBias += nSlot;
		
	}
	
	public int getVersion() {
		
		return getInt("version");
		
	}
	
	public int getJobSlotNum() {
		
		return getInt("job_slots");
		
	}
	
	void setNodeStatus(SGENodeStatus node) {
		
		this.node = node;
		
	}
	
	public NodeStatus getNode() {

		assert(node != null);
		return node;
		
	}

	public boolean isAlive() {

		return getNode().isAlive();
		
	}
	
	public boolean isIdle() {

		return (getUsedSlotNum() < getTotalSlotNum());
		
	}

	public OSType getOSType() {

		return getNode().getOSType();
		
	}

	public ArchType getArchType() {

		return getNode().getArchType();
		
	}

	public int getCPUNum() {

		//return getNode().getCPUNum();
		return getTotalSlotNum();
		
	}

	public double getLoadAverage() {

		return getNode().getLoadAverage();
		
	}

	public long getPhysicalMemory() {

		return getNode().getPhysicalMemory();
		
	}

	public int getIdleTime() {

		return getNode().getIdleTime();
		
	}

	public int getRunningJobNum() {

		return getUsedSlotNum();
		
	}

	public NodeResource getResource() {
		
		return SGENodeResource.getInstance(node);
		
	}

	public String getAttribute(String attr) {

		return node.getAttribute(attr);
		
	}

	public Map<String, String> getAttributeMap() {

		return node.getAttributeMap();
		
	}

}
