/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEOperatord;
import jp.aist.gtrc.plus.scheduler.status.JobID;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.ServerStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.sys.SignalType;

public class SGEMainServer implements MainServer {

	private Socket socket;
	
	private static ServerXMLParser serverParser;
	private static QueueXMLParser queueParser;
	private static NodeXMLParser nodeParser;
	private static JobXMLParser jobParser;
	private static HostGroupXMLParser hgroupParser;
	private static UsersetXMLParser usersetParser;
	private static ProjectXMLParser projectParser;
	private static ParallelEnvXMLParser peParser;
	private SGEOperatord operatord;

	protected static Logger logger = Logger.getLogger(SGEMainServer.class);
	
	public SGEMainServer() throws SchedulerException {

		if (serverParser == null) {
			serverParser = new ServerXMLParser();
			queueParser = new QueueXMLParser();
			nodeParser = new NodeXMLParser();
			jobParser = new JobXMLParser();
			hgroupParser = new HostGroupXMLParser();
			usersetParser = new UsersetXMLParser();
			projectParser = new ProjectXMLParser();
			peParser = new ParallelEnvXMLParser();
		}
		
		operatord = new SGEOperatord();
		connect();
		
	}
	
	private void connect() throws SchedulerException {
		
		socket = operatord.connect();
		
	}

	public boolean isConnected() {
		
		return operatord.isConnected();
		
	}

	public void disconnect() {
		
		operatord.disconnect();
		
	}
	
	public void shutdown() {
		
		operatord.shutdown();			
	}

	private void getStatus(String type, XMLParser parser) throws SchedulerException {
		
		operatord.sendRequest("GetStatus " + type);
		
		InputStream stream;
		try {
			stream = socket.getInputStream();
		} catch (IOException e) {
			throw new SchedulerException(e.getMessage());
		}
		
		parser.parse(stream);
		
	}
	
	public ServerStatus getServerStatus() throws SchedulerException {

		getStatus("server", serverParser);

		for (ServerStatus status : serverParser.getAllStatus()) {
			return status;
		}
		
		return null;
		
	}

	public Collection<NodeStatus> getNodeStatus() throws SchedulerException {
		
		getStatus("node", nodeParser);
		return nodeParser.getAllStatus();

	}

	public Collection<QueueStatus> getQueueStatus() throws SchedulerException {

		getStatus("queue", queueParser);
		return queueParser.getAllStatus();
		
	}

	public Collection<JobStatus> getJobStatus(QueueStatus queue)
			throws SchedulerException {
		
		/*
		 * WE IGNORE 'queue'.
		 * Return all *tasks* of all jobs in all queue always.
		 */
		getStatus("job", jobParser);
		return jobParser.getAllTasks();
		
	}
	
	public LinkedHashMap<String, SGEHostGroup> getHostGroups() throws SchedulerException {
		
		getStatus("hgroup", hgroupParser);
		LinkedHashMap<String, SGEHostGroup> map = hgroupParser.getAllStatusMap();
		return map;

	}

	public LinkedHashMap<String, SGEUserset> getUsersets() throws SchedulerException {
		
		getStatus("userset", usersetParser);
		LinkedHashMap<String, SGEUserset> map = usersetParser.getAllStatusMap();
		return map;

		
	}

	public LinkedHashMap<String, SGEProject> getProjects() throws SchedulerException {
		
		getStatus("project", projectParser);
		LinkedHashMap<String, SGEProject> map = projectParser.getAllStatusMap();
		return map;

	}

	public LinkedHashMap<String, SGEParallelEnv> getParallelEnvs() throws SchedulerException {
		
		getStatus("pe", peParser);
		LinkedHashMap<String, SGEParallelEnv> map = peParser.getAllStatusMap();
		return map;

	}

	private String checkReply() throws SchedulerException {
		
		String reply = operatord.receiveReply();
		reply.trim();
		if (reply.startsWith("OK") == false)
			throw new SchedulerException(reply);
		
		if (reply.length() > 3) {
			return reply.substring(3);
		} else {
			return null;
		}
		
	}

	private String sendOrder(String order) throws SchedulerException {
		
		operatord.sendRequest(order);
		return checkReply();
		
	}
	
	private void runJob(String jobId, String nodeNames) throws SchedulerException {
		
		sendOrder(String.format(Locale.US, "RunJob %s %s", jobId, nodeNames));
		
	}
	
	public void runJob(JobID jobID, NodeStatus node) throws SchedulerException {

		// 'nodeName' will be "all.q@host00.example.com 10 1"
		// 10 is current version of all.q@host00.example.com Qinstance,
		// 1 is slot to be used on it.
		String nodeName = node.getName();
		SGEQInstance ins = (SGEQInstance)node;
		nodeName += ins.getVersion() + " 1";
		runJob(jobID.toString(), nodeName);
		
	}

	public void runJob(JobStatus job, Collection<NodeInfo> nodes)
			throws SchedulerException {

		SGETaskStatus task = (SGETaskStatus)job;
		String names = "";
		for (NodeInfo node : nodes) {
			names += node.getStatus().getName() + " ";
			SGEQInstance ins = (SGEQInstance)node.getStatus();
			names += ins.getVersion();
			names += " " + node.getLaunchProcessNum() + " ";
		}
		
		String peName = task.getTargetParallelEnvName();
		if (peName.length() > 0) {
			names += peName;
		}
		
		runJob(task.getJobID().toString(), names);

		for (NodeInfo node : nodes) {
			SGEQInstance ins = (SGEQInstance)node.getStatus();
			ins.incrementUsedSlotNum(node.getLaunchProcessNum());
		}
	}

	private String operateJob(String order, JobID jobID) throws SchedulerException {

		return sendOrder(String.format(Locale.US, "%s %s",
				order, jobID.toString()));

	}

	public void deleteJob(JobID jobID) throws SchedulerException {

		// delete unfinished (waiting or running) job (shown by qstat)
		operateJob("DeleteJob", jobID);
		
	}

	public void expireJob(JobID jobID) throws SchedulerException {

		// delete finished job (cannot be seen by qstat)
		operateJob("ExpireJob", jobID);
		
	}

	public void suspendJob(JobID jobID) throws SchedulerException {

		operateJob("SuspendJob", jobID);
		
	}

	public void resumeJob(JobID jobID) throws SchedulerException {

		operateJob("ResumeJob", jobID);

	}

	public void holdJob(JobID jobID) throws SchedulerException {

		operateJob("HoldJob", jobID);

	}

	public void releaseJob(JobID jobID) throws SchedulerException {

		operateJob("ReleaseJob", jobID);

	}

	public void rerunJob(JobStatus job) throws SchedulerException {

		SGETaskStatus task = (SGETaskStatus)job;
		JobID jobID = task.getJobID();
		SGEJobID sgeID = (SGEJobID)jobID;
		String oldid = Integer.toString(sgeID.jobID());
		String newid = null;
		
		/*
		 * To Rerun job of 123.1, we must send
		 * 		"ResubmitJob 123 owner uid group gid"
		 * 		"DeleteJob 123"
		 * NOTE: SGE only allows resubmission by unit of a job, not a task.
		 * 'newid' doesn't contain task id. It maybe "124" etc. 
		 */
		String owner = task.getOwner();
		String uid = task.getUid();
		String group = task.getOwnersGroup();
		String gid = task.getGid();
		newid = sendOrder("ResubmitJob " + oldid + " "
				+ owner + " " + uid + " " + group + " " + gid);
		
		try {
			sendOrder("DeleteJob " + oldid);
		} catch (SchedulerException e1) {
			try {
				sendOrder("DeleteJob " + newid);
			} catch (SchedulerException e2) {
				// recover failed, we cannot do anymore.
				// oldid & newid jobs remain
				throw new SchedulerException("failed to delete old job at RerunJob");
			}
		}
		
	}

	public void signalJob(JobID jobID, SignalType signal)
			throws SchedulerException {
		
		throw new SchedulerException("signalJob() for SGE is not supported!");

	}

}
