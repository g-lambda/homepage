/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.specific.sge.common.SGENodeResource;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.util.SGEArch;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.util.PluSUtil;

public class SGESimpleNodeStatus implements NodeStatus {

	private static String[] invalidHeads = { "HOSTNAME", "-", "global" };
	
	private String hostname;
	private OSType os;
	private ArchType arch;
	private int ncpu;
	private double loadavg;
	private long memtotal;
	private boolean isAlive;
	private HashMap<String, String> attrMap;
	private HashMap<String, SGESimpleQInstance> qMap;
	
	/*
	 * NOTE:
	 * 'qhost' shows hostname only (not FQDN) always.
	 * 'qconf -sel' and 'qstat -f' show in FQDN or not-FQDN.
	 * We want to use FQDN if it's available for Map key.
	 * We cannot get domain name in some environment.
	 * 
	$ qhost
	HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
	-------------------------------------------------------------------------------
	global                  -               -     -       -       -       -       -
	ume00                   lx24-x86        2  0.00 1006.3M  136.2M    2.0G     0.0
	ume01                   lx24-x86        2  0.00 1006.3M  112.6M    2.0G     0.0
	ume02                   lx24-x86        2  0.01 1006.3M  112.4M    2.0G     0.0
	ume03                   lx24-x86        2  0.00 1006.3M  116.1M    2.0G     0.0
	ume04                   lx24-x86        2  0.00 1006.3M  118.5M    2.0G     0.0
	ume05                   lx24-x86        2  0.00 1006.3M  119.8M    2.0G     0.0
	ume06                   lx24-x86        2     - 1006.3M       -    2.0G       -
	ume07                   lx24-x86        2     - 1006.3M       -    2.0G       -
	
	host                    -               -     - -             -    -          -
	
	$ qconf -sel
	ume00.hpcc.jp
	ume01.hpcc.jp
	...
	 */
	
	private SGESimpleNodeStatus(String hostname, OSType os, ArchType arch,
			int ncpu, double loadavg, long memtotal, boolean isAlive) {
		
		this.hostname = hostname;
		this.os = os;
		this.arch = arch;
		this.ncpu = ncpu;
		this.loadavg = loadavg;
		this.memtotal = memtotal;
		this.isAlive = isAlive;
		this.attrMap = new HashMap<String, String>();
		this.qMap = new HashMap<String, SGESimpleQInstance>();
		
	}

	private SGESimpleNodeStatus(String hostname) {
	
		this(hostname, OSType.Unknown, ArchType.unknown, 1, 0.0, 0, false);
		
	}
	
	private static SGESimpleNodeStatus getInstance(String info, String hostname) throws SchedulerException {
		
		if (checkValidInfo(info) == false)
			return null;

		String params[] = info.split("\\s+");
		if (params.length != 8) {
			throw new SchedulerException("program error: cannot handle qhost output. not supported");
		}

		String fqdn = SGESimpleMainServer.makeFQDN(hostname);
		String fqdn2 = SGESimpleMainServer.makeFQDN(params[0]);
		if (fqdn.equals(fqdn2) == false) {
			throw new SchedulerException("program error: different host order of qhost and qconf -sel or invalid domainname. not supported");
		}
		
		if (params[3].equals("-") == false) {
			OSType os = SGEArch.getOSType(params[1]);
			ArchType arch = SGEArch.getArchType(params[1]);
			try {
				int ncpu = Integer.parseInt(params[2]);
				double loadavg = Double.parseDouble(params[3]);	// loadavg of 15min
				long memtotal = (long)PluSUtil.calcSize(params[4]);
				return new SGESimpleNodeStatus(fqdn, os, arch, ncpu, loadavg, memtotal, true);
			} catch (NumberFormatException e ) {
				// ignore, handle as down host
			}
		}
		return new SGESimpleNodeStatus(fqdn);
		
	}
	
	static SGESimpleNodeStatus getInstance(LinkedList<String> infos, String hostname) throws SchedulerException {
		
		if (infos.size() < 1) {
			return null;
		}
		
		String header = infos.removeFirst();
		SGESimpleNodeStatus status = getInstance(header, hostname);
		if (status != null) {
			for (String line : infos) {
				// line may be "   hl:arch=lx26-x86" etc.
				String s[] = line.split(":");
				if (s.length != 2) {
					continue;
				}
				String t[] = s[1].split("=");
				if (t.length == 2) {
					status.setAttribute(t[0], t[1]);
				}
			}
		}
		return status;
		
	}
	
	private static boolean checkValidInfo(String info) {
		
		for (String s : invalidHeads) {
			if (info.startsWith(s)) {
				return false;
			}
		}
		return true;
		
	}
	
	public boolean isAlive() {

		return isAlive;
		
	}

	public boolean isIdle() {

		return true;
		
	}

	public OSType getOSType() {
		
		return os;
		
	}

	public ArchType getArchType() {

		return arch;
		
	}

	public int getCPUNum() {

		return ncpu;
		
	}

	public double getLoadAverage() {

		return loadavg;
	}

	public long getPhysicalMemory() {

		return memtotal;
		
	}

	public int getIdleTime() {

		return 15*60 - (int)(15*60*loadavg);
		
	}

	public String getName() {

		return hostname;
		
	}
	
	private void setAttribute(String attr, String value) {
		
		attrMap.put(attr, value);
		
	}
	
	public NodeResource getResource() {

		return SGENodeResource.getInstance(this);
		
	}

	public String getAttribute(String attr) {
		
		return attrMap.get(attr);
		
	}

	public Map<String, String> getAttributeMap() {
		
		return attrMap;
		
	}
	
	void addQInstance(SGESimpleQInstance ins) {
		
		// overwrite 'ins' if already exists
		qMap.put(ins.getQHostName(), ins);
		
	}
	
	public Collection<SGESimpleQInstance> getAllQInstances() {
		
		return qMap.values();
		
	}

	public int getRunningJobNum() {

		int n = 0;
		for (SGESimpleQInstance qins: getAllQInstances()) {
			n += qins.getUsedSlotNum();
		}
		return n;
		
	}

}
