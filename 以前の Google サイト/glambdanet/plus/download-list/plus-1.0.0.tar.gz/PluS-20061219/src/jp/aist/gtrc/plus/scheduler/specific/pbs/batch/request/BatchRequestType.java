/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request;

import java.util.HashMap;
import java.util.Map;

public enum BatchRequestType{

	Connect(0),
	QueueJob(1),
	JobCred(2),
	jobscript(3),
	RdytoCommit(4),
	Commit(5),
	DeleteJob(6),
	HoldJob(7),
	LocateJob(8),
	Manager(9),
	MessJob(10),
	ModifyJob(11),
	MoveJob(12),
	ReleaseJob(13),
	Rerun(14),
	RunJob(15),
	SelectJobs(16),
	Shutdown(17),
	SignalJob(18),
	StatusJob(19),
	StatusQueue(20),
	StatusServer(21),
	TrackJob(22),
	AsyrunJob(23),
	ResourceQuery(24),
	ReserveResc(25),
	ReleaseResc(26),
	StageIn(48),
	AuthenUser(49),
	OrderJob(50),
	SelectStatus(51),
	RegistDep(52),
	CopyFiles(54),
	DelFiles(55),
	JobObit(56),
	MvJobFile(57),
	StatusNode(58),
	Disconnect(59);
	
	private static Map<Integer, BatchRequestType> map
		= new HashMap<Integer, BatchRequestType>();
	static {
		for (BatchRequestType t : BatchRequestType.values()) {
			map.put(t.value, t);
		}
	}
	public static BatchRequestType getRequestType(int value){
		return map.get(value);
	}
	
	private final int value;

	BatchRequestType(int value){
		this.value = value; 
	}

	int value(){
		return value;
	}

	public String toString(){
		return this.name() + "(" + value + ")";
	}
}