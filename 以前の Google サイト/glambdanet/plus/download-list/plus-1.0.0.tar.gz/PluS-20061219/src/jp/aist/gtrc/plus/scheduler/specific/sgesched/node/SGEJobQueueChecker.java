/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.node;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGENodeStatus;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEQInstance;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEQueueStatus;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGEStatusManager;
import jp.aist.gtrc.plus.scheduler.specific.sgesched.status.SGETaskStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.util.Checker;

public class SGEJobQueueChecker extends Checker<NodeInfo> {

	private SGETaskStatus task;
	private HashMap<String, QueueStatus> allQueues;
	private Collection<QueueStatus> targetQs; 
	private SGEQueueChecker qChecker;


	SGEJobQueueChecker(SGETaskStatus task) {
		
		this.task = task;
		this.allQueues = SGEStatusManager.getInstance().getQueueMap();
		
		/*
		 * NOTE: isOK() is called many times (max: number of nodes),
		 * so make targetQs&qChecker here for better performance.
		 */
		makeTargetQueues();
		qChecker = new SGEQueueChecker(task);
		
	}
	
	SGEJobQueueChecker(String owner) {
		
		this.task = null;
		this.allQueues = SGEStatusManager.getInstance().getQueueMap();

		makeTargetQueues();
		qChecker = new SGEQueueChecker(owner);
		
	}
	
	private void makeTargetQueues() {
		
		String qNames[] = (task != null) ? task.getTargetQueueNames() : null;
		
		if ((qNames == null) || (qNames.length == 0)) {
			// target queue is not specified, check all queues.
			targetQs = allQueues.values();
		} else {
			targetQs = new LinkedList<QueueStatus>();
			for (String qName : qNames) {
				SGEQueueStatus queue = getQueueStatus(qName);
				targetQs.add(queue);
			}
		}

	}
	
	private SGEQueueStatus getQueueStatus(String qName) {
		
		assert(qName != null);
		// TODO: we currently support qName as "all.q" etc, 
		// not support "all.q@*", "all.q@hostA" etc.
		String s[] = qName.split("@");
		if (s.length > 1) {
			qName = s[0];
		}

		QueueStatus q = allQueues.get(qName);
		assert(q != null);
		return  (SGEQueueStatus)q;
		
	}
	
	public boolean isOK(NodeInfo node) {
		
		NodeStatus status = node.getStatus();
		SGEQInstance qinstance = (status instanceof SGEQInstance)
			? (SGEQInstance)status : null;
		SGENodeStatus nodeStatus = SGENodeStatus.getSGENodeStatus(node);

		/*
		 * Check queue instance and its acl 
		 */
		for (QueueStatus q : targetQs) {
			SGEQueueStatus queue = (SGEQueueStatus)q;
			if (qinstance != null) {
				if (qinstance.getQName().equals(queue.getName()) == false) {
					continue;
				}
				if (qinstance.isReadyToUse() == false) {
					continue;
				}
			}
			if (queue.hasInstanceOnNode(nodeStatus) == false) {
				continue;
			}
			if (qChecker.isOK(queue) == true) {
				return true;
			}
		}

		// we cannot find available queue, so cannot run 'task' on 'node'
		return false;
	
	}

}
