/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.io.Serializable;


public class ReserveId implements Serializable, Comparable {

	private static final long serialVersionUID = -1767012868415607033L;
	private static final int MIN_ID = 1;
	protected static final int MINGUARD_ID = MIN_ID -1;
	static final int MAX_ID = 99999999;
	public static final String RSVID_PREFIX = "R";
	
	private static int lastId = MIN_ID;
	private static ReserveId firstId = ReserveId.getInstance(RSVID_PREFIX + MIN_ID);
	
	private int id;
	private String idstr;

	private final void setId(int id) {
		
		this.id = id;
		this.idstr = RSVID_PREFIX + Integer.toString(id);
		
	}
	
	protected final void setId(ReserveId rsvId) {
		
		setId(rsvId.id);
		
	}
	
	protected ReserveId(int id, boolean countUp) {

		assert(MINGUARD_ID <= id);
		assert(id <= MAX_ID);
		
		setId(id);
		
		if (countUp) {
			if (id < MAX_ID)
				lastId++;
			else
				lastId = MIN_ID;
		}
		
	}
	
	public ReserveId(){

		this(lastId, true);

	}
	
	void abortId() {
		
		if (lastId == (id + 1)) {
			lastId--;
		} else {
			assert(false);
		}
		
	}

	public static ReserveId getInstance(String id) {
		
		if ((id == null) || (id.length() == 0))
			return null;
		if (id.startsWith(RSVID_PREFIX) == false)
			return null;
		
		int n;
		try {
			id = id.substring(RSVID_PREFIX.length());
			n = Integer.parseInt(id);
			if ((n < MIN_ID) || (MAX_ID < n))
				return null;
		} catch (NumberFormatException e) {
			return null;
		}
		
		return new ReserveId(n, false);

	}
	
	public static ReserveId getFirstInstance() {
		
		return firstId;
		
	}
	
	static void setLastId(ReserveId last) {
		
		assert(last.id >= lastId);
		lastId = last.id + 1;
		
	}
	
	public String toString() {
		
		return idstr;
		
	}

	public boolean equals(Object obj) {

		if (obj instanceof ReserveId) {
			/*
			 * ReserveId objects with same id are treated as same, 
			 * even if they are different objects (this != id).
			 */
			return (this.id == ((ReserveId)obj).id);
		} else {
			return false;
		}
		
	}
	
	public final int hashCode() {
		
		return id;
		
	}

	public int compareTo(Object o) {

		if (o instanceof ReserveId) {
			return this.id - ((ReserveId)o).id;
		} else {
			assert(false);
			return -1;
		}
		
	}
	
	public Object clone() {
		
		return new ReserveId(this.id, false);
		
	}

}