/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command;

import jp.aist.gtrc.plus.command.util.PlusReserveCancelOptions;
import jp.aist.gtrc.plus.command.util.PlusReserveCommand;
import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveServer;
import jp.aist.gtrc.plus.reserve.ReserveStatus;


public class PlusReserveCancel extends PlusReserveCommand {

	/*
	 * To Cancel:
	 * 	java PlusReserveCancel {-r rsvId} {-o owner}
	 * 
	 * To Show command help:
	 * 	java PlusReserve -h
	 */
	public static void main(String[] args){

		ReserveServer server = null;
		PlusReserveCancelOptions options = new PlusReserveCancelOptions("plus_cancel");
		ReserveId rsvId = null;
		String owner = null;
		
		try {
			options.parse(args);
			
			rsvId = options.getReserveId();
			owner = options.getOwner();
		} catch (Exception e) {
			showCommandHelp(options, e);
			System.exit(1);
		}
		
		try {
			server = getReserveServer(options.getReserveServerHost());
			if (rsvId != null) {
				ReserveStatus status = server.getStatus(rsvId);
				if (getMyname().equals(status.getOwner()) == false)
					throw new ReserveException("You are not owner of this reserve");
				server.cancel(rsvId);
				if (options.isTransaction() == false) {
					server.commit(rsvId);
				}
				System.out.println("Reserve id = " + rsvId + " canceled");
				if (options.isTransaction()) {
					System.out.println("You need plus_commit/plus_abort");
				}
			} else if (owner != null) {
				if (getMyname().equals(owner) == false) 
					throw new ReserveException("You cannot cancel other's reserves");
				server.cancelOfOwner(owner);
				// committed automatically  by server 
				System.out.println("All reserves owned by " + owner + " canceled");
			}
		} catch (Exception e) {
			showException(e);
			System.exit(1);
		}
		
	}

}