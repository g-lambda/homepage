/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

public class Option {

	private String optPrefix;
	private String optParam;
	private String defaultValue;
	private String value;
	private String description;
	private boolean required;
	private boolean isSet;
	private static final String WITHOUT_VALUE = "###";
	private static final String OPTIONAL_VALUE = "@@@";
	private static final String DUMMY_VALUE = "$$$";

	public Option(String optPrefix, String optParam, String description, String defaultValue, boolean required){
		this.optPrefix = optPrefix;
		this.optParam = optParam;
		this.defaultValue = defaultValue;
		this.value = defaultValue;
		this.description = description;
		this.required = required;
		this.isSet = false;
	}
	
	public Option(String optPrefix, String optParam, String description, String defaultValue){
		this(optPrefix, optParam, description, defaultValue, false);
	}
	
	public Option(String optPrefix, String description, boolean required){
		this(optPrefix, null, description, WITHOUT_VALUE);
	}

	public Option(String optPrefix, String optParam, String description){
		this(optPrefix, optParam, description, OPTIONAL_VALUE);
	}
	
	public Option(String optPrefix, String description){
		this(optPrefix, description, false);
	}
	
	String getPrefix() {
		return optPrefix;
	}
	
	String getParam() {
		return optParam;
	}
	
	String getValue(){
		return ((value != WITHOUT_VALUE) && (value != OPTIONAL_VALUE) && (value != DUMMY_VALUE))
			? value : null;
	}
	
	void setValue(String value){
		this.value = value;
		this.isSet = true;
	}
	
	void setValue() {
		setValue(DUMMY_VALUE);
	}
	
	boolean hasParamValue() {
		
		return (defaultValue != WITHOUT_VALUE);
		
	}
	
	boolean mustSetParamValue() {
		
		return (defaultValue != WITHOUT_VALUE) && (defaultValue != OPTIONAL_VALUE);
		
	}
	
	boolean isSet() {
		
		return isSet;
	}
	
	void setRequired(boolean required) {
		this.required = required;
	}

	boolean isRequired() {
		return required;
	}
	
	public String toString(){
		
		if (hasParamValue()) {
			String s = optPrefix + " " + optParam + "\t" + description;
			if (mustSetParamValue() && (defaultValue != null) && (defaultValue.length() > 0))
				s += " (default: " + defaultValue + ")";
			return s;
		} else {
			return optPrefix + "\t\t" + description;
		}
		
	}
	
}
