/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class SGESimpleQInstance implements QueueStatus {

	private static String[] invalidHeads = { "queuename ", "-", " ", "#" };
	
	/*
	$ qstat -f
	queuename                      qtype used/tot. load_avg arch          states
	----------------------------------------------------------------------------
	apst.q@ume0e.hpcc.jp           BIP   2/2       2.00     lx24-x86
	  54436 0.56000 scheduler_ cme          r     06/28/2006 13:02:28     1
	  54447 0.56000 scheduler_ cme          r     06/28/2006 14:40:53     1
	----------------------------------------------------------------------------
	apst.q@ume0f.hpcc.jp           BIP   0/2       -NA-     lx24-x86      adu
	----------------------------------------------------------------------------
	apst.q@ume10.hpcc.jp           BIP   2/2       2.00     lx24-x86
	  54428 0.56000 scheduler_ cme          r     06/28/2006 07:07:53     1
	  54437 0.56000 scheduler_ cme          r     06/28/2006 13:44:13     1
	----------------------------------------------------------------------------
	apst.q@ume11.hpcc.jp           BIP   2/2       2.01     lx24-x86
	  54423 0.56000 scheduler_ cme          r     06/28/2006 06:50:48     1
	...
	############################################################################
	 - PENDING JOBS - PENDING JOBS - PENDING JOBS - PENDING JOBS - PENDING JOBS
	############################################################################
	  54456 0.56000 scheduler_ cme          qw    06/28/2006 15:15:45     1
	  54457 0.56000 scheduler_ zhengc       qw    06/28/2006 16:05:48     1
	  54458 0.56000 scheduler_ cme          qw    06/28/2006 16:06:10     1
	 ...
	 */
	
	private String fullname, qname, hostname;
	private int usedSlot;
	private boolean isRunning;
	private boolean isSuspended;
	
	private SGESimpleQInstance(String fullname, int usedSlot, boolean isRunning, boolean isSuspended) throws SchedulerException {

		String s[] = fullname.split("@");
		if (s.length != 2) {
			throw new SchedulerException("Invalid queue name"); 
		}
		this.qname = s[0];
		this.hostname = SGESimpleMainServer.makeFQDN(s[1]);
		this.fullname = this.qname + "@" + this.hostname;
		this.usedSlot = usedSlot;
		this.isRunning = isRunning;
		this.isSuspended = isSuspended;
		
	}
	
	public static SGESimpleQInstance getInstance(String info) {

		if (checkValidInfo(info) == false)
			return null;
		
		String params[] = info.split("\\s+");
		if ((params.length == 5) || (params.length == 6)) {
			int used;
			try {
				used = Integer.parseInt(params[2].split("/")[0]);
			} catch (NumberFormatException e) {
				return null;
			}
			boolean isR = (params.length == 5);
			boolean isS = ((params.length == 6) && (params[5].indexOf("s") >= 0));
			try {
				return new SGESimpleQInstance(params[0], used, isR, isS);
			} catch (SchedulerException e) {
				// ignore
			}
		}
		return null;
		
	}
	
	private static boolean checkValidInfo(String info)  {
		
		for (String s : invalidHeads) {
			if (info.startsWith(s)) {
				return false;
			}
		}
		return true;
		
	}
	
	public boolean isReadyToUse() {

		return isRunning;
		
	}

	public int getPriority() {
		
		return 0;
		
	}

	public void setQueueIndex(int index) {

	}

	public int getQueueIndex() {

		return 0;
		
	}

	public String getName() {

		return getFullName();
		
	}
	
	public String getFullName() {
		
		return fullname;
		
	}
	
	public String getQname() {
		
		return qname;
		
	}
	
	public String getQHostName() {
		
		return hostname;
		
	}
	
	public int getUsedSlotNum() {
		
		return usedSlot;
		
	}
	
	public boolean isSuspended() {
		
		return isSuspended;
		
	}

	public boolean isRunning() {
		
		return !isSuspended;
		
	}
}
