/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;

class GetStatusOperator extends OperatorBase {

	GetStatusOperator(ReserveManager rsvMgr) {
		
		super(rsvMgr);
		
	}
	
	ReserveStatus getStatus(ReserveId rsvId) throws ReserveException {

		logger.debug("Try getStatus: " + rsvId);

		ReserveInfo info = getReserveInfo(rsvId);

		logger.debug("status: " + info);

		return info.getReserveStatus();
		
	}

	ReserveStatus[] getStatus(String owner, Calendar start, Calendar end, int nShowExpired) throws ReserveException {
		
		Calendar now = Calendar.getInstance();
		
		logger.debug("Try getStatus of all: owner=" + owner +
				", start=" + ((start != null) ? String.format(Locale.US, "%tc", start) : "null") + 
				", end=" + ((end != null) ? String.format(Locale.US, "%tc", end) : "null") + 
				", nShowExpired=" + nShowExpired);

		if (nShowExpired < 0) {
			nShowExpired = 0;
		}
		
		LinkedList<ReserveStatus> rsvList = new LinkedList<ReserveStatus>();
		LinkedList<ReserveStatus> expiredList = new LinkedList<ReserveStatus>();
		for (ReserveInfo info : table.getAllByStartOrder()) {
			logger.debug(info);

			ReserveStatus status = info.getReserveStatus();
			if ((owner != null) && (status.getOwner().equals(owner) == false)) {
				logger.debug("Drop it because of different owner");
				continue;
			}
			if ((start != null) && !status.getEndTime().after(start)) {
				// ignore already ended before 'start'
				// status.end <= start
				logger.debug("Drop it because ended before start");
				continue;
			}
			if ((end != null) && !status.getStartTime().before(end)) {
				// ignore not started yet until 'end'
				// end <= status.start
				logger.debug("Drop it because not started before end");
				continue;
			}
			if (info.isExpired(now)) {
				if (nShowExpired > 0) {
					expiredList.add(status);
				}
			} else {
				rsvList.add(status);
			}
		}
		
		while (expiredList.size() > nShowExpired) {
			ReserveStatus status = expiredList.removeFirst();
			logger.debug("Drop " + status.getReserveId().toString() + " because it's too old to show");
		}
		
		expiredList.addAll(rsvList);
		
		return expiredList.toArray(new ReserveStatus[]{});

	}

	int availableNodeNum(Calendar start, Calendar end) throws ReserveException {

		logger.debug("availableNodeNum from "
				+ String.format(Locale.US, "%tc", start) + " to "
				+ String.format(Locale.US, "%tc", end));

		int avail = 0;
		for (NodeInfo node : rsvMgr.getNodeManager().getNodes()) {
			if (node.isFree(start, end)) {
				avail++;
				logger.debug(node.getStatus().getName() + " is free");
			} else {
				// 'node' is reserved during [start, end).
				logger.debug(node.getStatus().getName() + " is not free");
			}
		}
		
		logger.debug("availableNodeNum is " + avail);

		return avail;

	}

}
