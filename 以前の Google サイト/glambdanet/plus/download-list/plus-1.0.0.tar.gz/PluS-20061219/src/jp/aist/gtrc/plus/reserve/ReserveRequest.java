/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.OSType;

public class ReserveRequest implements Serializable, GetRefs {

	private static final long serialVersionUID = 5798440468207583306L;

	private String owner;
	private String users[];
	private int nodeNum;
	private Calendar startTime;
	private Calendar endTime;
	private Map<String, String> options;
	private Map<String, String> extRscs;
	
	private static final String OPT_CPUNUM = "cpunum";
	private static final String OPT_MEM = "mem";
	private static final String OPT_ARCH = "arch";
	private static final String OPT_OS = "os";
	private static final String OPT_PREPOSTQ = "prepostq";
	private static final String OPT_SLOTNUM = "slotnum";
	private static final String OPT_SGEQNAME = "sgeqname";
	private static final boolean MAKE_PREPOSTQ_DEFAULT = false;
	private static final int DEFAULT_SLOTNUM = 0;
	
	private void checkValidReserveRequest(String owner, String users[], int nodeNum,
			Calendar startTime,	Calendar endTime) throws ReserveException {
		
		if ((owner == null) || (owner.length() == 0))
			throw new ReserveException("Invalid Reserve owner");
		
		if ((users == null) || (users.length == 0))
			throw new ReserveException("Invalid Reserve users");
		for (String name : users) {
			if ((name == null) || (name.length() == 0)) 
				throw new ReserveException("Invalid Reserve user name");
		}
		
		if (nodeNum <= 0)
			throw new ReserveException("Invalid number of Node");
		
		if (startTime == null) 
			throw new ReserveException("missing startTime");
		if (endTime == null) 
			throw new ReserveException("missing endTime");
		if (startTime.before(endTime) == false)
			throw new ReserveException("startTime must be before endTime");

	}
	
	private void init(String owner, String users[], int nodeNum, Calendar startTime,
			Calendar endTime) throws ReserveException {
		
		checkValidReserveRequest(owner, users, nodeNum, startTime, endTime);

		this.owner = owner;
		this.users = users;
		this.nodeNum = nodeNum;
		this.startTime = startTime;
		this.endTime = endTime;
		this.options = new HashMap<String, String>();
		this.extRscs = null;

	}
	
	protected void modifyRequest(ReserveRequest req) throws ReserveException {
		
		init(req.getOwner(), req.getUsers(), req.getNodeNum(),
				req.getStartTime(), req.getEndTime());
		
		options.clear();
		options.putAll(req.getOptions());
		
		Map<String, String> map = req.getResourceOptions();
		if (map != null) {
			if (extRscs == null) {
				extRscs = new HashMap<String, String>();
			} else {
				extRscs.clear();
			}
			extRscs.putAll(map);
		}
		
	}

	public ReserveRequest(String owner, String users[], int nodeNum, Calendar startTime,
			Calendar endTime) throws ReserveException {
		
		init(owner, users, nodeNum, startTime, endTime);
		
	}
	
	public ReserveRequest(ReserveRequest req) throws ReserveException {
		
		modifyRequest(req);
		
	}
	
	public void setNodeCPUNum(int num) throws ReserveException {
		
		if (num > 0) {
			options.put(OPT_CPUNUM, Integer.toString(num));
		} else {
			throw new ReserveException("CPU number must be positive");
		}
		
	}

	public void setNodePhysicalMemory(long memByte) throws ReserveException {
		
		if (memByte > 0) {
			options.put(OPT_MEM, Long.toString(memByte));
		} else {
			throw new ReserveException("memory size must be positive");
		}
		
	}

	public void setMakePrePostQueue(boolean use) {
		
		options.put(OPT_PREPOSTQ, Boolean.toString(use));
		
	}
	
	public void setArchType(ArchType arch) {
		
		if (arch != null)
			options.put(OPT_ARCH, arch.name());
		
	}

	public void setOSType(OSType os) {
		
		if (os != null)
			options.put(OPT_OS, os.name());
		
	}
	
	public void setSlotNum(int num) {
		
		options.put(OPT_SLOTNUM, Integer.toString(num));
		
	}
	
	public void setSGEQueueName(String qName) {
		
		if (qName != null) {
			options.put(OPT_SGEQNAME, qName);
		}
		
	}

	public String getOwner() {
		return owner;
	}

	public String[] getUsers() {
		return users;
	}
	
	public String getUserNames(String delim) {

		String users[] = getUsers();
		String userNames = "";
		for (String name : users) {
			userNames += name + delim; 
		}
		if (userNames.length() > 0) {
			userNames = userNames.substring(0, userNames.length() - delim.length());
		}
		return userNames;
		
	}
	
	public int getNodeNum() {
		return nodeNum;
	}

	public Calendar getStartTime() {
		return startTime;
	}

	public Calendar getEndTime() {
		return endTime;
	}
	
	private String getNodeOption(String attr) {
		String v = options.get(attr);
		if (v != null)
			return v;
		else
			return "";
	}
	
	public int getNodeCPUNum() {
		String n = getNodeOption(OPT_CPUNUM);
		if (n.length() > 0)
			return Integer.parseInt(n);
		else
			return 1;
	}
	
	public long getNodePhysicalMemory() {
		String n = getNodeOption(OPT_MEM);
		if (n.length() > 0)
			return Long.parseLong(n);
		else
			return 1; // = 1 byte
	}
	
	public Map<String, String> getOptions() {
		return options;
	}
	
	public void setOptions(Map<String, String> prop) {
		if (prop != null) {
			this.options = prop;
		}
	}
	
	public void addResourceOptions(String reqProp[]) {
	
		if ((reqProp.length > 0) && (extRscs == null)) {
			extRscs = new HashMap<String, String>();
		}
		
		for (String req : reqProp) {
			String r[] = req.split("=");
			switch (r.length) {
			case 2:
				extRscs.put(r[0], r[1]);
				break;
			case 1:
				extRscs.put(req, NodeResource.PROP_EXISTS);
				break;
			default:
				// ignore
				break;
			}
		}
		
	}
	
	public Map<String, String> getResourceOptions() {
		
		return extRscs;
		
	}
	
	public boolean isMakePrePostQueue() {
		String s = getNodeOption(OPT_PREPOSTQ);
		return (s.length() > 0) ? Boolean.valueOf(s) : MAKE_PREPOSTQ_DEFAULT;
	}
	
	public ArchType getArchType() {
		
		String s = getNodeOption(OPT_ARCH);
		return (s.length() > 0) ? ArchType.getArch(s) : null;
		
	}
	
	public OSType getOSType() {
		
		String s = getNodeOption(OPT_OS);
		return (s.length() > 0) ? OSType.getOS(s) : null;
		
	}

	public int getSlotNum() {
		String s = getNodeOption(OPT_SLOTNUM);
		return (s.length() > 0) ? Integer.valueOf(s) : DEFAULT_SLOTNUM;
	}

	public String getSGEQueueName() {
		return getNodeOption(OPT_SGEQNAME);
	}

	protected String mapToString(Map<String, String> map) {
		if (map == null) {
			return "";
		}
		
		String s = "";
		for (Entry<String, String> ent : map.entrySet()) {
			s += ent.getKey() + "=" + ent.getValue() + " ";
		}
		return s.trim();
	}
	
	public String toString() {
		
		return "from " + String.format(Locale.US, "%tc", startTime)
			+ " to " + String.format(Locale.US, "%tc", endTime)
			+ " by " + owner
			+ " for " + getUserNames(" ")
			+ " of " + nodeNum + "nodes"
			+ " prop = " + mapToString(options)
			+ ", extRscs = " + mapToString(extRscs);
		
	}

	public Collection<Object> getRefs() {

		LinkedList<Object> list = new LinkedList<Object>();
		list.add(this);
		list.add(startTime);
		list.add(endTime);
		list.add(options);
		return list;
		
	}
	
}
