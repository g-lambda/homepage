/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.sys;

public enum SignalType {
	
	SIGHUP(1),
	SIGINT(2),
	SIGQUIT(3),
	SIGILL(4),
	SIGTRAP(5),
	SIGABRT(6),
	SIGIOT(6),
	SIGBUS(7),
	SIGFPE(8),
	SIGKILL(9),
	SIGUSR1(10),
	SIGSEGV(11),
	SIGUSR2(12),
	SIGPIPE(13),
	SIGALRM(14),
	SIGTERM(15),
	SIGSTKFLT(16),
	SIGCHLD(17),
	SIGCONT(18),
	SIGSTOP(19),
	SIGTSTP(20),
	SIGTTIN(21),
	SIGTTOU(22),
	SIGURG(23),
	SIGXCPU(24),
	SIGXFSZ(25),
	SIGVTALRM(26),
	SIGPROF(27),
	SIGWINCH(28),
	SIGIO(29),
	SIGPOLL(29),
	
	// for PBS, not real signal
	suspend,
	resume;
	
	private final int signal;
	private static final int PSUDE_SIGNAL = -1;
	
	
	private SignalType() {
		
		this(PSUDE_SIGNAL);
		
	}

	private SignalType(int signal) {
		
		this.signal = signal;
		
	}
	
	public int signal() {
		
		assert(signal != PSUDE_SIGNAL);
		return signal;
		
	}

}
