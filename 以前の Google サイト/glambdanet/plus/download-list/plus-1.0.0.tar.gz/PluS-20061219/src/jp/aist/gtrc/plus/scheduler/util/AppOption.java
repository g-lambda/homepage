/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.util.LinkedHashMap;
import java.util.Map;


public class AppOption{
	
	private String appName;
	private Map<String, Option> map  = new LinkedHashMap<String, Option>();
	private static final String OPT_PREFIX_SHOW_HELP = "-h";
	
	protected AppOption(String appName) {
		
		this.appName = appName;
		
	}
	
	private void addOption(String optPrefix, Option option) {
		
		if (map.containsKey(optPrefix) == false) {
			map.put(optPrefix, option);
		} else {
			System.err.println("PROGRAM ERROR: option key " + optPrefix + " is duplicated");
			System.exit(1);
		}
		
	}
	
	protected void addOption(Option option) {
		
		addOption(option.getPrefix(), option);
		
	}
	
	protected void addRequiredOption(String optPrefix, String optParam,
			String description, String defaultValue) {

		addOption(optPrefix, new Option(optPrefix, optParam, description, defaultValue, true));
		
	}

	protected void addOption(String optPrefix, String optParam,
			String description, String defaultValue) {
		
		addOption(optPrefix, new Option(optPrefix, optParam, description, defaultValue));
		
	}

	protected void addOption(String optPrefix, String optParam, String description) {
		
		addOption(optPrefix, new Option(optPrefix, optParam, description));
		
	}
	
	protected void addRequiredOption(String optPrefix, String description) {
		
		addOption(optPrefix, new Option(optPrefix, description, true));
		
	}

	protected void addOption(String optPrefix, String description) {
		
		addOption(optPrefix, new Option(optPrefix, description));
		
	}
	
	protected void deleteOption(String optPrefix) {
		
		if (map.containsKey(optPrefix)) {
			map.remove(optPrefix);
		}
		
	}
	
	protected void setRequired(String optPrefix, boolean required) {
		
		Option opt = map.get(optPrefix);
		if (opt != null) {
			opt.setRequired(required);
		}
		
	}

	public void showHelp(){
		
		String msg = appName;
		for (Map.Entry<String, Option> e : map.entrySet()) {
			Option opt = e.getValue();
			String s = opt.getPrefix();
			if (opt.hasParamValue()) {
				if (opt.mustSetParamValue()) {
					s += " " + opt.getParam();
				} else {
					s += " [" + opt.getParam() + "]";
				}
			}
			if (opt.isRequired()) {
				msg += " " + s;
			} else {
				msg += " [" + s + "]";
			}
		}
		System.out.println(msg);
		
		for (Map.Entry<String, Option> e : map.entrySet()) {
			System.out.println("  " + e.getValue().toString());
		}
		
	}
	
	private void checkParams() throws Exception {
		
		for (Map.Entry<String, Option> e : map.entrySet()) {
			Option opt = e.getValue();
			if (opt.isRequired() && !opt.isSet()) {
				String msg = "missing \"" + opt.getPrefix();
				if (opt.hasParamValue()) {
					msg += " " + opt.getParam();
				}
				msg += "\"";
				throw new Exception(msg);
			}
		}
		
	}
	
	public void parse(String args[]) throws Exception {
		
		int i = 0;
		while (i < args.length) {
			String optPrefix = args[i];
			if (optPrefix.equals(OPT_PREFIX_SHOW_HELP)) {
				showHelp();
				System.exit(0);
			}
			
			Option opt = map.get(optPrefix);
			if (opt == null)
				throw new Exception("Unknown parameter: " + optPrefix);
			
			if (opt.hasParamValue()) {
				if ((i+1 < args.length) && (args[i+1].startsWith("-") == false)) {
					opt.setValue(args[i+1]);
					i += 2;
					continue;
				} else if (opt.mustSetParamValue()) {
					throw new Exception("Lost parameter value of " + optPrefix);
				}
			}
			opt.setValue();
			i++;
			
		}
	
		checkParams();
		
	}
	
	public String getOptionValue(String optPrefix) {
		
		Option opt = map.get(optPrefix);
		if (opt != null) {
			return opt.getValue();
		} else {
			System.err.println("PROGRAM ERROR: option key " + optPrefix + " is unusable");
			System.exit(1);
			return null;
		}
		
	}
	
	public boolean isOptionSet(String optPrefix) {
		
		Option opt = map.get(optPrefix);
		if (opt != null) {
			return opt.isSet();
		} else {
			System.err.println("PROGRAM ERROR: option key " + optPrefix + " is unusable");
			System.exit(1);
			return false;
		}
		
	}

}

