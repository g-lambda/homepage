/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.status.JobID;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.ServerStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.sys.SignalType;
import jp.aist.gtrc.plus.scheduler.util.PluSUtil;

public class SGESimpleMainServer implements MainServer {

	private static SGESimpleMainServer instance = null;
	private static String domainName = null;
	protected static Logger logger = Logger.getLogger(SGESimpleMainServer.class);

	public static SGESimpleMainServer getInstance() {
		
		if (instance == null) {
			 instance = new SGESimpleMainServer();
			 domainName = checkDomainName();
			 logger.debug("makeFQDN(\"host\") is " + makeFQDN("host"));
		}
		return instance;
		
	}
	
	private static LinkedList<String> getExecNodeNamesByQconf() throws ReserveException {
		
		return PluSUtil.runCommand(new String[]{"qconf", "-sel"});
		
	}
	
	private static LinkedList<String> runQhost(boolean withAttr) throws ReserveException {
		
		final int HEADLINE_NUM = 3;
		/*
		 * qhost output always has 3 line heder as follows:
		 * 		HOSTNAME	...
		 * 		----------  ....
		 * 		global		...
		 * They are needless, so skip them. 
		 */
		
		String cmd[] = withAttr ? new String[]{"qhost", "-F"} : new String[]{"qhost"};
		LinkedList<String> stdout = PluSUtil.runCommand(cmd);
		for (int i = 0; i < HEADLINE_NUM; i++) {
			stdout.removeFirst();	// drop header
		}
		
		return stdout;
		
	}
	
	private static LinkedList<LinkedList<String>> getExecNodeInfoByQhostWithAttr() throws ReserveException {
		
		LinkedList<String> stdout = runQhost(true);
		LinkedList<LinkedList<String>> nodeList = new LinkedList<LinkedList<String>>();
		LinkedList<String> node = null;
		for (String line : stdout) {
			if (line.startsWith(" ") == false) {
				node = new LinkedList<String>();
				nodeList.add(node);
			}
			if (node != null) {
				node.add(line);
			}
		}
		
		return nodeList;
		
	}
	
	private static String checkDomainName() {
		
		try {
			LinkedList<String> names = getExecNodeNamesByQconf();
			if (names.size() > 0) {
				String hostname = names.getFirst();
				int index = hostname.indexOf('.');
				if (index > 0) {
					return hostname.substring(index);
				}
			}
		} catch (Exception e) {
			// ignore
		}
		
		return null;
		
	}
	
	static String makeFQDN(String hostname) {
		
		assert(hostname != null);
		if (hostname.indexOf('.') > 0) {
			return hostname;
		} else if (domainName != null) {
			return hostname + domainName;
		} else {
			return hostname;
		}
		
	}
		
	public boolean isConnected() {
		
		return true;
		
	}

	public void disconnect() {
	}

	public ServerStatus getServerStatus() throws SchedulerException {

		return SGESimpleServerStatus.getInstance();
		
	}

	public Collection<NodeStatus> getNodeStatus() throws SchedulerException {

		LinkedList<NodeStatus> list = new LinkedList<NodeStatus>();
		
		LinkedList<String> names = getExecNodeNamesByQconf();
		LinkedList<LinkedList<String>> nodeList = getExecNodeInfoByQhostWithAttr();
		
		for (LinkedList<String> node : nodeList) {
			String hostname = names.removeFirst();
			SGESimpleNodeStatus status = SGESimpleNodeStatus.getInstance(node, hostname);
			if (status == null) {
				throw new SchedulerException("invalid host status information");
			}
			list.add(status);
		}
		
		return list;
		
	}

	public Collection<QueueStatus> getQueueStatus() throws SchedulerException {

		LinkedList<QueueStatus> list = new LinkedList<QueueStatus>();
		
		Collection<String> stdout = PluSUtil.runCommand(new String[]{"qconf", "-sql"});
		for (String line : stdout) {
			SGESimpleQueueStatus status = SGESimpleQueueStatus.getInstance(line);
			if (status != null) {
				list.add(status);
			}
		}
		
		return list;
		
	}

	public Collection<SGESimpleQInstance> getQInstanceStatus() throws SchedulerException {

		LinkedList<SGESimpleQInstance> list
			= new LinkedList<SGESimpleQInstance>();
		
		Collection<String> stdout = PluSUtil.runCommand(new String[]{"qstat", "-f"});
		for (String line : stdout) {
			SGESimpleQInstance status = SGESimpleQInstance.getInstance(line);
			if (status != null) {
				list.add(status);
			}
		}
		
		return list;
		
	}
	
	public int getPendingJobNum(QueueStatus queue) throws SchedulerException {
		
		final int HEADLINE_NUM = 2;
		Collection<String> stdout = PluSUtil.runCommand(
				new String[]{"qstat", "-q", queue.getName(), "-s", "p"});
		int n = stdout.size();
		return (n > HEADLINE_NUM) ? (n - HEADLINE_NUM) : 0; 
		
	}

	public Collection<JobStatus> getJobStatus(QueueStatus queue)
			throws SchedulerException {
		throw new SchedulerException("NOT SUPPORTED");
	}

	public void runJob(JobID jobID, NodeStatus node) throws SchedulerException {
		throw new SchedulerException("NOT SUPPORTED");
	}

	public void runJob(JobStatus job, Collection<NodeInfo> nodes)
			throws SchedulerException {
		throw new SchedulerException("NOT SUPPORTED");
	}

	public void deleteJob(JobID jobID) throws SchedulerException {
		
		PluSUtil.runCommand(new String[]{"qdel", jobID.toString()});
		
	}

	public void suspendJob(JobID jobID) throws SchedulerException {
		
		PluSUtil.runCommand(new String[]{"qmod", "-sj", jobID.toString()});
		
	}

	public void resumeJob(JobID jobID) throws SchedulerException {
		
		PluSUtil.runCommand(new String[]{"qmod", "-usj", jobID.toString()});
		
	}

	public void holdJob(JobID jobID) throws SchedulerException {
		
		PluSUtil.runCommand(new String[]{"qhold", jobID.toString()});
		
	}

	public void releaseJob(JobID jobID) throws SchedulerException {
		
		PluSUtil.runCommand(new String[]{"qrls", jobID.toString()});
		
	}

	public void rerunJob(JobStatus job) throws SchedulerException {
		
		String id[] = job.getJobID().toString().split(".");
		String jobID = id[0];	// ignore task id
		
		PluSUtil.runCommand(new String[]{"qmod", "-sj", jobID});
		PluSUtil.runCommand(new String[]{"sudo", "-u" , job.getOwner(),
				"qresub", jobID});
		PluSUtil.runCommand(new String[]{"qdel", jobID});
		
	}

	public void signalJob(JobID jobID, SignalType signal) throws SchedulerException {
		
		throw new SchedulerException("NOT SUPPORTED");
		
	}
	
	public String getPENames() throws SchedulerException {
		
		Collection<String> stdout = PluSUtil.runCommand(new String[]{"qconf", "-spl"});
		if (stdout.size() == 0) {
			return "NONE";
		}
		String names = "";
		for (String s : stdout) {
			names += s + ",";
		}
		if (names.length() > 0) {
			// drop last ","
			names = names.substring(0, names.length() -1);
		}
		return names;
		
	}

}
