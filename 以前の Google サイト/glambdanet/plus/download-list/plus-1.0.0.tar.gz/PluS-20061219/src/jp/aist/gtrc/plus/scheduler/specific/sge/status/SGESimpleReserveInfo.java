/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.io.Serializable;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveInfo;
import jp.aist.gtrc.plus.reserve.ReserveNodeSet;
import jp.aist.gtrc.plus.reserve.ReserveOperationType;
import jp.aist.gtrc.plus.reserve.ReserveRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.sge.util.SGESimpleReserveManager;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.util.PluSUtil;

public class SGESimpleReserveInfo extends ReserveInfo implements Serializable {

	private static final long serialVersionUID = -7407677492134975434L;
	
	transient private SGESimpleReserveManager rsvMgr;

	public SGESimpleReserveInfo(ReserveId id, ReserveRequest req,
			ReserveNodeSet rsvNodeSet, SGESimpleReserveManager rsvMgr) throws ReserveException {

		super(id, req, rsvNodeSet);
		this.rsvMgr = rsvMgr;
		
	}
	
	public void normalize(SGESimpleReserveManager rsvMgr) {
		
		this.rsvMgr = rsvMgr; 
		
	}
	
	private void registerNodes(ReserveNodeSet rsvNodeSet) throws ReserveException {
		
		/*
		 * usage: sge_rsvq_reg_nodes.sh $RSVID $HOSTLIST
		 */
		PluSUtil.runCommand(new String[]{
				"sge_rsvq_reg_nodes.sh",
				getReserveId().toString(),
				getHostList()}
		);
		
	}
	
	private void unregisterNodes() throws ReserveException {
		
		/*
		 * usage: sge_rsvq_unreg_nodes.sh $RSVID
		 */
		PluSUtil.runCommand(new String[]{
				"sge_rsvq_unreg_nodes.sh",
				getReserveId().toString()}
		);

	}
	
	private ReserveOperationType getCurrentOperationType() {
		
		if (rsvMgr == null) {
			// not initiallized yet
			return ReserveOperationType.reserve;
		} else { 
			return rsvMgr.getCurrentOperation().getOperationType();
		}
		
	}
	
	protected void registerReservedNodes(ReserveNodeSet rsvNodeSet) throws ReserveException {
		
		ReserveNodeSet oldSet = getReserveNodeSet();
		
		super.registerReservedNodes(rsvNodeSet);
		
		switch (getCurrentOperationType()) {
		case cancel:
		case destroy: 
			// fall-through to recover/modify reserved nodes
		case reserve:
		case modify:
			if ((rsvNodeSet != null) && (rsvNodeSet.equals(oldSet) == false)) {
				registerNodes(rsvNodeSet);
			}
			break;
		case idle:
		case remove:
			assert(false);
			break;
		default:
			assert(false);
			break;
		}
		
	}
	
	protected void unregisterReservedNodesForever() throws ReserveException {

		super.unregisterReservedNodesForever();
		
		switch (getCurrentOperationType()) {
		case cancel:
		case modify:
			try {
				unregisterNodes();
			} catch (Exception e) {
				// TODO ignore
			}
			break;
		case reserve:
			// abort of reserve was called.
			// don't call unregisterNodes() same as destroy etc.
			break;
		case idle:
			// reserve will be deleted by scheduling
			break;
		case destroy: 
		case remove:
			// reserve queue will be removed soon, 
			// don't call unregisterNodes()
			break;
		default:
			assert(false);
			break;
		}
		
	}
	
	protected void changeReserveRequest(ReserveRequest oldReq, ReserveRequest newReq) throws ReserveException {

		String oldUserNames = oldReq.getUserNames(",");
		String newUserNames = newReq.getUserNames(",");
		
		super.changeReserveRequest(oldReq, newReq);
		
		if (oldUserNames.equals(newUserNames) == false) {
			PluSUtil.runCommand(new String[]{
					"sge_rsvq_mod_users.sh",
					getReserveId().toString(),
					newUserNames});
		}
		
	}

	public String getSlotNumList() {
		
		/*
		 * Assume that we reserved
		 * 		host00.example.com (2 CPU) and host01.example.com (1 CPU),
		 * this method returns "1,[host00.example.com=2],[host01.example.com=1]"
		 * First "1" is ignored because it is default value.
		 */
		String list = "1,";
		for (NodeInfo node : getReservedNodeInfos()) {
			NodeStatus status = node.getStatus();
			list += "[" + status.getName() + "=" + status.getCPUNum() + "],";
		}
		return list.substring(0, list.length() -1);
		
	}
	
	public String getHostList() {
		
		// NOTE: hostnames are separated by " "
		String list = "";
		for (NodeInfo node : getReservedNodeInfos()) {
			list += node.getStatus().getName() + " ";
		}
		if (list.length() > 0) {
			// drop last " "
			return list.substring(0, list.length() -1);
		} else {
			return "NONE";
		}
		
	}
	
}
