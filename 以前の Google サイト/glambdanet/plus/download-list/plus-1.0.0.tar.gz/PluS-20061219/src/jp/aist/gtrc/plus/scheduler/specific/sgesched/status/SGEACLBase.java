/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sgesched.status;

import java.util.Collection;

import jp.aist.gtrc.plus.scheduler.status.Status;

abstract class SGEACLBase<V extends Status> {
	
	private Collection<V> allows = null;
	private Collection<V> denys = null;

	protected static String[] getACLEntryNames(String rawText[]) {
		
		/*
		 * 'rawText' must be getStringParams("acl") or getStringParams("xacl")
		 * ex:
		 * 	{	"users_A", "0", "0", "0", "0", "0",
		 * 	 	"users_B", "0", "0", "0", "0", "0" }
		 * return { "users_A", "users_B" }
		 */ 
		if (rawText.length == 0)
			return null;
		if ((rawText.length % SGEACLEntry.RAW_DATA_NUM) != 0)
			return null;
		
		int entnum = rawText.length / SGEACLEntry.RAW_DATA_NUM;
		String users[] = new String[entnum];
		for (int i = 0; i < entnum; i++) {
			users[i] = rawText[i * SGEACLEntry.RAW_DATA_NUM];
		}

		return users;
		
	}
	
	protected abstract boolean contains(String name, Collection<V> collection);

	protected void setAllowsDenys(Collection<V> allows, Collection<V> denys) {
		
		this.allows = allows;
		this.denys = denys;
		
	}
	
	private boolean isEmpty(Collection<V> collection) {
		
		return ((collection == null) || (collection.size() == 0));
		
	}
	
	public boolean isAllowed(String name) {
		
		if ((name == null) || (name.length() == 0)) {
			return true;
		}
		
		if (isEmpty(allows) == false) {
			if (isEmpty(denys)) {
				return contains(name, allows);
			} else {
				// return false even if 'name' in both of allows&denys
				if (contains(name, denys))
					return false;
				return contains(name, allows);
			}
		} else {
			if (isEmpty(denys)) {
				// always return true if allows&denys are both empty
				return true;
			} else {
				return (contains(name, denys) == false);
			}
		}
		
	}

	private String getEntryNames(Collection<V> collection) {
		
		if (isEmpty(collection))
			return "NONE";
		
		String s = "";
		for (V v : collection)
			s += v.getName() + " ";
		return s;
		
	}
	
	public String toString() {
		
		return "allow<" + getEntryNames(allows)
			+ ">, deny<" + getEntryNames(denys) + ">";
		
	}
}
