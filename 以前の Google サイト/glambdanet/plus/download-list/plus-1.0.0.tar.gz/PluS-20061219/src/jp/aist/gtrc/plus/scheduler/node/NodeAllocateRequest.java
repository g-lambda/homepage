/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Locale;

import jp.aist.gtrc.plus.reserve.ReserveRequest;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;


public class NodeAllocateRequest {

	private Collection <NodeAllocateSet> allocSets;
	private Calendar startTime;
	private Calendar endTime;
	private JobStatus job;
	private ReserveRequest rsvReq;
	private String requester;

	public NodeAllocateRequest(JobStatus job){

		assert(job != null);
		
		allocSets = job.getNodeRequests();
		startTime = Calendar.getInstance();
		endTime = (Calendar)startTime.clone();
		endTime.add(Calendar.SECOND, job.getRequestedTime());
		this.job = job;
		this.rsvReq = null;
		requester = job.getOwner();

	}

	public NodeAllocateRequest(ReserveRequest rsvReq){
		
		assert(rsvReq != null);
		
		allocSets = new LinkedList<NodeAllocateSet>();
		NodeAllocateSet set = new NodeAllocateSet(
				rsvReq.getNodeNum(), new NodeResource(rsvReq));
		allocSets.add(set);
		startTime = rsvReq.getStartTime();
		endTime = rsvReq.getEndTime();
		this.job = null;
		this.rsvReq = rsvReq;
		requester = rsvReq.getOwner();

	}

	public Collection<NodeAllocateSet> getRequestedNodeAllocateSets() {
		return allocSets;
	}
	
	public Calendar getStartTime() {
		return startTime;
	}
	
	public Calendar getEndTime() {
		return endTime;
	}
	
	public JobStatus getTargetJob() {
		return job;
	}
	
	public ReserveRequest getReserveRequest() {
		return rsvReq;
	}
	
	public String getRequester() {
		return requester;
	}
	
	public boolean isAllocatedEnough() {
		
		for (NodeAllocateSet set : allocSets) {
			if (set.isAllocatedEnough() == false)
				return false;
		}
		return true;
		
	}
	
	public String toString() {
		
		return String.format(Locale.US, "start=%tc, end=%tc, requester=%s, job=%s, allocSets=%s",
				startTime, endTime, requester, 
				((job != null) ? job.getName() : "null"),
				allocSets.toString());
		
	}

}