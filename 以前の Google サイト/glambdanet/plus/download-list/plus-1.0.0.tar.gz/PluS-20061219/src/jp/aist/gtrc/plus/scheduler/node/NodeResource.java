/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import jp.aist.gtrc.plus.reserve.ReserveRequest;
import jp.aist.gtrc.plus.scheduler.status.ArchType;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.OSType;


public class NodeResource {

	private Map<String, Object> resources = new HashMap<String, Object>();
	private Map<String, String> extRscs;
	
	private static final String RES_CPUNUM = "cpunum";		// # of CPU/node
	private static final String RES_PROCNUM = "procnum";		// # of Process/node
	private static final String RES_ARCH = "arch";		// CPU arch
	private static final String RES_OS = "os";		// OS type
	private static final String RES_MEM = "phymem"; // [KB]
	
	private static final int DEFAULT_CPUNUM = 1;
	private static final int DEFAULT_PROCNUM = 1;
	private static final long DEFAULT_MEM = 1024; // = 1[MB]
	public static final String PROP_EXISTS = Boolean.toString(true);
	
	protected void addResourceOptions(Map<String, String> optMap) {
		
		if (optMap != null) {
			if (extRscs == null) {
				 extRscs = new HashMap<String, String>();
			}
			extRscs.putAll(optMap);
		}

	}
	
	protected void addResourceOption(String attr, String value) {
		
		if (extRscs == null) {
			 extRscs = new HashMap<String, String>();
		}
		extRscs.put(attr, value);

	}

	public NodeResource(NodeStatus status){
		
		this(status.getCPUNum(), 1, status.getArchType(), status.getOSType());
		putPhysicalMemorySize(status.getPhysicalMemory());
		addResourceOptions(status.getAttributeMap());

	}

	public NodeResource(int cpunum, int procnum, ArchType arch, OSType os) {
		
		putCPUNum(cpunum);
		putProcessNum(procnum);
		putArchType(arch);
		putOSType(os);
		
	}

	public NodeResource(int cpunum, int procnum) {
		
		this(cpunum, procnum, ArchType.unknown, OSType.Unknown);
		
	}
	
	public NodeResource(ReserveRequest rsvReq){
		
		putCPUNum(rsvReq.getNodeCPUNum());
		putPhysicalMemorySize(rsvReq.getNodePhysicalMemory());
		putArchType(rsvReq.getArchType());
		putOSType(rsvReq.getOSType());
		addResourceOptions(rsvReq.getResourceOptions());

	}

	private void putCPUNum(int num) {

		resources.put(RES_CPUNUM, num);

	}
	
	private void putProcessNum(int num) {

		resources.put(RES_PROCNUM, num);

	}
	
	private void putPhysicalMemorySize(long memByte){
		
		resources.put(RES_MEM, memByte);
		
	}
	
	private void putArchType(ArchType arch) {
		
		resources.put(RES_ARCH, arch);
		
	}
	
	private void putOSType(OSType os) {
		
		resources.put(RES_OS, os);
		
	}
	
	public int getCPUNum(){
		
		Integer n = (Integer)resources.get(RES_CPUNUM);
		return (n != null) ? n : DEFAULT_CPUNUM; 
		
	}
	
	public int getProcessNum() {
		
		Integer n = (Integer)resources.get(RES_PROCNUM);
		return (n != null) ? n : DEFAULT_PROCNUM; 
		
	}

	public long getPhysicalMemorySize(){
		
		Long n = (Long)resources.get(RES_MEM);
		return (n != null) ? n : DEFAULT_MEM; 

	}
	
	public ArchType getArchType() {
		
		ArchType a = (ArchType)resources.get(RES_ARCH);
		return (a != null) ? a : ArchType.unknown; 

	}

	public OSType getOSType() {
		
		OSType os = (OSType)resources.get(RES_OS);
		return (os != null) ? os : OSType.Unknown; 

	}

	public String getResourceValue(String resourceName){

		String v = (String)resources.get(resourceName);
		if (v != null)
			return v;
		else
			return "";
		
	}

	private Map<String, String> getExtendResource() {
		
		return extRscs;
		
	}
	
	protected String getCanonicalResourceName(String name) {
		
		/*
		 * NOTE: On SGE, canonical name and shortcut name are usable.
		 */
		return name;
		
	}
	
	protected boolean isResourceMatch(String rscName, String reqValue, String myValue) {
		
		return (reqValue.equals(myValue));
	}
	
	protected boolean isExtendResourceEnough(NodeResource reqResource) {
		
		Map<String, String> reqMap = reqResource.getExtendResource();
		Map<String, String> myMap = this.getExtendResource();
		
		if ((reqMap == null) || (reqMap.size() == 0)) {
			// nothing requested
			return true;
		}
		if ((myMap == null) || (myMap.size() == 0)) {
			// requested, but I don't have any resource
			return false;
		}
		
		for (Map.Entry<String, String> entry : reqMap.entrySet()) {
			String key = getCanonicalResourceName(entry.getKey());
			String myValue = myMap.get(key);
			if (myValue == null) {
				// don't have requested resource
				return false;
			}
			if (isResourceMatch(key, entry.getValue(), myValue) == false) {
				// don't match resource value
				return false;
			}
		}
		
		// I have all of requested resources
		return true;
		
	}
	
	private boolean isResourceEnough(NodeResource reqResource) {
		
		// enough CPU (dual or SMP etc) ?
		if (getCPUNum() < reqResource.getCPUNum())
			return false;
		
		// enough Memory ?
		if (getPhysicalMemorySize() < reqResource.getPhysicalMemorySize())
			return false;
		
		ArchType reqArch = reqResource.getArchType();
		if ((reqArch != null) && (reqArch != ArchType.unknown)) {
			if (getArchType() != reqArch)
				return false;
		} else {
			// means requested arch not specified, any arch is OK
		}
		
		OSType reqOS = reqResource.getOSType();
		if ((reqOS != null) && (reqOS != OSType.Unknown)) {
			if (OSType.isMatch(reqOS, getOSType()) == false) {
				return false;
			}
		} else {
			// means requested OS not specified, any OS is OK
		}

		return isExtendResourceEnough(reqResource);

	}
	
	public NodeResource getEnoughResource(Collection<NodeResource> reqResources) {
		
		for (NodeResource rsc : reqResources) {
			if (isResourceEnough(rsc) == true)
				return rsc;
		}
		
		return null;
		
	}
	
	public boolean isEnough(Collection<NodeResource> reqResources) {

		return (getEnoughResource(reqResources) != null);
		
	}
	
	public String toString() {
		
		String s = "";
		for (Map.Entry<String, Object> ent : resources.entrySet()) {
			s += ent.getKey() + "=" + ent.getValue().toString() + " ";
		}
		return s;
		
	}

}