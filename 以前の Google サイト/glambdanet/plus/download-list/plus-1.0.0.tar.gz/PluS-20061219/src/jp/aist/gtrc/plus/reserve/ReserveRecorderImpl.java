/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.node.NodeManager;


import org.apache.log4j.Logger;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.Configuration;
import com.db4o.config.ObjectClass;


public class ReserveRecorderImpl implements ReserveRecorder {

	transient private ObjectContainer db = null;
	transient private NodeManager nodeMgr = null;
	transient private ReserveOperation ope = null;
	transient boolean isLoaded = false;

	private LastReserveId lastId = new LastReserveId();
	
	transient private static final String DB_FILE_NAME = "reserves.db4o";
	transient protected static Logger logger = Logger.getLogger(ReserveRecorderImpl.class);
	
	class LastReserveId extends ReserveId {

		private static final long serialVersionUID = 4801320709790482891L;
		// db4o classify objects by its class.
		// LastReserveId exists for distinction from all other ReserveId.
		
		LastReserveId() {
			super(ReserveId.MINGUARD_ID, false);
		}
		
	}
	
	public ReserveRecorderImpl(String rsvFilePath, NodeManager nodeMgr) throws ReserveException {
		
		try {
			/*
			 * NOTE: set db4o configuration **BEFORE** Db4o.openFile()
			 */
			Configuration conf = Db4o.configure();
			conf.activationDepth(10);
			conf.exceptionsOnNotStorable(true);
			conf.updateDepth(10);
			//conf.messageLevel(3);

			/*
			 * If set(ReserveInfo) called, update not only ReserveInfo
			 * but also ReserveStatus, ReserveReqeust, Map, String, ...
			 */
			ObjectClass oc = conf.objectClass(ReserveInfo.class);
			oc.cascadeOnActivate(true);
			oc.cascadeOnDelete(false);	// must delete all members manually, see remve()
			oc.cascadeOnUpdate(true);
			oc.storeTransientFields(false);
			
			oc = conf.objectClass(LastReserveId.class);
			oc.cascadeOnActivate(true);
			oc.cascadeOnDelete(true);
			oc.cascadeOnUpdate(true);
			oc.storeTransientFields(false);
			
			oc = conf.objectClass(Calendar.class);
			oc.cascadeOnActivate(true);
			oc.cascadeOnDelete(true);	// set true for delete TimeZone etc.
			oc.cascadeOnUpdate(true);
			oc.storeTransientFields(true);
			
			oc = conf.objectClass(ReserveOperation.class);
			oc.cascadeOnActivate(false);
			oc.cascadeOnDelete(false);	// only delete ReserveOperation object
			oc.cascadeOnUpdate(false);
			oc.storeTransientFields(false);
			
			/*
			 * NOTE: call openFile() **AFTER** configuration
			 */
			if ((rsvFilePath == null) || (rsvFilePath.length() == 0))
				rsvFilePath = ".";
			String rsvFile = rsvFilePath + "/" + DB_FILE_NAME;
			db = Db4o.openFile(rsvFile);
			logger.info("Open reserve db file : " + rsvFile);
			
			assert(nodeMgr != null);
			this.nodeMgr = nodeMgr;
		} catch (Exception e) {
			logger.error("Cannot open db file", e);
			throw new ReserveException("Cannot open reserve db file");
		}
		
	}
	
	public void store(ReserveInfo info) throws ReserveException{

		assert(info != null);
		
		try {
			// ObjectContainer#store()
			//	newly stores objects or updates stored objects.
			logger.debug("Try store: " + info);
			db.set(info);
			
			// We want to know last reserve id beyond server restart.
			// lastId exists in DB always even if all reserves are expired.
			ReserveId id = info.getReserveId(); 
			if (id.compareTo(lastId) > 0) {
				// 'id' may not last if called from reserve modify.
				lastId.setId(id);
				db.set(lastId);
				logger.debug("LastId changed to " + id);
			}
			logger.debug("Stored");
		} catch (Exception e) {
			info.setAsError();
			logger.warn("Store failed", e);
			throw new ReserveException(e.getMessage());
		}

	}

	private void removeAllRefs(GetRefs refObject) throws ReserveException {
		
		for (Object obj : refObject.getRefs()) {
			db.delete(obj);
		}
		
	}
	
	public void remove(ReserveInfo info) throws ReserveException{

		assert(info != null);

		try {
			logger.debug("Try deleted: " + info);
			removeAllRefs(info);
			logger.debug("Deleted: " + info);
		} catch (Exception e) {
			info.setAsError();
			logger.warn("Delete failed", e);
			throw new ReserveException(e.getMessage());
		}

	}

	public void commit(ReserveInfo info) throws ReserveException{

		try {
			db.commit();
			logger.debug("Commited: " + info);
		} catch (Exception e) {
			logger.warn("Commit failed", e);
			throw new ReserveException(e.getMessage());
		}

	}

	public void rollback() throws ReserveException{

		try {
			db.rollback();
			logger.debug("Rollbacked: ");
		} catch (Exception e) {
			logger.warn("Rollback failed", e);
			throw new ReserveException(e.getMessage());
		}

	}

	protected void normalize(ReserveInfo info) {
		
		info.normalize(nodeMgr);
		
	}
	
	public Collection<ReserveInfo> loadAll() throws ReserveException {

		ObjectSet<Object> infos;
		try {
			/*
			 * infos is a set of all objects which refered by ReserveInfo.
			 * It has not only ReserveInfo object but also ReserveStatus,
			 * ReserveRequests, Calendar, many Strings, Maps, ..., and so on.
			 * db.get(new ReserveInfo()) returns empty list. 
			 */
			infos = db.get(null);
		} catch (Exception e) {
			logger.warn("Load failed", e);
			throw new ReserveException(e.getMessage());
		}
		
		LinkedList<ReserveInfo> infoList = new LinkedList<ReserveInfo>();
		for (Object obj : infos) {
			if (obj instanceof ReserveInfo) {
				ReserveInfo info = (ReserveInfo)obj;
				normalize(info);
				infoList.add(info);
			} else if (obj instanceof LastReserveId) {
				lastId = (LastReserveId)obj;
				ReserveId.setLastId(lastId);
				logger.debug("LastId changed to " + lastId.toString());
			} else if (obj instanceof ReserveOperation) {
				ope = (ReserveOperation)obj;
			}
		}
		
		isLoaded = true;	

		// NOTE: infoList entries may not sorted by ReserveId
		return infoList;
		
	}

	public void finish() {
		
		if (db != null) {
			try {
				db.close();
				logger.debug("Closed DB file");
			} catch (Exception e) {
				// ignore
				logger.warn("Closed DB file failed", e);
			}
			db = null;
		}
		
	}

	public void storeOperation(ReserveOperation ope) throws ReserveException {
		
		logger.debug("Try store Operation " + ope);
		
		try {
			db.set(ope);
		} catch (Exception e) {
			logger.debug("Cannot store ReserveOperation", e);
			throw new ReserveException("Cannot store ReserveOperation");
		}
		
	}

	public void removeOperation(ReserveOperation ope) throws ReserveException {

		logger.debug("Try remove Operation " + ope);

		try {
			removeAllRefs(ope);
		} catch (Exception e) {
			logger.debug("Cannot remove ReserveOperation", e);
			throw new ReserveException("Cannot remove ReserveOperation");
		}
		
	}

	public ReserveOperation loadOperation() throws ReserveException {

		if (isLoaded == false) {
			loadAll();
		}
		return ope;
		
	}

}