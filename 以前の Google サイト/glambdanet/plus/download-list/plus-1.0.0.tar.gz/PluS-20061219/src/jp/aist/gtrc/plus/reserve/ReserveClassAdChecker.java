/************************************************************************
Copyright 2003, 2004, 2005, 2006 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import condor.classad.*;

import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.util.Checker;
import jp.aist.gtrc.plus.scheduler.util.ClassAdEvaluator;

public class ReserveClassAdChecker extends Checker<NodeInfo> {

	private HashMap<String, Expr> infoMap;
	private ClassAdEvaluator evaluator;
	private static final Logger logger = Logger.getLogger(ReserveClassAdChecker.class);

	private static final String CLASSAD_FILE = "reservable.ad";
	private static final boolean DEFAULT_RESERVABILITY = true; 
	
	ReserveClassAdChecker(NodeManager nodeMgr, String dbPath, NodeAllocateRequest allocReq) {

		String adFilePath = dbPath + "/" + CLASSAD_FILE;
		try {
			this.evaluator = new ClassAdEvaluator(adFilePath, allocReq);

			this.infoMap = new LinkedHashMap<String, Expr>();
			for (NodeInfo info : nodeMgr.getNodes()) {
				infoMap.put(info.getStatus().getName(), makeNodeExpr(info));
			}
			this.evaluator.insertAttribute("PLUS_ALL_NODES",
					new ListExpr(new LinkedList<Expr>(infoMap.values())));
		} catch (ReserveException e) {
			this.evaluator = null;
			this.infoMap = null;
		}

	}
	
	private Expr makeNodeExpr(NodeInfo info) {
		
		RecordExpr expr = new RecordExpr();
		NodeStatus status = info.getStatus();
		
		expr.insertAttribute("name",
				Constant.getInstance(status.getName()));
		expr.insertAttribute("isAlive",
				Constant.getInstance(status.isAlive()));
		expr.insertAttribute("loadavg",
				Constant.getInstance(status.getLoadAverage()));
		expr.insertAttribute("nRunJobs",
				Constant.getInstance(status.getRunningJobNum()));
		/*
		expr.insertAttribute("os",
				Constant.getInstance(status.getOSType().name()));
		expr.insertAttribute("arch",
				Constant.getInstance(status.getArchType().name()));
		*/
		
		return expr;
		
	}
	
	private Expr makeNodeExprList(Collection<NodeInfo> okInfos) {
		
		ListExpr list = new ListExpr();
		for (NodeInfo info : okInfos) {
			Expr e = infoMap.get(info.getStatus().getName());
			if (e != null) {
				list.add(e);
			} else {
				assert(false);
			}
		}
		return list;
		
	}
	
	public boolean isOK(NodeInfo info) {
		assert(false);
		return false;
	}

	public boolean isOK(NodeInfo info, Collection<NodeInfo> okInfos) {

		if (evaluator == null) {
			// treat all nodes are reservable if reservable.ad is invalid
			return DEFAULT_RESERVABILITY;
		}
		
		evaluator.insertAttribute("PLUS_CANDIDATE_NODE",
				infoMap.get(info.getStatus().getName()));
		evaluator.insertAttribute("PLUS_ALLOCATED_NODES",
				makeNodeExprList(okInfos));
		
		Expr value = evaluator.eval("PLUS_NODE_RESERVABLE");
		logger.debug("reservability of " + info.getStatus().getName() + " is " + value.toString());
		return value.isTrue();

	}

}
