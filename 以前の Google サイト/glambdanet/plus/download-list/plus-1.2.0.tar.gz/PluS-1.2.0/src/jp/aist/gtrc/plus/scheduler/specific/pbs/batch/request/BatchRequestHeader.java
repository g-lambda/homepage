/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISDecodable;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISDecoder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISEncodable;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISEncoder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSMainServer;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSErrorCode;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSException;

public class BatchRequestHeader implements DISEncodable, DISDecodable {

    private int protocolType = PBSMainServer.PROTOCOL_TYPE;
    private int protocolVersion = PBSMainServer.PROTOCOL_VERSION;
    private BatchRequestType requestType;
    private String userName;

    protected BatchRequestHeader(BatchRequestType type, String name) {

        this.requestType = type;
        this.userName = name;

    }

    void setUserName(String userName) {

        this.userName = userName;

    }

    public void encode(DISEncoder encoder) {

        encoder.putInt(protocolType);
        encoder.putInt(protocolVersion);
        encoder.putInt(requestType.value());
        encoder.putString(userName);

    }

    public String toString() {

        return "REQUEST: reqType=" + requestType.toString();

    }

    public BatchRequestHeader(DISDecoder decoder) throws PBSException {

        decode(decoder);

    }

    public final void decode(DISDecoder decoder) throws PBSException {

        this.protocolType = decoder.getInt();
        this.protocolVersion = decoder.getInt();
        this.requestType = BatchRequestType.getRequestType(decoder.getInt());
        if (this.requestType == null)
            throw new PBSException(PBSErrorCode.UNKREQ);
        this.userName = decoder.getString();

    }

    public BatchRequestType getRequestType() {

        return requestType;

    }
}
