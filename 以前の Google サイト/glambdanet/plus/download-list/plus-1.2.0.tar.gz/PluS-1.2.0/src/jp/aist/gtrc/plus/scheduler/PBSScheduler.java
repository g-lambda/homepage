/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import java.io.IOException;
import java.net.Socket;
import java.util.Collection;

import jp.aist.gtrc.plus.scheduler.net.AcceptChecker;
import jp.aist.gtrc.plus.scheduler.net.GuardedRMIClientSocketFactory;
import jp.aist.gtrc.plus.scheduler.net.GuardedRMIServerSocketFactory;
import jp.aist.gtrc.plus.scheduler.node.NodeAllocator;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.node.NodeSorter;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.PBSBatchServer;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.actor.BatchActorAuthenticateUser;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.actor.BatchActorDisconnect;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.actor.PBSBatchActor;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSMainServer;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSNodeStatus;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSExecNodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSReserveNodeAllocator;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSScheduleStarter;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSSchedulerOptions;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSServerConfig;
import jp.aist.gtrc.plus.scheduler.specific.pbs.util.PBSServerConnector;
import jp.aist.gtrc.plus.scheduler.status.JobStatus;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

class PBSScheduler extends DefaultSelfScheduler {

    protected PBSSchedulerOptions options;
    protected PBSServerConnector serverConnector;
    protected PBSServerConfig serverConf;
    protected PBSBatchServer authServer;
    protected AcceptChecker checker;

    PBSScheduler(SchedulerOptions options) throws Exception {

        super(options);

        init(options);

        startAuthenticateServer(serverConf.getAuthenticateServerPort());
        startReserveServer(options.getRMIPort());

    }

    private void init(SchedulerOptions scOpts) throws Exception {

        if (options == null) {
            options = new PBSSchedulerOptions(scOpts.getArgs());
            serverConf = new PBSServerConfig(options);
            serverConnector = new PBSServerConnector(serverConf);
            checker = new AcceptChecker();
        }

    }

    protected ScheduleStarter getScheduleStarter(SchedulerOptions scOpts) throws SchedulerException {

        try {
            init(scOpts);
        } catch (Exception e) {
            throw new SchedulerException("cannot initialize PBSScheduler");
        }

        return new PBSScheduleStarter(serverConf);

    }

    protected NodeAllocator getExecNodeAllocator(SchedulerOptions options)
            throws SchedulerException {

        return new PBSExecNodeAllocator(new NodeSorter(options));

    }

    protected NodeAllocator getRsvNodeAllocator(SchedulerOptions options) throws SchedulerException {

        return new PBSReserveNodeAllocator(options, nodeMgr, statusMgr);

    }

    private void startAuthenticateServer(int authSrvPort) throws IOException {

        PBSBatchActor actor = new PBSBatchActor();
        actor.addActor(new BatchActorAuthenticateUser(checker));
        actor.addActor(new BatchActorDisconnect());
        authServer = new PBSBatchServer(authSrvPort, actor);
        Thread t = new Thread(authServer, "PBSAuthenticateServer");
        t.setDaemon(true);
        t.start();

    }

    private void stopAuthenticateServer() {

        if (authServer != null) {
            authServer.finish();
            authServer = null;
        }

    }

    protected void startReserveServer(int rmiPort) throws Exception {

        GuardedRMIClientSocketFactory csf =
                new GuardedRMIClientSocketFactory(serverConf.getAuthenticateServerName(),
                        serverConf.getAuthenticateServerPort());
        GuardedRMIServerSocketFactory ssf = new GuardedRMIServerSocketFactory(checker);

        super.startReserveServer(csf, ssf);

    }

    protected MainServer getMainServer() throws Exception {

        // get current pbs_server status and node information.
        // node information is needed for reserve node check.
        Socket s = serverConnector.getAuthorizedSocket();
        return (MainServer) new PBSMainServer(s);

    }

    /*
     * protected ReserveManager getReserveManager(SchedulerOptions options)
     * throws SchedulerException {
     * 
     * NodeAllocator rsvNodeAllocator = getRsvNodeAllocator(options); if
     * (rsvNodeAllocator == null) { throw new
     * SchedulerException("Invalid ReserveNodeAllocator"); }
     * 
     * return new PBSReserveManager(getReserveNodeManager(), starter,
     * options.getReserveFilePath(), rsvNodeAllocator, new
     * PBSQueueManager(serverConnector), options.getMaxExpiredReserves());
     * 
     * }
     */

    protected void stopScheduler() {

        stopAuthenticateServer();
        super.stopScheduler();

    }

    protected boolean handleUnreservedJobs(MainServer srv, Collection<NodeInfo> rsvdNodes) {

        boolean reruned = false;

        for (NodeInfo node : rsvdNodes) {
            // 'runningJobs' is all job names running on node with/without
            // reserve.
            NodeStatus s = node.getStatus();
            assert (s instanceof PBSNodeStatus);
            PBSNodeStatus ns = (PBSNodeStatus) s;
            for (String jobId : ns.getRunningJobIDs()) {
                JobStatus job = statusMgr.getJob(jobId);
                if (job == null) {
                    assert (false);
                    continue;
                }
                ReserveId rsvId = job.getReserveId();
                if (rsvId != null) {
                    // 'job' is using reserve. OK to run.
                    continue;
                }

                /*
                 * 'job' is running without reserve. We want to run reserved job
                 * on this 'node', so rerurn un-reserved job here. Reruned job
                 * will be killed by pbs_server, and restart running at next
                 * scheduling cycle if possible.
                 */
                try {
                    srv.rerunJob(job);
                    reruned = true;
                } catch (SchedulerException e) {
                    logger.info("cannot rerun of " + job.getName());
                }
            }
        }

        return reruned;

    }

}
