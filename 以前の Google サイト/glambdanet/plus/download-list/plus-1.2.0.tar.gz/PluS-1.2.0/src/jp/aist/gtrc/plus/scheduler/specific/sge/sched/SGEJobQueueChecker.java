/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.sched;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGENodeStatus;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGEQInstance;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGEQueueStatus;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGEStatusManager;
import jp.aist.gtrc.plus.scheduler.specific.sge.status.SGETaskStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.util.Checker;
import jp.aist.gtrc.plus.scheduler.util.CollectionUtil;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class SGEJobQueueChecker extends Checker<NodeInfo> {

    private SGETaskStatus task;
    private HashMap<String, QueueStatus> allQueues;
    private Collection<QueueStatus> targetQs;
    private SGEQueueChecker qChecker;
    private boolean alwaysOK;

    private static final SGEStatusManager statusMgr = SGESelfStatusManager.getInstance();

    private void init(SGETaskStatus task, String owner) {

        this.task = task;
        this.allQueues = statusMgr.getQueueMap();
        this.alwaysOK = CollectionUtil.isEmpty(this.allQueues);

        if (alwaysOK == false) {
            /*
             * NOTE: isOK() is called many times (max: number of nodes), so make
             * targetQs&qChecker here for better performance.
             */
            this.targetQs = makeTargetQueues();
            this.qChecker = (task != null) ? new SGEQueueChecker(task) : new SGEQueueChecker(owner);
        }

    }

    SGEJobQueueChecker(SGETaskStatus task) {

        init(task, null);

    }

    SGEJobQueueChecker(String owner) {

        init(null, owner);

    }

    private Collection<QueueStatus> makeTargetQueues() {

        String[] qNames = (task != null) ? task.getTargetQueueNames() : null;

        if (CollectionUtil.isEmpty(qNames)) {
            // target queue is not specified, check all queues.
            return allQueues.values();
        } else {
            Collection<QueueStatus> list = new LinkedList<QueueStatus>();
            for (String qName : qNames) {
                SGEQueueStatus queue = getQueueStatus(qName);
                list.add(queue);
            }
            return list;
        }

    }

    private SGEQueueStatus getQueueStatus(String qName) {

        assert (TextUtil.isValid(qName));

        // TODO: we currently support qName as "all.q" etc,
        // not support "all.q@*", "all.q@hostA" etc.
        String[] s = qName.split("@");
        if (s.length > 1) {
            qName = s[0];
        }

        QueueStatus q = allQueues.get(qName);
        assert (q != null);
        return (SGEQueueStatus) q;

    }

    public boolean isOK(NodeInfo node) {

        if (alwaysOK) {
            return true;
        }

        SGENodeStatus nodeStatus = SGENodeStatus.getSGENodeStatus(node);

        NodeStatus status = node.getStatus();
        SGEQInstance qinstance = (status instanceof SGEQInstance) ? (SGEQInstance) status : null;

        /*
         * Check queue instance and its acl
         */
        for (QueueStatus q : targetQs) {
            SGEQueueStatus queue = (SGEQueueStatus) q;
            if (qinstance != null) {
                if (qinstance.getQname().equals(queue.getName()) == false) {
                    continue;
                }
                if (qinstance.isReadyToUse() == false) {
                    continue;
                }
            }
            if (queue.hasInstanceOnNode(nodeStatus) == false) {
                continue;
            }
            if (qChecker.isOK(queue) == true) {
                return true;
            }
        }

        // we cannot find available queue, so cannot run 'task' on 'node'
        return false;

    }

}
