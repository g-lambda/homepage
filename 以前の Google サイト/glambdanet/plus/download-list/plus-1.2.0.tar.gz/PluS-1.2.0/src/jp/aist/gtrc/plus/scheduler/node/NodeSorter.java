/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Collection;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.SchedulerOptions;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.util.SortKey;
import jp.aist.gtrc.plus.scheduler.util.Sorter;

import org.apache.log4j.Logger;

public class NodeSorter {

    private final Sorter<NodeInfo> sorter;

    private static final String TITLE_NODE_SORTKEY = "NodeSortKey";
    private static final String DELIM_KEYS = ",\\s*";

    protected static final Logger logger = Logger.getLogger(NodeSorter.class);

    public NodeSorter() {

        sorter = new Sorter<NodeInfo>();

    }

    public NodeSorter(SchedulerOptions options) throws SchedulerException {

        this();

        assert (options != null);
        Map<String, String> confs = options.getConfig();
        if (confs == null) {
            // not specified config filename of scheduler, it's OK.
            logger.info("config file not specified, never sort");
            return;
        }

        String nodeKeyConf = confs.get(TITLE_NODE_SORTKEY);
        if (nodeKeyConf == null) {
            // not specified NodeSortKey in config file, it's OK.
            logger.info("Not found " + TITLE_NODE_SORTKEY + " in config file, never sort");
            return;
        }

        for (String keyName : nodeKeyConf.split(DELIM_KEYS)) {
            NodeSortKey key = NodeSortKey.valueOf(keyName);
            if (key == null) {
                logger.warn("Unknown node sort key: " + keyName + ", ignored");
                continue;
            }
            if (sorter.containsKey(key)) {
                logger.warn("Duplicate node sort key: " + keyName + ", refers first one");
                continue;
            }

            // use addFirst() to sort by *least* important key at *first*,
            // sort by *most* important key at *last*.
            // See sortNodes()
            sorter.addSortKey(key);
        }
        if (sorter.size() == 0) {
            logger.warn("No valid node sort key. " + "First free node will be simply used.");
        }

    }

    public void addSortKey(SortKey<NodeInfo> key) {

        sorter.addSortKey(key);
        logger.info("Added JobSortKey " + key);

    }

    public Collection<NodeInfo> sort(Collection<NodeInfo> nodes) {

        if ((sorter.size() > 0) && (nodes.size() > 1)) {
            NodeInfo[] array = nodes.toArray(new NodeInfo[nodes.size()]);
            sorter.sort(array);

            nodes.clear();
            for (NodeInfo info : array) {
                nodes.add(info);
            }
            return nodes;
        } else {
            // not specified NodeSortKey, do nothing
            return nodes;
        }

    }

}
