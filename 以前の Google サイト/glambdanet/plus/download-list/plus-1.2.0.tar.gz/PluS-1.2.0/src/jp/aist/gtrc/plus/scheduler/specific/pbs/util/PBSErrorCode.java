/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import java.util.HashMap;
import java.util.Map;

public enum PBSErrorCode {

    SUCCESS(0, "no error"), UNKJOBID(15001, "Unknown Job Identifier"), NOATTR(15002,
            "Undefined Attribute"), ATTRRO(15003, "attempt to set READ ONLY attribute"), IVALREQ(
            15004, "Invalid request"), UNKREQ(15005, "Unknown batch request"), TOOMANY(15006,
            "Too many submit retries"), PERM(15007, "No permission"), BADHOST(15008,
            "access from host not allowed"), JOBEXIST(15009, "job already exists"), SYSTEM(15010,
            "system error occurred"), INTERNAL(15011, "internal server error occurred"), REGROUTE(
            15012, "parent job of dependent in rte que"), UNKSIG(15013, "unknown signal name"),
    BADATVAL(15014, "bad attribute value"), MODATRRUN(15015, "Cannot modify attrib in run state"),
    BADSTATE(15016, "request invalid for job state"), UNKQUE(15018, "Unknown queue name"), BADCRED(
            15019, "Invalid Credential in request"),
    EXPIRED(15020, "Expired Credential in request"), QUNOENB(15021, "Queue not enabled"), QACESS(
            15022, "No access permission for queue"),
    BADUSER(15023, "Bad user - no password entry"), HOPCOUNT(15024, "Max hop count exceeded"),
    QUEEXIST(15025, "Queue already exists"), ATTRTYPE(15026, "incompatable queue attribute type"),
    QUEBUSY(15027, "Queue Busy (not empty)"), QUENBIG(15028, "Queue name too long"), NOSUP(15029,
            "Feature/function not supported"), QUENOEN(15030, "Cannot enable queue,needs add def"),
    PROTOCOL(15031, "Protocol (ASN.1) error"), BADATLST(15032, "Bad attribute list structure"),
    NOCONNECTS(15033, "No free connections"), NOSERVER(15034, "No server to connect to"), UNKRESC(
            15035, "Unknown resource"), EXCQRESC(15036, "Job exceeds Queue resource limits"),
    QUENODFLT(15037, "No Default Queue Defined"), NORERUN(15038, "Job Not Rerunnable"), ROUTEREJ(
            15039, "Route rejected by all destinations"), ROUTEEXPD(15040,
            "Time in Route Queue Expired"), MOMREJECT(15041, "Request to MOM failed"), BADSCRIPT(
            15042, "(qsub) cannot access script file"), STAGEIN(15043, "Stage In of files failed"),
    RESCUNAV(15044, "Resources temporarily unavailable"), BADGRP(15045, "Bad Group specified"),
    MAXQUED(15046, "Max number of jobs in queue"),
    CKPBSY(15047, "Checkpoint Busy, may be retries"), EXLIMIT(15048, "Limit exceeds allowable"),
    BADACCT(15049, "Bad Account attribute value"), ALRDYEXIT(15050, "Job already in exit state"),
    NOCOPYFILE(15051, "Job files not copied"),
    CLEANEDOUT(15052, "unknown job id after clean init"),
    NOSYNCMSTR(15053, "No Master in Sync Set"), BADDEPEND(15054, "Invalid dependency"), DUPLIST(
            15055, "Duplicate entry in List"), DISPROTO(15056, "Bad DIS based Request Protocol"),
    EXECTHERE(15057, "cannot execute there"), SISREJECT(15058, "sister rejected"), SISCOMM(15059,
            "sister could not communicate"), SVRDOWN(15060, "req rejected -server shutting down"),
    CKPSHORT(15061, "not all tasks could checkpoint"), UNKNODE(15062,
            "Named node is not in the list"), UNKNODEATR(15063, "node-attribute not recognized"),
    NONODES(15064, "Server has no node list"), NODENBIG(15065, "Node name is too big"), NODEEXIST(
            15066, "Node name already exists"), BADNDATVAL(15067, "Bad node-attribute value"),
    MUTUALEX(15068, "State values are mutually exclusive"), GMODERR(15069,
            "Error(s) during global modification of nodes"), NORELYMOM(15070,
            "could not contact Mom"), NOTSNODE(15071, "no time-shared nodes"), RMUNKNOWN(15201,
            "resource unknown"), RMBADPARAM(15202, "parameter could not be used"), RMNOPARAM(15203,
            "a parameter needed did not exist"),
    RMEXIST(15204, "something specified didn't exist"), RMSYSTEM(15205, "a system error occured"),
    RMPART(15206, "only part of reservation made");

    private final int code;
    private final String description;

    private static final Map<Integer, PBSErrorCode> map = new HashMap<Integer, PBSErrorCode>();
    static {
        for (PBSErrorCode c : PBSErrorCode.values()) {
            map.put(c.code, c);
        }
    }

    public static PBSErrorCode getErrorCode(int code) {
        return map.get(code);
    }

    PBSErrorCode(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getErrorCode() {
        return code;
    }

    public String toString() {
        return description + " (" + code + ")";
    }

}
