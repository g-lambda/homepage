/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command;

import java.util.Calendar;

import jp.aist.gtrc.plus.command.util.PlusReserveCommand;
import jp.aist.gtrc.plus.command.util.PlusReserveModifyOptions;
import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveRequest;
import jp.aist.gtrc.plus.reserve.ReserveServer;
import jp.aist.gtrc.plus.reserve.ReserveStatus;

public class PlusReserveModify extends PlusReserveCommand {

    /*
     * To Modify Reserve: java PlusReserveModify -r rsvId {-s startTime} {-e
     * endTime} {-n nodeNum} java PlusReserveModify -r rsvId {-s startTime} {-d
     * duration} {-n nodeNum}
     * 
     * specified reserve option will be changed
     * 
     * To Show command help: java PlusReserveModify -h
     * 
     * see PlusReserveOptions for time&date format
     */
    public static void main(String[] args) {

        ReserveServer server = null;
        PlusReserveModifyOptions options = new PlusReserveModifyOptions("plus_modify");
        ReserveId rsvId = null;
        int newNodeNum = 0;
        Calendar newStart = null, newEnd = null;
        String[] newUsers = null;

        try {
            options.parse(args);

            rsvId = options.getReserveId();
            if (rsvId == null)
                throw new ReserveException("Invalid or Unspecified Reserve id");
            newNodeNum = options.getNodeNum();
            newStart = options.getStartTime();
            newEnd = options.getEndTime();
            newUsers = options.getUsers();
        } catch (Exception e) {
            showCommandHelp(options, e);
            System.exit(1);
        }

        try {
            server = getReserveServer(options);
            // Get current reserve status of rsvId, and check owner
            ReserveStatus status = server.getStatus(rsvId);
            String owner = status.getOwner();
            if (getMyname().equals(owner) == false)
                throw new ReserveException("You are not owner of this reserve");

            // Change parameters if specified, remain original if not.
            int nodeNum = (newNodeNum > 0) ? newNodeNum : status.getNodeNum();
            Calendar start = (newStart != null) ? newStart : status.getStartTime();
            Calendar end = (newEnd != null) ? newEnd : status.getEndTime();
            String[] users = (newUsers != null) ? newUsers : status.getUsers();

            // submit new reserve request
            ReserveRequest request = new ReserveRequest(owner, users, nodeNum, start, end);
            request.setOptions(status.getOptions());
            server.modify(rsvId, request);
            if (options.isTransaction() == false) {
                server.commit(rsvId);
            }
            System.out.println("Modify reservation succeeded");
            if (options.isTransaction()) {
                System.out.println("You need plus_commit/plus_abort");
            }
        } catch (Exception e) {
            showException(e);
            System.exit(1);
        }

    }

}
