/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.dummy;

import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveInfo;
import jp.aist.gtrc.plus.reserve.ReserveManager;
import jp.aist.gtrc.plus.scheduler.SchedulerOptions;
import jp.aist.gtrc.plus.scheduler.node.NodeManager;
import jp.aist.gtrc.plus.scheduler.status.MainServer;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;

public class DummyReserveManager extends ReserveManager {

    private class CheckExpiredReserve extends TimerTask {

        private final DummyReserveManager rsvMgr;

        CheckExpiredReserve(DummyReserveManager rsvMgr) {
            this.rsvMgr = rsvMgr;
        }

        public void run() {
            rsvMgr.removeExpired();
        }

    }

    private static final SchedulerOptions schedOpt = SchedulerOptions.getInstance();
    private final Timer timer = new Timer();
    private static final int POLLING_INTERVAL_SEC = 5; // [sec]

    private DummyReserveManager() throws ReserveException {
        super(new NodeManager(), null, new DummyReserveRecorder(), null, schedOpt,
                new StatusManager());
        timer.schedule(new CheckExpiredReserve(this), 1000, POLLING_INTERVAL_SEC * 1000);
    }

    public DummyReserveManager(Properties prop) throws SchedulerException {
        this();
        MainServer mainSrv = new DummyMainServer(prop);
        StatusManager statMgr = this.getStatusManager();
        NodeManager nodeMgr = this.getNodeManager();
        statMgr.updateStatus(mainSrv);
        nodeMgr.update(statMgr.getNodes());
    }

    private void removeExpired() {
        for (ReserveInfo rsvInfo : getExpiredReserve()) {
            try {
                removeReserveInfo(rsvInfo, false);
            } catch (ReserveException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void stopServer() throws ReserveException {
        timer.cancel();
    }

}
