/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.reply;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSServerStatus;
import jp.aist.gtrc.plus.scheduler.status.ServerStatus;

public class BatchReplyStatusServer extends BatchReplyStatus<PBSServerStatus> {

    private String serverName = null;

    public BatchReplyStatusServer(BatchReplyHeader header) {

        super(header);

    }

    public ServerStatus getStatus() {

        return getStatus(serverName);

    }

    protected BatchObjectType getObjectType() {

        return BatchObjectType.SERVER;

    }

    protected PBSServerStatus newStatus(String name) {

        assert (serverName == null); // support single server only
        serverName = name;

        return new PBSServerStatus(name);

    }

    protected PBSServerStatus[] emptyArray() {

        return new PBSServerStatus[] {};

    }

}
