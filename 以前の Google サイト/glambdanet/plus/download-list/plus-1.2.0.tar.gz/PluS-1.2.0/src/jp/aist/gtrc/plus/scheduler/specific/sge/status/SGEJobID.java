/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Locale;

import jp.aist.gtrc.plus.scheduler.status.JobID;

public class SGEJobID implements JobID, Comparable<SGEJobID> {

    private final int jobID;
    private final int taskID;

    public SGEJobID(int jobID, int taskID) {

        this.jobID = jobID;
        this.taskID = taskID;

    }

    public String toString() {

        return String.format(Locale.US, "%d.%d", jobID, taskID);

    }

    public int jobID() {

        return jobID;

    }

    public int taskID() {

        return taskID;

    }

    public boolean equals(Object o) {

        if (o instanceof SGEJobID) {
            SGEJobID other = (SGEJobID) o;
            return ((this.jobID == other.jobID) && (this.taskID == other.taskID));
        } else {
            return false;
        }
    }

    public int hashCode() {

        return (jobID << 8) + taskID;

    }

    public int compareTo(SGEJobID o) {

        SGEJobID other = (SGEJobID) o;
        if (this.jobID != other.jobID)
            return this.jobID - other.jobID;
        else
            return this.taskID - other.taskID;

    }

}
