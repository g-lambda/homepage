/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import jp.aist.gtrc.plus.scheduler.node.NodeAllocateRequest;
import jp.aist.gtrc.plus.scheduler.node.NodeInfo;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSJobStatus;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSQueueStatus;
import jp.aist.gtrc.plus.scheduler.status.QueueStatus;
import jp.aist.gtrc.plus.scheduler.status.StatusManager;
import jp.aist.gtrc.plus.scheduler.util.Checker;

public class PBSQueueACLChecker extends Checker<NodeInfo> {

    private final static StatusManager statMgr = StatusManager.getInstance();
    private final NodeAllocateRequest allocReq;

    public PBSQueueACLChecker(NodeAllocateRequest allocReq) {
        this.allocReq = allocReq;
    }

    private boolean checkAclHosts(NodeInfo node, PBSQueueStatus tgtQ) {
        if (tgtQ.isAclHostEnable() == false) {
            for (String okHost : tgtQ.getAclHosts()) {
                if (okHost.equals(node.getName())) {
                    // node is in AclHosts, usable
                    return true;
                }
            }
            return false;
        } else {
            // only restrict submit hosts, not exec hosts.
            return true;
        }
    }

    /*
     * private boolean checkAclUsers(NodeInfo node, PBSQueueStatus tgtQ) { if
     * (tgtQ.isAclUserEnable() == false) { // no user restriction by ACL, every
     * nodes can usable return true; } for (String okUser : tgtQ.getAclUsers())
     * { if (okUser.equals(allocReq.getRequester())) { // user is in AclUsers,
     * usable return true; } } // user is not in AclUsers, not usable return
     * false; }
     */

    private boolean checkNodeByTheQueue(NodeInfo node, PBSQueueStatus tgtQ) {
        if (checkAclHosts(node, tgtQ) == false) {
            return false;
        }
        /*
         * if (checkAclUsers(node, tgtQ) == false) { return false; }
         */
        return true;
    }

    private boolean checkNodeByAllQueues(NodeInfo node) {
        for (QueueStatus q : statMgr.getQueues()) {
            PBSQueueStatus queue = (PBSQueueStatus) q;
            if (checkNodeByTheQueue(node, queue)) {
                return true;
            }
        }
        return false;
    }

    public boolean isOK(NodeInfo node) {
        PBSJobStatus job = (PBSJobStatus) allocReq.getTargetJob();
        if (job != null) {
            PBSQueueStatus tgtQ = (PBSQueueStatus) job.getQueueStatus();
            if (tgtQ != null) {
                return checkNodeByTheQueue(node, tgtQ);
            }
        }
        return checkNodeByAllQueues(node);
    }
}
