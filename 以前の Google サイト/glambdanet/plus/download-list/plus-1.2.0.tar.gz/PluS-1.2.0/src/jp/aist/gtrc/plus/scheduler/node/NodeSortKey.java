/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Comparator;

import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSNodeStatus;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.scheduler.util.SortKey;

public enum NodeSortKey implements SortKey<NodeInfo> {

    NodeName(new Comparator<NodeInfo>() {
        public int compare(NodeInfo arg0, NodeInfo arg1) {
            return arg0.getName().compareTo(arg1.getName());
        }
    }),

    LowestLoadAverage(new Comparator<NodeInfo>() {
        public int compare(NodeInfo arg0, NodeInfo arg1) {
            return (int) (100.0 * (arg0.getStatus().getLoadAverage() - arg1.getStatus()
                    .getLoadAverage()));
        }
    }),

    LongestIdleTime(new Comparator<NodeInfo>() {
        public int compare(NodeInfo arg0, NodeInfo arg1) {
            NodeStatus n0 = arg0.getStatus();
            NodeStatus n1 = arg1.getStatus();
            if ((n0 instanceof PBSNodeStatus) && (n1 instanceof PBSNodeStatus)) {
                PBSNodeStatus p0 = (PBSNodeStatus) n0;
                PBSNodeStatus p1 = (PBSNodeStatus) n1;
                return p0.getIdleTime() - p1.getIdleTime();
            } else {
                return 0;
            }
        }
    }),

    LargestPhysicalMemory(new Comparator<NodeInfo>() {
        public int compare(NodeInfo arg0, NodeInfo arg1) {
            return (int) (arg1.getStatus().getPhysicalMemory() - arg0.getStatus()
                    .getPhysicalMemory());
        }
    });

    private final Comparator<NodeInfo> comp;

    NodeSortKey(Comparator<NodeInfo> comp) {

        this.comp = comp;

    }

    public Comparator<NodeInfo> getComparator() {

        return comp;

    }

}
