#!/bin/sh

# Copyright 2003, ..., 2010 Grid Technology Research Center,
# National Institute of Advanced Industrial Science and Technology.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# usage exmaple:
#  ./sge_rsvq_mod_users.sh R123 userA{,userB,...}
#

if [ "$#" -ne 2 ]; then
  echo 'usage: sge_rsvq_mod_users.sh RSVID USERLIST'
  exit 1
fi

RSVID=$1
NEW_USERLIST=$2

SGE_QNAME="${RSVID}"
SGE_USERLIST="${SGE_QNAME}_users"

#
# Modify userset
#
SGE_USERSFILE="/tmp/sgersv_${SGE_USRLIST}"
echo "name    ${SGE_USERLIST}
	type    ACL
	fshare  0
	oticket 0
	entries ${NEW_USERLIST}" > ${SGE_USERSFILE}
qconf -Mu ${SGE_USERSFILE}
EXIT_CODE=$?
rm -f ${SGE_USERSFILE}

exit ${EXIT_CODE}
