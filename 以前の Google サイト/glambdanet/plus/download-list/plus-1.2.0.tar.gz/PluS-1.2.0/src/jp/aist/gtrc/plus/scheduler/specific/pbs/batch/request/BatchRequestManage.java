/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.batch.request;

import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchObjectType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.BatchOperationType;
import jp.aist.gtrc.plus.scheduler.specific.pbs.batch.DISEncoder;

public class BatchRequestManage extends BatchRequest {

    public enum ManagerCommandType {
        CREATE(0), DELETE(1), SET(2), UNSET(3), LIST(4), PRINT(5), ACTIVE(6);

        private final int value;

        ManagerCommandType(int value) {
            this.value = value;
        }

        int value() {
            return value;
        }
    }

    private final ManagerCommandType cmd;
    private final BatchObjectType objType;
    private final String objName;
    private final String attr;
    private final String rsc;
    private final String value;
    private final BatchOperationType opeType;

    public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType, String objName,
            String attr, String rsc, String value, BatchOperationType opeType) {

        super();
        this.cmd = cmd;
        this.objType = objType;
        this.objName = objName;
        this.attr = attr;
        this.rsc = rsc;
        this.value = value;
        this.opeType = opeType;

    }

    public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType, String objName,
            String attr, String value) {

        this(cmd, objType, objName, attr, null, value, null);

    }

    public BatchRequestManage(ManagerCommandType cmd, BatchObjectType objType, String objName) {

        this(cmd, objType, objName, null, null, null, null);

    }

    protected void encodeBody(DISEncoder encoder) {

        encoder.putInt(cmd.value());
        encoder.putInt(objType.value());
        encoder.putString(objName);
        encoder.putAttrRscValue(attr, rsc, value);
        if (opeType != null) {
            encoder.putInt(opeType.value());
        }

    }

    public BatchRequestType getRequestType() {

        return BatchRequestType.Manager;

    }

}
