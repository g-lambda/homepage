/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.pbs.util;

import java.net.Socket;

import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.ScheduleOrder;
import jp.aist.gtrc.plus.scheduler.specific.pbs.status.PBSMainServer;

public class PBSScheduleOrder extends ScheduleOrder {

    private final PBSSchedulerCommandType cmd;

    public PBSScheduleOrder(PBSSchedulerCommandType cmd, Socket socket) {

        super(new PBSMainServer(socket));
        this.cmd = cmd;

    }

    public PBSScheduleOrder(ReserveId rsvId, Socket socket) {

        super(new PBSMainServer(socket), rsvId);
        this.cmd = PBSSchedulerCommandType.RESERVE;

    }

    public PBSSchedulerCommandType getSchedulerCommand() {

        return cmd;

    }

    public boolean equals(Object o) {

        if (o instanceof PBSScheduleOrder) {
            PBSScheduleOrder order = (PBSScheduleOrder) o;
            return order.getSchedulerCommand() == this.getSchedulerCommand();
        } else {
            return false;
        }

    }

    public int hashCode() {

        return cmd.hashCode();

    }

    public boolean toBeQuit() {

        return (getSchedulerCommand() == PBSSchedulerCommandType.QUIT);

    }

}
