/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.condor;

import jp.aist.gtrc.plus.scheduler.status.JobID;

public class CondorJobID implements JobID {

    private final int cluster;
    private final int proc;
    private final String jobID;

    public CondorJobID(int cluster, int proc) {
        this.cluster = cluster;
        this.proc = proc;
        this.jobID = cluster + "." + proc;
    }

    public String toString() {
        return jobID;
    }

    public int getCluster() {
        return cluster;
    }

    public int getProc() {
        return proc;
    }

    public boolean equals(Object o) {
        if (!(o instanceof CondorJobID))
            return false;
        return jobID.equals(o.toString());
    }

    @Override
    public int hashCode() {
        return jobID.hashCode();
    }
}
