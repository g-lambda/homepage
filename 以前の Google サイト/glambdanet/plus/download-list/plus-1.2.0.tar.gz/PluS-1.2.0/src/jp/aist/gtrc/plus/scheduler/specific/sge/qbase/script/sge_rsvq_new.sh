#!/bin/sh

# Copyright 2003, ..., 2010 Grid Technology Research Center,
# National Institute of Advanced Industrial Science and Technology.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# usage exmaple:
#  ./sge_rsvq_new.sh R123 1 userA,userB make,mpich true
#
# NOTE:
#	RSVID must be started with 'R'
#	SLOTPERNODE must be one integer vaulue (ex: 1 or 2) or format below:
#		"1,[host0.example.com=2],[host1.exmaple.com=2]"
#	USERLIST and PE must be separated by ","
#	

if [ "$#" -ne 5 ]; then
	echo 'usage: sge_rsvq_new.sh RSVID SLOTPERNODE USERLIST PE PREPOSTQ'
	exit 1
fi

RSVID=$1
SLOTPERNODE=$2
USERLIST=$3
PE=$4
PREPOSTQ=$5

SGE_QNAME="${RSVID}"
SGE_HOSTLIST="@${SGE_QNAME}_hosts"
SGE_USERLIST="${SGE_QNAME}_users"
SGE_SLOTS="${SLOTPERNODE}"
SGE_PELIST=${PE}
SGE_MAKE_PREPOSTQ=${PREPOSTQ}

#
# Create userset
#
qconf -au ${USERLIST} ${SGE_USERLIST}
if [ "$?" -ne 0 ]; then
  exit 1
fi

#
# Create hostgroup
#	NOTE: we assume already created by sge_rsvq_reg_nodes.sh


#
# Create (or modify if exists) suspended queue function
#	$1: qname
#	$2: hostlist
#	$3: pe_list
#	$4: slots
#	$5: user_lists
create_suspended_queue() {
	if [ "$#" -ne 5 ]; then
		exit 1
	fi
	
	arg_qname=$1
	arg_hostlist=$2
	arg_pe_list=$3
	arg_slots=$4
	arg_user_lists=$5
	
	tmp_queuefile="/tmp/sgersv_${arg_qname}"
	echo "qname			 ${arg_qname}
		hostlist              ${arg_hostlist}
		seq_no                0
		load_thresholds       np_load_avg=1.75
		suspend_thresholds    NONE
		nsuspend              1
		suspend_interval      00:05:00
		priority              0
		min_cpu_interval      00:05:00
		processors            UNDEFINED
		qtype                 BATCH INTERACTIVE
		ckpt_list             NONE
		pe_list               ${arg_pe_list}
		rerun                 FALSE
		slots                 ${arg_slots}
		tmpdir                /tmp
		shell                 /bin/csh
		prolog                NONE
		epilog                NONE
		shell_start_mode      posix_compliant
		starter_method        NONE
		suspend_method        NONE
		resume_method         NONE
		terminate_method      NONE
		notify                00:00:60
		owner_list            NONE
		user_lists            ${arg_user_lists}
		xuser_lists           NONE
		subordinate_list      NONE
		complex_values        NONE
		projects              NONE
		xprojects             NONE
		calendar              NONE
		initial_state         default
		s_rt                  INFINITY
		h_rt                  INFINITY
		s_cpu                 INFINITY
		h_cpu                 INFINITY
		s_fsize               INFINITY
		h_fsize               INFINITY
		s_data                INFINITY
		h_data                INFINITY
		s_stack               INFINITY
		h_stack               INFINITY
		s_core                INFINITY
		h_core                INFINITY
		s_rss                 INFINITY
		h_rss                 INFINITY
		s_vmem                INFINITY
		h_vmem                INFINITY
	" > ${tmp_queuefile}

	#
	# Add queue
	#
	qconf -Aq ${tmp_queuefile}
	if [ "$?" -ne 0 ]; then
		#
		# Try Modify queue if failed
		#
		qconf -Mq ${tmp_queuefile}
		if [ "$?" -ne 0 ]; then
			rm -f ${tmp_queuefile}
			exit 1
		fi
	fi
	rm -f ${tmp_queuefile}

	#
	# Suspend queue
	#
	qmod -sq ${arg_qname}
	if [ "$?" -ne 0 ]; then
		exit 1
	fi
}

#
# Create (or modify if exists) reserve queue
#
create_suspended_queue ${SGE_QNAME} ${SGE_HOSTLIST} ${SGE_PELIST} ${SGE_SLOTS} ${SGE_USERLIST}

#
# Create (or modify if exists) pre-post queue if needed
#
if [ "$SGE_MAKE_PREPOSTQ" = "true" ]; then
  create_suspended_queue "${SGE_QNAME}pre"  ${SGE_HOSTLIST} ${SGE_PELIST} ${SGE_SLOTS} ${SGE_USERLIST}
  create_suspended_queue "${SGE_QNAME}post" ${SGE_HOSTLIST} ${SGE_PELIST} ${SGE_SLOTS} ${SGE_USERLIST}
fi
