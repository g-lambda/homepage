/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

import java.util.Collection;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.node.NodeResource;

public abstract class NodeStatusBase implements NodeStatus {

    public abstract String getName();

    public ArchType getArchType() {
        return ArchType.unknown;
    }

    public String getAttribute(String attr) {
        Map<String, String> map = getAttributeMap();
        return (map != null) ? map.get(attr) : null;
    }

    public Map<String, String> getAttributeMap() {
        return null;
    }

    public int getCPUNum() {
        return 1;
    }

    public Collection<JobStatus> getJobs() {
        return null;
    }

    public double getLoadAverage() {
        return 0.0;
    }

    public OSType getOSType() {
        return OSType.Unknown;
    }

    public long getPhysicalMemory() {
        return 128 * 1024 * 1024L; // maybe 128[MB] at least...
    }

    public NodeResource getResource() {
        return new NodeResource(getCPUNum());
    }

    public int getRunningJobNum() {
        return 0;
    }

    public boolean isAlive() {
        return true;
    }

    public boolean isIdle() {
        return true;
    }

}
