/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.dummy;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import jp.aist.gtrc.plus.reserve.*;
import jp.aist.gtrc.plus.scheduler.util.LogUtil;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class DummyReserveManagerTest {

    public static void main(String[] args) {
        try {
            LogUtil.init();

            String propFileName = (args.length > 0) ? args[0] : "conf/dummynodes.properties";
            Properties prop = new Properties();
            prop.load(new FileInputStream(propFileName));
            DummyReserveManager rsvMgr = new DummyReserveManager(prop);
            DummyReserveManager rsvMgr2 = new DummyReserveManager(prop);
            ReserveServer rsvSrv = rsvMgr.getReserveServer();
            ReserveServer rsvSrv2 = rsvMgr2.getReserveServer();

            SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            String owner = "user00";
            String[] users = { owner };
            int nodeNum = 2;
            Calendar start = Calendar.getInstance(), end = Calendar.getInstance();
            start.setTime(sdFormat.parse("2009-11-30T17:00:00"));
            end.setTime(sdFormat.parse("2009-11-30T18:00:00"));
            ReserveRequest req = new ReserveRequest(owner, users, nodeNum, start, end);
            ReserveId rsvId = rsvSrv.reserve(req);
            rsvSrv.commit(rsvId);
            ReserveId rsvId2 = rsvSrv2.reserve(req);
            rsvSrv2.commit(rsvId2);

            ReserveStatus status = rsvSrv.getStatus(rsvId);
            System.out.println(status);
            ReserveStatus status2 = rsvSrv2.getStatus(rsvId2);
            System.out.println(status2);

            if (TextUtil.fromArray(status.getReservedNodeNames(), ",").equals(
                    TextUtil.fromArray(status2.getReservedNodeNames(), ","))) {
                System.out.println("same nodes are reserved because RsvMgr is different. It's OK");
            } else {
                System.err
                        .println("different nodes are reserved dispite of RsvMgr is different. It's NG");
            }

            Thread.sleep(10 * 1000);

            rsvSrv.cancel(rsvId);
            rsvSrv.commit(rsvId);
            System.out.println(rsvId + " of RsvMgr is canceled");
            rsvSrv2.cancel(rsvId2);
            rsvSrv2.commit(rsvId2);
            System.out.println(rsvId2 + " of RsvMgr2 is canceled");

            rsvSrv.stopServer();
            rsvSrv2.stopServer();
            System.out.println("Stop this program");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
