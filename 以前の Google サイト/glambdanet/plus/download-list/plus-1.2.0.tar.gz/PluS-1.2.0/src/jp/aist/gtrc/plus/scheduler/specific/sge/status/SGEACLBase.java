/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.Collection;

import jp.aist.gtrc.plus.scheduler.status.Status;
import jp.aist.gtrc.plus.scheduler.util.CollectionUtil;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

abstract class SGEACLBase<V extends Status> {

    private Collection<V> allows = null;
    private Collection<V> denies = null;

    protected abstract boolean contains(String name, Collection<V> collection);

    protected void setAllowsDenies(Collection<V> allows, Collection<V> denies) {

        assert (this.allows == null);
        assert (this.denies == null);

        this.allows = allows;
        this.denies = denies;

    }

    public boolean isAllowed(String name) {

        if (TextUtil.isEmpty(name)) {
            return true;
        }

        if (CollectionUtil.isEmpty(allows) == false) {
            if (CollectionUtil.isEmpty(denies)) {
                return contains(name, allows);
            } else {
                // return false even if 'name' in both of allows&denies
                if (contains(name, denies))
                    return false;
                return contains(name, allows);
            }
        } else {
            if (CollectionUtil.isEmpty(denies)) {
                // always return true if allows&denies are both empty
                return true;
            } else {
                return (contains(name, denies) == false);
            }
        }

    }

    private String getEntryNames(Collection<V> collection) {

        if (CollectionUtil.isEmpty(collection))
            return "NONE";

        StringBuffer sb = new StringBuffer();
        for (V v : collection) {
            sb.append(v.getName());
            sb.append(' ');
        }
        return sb.toString();

    }

    public String toString() {

        return "allow<" + getEntryNames(allows) + ">, deny<" + getEntryNames(denies) + ">";

    }
}
