/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command.util;

import java.util.Calendar;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class PlusReserveStatusOptions extends PlusCommandOptions {

    private static final String OPT_N_EXPIRED = "-ne";
    private static final String OPT_SORT_BY_NODE = "-n";
    private static final String OPT_USE_XML = "-x";

    private static final int DEFAULT_N_EXPIRED_NUM = 0;
    private static final String DEFAULT_N_EXPIRED_STR = Integer.toString(DEFAULT_N_EXPIRED_NUM);

    public PlusReserveStatusOptions(String appName) {

        super(appName);
        addOption(reserveId(false));
        addOption(owner());
        addOption(startTime(false));
        addOption(endTime(false));

        addOption(OPT_N_EXPIRED, "numShowExpired", "max # of expired reserves to be shown",
                DEFAULT_N_EXPIRED_STR);
        addOption(OPT_SORT_BY_NODE, "show status sorted by node");
        addOption(OPT_USE_XML, "show status in XML");

    }

    public ReserveId getReserveId() throws ReserveException {

        return super.getReserveId();

    }

    public String getOwner() {

        return super.getOwner();

    }

    public Calendar getStartTime() throws ReserveException {

        return super.getStartTime();

    }

    public Calendar getEndTime() throws ReserveException {

        return super.getEndTime();

    }

    public int getNumShowExpired() throws ReserveException {

        String n = getOptionValue(OPT_N_EXPIRED);
        if (TextUtil.isValid(n)) {
            try {
                return Integer.parseInt(n);
            } catch (NumberFormatException e) {
                throw new ReserveException("invalid number: " + n);
            }
        } else {
            return DEFAULT_N_EXPIRED_NUM;
        }

    }

    public boolean isShowByXML() {

        return isOptionSet(OPT_USE_XML);
    }

    public boolean isShowSortedByNode() {

        return isOptionSet(OPT_SORT_BY_NODE);
    }

}
