/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler;

import jp.aist.gtrc.plus.scheduler.sys.SchedulerException;
import jp.aist.gtrc.plus.scheduler.util.LogUtil;
import jp.aist.gtrc.plus.scheduler.util.AppOption.AppOptionException;

public class MainApp {

    public static PluScheduler makeScheduler(SchedulerOptions options) throws Exception {

        String type = options.getTargetSystem();

        if (type.equals("pbs"))
            return new PBSScheduler(options);
        if (type.equals("sge"))
            return new SGEQbaseScheduler(options);
        if (type.equals("sgesched"))
            return new SGESelfScheduler(options);
        if (type.equals("condor"))
            return new CondorQbaseScheduler(options);

        throw new SchedulerException("Unknown scheduler type: " + type);

    }

    public static void main(String[] args) {

        LogUtil.initWithCmdLog();

        SchedulerOptions options = new SchedulerOptions();
        try {
            options.parse(args);
            PluScheduler scheduler = makeScheduler(options);
            scheduler.run();
        } catch (AppOptionException e) {
            if (e.isHelpRequested() == false) {
                System.err.println("Error: " + e.getMessage());
            }
            options.showHelp();
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }

    }

}
