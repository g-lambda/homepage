/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import java.util.HashMap;
import java.util.Map;

public class SGEComplexEntry {

    public enum ValType {

        INT(1), STRING(2), // case sensitve string (use strcmp(3))
        TIME(3), MEMORY(4), BOOL(5), CSTRING(6), // case insensitive string (use
                                                 // strcasecmp(3))
        HOST(7), // host name string
        DOUBLE(8), RESTRING(9); // regular expression

        private final int type;
        private static final Map<Integer, ValType> mapType = new HashMap<Integer, ValType>();
        private static final Map<String, ValType> mapName = new HashMap<String, ValType>();
        static {
            for (ValType v : ValType.values()) {
                mapType.put(v.type, v);
                mapName.put(v.name(), v);
            }
        }

        private ValType(int type) {
            this.type = type;
        }

        public static ValType getValType(int type) {
            return mapType.get(type);
        }

        public static ValType getValType(String name) {
            return mapName.get(name);
        }
    }

    public enum RelationOpe {

        EQ(1, "=="), GE(2, ">="), GT(3, ">"), LT(4, "<"), LE(5, "<="), NE(6, "!=");

        private final int id;
        private final String rel;
        private static Map<Integer, RelationOpe> mapId = new HashMap<Integer, RelationOpe>();
        private static Map<String, RelationOpe> mapRel = new HashMap<String, RelationOpe>();
        static {
            for (RelationOpe r : RelationOpe.values()) {
                mapId.put(r.id, r);
                mapRel.put(r.rel, r);
            }
        }

        private RelationOpe(int id, String rel) {
            this.id = id;
            this.rel = rel;
        }

        public static RelationOpe getRelationOpe(int id) {
            return mapId.get(id);
        }

        public static RelationOpe getRelationOpe(String rel) {
            return mapRel.get(rel);
        }

    }

    private final String name;
    private final String shortcut;
    private final ValType type;
    private final RelationOpe ope;
    private final boolean requestable;
    private final boolean consumable;
    private final String defaultValue;
    private final int urgency;

    SGEComplexEntry(String name, String shortcut, ValType type, RelationOpe ope,
            boolean requestable, boolean consumable, String defaultValue, int urgency) {

        assert (name != null);
        assert (shortcut != null);
        assert (type != null);
        assert (ope != null);

        this.name = name;
        this.shortcut = shortcut;
        this.type = type;
        this.ope = ope;
        this.requestable = requestable;
        this.consumable = consumable;
        this.defaultValue = defaultValue;
        this.urgency = urgency;

    }

    public String getName() {

        return name;

    }

    public String getShortcutName() {

        return shortcut;

    }

    public ValType getValType() {

        return type;

    }

    public RelationOpe getRelationOpe() {

        return ope;

    }

    public boolean isRequestable() {

        return requestable;

    }

    public boolean isConsumable() {

        return consumable;

    }

    public String toString() {

        return name + ":" + shortcut + ":" + getValType().name() + ":" + getRelationOpe()
                + ":isReq=" + Boolean.toString(isRequestable()) + ":isCons="
                + Boolean.toString(isConsumable()) + ":" + defaultValue + ":"
                + Integer.toString(urgency);

    }

}
