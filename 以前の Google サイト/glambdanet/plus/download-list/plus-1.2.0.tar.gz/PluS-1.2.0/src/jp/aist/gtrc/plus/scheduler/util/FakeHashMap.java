/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.util;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.db4o.ObjectContainer;

/*
 * This class is designed as a substitue for java.util.HashMap.
 * db4o cannot handle HashMap correctly (cannot delete each elements).
 */
public abstract class FakeHashMap<K, V> implements Map<K, V>, Serializable {

    private static final long serialVersionUID = 6591646940788708493L;

    private transient HashMap<K, V> transientMap = new HashMap<K, V>();
    private String[][] mapdata;

    private void updateData() {
        if (transientMap != null) {
            mapdata = new String[transientMap.size()][2];
            int i = 0;
            for (Entry<K, V> e : transientMap.entrySet()) {
                K key = e.getKey();
                V value = e.getValue();
                mapdata[i][0] = (key != null) ? key.toString() : null;
                mapdata[i][1] = (value != null) ? value.toString() : null;
                i++;
            }
        } else {
            mapdata = new String[0][2];
        }
    }

    protected abstract K newK(String desc);

    protected abstract V newV(String desc);

    private void restoreData() {
        if ((transientMap == null) && (mapdata != null)) {
            transientMap = new HashMap<K, V>();
            for (int i = 0; i < mapdata.length; i++) {
                transientMap.put(newK(mapdata[i][0]), newV(mapdata[i][1]));
            }
        }
    }

    public void objectOnActivate(ObjectContainer container) {
        restoreData();
    }

    public void clear() {
        if (transientMap != null) {
            transientMap.clear();
        }
        updateData();
    }

    public boolean containsKey(Object key) {
        restoreData();
        return transientMap.containsKey(key);
    }

    public boolean containsValue(Object value) {
        restoreData();
        return transientMap.containsValue(value);
    }

    public Set<java.util.Map.Entry<K, V>> entrySet() {
        restoreData();
        return transientMap.entrySet();
    }

    public V get(Object key) {
        restoreData();
        return transientMap.get(key);
    }

    public boolean isEmpty() {
        restoreData();
        return transientMap.isEmpty();
    }

    public Set<K> keySet() {
        restoreData();
        return transientMap.keySet();
    }

    public V put(K key, V value) {
        restoreData();
        V v = transientMap.put(key, value);
        updateData();
        return v;
    }

    public void putAll(Map<? extends K, ? extends V> t) {
        restoreData();
        if (t != null) {
            transientMap.putAll(t);
        }
        updateData();
    }

    public V remove(Object key) {
        restoreData();
        V v = transientMap.remove(key);
        updateData();
        return v;
    }

    public int size() {
        restoreData();
        return transientMap.size();
    }

    public Collection<V> values() {
        restoreData();
        return transientMap.values();
    }

    public String toString() {
        restoreData();
        return transientMap.toString();
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + Arrays.hashCode(mapdata);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FakeHashMap<?, ?> other = (FakeHashMap<?, ?>) obj;
        if (!Arrays.equals(mapdata, other.mapdata))
            return false;
        return true;
    }

}
