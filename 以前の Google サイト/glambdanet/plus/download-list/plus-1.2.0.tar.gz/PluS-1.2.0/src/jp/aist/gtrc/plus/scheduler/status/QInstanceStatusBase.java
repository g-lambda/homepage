/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.status;

public class QInstanceStatusBase implements QInstanceStatus {

    private final QueueStatus queue;
    private final String hostname;

    protected QInstanceStatusBase(QueueStatus queue, String hostname) {
        this.queue = queue;
        this.hostname = hostname;
    }

    public static QInstanceStatusBase getInstance(QueueStatus queue, String hostname) {
        return new QInstanceStatusBase(queue, hostname);
    }

    public int getAllSlotNum() {
        return 1;
    }

    public String getHostname() {
        return hostname;
    }

    public String getQname() {
        return queue.getName();
    }

    public int getUsedSlotNum() {
        return 0;
    }

    public boolean isReadyToUse() {
        return true;
    }

    public boolean isSuspended() {
        return false;
    }

    public String getName() {
        return getQname() + '@' + getHostname();
    }

}
