/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.node;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jp.aist.gtrc.plus.scheduler.status.NodeStatus;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveInfo;

public class NodeInfo {

    private PhysicalNodeInfo phyNode;
    private final Map<ReserveId, ReserveInfo> rsvInfos = new HashMap<ReserveId, ReserveInfo>();

    public NodeInfo(NodeStatus status) {

        this.phyNode = new PhysicalNodeInfo(status);

    }

    void changePhysicalNodeInfo(PhysicalNodeInfo pNode) {

        this.phyNode = pNode;

    }

    public PhysicalNodeInfo getPhysicalNodeInfo() {

        return phyNode;

    }

    public void update(NodeStatus status) {

        phyNode.update(status);

    }

    public NodeStatus getStatus() {

        return phyNode.getStatus();

    }

    public NodeResource getResource() {

        return phyNode.getResource();

    }

    public String getName() {

        return getStatus().getName();

    }

    public void setLaunceProcessNum(int procNum) {

        phyNode.setLaunceProcessNum(procNum);

    }

    public int getLaunchProcessNum() {

        return phyNode.getLaunchProcessNum();

    }

    public void addReserveInfo(ReserveInfo info) {

        /*
         * NOTE: ReserveId#equals() returns true if id are same even if
         * ReserveId objects are different. Map#containsKey() uses
         * ReserveId#equals() for check, so it works well.
         */
        ReserveId id = info.getReserveId();
        if (rsvInfos.containsKey(id) == false)
            rsvInfos.put(id, info);
        else
            assert (false);

    }

    public void removeReserveInfo(ReserveInfo info) {

        ReserveId id = info.getReserveId();
        if (rsvInfos.containsKey(id) == true) {
            rsvInfos.remove(id);
        }

    }

    public boolean isReservedNow() {

        Calendar now = Calendar.getInstance();
        return (isFree(now, now) == false);

    }

    public boolean isFree(Calendar start, Calendar end) {

        for (ReserveInfo info : rsvInfos.values()) {
            if (info.isOverlap(start, end))
                return false;
        }

        return true;

    }

    public String toString() {

        StringBuffer sb = new StringBuffer();
        if (phyNode != null) {
            sb.append("node=[");
            sb.append(phyNode.toString());
            sb.append("], ");
        }
        sb.append("reserve=");
        for (ReserveInfo r : rsvInfos.values()) {
            sb.append(r.toString());
            sb.append("\n");
        }
        return sb.toString();

    }

}
