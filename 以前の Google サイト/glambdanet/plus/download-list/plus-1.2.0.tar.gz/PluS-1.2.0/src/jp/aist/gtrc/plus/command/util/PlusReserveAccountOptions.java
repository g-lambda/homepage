/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command.util;

import java.util.Calendar;

import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.scheduler.SchedulerOptions;
import jp.aist.gtrc.plus.scheduler.util.TimeUtil;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class PlusReserveAccountOptions extends PlusCommandOptions {

    private boolean isCalced = false;
    private Calendar start = null, end = null;

    private static final String OPT_ACT_DAYS = "-d";
    private static final String OPT_ACT_LIST = "-l";
    private static final String OPT_ACT_START = "-S";
    private static final String OPT_ACT_NODE = "-n";
    private static final String OPT_ACT_LOGFILE = "-f";

    public PlusReserveAccountOptions(String appName) {

        super(appName);
        addOption(OPT_OF_OWNER, "owner", "reserve owner to show (userA)");
        addOption(OPT_RSV_START, "startTime", "show start time(date), " + SUPPORT_TIME_NOTATION
                + " or [yyyy-]MM-DD", null);
        addOption(endTime(false));
        addOption(OPT_ACT_DAYS, "days", "show duration in days", null);

        addOption(OPT_ACT_LOGFILE, "logfile", "reserve log file path",
                SchedulerOptions.DEFAULT_SCHED_RSVPATH);
        addOption(OPT_ACT_LIST, "show reserves per reserves");
        addOption(OPT_ACT_START, "show reserves per reserve start date");
        addOption(OPT_ACT_NODE, "rsvNodes", "reserve nodes to show (hostA[,hostB,...])");

    }

    public String getOwner() {

        return super.getOwner();

    }

    private void setStartEnd(Calendar s, Calendar e) {

        this.start = s;
        this.end = e;

    }

    protected Calendar parseTime(String time) {

        Calendar c = super.parseTime(time);
        if (c == null) {
            c = TimeUtil.makeCalendarFromDate(time);
        }
        return c;

    }

    private void calcStartEnd() throws ReserveException {

        Calendar s = super.getStartTime();
        Calendar e = super.getEndTime();
        String d = getOptionValue(OPT_ACT_DAYS);
        int duration; // [sec]
        if (TextUtil.isValid(d)) {
            try {
                duration = (int) (24 * 3600 * Double.parseDouble(d));
            } catch (NumberFormatException e1) {
                throw new ReserveException("days must be number");
            }
        } else {
            duration = 0;
        }

        /*
         * s e d --------------------------- n n n all available period, start
         * == end == null n n D [now - D, now] n E n [null, E], all available
         * before E n E D [E - D, E] S n n [S, now] S n D [S, S + D] S E n [S,
         * E] S E D ERROR
         */

        Calendar now = Calendar.getInstance();
        if (s == null) {
            if (e == null) {
                if (d == null) {
                    // all available period
                    // start will be set as PluS logging start time
                    setStartEnd(null, null);
                } else {
                    // [now - D, now]
                    s = (Calendar) now.clone();
                    s.add(Calendar.SECOND, -duration);
                    setStartEnd(s, now);
                }
            } else {
                if (d == null) {
                    // [null, E], all available before E
                    setStartEnd(null, e);
                } else {
                    // [E - D, E]
                    s = (Calendar) e.clone();
                    s.add(Calendar.SECOND, -duration);
                    setStartEnd(s, e);
                }
            }
        } else {
            if (e == null) {
                if (d == null) {
                    // [S, now]
                    setStartEnd(s, now);
                } else {
                    // [S, S + D]
                    e = (Calendar) s.clone();
                    e.add(Calendar.SECOND, duration);
                    setStartEnd(s, e);
                }
            } else {
                if (d == null) {
                    // [S, E]
                    setStartEnd(s, e);
                } else {
                    throw new ReserveException("cannot set endTime and days at same time");
                }
            }
        }

        isCalced = true;

    }

    public Calendar getStartTime() throws ReserveException {

        if (isCalced == false) {
            calcStartEnd();
        }
        return start; // may be null

    }

    public void setStartTime(Calendar newStart) {

        if (isCalced && (this.start == null)) {
            this.start = newStart;
        }

    }

    public void setEndTime(Calendar newEnd) {

        if (isCalced && (this.end == null)) {
            this.end = newEnd;
        }

    }

    public Calendar getEndTime() throws ReserveException {

        if (isCalced == false) {
            calcStartEnd();
        }
        return end; // always not null

    }

    public String getLogFilePath() {

        return getOptionValue(OPT_ACT_LOGFILE);

    }

    public boolean toShowList() {

        return isOptionSet(OPT_ACT_LIST);

    }

    public boolean toShowPerStartDate() {

        return isOptionSet(OPT_ACT_START);

    }

    public boolean toShowPerNode() {

        return isOptionSet(OPT_ACT_NODE);

    }

    public String[] getReservedNodes() {

        String s = getOptionValue(OPT_ACT_NODE);
        return TextUtil.isEmpty(s) ? null : s.split(",");

    }

}
