/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.reserve;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Locale;

import jp.aist.gtrc.plus.scheduler.node.ResourceOption;
import jp.aist.gtrc.plus.scheduler.util.CollectionUtil;
import jp.aist.gtrc.plus.scheduler.util.TextUtil;

public class ReserveRequest implements Serializable {

    private static final long serialVersionUID = 5798440468207583306L;

    private String owner;
    private String[] users;
    private int nodeNum;
    private Calendar startTime;
    private Calendar endTime;
    private ResourceOption opts;

    private void checkValidReserveRequest(String owner, String[] users, int nodeNum,
            Calendar startTime, Calendar endTime) throws ReserveException {

        if (TextUtil.isEmpty(owner))
            throw new ReserveException("Invalid Reserve owner");

        if (CollectionUtil.isEmpty(users))
            throw new ReserveException("Invalid Reserve users");
        for (String name : users) {
            if (TextUtil.isEmpty(name))
                throw new ReserveException("Invalid Reserve user name");
        }

        if (nodeNum <= 0)
            throw new ReserveException("Invalid number of Node");

        if (startTime == null)
            throw new ReserveException("missing startTime");
        if (endTime == null)
            throw new ReserveException("missing endTime");
        if (startTime.before(endTime) == false)
            throw new ReserveException("startTime must be before endTime");

    }

    private void init(String owner, String[] users, int nodeNum, Calendar startTime,
            Calendar endTime) throws ReserveException {

        checkValidReserveRequest(owner, users, nodeNum, startTime, endTime);

        this.owner = owner;
        this.users = users;
        this.nodeNum = nodeNum;
        this.startTime = startTime;
        this.endTime = endTime;
        this.opts = new ResourceOption();

    }

    protected final void modifyRequest(ReserveRequest req) throws ReserveException {

        init(req.getOwner(), req.getUsers(), req.getNodeNum(), req.getStartTime(), req.getEndTime());

        opts.reloadOptions(req.getOptions());

    }

    public ReserveRequest(String owner, String[] users, int nodeNum, Calendar startTime,
            Calendar endTime) throws ReserveException {

        init(owner, users, nodeNum, startTime, endTime);

    }

    public ReserveRequest(ReserveRequest req) throws ReserveException {

        modifyRequest(req);

    }

    public String getOwner() {
        return owner;
    }

    public String[] getUsers() {
        return TextUtil.cloneStringArray(users);
    }

    public int getNodeNum() {
        return nodeNum;
    }

    public Calendar getStartTime() {
        return startTime;
    }

    public Calendar getEndTime() {
        return endTime;
    }

    public ResourceOption getOptions() {
        return opts;
    }

    public void setOptions(ResourceOption newOpts) {
        opts.reloadOptions(newOpts);
    }

    public String toString() {

        return "from " + String.format(Locale.US, "%tc", startTime) + " to "
                + String.format(Locale.US, "%tc", endTime) + " by " + owner + " for "
                + TextUtil.fromArray(getUsers(), " ") + " of " + nodeNum + "nodes "
                + opts.toString();

    }

    public boolean equals(Object o) {

        if (o instanceof ReserveRequest) {
            ReserveRequest other = (ReserveRequest) o;
            if (this.owner.equals(other.owner) == false)
                return false;
            if (this.nodeNum != other.nodeNum)
                return false;
            if (this.startTime.equals(other.startTime) == false)
                return false;
            if (this.endTime.equals(other.endTime) == false)
                return false;
            if (this.opts.equals(other.opts) == false)
                return false;
            return true;
        } else {
            assert (false);
            return false;
        }

    }

    public int hashCode() {
        return toString().hashCode();
    }

}
