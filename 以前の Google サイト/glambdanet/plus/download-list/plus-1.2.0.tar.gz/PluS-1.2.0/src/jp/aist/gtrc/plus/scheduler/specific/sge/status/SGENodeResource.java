/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.scheduler.specific.sge.status;

import jp.aist.gtrc.plus.scheduler.node.NodeResource;
import jp.aist.gtrc.plus.scheduler.status.NodeStatus;

public final class SGENodeResource extends NodeResource {

    private static final long serialVersionUID = 315815335717056232L;

    private SGENodeResource(NodeStatus status) {

        super(status);

        /*
         * NOTE: use below line to enable "plus_reserve .. -l hostname=xxx". BUT
         * it can specify one hostname only, actually not useful... On SGE
         * 6.0u8, qsub with "-pe" and "-l hostname" isn't usable.
         */
        /*
         * addResourceOption("hostname", status.getName());
         */

    }

    public static SGENodeResource getInstance(SGENodeStatus status) {

        SGENodeResource rsc = new SGENodeResource((NodeStatus) status);
        return rsc;

    }

    protected String getCanonicalResourceName(String name) {

        /*
         * On SGE, name maybe canonical name or shortcut name. canonical
         * example: "arch", "free_mem" etc shortcut example: "a", "fm" etc
         */
        SGEComplexEntry entry = SGEComplex.getComplex(name);
        return (entry != null) ? entry.getName() : name;

    }

    protected boolean isResourceMatch(String rscName, String reqValue, String myValue) {

        return SGEComplex.isResourceMatch(rscName, reqValue, myValue);

    }

}
