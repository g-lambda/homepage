/************************************************************************
Copyright 2003, ..., 2010 Grid Technology Research Center,
National Institute of Advanced Industrial Science and Technology.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
************************************************************************/

package jp.aist.gtrc.plus.command;

import java.util.Calendar;

import jp.aist.gtrc.plus.command.util.PlusReserveCommand;
import jp.aist.gtrc.plus.command.util.PlusReserveOptions;
import jp.aist.gtrc.plus.reserve.ReserveException;
import jp.aist.gtrc.plus.reserve.ReserveId;
import jp.aist.gtrc.plus.reserve.ReserveRequest;
import jp.aist.gtrc.plus.reserve.ReserveServer;

public class PlusReserve extends PlusReserveCommand {

    private static ReserveRequest makeRequest(PlusReserveOptions options) throws ReserveException {

        String owner = getMyname();
        String[] users = options.getUsers();
        int nodeNum = options.getNodeNum();
        Calendar start = options.getStartTime();
        Calendar end = options.getEndTime();
        int duration = options.getDuration();
        if (end == null) {
            if (duration != PlusReserveOptions.NO_DURATION) {
                end = (Calendar) start.clone();
                end.add(Calendar.SECOND, duration);
            } else {
                throw new ReserveException("must specify endTime or duration");
            }
        } else {
            if (duration != PlusReserveOptions.NO_DURATION) {
                throw new ReserveException("cannot specify both of endTime and duration");
            }
        }
        Calendar now = Calendar.getInstance();
        if (end.before(now) == true) {
            throw new ReserveException("Reserve period has already passed");
        }

        ReserveRequest req = new ReserveRequest(owner, users, nodeNum, start, end);
        req.setOptions(options.getResourceOption());

        return req;

    }

    /*
     * To Reserve: java PlusReserve -s startTime -e endTime -n nodeNum {-x} java
     * PlusReserve -s startTime -d duration -n nodeNum {-x}
     * 
     * use endTime if both endTime and duration are specified
     * 
     * To Show command help: java PlusReserve -h
     * 
     * see PlusReserveOptions for time&date format
     */
    public static void main(String[] args) {

        ReserveServer server = null;
        PlusReserveOptions options = new PlusReserveOptions("plus_reserve");
        ReserveRequest request = null;

        try {
            options.parse(args);
            request = makeRequest(options);
        } catch (Exception e) {
            showCommandHelp(options, e);
            System.exit(1);
        }

        try {
            server = getReserveServer(options);
            ReserveId id = server.reserve(request);
            if (options.isTransaction() == false) {
                server.commit(id);
            }
            if (options.isShowSimple() == false) {
                System.out.println("Reserve succeeded: reserve id is " + id);
                if (options.isTransaction()) {
                    System.out.println("You need plus_commit/plus_abort");
                }
            } else {
                // without message & return.
                // Not XML format, only id.
                System.out.print(id.toString());
            }
        } catch (Exception e) {
            showException(e);
            System.exit(1);
        }

    }

}
